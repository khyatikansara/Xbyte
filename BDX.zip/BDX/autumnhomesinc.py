# -*- coding: utf-8 -*-
import hashlib
import re
import requests
import scrapy
from scrapy.http import HtmlResponse
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class AutumnhomesincSpider(scrapy.Spider):
    name = 'autumnhomesinc'
    allowed_domains = []
    start_urls = ['https://autumnhomesinc.com/']
    builderNumber = "946460952306748218242355875340"


    def parse(self, response):
        try:
            img =  response.xpath('//div[@class="mk-section-image slide"]/@style').extract()
            im1 = img.split('background-image: url(')
            im = im1[-1]
            im = im.replace(');', '').strip()
        except Exception as e:
            im = ''


                    #  Fake Community
        try:
            item2 = BdxCrawlingItem_subdivision()
            item2['sub_Status'] = "Active"
            item2['SubdivisionName'] = 'CUSTOM HOME BUILDING'
            item2['SubdivisionNumber'] = self.builderNumber
            item2['BuilderNumber'] = self.builderNumber
            item2['BuildOnYourLot'] = 0
            item2['OutOfCommunity'] = 1
            item2['Street1'] = '1015 Shimer Court'
            item2['City'] = 'Naperville'
            item2['State'] = 'IL'
            item2['ZIP'] = '60565'
            item2['AreaCode'] = '630'
            item2['Prefix'] = '933'
            item2['Suffix'] =  '6220'
            item2['Extension'] = ""
            item2['Email'] = 'Sales@AutumnHomesInc.com'
            item2['SubDescription'] = 'Autumn Homes, Builders of innovative custom homes, builds on decades of experience to provide our clients with not only the highest quality home, but also a great home building experience. We specialize in forming a partnership with our clients to bring their vision to reality. Our refined process, the diligence of our people and the dedication to our product sets us apart from the rest. Having served Naperville and the surrounding areas we are proud to have completed over 400 custom Homes. Contact Autumn for your next custom home build to see firsthand why our customers have made Autumn Homes their builder of choice.'
            item2['SubImage'] = im
            item2['SubWebsite'] = 'https://autumnhomesinc.com/'
            item2['AmenityType'] =""
            yield item2
        except Exception as e:
            print(e)


                 #  Fake Plans
        try:
            unique = str("Plan Unknown") + str(self.builderNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            item = BdxCrawlingItem_Plan()
            item['unique_number'] = unique_number
            item['Type'] = "SingleFamily"
            item['PlanNumber'] = "Plan Unknown"
            item['SubdivisionNumber'] = self.builderNumber
            item['PlanName'] = "Plan Unknown"
            item['PlanNotAvailable'] = 1
            item['PlanTypeName'] = "Single Family"
            item['BasePrice'] = 0
            item['BaseSqft'] = 0
            item['Baths'] = 0
            item['HalfBaths'] = 0
            item['Bedrooms'] = 0
            item['Garage'] = 0
            item['Description'] = ""
            item['ElevationImage'] = ""
            item['PlanWebsite'] = ""
            yield item
        except Exception as e:
            print(e)

        response = requests.get(url= 'https://www.autumnhomesinc.com/current-offerings/')
        resp3 = HtmlResponse(url=response.url, body=response.content)


            # take all home name
        all_names = resp3.xpath('//h3[@class="mk-fancy-title  simple-style  color-single"]//text()').extract()
        perfect_names = []
        for x in all_names:
            if len(x) >= 4:
                perfect_names.append(x)


        take_imgs  = resp3.xpath('//div[@class="vc_col-sm-6 wpb_column column_container  _ height-full"][1]')
        print(len(take_imgs))

        take_description = resp3.xpath('//div[@class="vc_col-sm-6 wpb_column column_container  _ height-full"][2]//div[@class="mk-text-block   "]')
        print(len(take_description))

        take_all_bath_bath_badinfo = resp3.xpath('//div[@class="mk-list-styles  mk-align-left ah-vt-specs clear"]//ul')




        print(len(take_all_bath_bath_badinfo))

        if len(perfect_names) == len(take_imgs)  == len(take_description) == len(take_all_bath_bath_badinfo):

            for i in range(0,len(take_imgs)):
                SpecStreet1 = perfect_names[i]
                SpecStreet1 = SpecStreet1.strip()



                img_1 = take_imgs[i].xpath('.//article//a/@href').extract()
                # print("total imgs ",img_1)

                if img_1 != []:
                    if len(img_1) >1 :
                        SpecElevationImage = '|'.join(img_1)
                    else:
                        SpecElevationImage  = ''.join(SpecElevationImage)
                else:
                    SpecElevationImage = ''


                take_bath__price = take_all_bath_bath_badinfo[i].xpath('./li//text()').extract()
                filter_info = []
                for x in take_bath__price:
                    if len(x) >=3:
                        filter_info.append(x)
                    else:
                        pass


                for finding1 in filter_info:

                    if "square feet" in finding1 or "Square Feet" in finding1:
                        SpecSqft = finding1
                        try:
                            SpecSqft = re.findall(r"(\d+)", SpecSqft)[0]
                        except Exception as e:
                            SpecSqft = 0

                    if "Car Garage" in finding1:
                        SpecGarage = finding1
                        try:
                            SpecGarage = re.findall(r"(\d+)", SpecGarage)[0]
                        except Exception as e:
                            SpecGarage = 0


                    if "Bedrooms" in finding1:
                        SpecBedrooms = finding1
                        try:
                            SpecBedrooms = re.findall(r"(\d+)", SpecBedrooms)[0]
                        except Exception as e:
                            SpecBedrooms = 0


                    if "Price" in finding1 or "pricing" in finding1 or "price" in finding1:
                        SpecPrice = finding1.replace('Price $','').replace(',','')
                        try:
                            SpecPrice = re.findall(r"(\d+)", SpecPrice)[0]
                        except Exception as e:
                            print(e)

                    if "Bathrooms" in finding1:
                        SpecBaths = finding1
                        try:
                            tmp = re.findall(r"(\d+)", SpecBaths)
                            SpecBaths = tmp[0]
                            if len(tmp) > 1:
                                SpecHalfBaths = 1
                            else:
                                SpecHalfBaths = 0
                        except Exception as e:
                            SpecBaths = 0
                            SpecHalfBaths = 0

                print(SpecPrice)
                SpecCity = 'St Naperville'
                SpecState = 'IL'
                SpecZIP = '60540'
                unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % SpecNumber, "wb")
                f.write(resp3.body)
                f.close()
                try:
                    SpecDescription = take_description[i].xpath('.//p/text()').extract_first(default='')
                except Exception as e:
                    print(e)

                if SpecStreet1 != '347 Redbud':
                # ______________________HOME_______________________#
                    try:
                        item = BdxCrawlingItem_Spec()
                        item['SpecNumber'] = SpecNumber
                        item['PlanNumber'] = unique_number
                        item['SpecStreet1'] = SpecStreet1
                        item['SpecCity'] = SpecCity
                        item['SpecState'] = SpecState
                        item['SpecZIP'] = SpecZIP
                        item['SpecCountry'] = ''
                        item['SpecPrice'] = SpecPrice
                        item['SpecSqft'] = SpecSqft
                        item['SpecBaths'] = SpecBaths
                        item['SpecHalfBaths'] = SpecHalfBaths
                        item['SpecBedrooms'] = SpecBedrooms
                        item['MasterBedLocation'] = 'Down'
                        item['SpecGarage'] = SpecGarage
                        item['SpecDescription'] = SpecDescription
                        item['SpecElevationImage'] = SpecElevationImage
                        item['SpecWebsite'] = 'https://autumnhomesinc.com/currentofferings/'
                        yield item
                    except Exception as e:
                        print(e)

if __name__=='__main__':
    from scrapy.cmdline import execute
    execute("scrapy crawl autumnhomesinc".split())
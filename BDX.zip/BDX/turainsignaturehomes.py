# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
import requests
from  scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class TurainsignaturehomesSpider(scrapy.Spider):
    name = 'turainsignaturehomes'
    allowed_domains = []
    start_urls = ['http://www.turainsignaturehomes.com/']
    builderNumber = "46280415668583685619797999252"

    def parse(self, response):

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()
        images = []
        img_urls = ['https://www.turainsignaturehomes.com/home-gallery/','https://www.turainsignaturehomes.com/room-gallery/']
        for img_url in img_urls:
            res_i = requests.request("GET", img_url)
            response_i = HtmlResponse(url=res_i.url, body=res_i.content)
            images_list = response_i.xpath('//*[@class="html5galleryimg html5gallery-tn-image"]/@src').extract()
            for img in images_list:
                images.append(img)
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "19123 Centre Rose Blvd."
        item['City'] = "Lutz"
        item['State'] = "FL"
        item['ZIP'] = "33558"
        item['AreaCode'] = "813"
        item['Prefix'] = "714"
        item['Suffix'] = "3538"
        item['Extension'] = ""
        item['Email'] = "Greg@TurainSignatureHomes.com"
        item['SubDescription'] = "With 35 years of experience in new home construction throughout the Tampa Bay community, Greg Turain knows what it takes to build a home with lasting value. At Turain Signature Homes, we start with home designs created around how people want to live today. Open floorplans with flexible, functional spaces. Lots of natural light. Soaring ceilings. Outstanding energy efficiency. Plus all the innovative features and touches you are looking for in your home, from stunning architectural detailing to bonus rooms and home offices. Turain Signature Homes – Tampa’s premiere, custom, new-home builder. Integrity – Quality – Value"
        item['SubImage'] = '|'.join(images)
        item['SubWebsite'] = self.start_urls[0]
        item['AmenityType'] = ''
        yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl turainsignaturehomes".split())


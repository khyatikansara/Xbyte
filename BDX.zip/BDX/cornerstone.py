import hashlib

import requests
import scrapy
import re

from scrapy.http import HtmlResponse

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class CornerstoneHomesSpider(scrapy.Spider):
    name = 'cornerstone'
    allowed_domains = []
    start_urls = ['https://www.cornerstone-homes.com/']

    builderNumber = "184462880739154215314342220199"
    community_names = {}
    plan_names = []
    match_dict = {}
    match_dict_comm = []

    def parse(self, response):
        link = 'https://www.cornerstone-homes.com/' + response.xpath('//div[@class="txt "]/p/span/a/@href').extract_first()
        yield scrapy.Request(url=link, callback=self.community_page)


    def community_page(self, response):
        # div_data = response.xpath('//span[contains(text(),"Single-Family")]/ancestor::div[@class="wsb-element-text"]')
        div_data = response.xpath('//span[contains(text(),"Homesites")]/ancestor::div[@class="wsb-element-text"]')
        community_links = []
        for divs in div_data:
            if not divs.xpath('.//*[contains(text(),"SOLD OUT")]'):
                subdivisonName = divs.xpath('.//span[@style="font-size: 28px;"]/text()').extract_first()
                subdivisonNumber = int(hashlib.md5(bytes(subdivisonName, "utf8")).hexdigest(), 16) % (10 ** 30)
                # self.community_names.append(f"{subdivisonNumber}:{subdivisonName}")
                self.community_names[str(subdivisonNumber)] = subdivisonName
                f = open("html/%s.html" % subdivisonNumber, "wb")
                f.write(response.body)
                f.close()

                try:
                    link = divs.xpath('.//div/h3/strong/a[2]/@href').extract_first()
                    if link == '':
                        link = divs.xpath('.//div/h3/strong/a[3]/@href').extract_first()

                    res = requests.get('https://www.cornerstone-homes.com/' + link)
                    url = res.url
                    community_links.append(url)
                    response1 = HtmlResponse(url='xyz.com', body=res.content)
                    Images = []
                    images = response1.xpath('//div[@class="img"]//img/@src').extract()
                    for img in images:
                        imgs = 'http:'+str(img)
                        Images.append(imgs)
                except Exception as e:
                    print(str(e))

                try:
                    site_text = divs.xpath('.//span[contains(text(),"GPS Address:")]/text()').extract_first().strip()
                    street = re.findall(r'GPS Address: (.*?),', site_text)[0].strip()
                    city = re.findall(r', ([A-z][a-z]+),', site_text)[0].strip()
                    state = re.findall(r', ([A-Z]{2})', site_text)[0].strip()
                    zipcode = re.findall(r'MD (\d+)', site_text)[0].strip()
                except Exception as e:
                    print(str(e))

                item = BdxCrawlingItem_subdivision()
                item['sub_Status'] = "Active"
                item['SubdivisionName'] = subdivisonName
                item['SubdivisionNumber'] = subdivisonNumber
                item['BuilderNumber'] = self.builderNumber
                item['BuildOnYourLot'] = 0
                item['OutOfCommunity'] = 1
                item['Street1'] = street
                item['City'] = city
                item['State'] = state
                item['ZIP'] = zipcode
                item['AreaCode'] = '410'
                item['Prefix'] = '792'
                item['Suffix'] = '2565'
                item['Extension'] = ""
                item['Email'] = "info@cornerstone-homes.com"
                item['SubDescription'] = 'Cornerstone Homes builds homes of the finest quality while providing the homeowner the greatest value for their money. We believe that our experience and attention to detail distinguish us from the rest of the homebuilding industry.'
                item['SubImage'] = '|'.join(Images)
                item['SubWebsite'] = url
                item['AmenityType'] = ''
                yield item

                # for links in community_links:
                yield scrapy.Request(url=url, callback=self.plans_page, meta={'SubdivisionNumber': subdivisonNumber})
            # yield scrapy.Request(url='https://www.cornerstone-homes.com/high-ridge-park.html', callback=self.plans_page, meta={'SubdivisionNumber':subdivisonNumber})
            # break

        # yield scrapy.Request(url='https://www.cornerstone-homes.com/quick-delivery.html', callback=self.homes)


    def plans_page(self, response):
        SubdivisionNumber = response.meta['SubdivisionNumber']
        if not response.xpath('//*[contains(text(),"SOLD OUT!")]'):
            divs = response.xpath('//*[contains(text(),"Bedrooms")]/../../../../*')
            for div in divs:
                try:
                    PlanName = div.xpath('.//span//text()').extract_first(default='').strip()
                    self.plan_names.append(PlanName)
                except Exception as e:
                    print(e)

                PlanNumber = int(hashlib.md5(bytes(response.url+PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                comm_name = self.community_names[str(SubdivisionNumber)]
                data = '|'.join(div.xpath('.//span[@style="font-size:18px;"]/text()').extract())

                try:
                    BasePrice = re.findall(r'\$(\d+,\d+)', data)[0].replace(',','').strip()
                except Exception as e:
                    print(e)
                    BasePrice = '0'
                try:
                    base = re.findall(r'\|(.*?)Square Feet', data)[0]
                    if '|' in base:
                        BaseSqft = base.split('|')[1].replace(',','').strip()
                    else:
                        BaseSqft = [int(i) for i in re.findall(r'(.*?)\|(.*?)Square Feet', data)[0][1].strip().replace('\xa0','').replace(',','').split('-')]
                        BaseSqft = max(BaseSqft)
                except Exception as e:
                    print(e)

                try:
                    base = re.findall(r'\|(.*?)Square Feet', data)[0]
                    if '|' in base:
                        BaseBedrooms = re.findall(r'\|(.*?)Bedroom', data)[0].split('-')[1].strip()
                    else:
                        BaseBedrooms = re.findall(r'(.*?)Bedroom', data)[0].split('-')[1].strip()
                except Exception as e:
                    print(str(e))

                try:
                    base = re.findall(r'\|(.*?)Square Feet', data)[0]
                    if '|' in base:
                        BaseBathrooms = re.findall(',\s(.*?)Bathroom', data)[0].strip()
                    else:
                        BaseBathrooms = re.findall(',\s(.*?)Bathroom', data)[0].split('-')[1].strip()
                    tmp = re.findall(r"(\d+)", BaseBathrooms)
                    BaseBathrooms = tmp[0]
                    if len(tmp) > 1:
                        BaseHalfBaths = 1
                    else:
                        BaseHalfBaths = 0
                except Exception as e:
                    BaseBathrooms = 0
                    BaseHalfBaths = 0

                try:
                    dict = {'Claremont': 'https://nebula.wsimg.com/6f1577b4806deff744027a1643cdfefc?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                            'chartley' : 'https://nebula.wsimg.com/a8e8b74bd1960504ba3cceb90531cf25?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                            'annapolis' : 'https://nebula.wsimg.com/8ecd2e3ba349cd212d1c76faed31aab3?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                            'parker' : 'https://nebula.wsimg.com/a1afa8a3ed9d5b2c2b007171f7f49af8?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                            'aberdeen' : 'https://nebula.wsimg.com/25c586efb14387b4a9cf96aa0b21fd67?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                            'Devonshire' : 'https://nebula.wsimg.com/acf642495004f54a9203b7e7002504db?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1'}
                    for key,value in dict.items():
                        if PlanName == key:
                            SpecElevationImage = value
                except Exception as e:
                    print(e)

                try:
                    unique = str(PlanNumber) + str(PlanName) + str(BasePrice) + str(BaseSqft) + str(self.builderNumber)  # < -------- Changes here
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                    self.match_dict[unique_number] = [PlanName, comm_name]
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = 'SingleFamily'
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number  # < -------- Changes here
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = 0
                    item['PlanTypeName'] = 'Single Family'
                    item['BasePrice'] = BasePrice
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = BaseBathrooms
                    item['HalfBaths'] = BaseHalfBaths
                    item['Bedrooms'] = BaseBedrooms
                    item['Garage'] = 0.00
                    item['Description'] = ''
                    item['ElevationImage'] = SpecElevationImage
                    item['PlanWebsite'] = response.url
                    yield item
                except Exception as e:
                    print(e)

        # yield scrapy.Request(url='https://www.cornerstone-homes.com/quick-delivery.html',callback=self.homes)
        for k, v in self.match_dict.items():
            self.match_dict_comm.append(v[1])
        self.match_dict_comm_name = list(set(self.match_dict_comm))
        if len(self.match_dict_comm_name) != 1:
            yield scrapy.Request(url='https://www.cornerstone-homes.com/quick-delivery.html', callback=self.homes)
        # request_home = requests.get(url="https://www.cornerstone-homes.com/quick-delivery.html")
        # print(request_home.text)

    def homes(self, response):
        list_all = []
        final_list = []
        ElevationImage_dict = {'10949 Hilltop lane': 'https://nebula.wsimg.com/36b952825a7a51de674d6b1f1ef10a2b?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                               '9112 Grant avenue': 'https://nebula.wsimg.com/847559cbf3ae509360c180e94012b486?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1',
                               '9142 Bryant avenue': 'https://nebula.wsimg.com/97b78df844d52a95367d35ee7bfdfea7?AccessKeyId=931C8502FB02191BF70E&disposition=0&alloworigin=1'}
        divs = response.xpath('//div[@class="txt "]/h1')
        for div in divs:
            text_all = div.xpath('..//text()').extract()
            if 'Quick delivery' not in text_all[0]:
                if text_all not in list_all:
                    list_all.append(text_all)
        for list1 in list_all:
            list_tmp = []
            for tmp1 in list1:
                tmp = tmp1.strip()
                if tmp != '​​​​​​​' and tmp != '':
                    list_tmp.append(tmp)
            final_list.append(list_tmp)

        print(final_list)
        for i in final_list:
            try:
                SpecStreet1 = i[0].replace(',','').strip()
            except Exception as e:
                print(e)

            try:
                SpecCity = i[1].split(',')[0].strip()
            except Exception as e:
                print(e)

            try:
                SpecState = i[1].split(',')[1].split()[0].upper().strip()
            except Exception as e:
                print(e)

            try:
                SpecZIP = i[1].split(',')[1].split()[1].strip()
            except Exception as e:
                print(e)

            try:
                unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % SpecNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)
            tmp_comm = i[5].lower().strip()
            tmp_plan = i[7].lower().strip()
            for k,v in self.match_dict.items():
                if v[1].lower() in tmp_comm and v[0].lower() in tmp_plan:
                    PlanNumber = k
                    break
                else:
                    PlanNumber = ''
            if PlanNumber != '':
                try:
                    SpecPrice = i[11].strip().replace('$','').replace(',','').replace('+','')
                except Exception as e:
                    print(e)

                try:
                    if '+' in i[9]:
                        SpecBedrooms = i[9].split('+')[0]
                        SpecBedrooms = re.findall(r"(\d+)", SpecBedrooms)[0].strip()
                    else:
                        SpecBedrooms = i[9].split(',')[0]
                        SpecBedrooms = re.findall(r"(\d+)", SpecBedrooms)[0].strip()
                except Exception as e:
                    print(e)

                try:
                    if '+' in i[9]:
                        SpecBaths = i[9].split('+')[1]
                    else:
                        SpecBaths = i[9].split(',')[1]
                    tmp = re.findall(r"(\d+)", SpecBaths)
                    SpecBaths = tmp[0]
                    if len(tmp) > 1:
                        SpecHalfBaths = 1
                    else:
                        SpecHalfBaths = 0
                except Exception as e:
                    print(e)

                try:
                    SpecSqft = i[10].replace('SQFT','').replace(',','').strip()
                except Exception as e:
                    print(e)

                try:
                    ElevationImage = ElevationImage_dict[SpecStreet1]
                except Exception as e:
                    print(e)

                try:
                    # ----------------------- Don't change anything here ---------------- #
                    item = BdxCrawlingItem_Spec()
                    item['SpecNumber'] = SpecNumber
                    item['PlanNumber'] = PlanNumber
                    item['SpecStreet1'] = SpecStreet1
                    item['SpecCity'] = SpecCity
                    item['SpecState'] = SpecState
                    item['SpecZIP'] = SpecZIP
                    item['SpecCountry'] = "USA"
                    item['SpecPrice'] = SpecPrice
                    item['SpecSqft'] = SpecSqft
                    item['SpecBaths'] = SpecBaths
                    item['SpecHalfBaths'] = SpecHalfBaths
                    item['SpecBedrooms'] = SpecBedrooms
                    item['MasterBedLocation'] = "Down"
                    item['SpecGarage'] = 0.00
                    item['SpecDescription'] = 'Cornerstone Homes builds homes of the finest quality while providing the homeowner the greatest value for their money. We believe that our experience and attention to detail distinguish us from the rest of the homebuilding industry.'
                    item['SpecElevationImage'] = ElevationImage
                    item['SpecWebsite'] = response.url
                    yield item
                except Exception as e:
                    print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl cornerstone".split())
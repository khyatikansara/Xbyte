# -*- coding: utf-8 -*-
import hashlib
import re
import json
import requests
from scrapy.http import HtmlResponse
import scrapy
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec
from lxml import html
from BDX_Crawling.pipelines import BdxCrawlingPipeline


class TravisHomesSpider(scrapy.Spider):
    name = 'Travis_Homes'
    allowed_domains = ['www.travishomebuilders.com/']
    start_urls = ['http://www.travishomebuilders.com']

    builderNumber = "19830"

    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        res = requests.get(url="http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/slideshow.json")
        response1 = HtmlResponse(url=res.url, body=res.content)
        json_data = json.loads(response1.text)
        image_list = []
        for data in json_data:
            img = "http://www.travishomebuilders.com/" + data['imageSource']
            image_list.append(img)
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "16427 Telge Road"
        item['City'] = "Cypress"
        item['State'] = "TX"
        item['ZIP'] = "77429"
        item['AreaCode'] = "206"
        item['Prefix'] = "388"
        item['Suffix'] = "3121"
        item['Extension'] = ""
        item['Email'] = "livebetter@eghome.net"
        item['SubDescription'] = "Travis Homes and WG Homes by Travis Homes are Houston, Texas based new home builders that specializes in living environments built around the specific needs of today's homeowners. Travis Homes are available in a growing number of communities in Houston as well as through a 'Build On Your Lot' program."
        item['SubImage'] = '|'.join(image_list)
        item['SubWebsite'] = ""
        item['AmenityType'] = ''
        yield item

        comm_link = 'http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/communities.json'
        yield scrapy.Request(url=comm_link, callback=self.community, dont_filter=True)

    def community(self, response):
        data_json = json.loads(response.text)
        for data in data_json:
            if data['com_status'] == 'Active':
                if 'com_street1' in data.keys():
                    SubdivisionName = data['com_name']
                    comm_id = data['com_id']
                    SubdivisionNumber = int(hashlib.md5(bytes(SubdivisionName + str(self.builderNumber) + str(comm_id), "utf8")).hexdigest(), 16) % (10 ** 30)
                    Street1 = data['com_street1']
                    City = data['city_name']
                    State = data['state_code']
                    ZIP = data['com_zip']
                    try:Email = data['com_email']
                    except: Email = "livebetter@eghome.net"
                    images = 'http://www.travishomebuilders.com' + data['z_comImageSource']
                    SubWebsite = 'http://www.travishomebuilders.com' + data['url']
                    item = BdxCrawlingItem_subdivision()
                    item['sub_Status'] = "Active"
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['BuilderNumber'] = self.builderNumber
                    item['SubdivisionName'] = SubdivisionName
                    item['BuildOnYourLot'] = 0
                    item['OutOfCommunity'] = 1
                    item['Street1'] = Street1
                    item['City'] = City
                    item['State'] = State
                    item['ZIP'] = ZIP
                    item['AreaCode'] = "719"
                    item['Prefix'] = "322"
                    item['Suffix'] = "5826"
                    item['Extension'] = ""
                    item['Email'] = Email
                    item['SubDescription'] = "Travis Homes and WG Homes by Travis Homes are Houston, Texas based new home builders that specializes in living environments built around the specific needs of today's homeowners. Travis Homes are available in a growing number of communities in Houston as well as through a 'Build On Your Lot' program."
                    item['SubImage'] = images
                    item['SubWebsite'] = SubWebsite
                    item['AmenityType'] = ''
                    yield item

        try:
            link = "http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/common.json"
            header = {
                'Accept': 'application/json, text/plain, */*',
                'Referer': 'http://www.travishomebuilders.com/plans',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'
            }
            yield scrapy.Request(url=link, callback=self.process_plan_link, headers=header, dont_filter=True)
        except Exception as e:
            print(e)

    def process_plan_link(self, response):
        data_json = json.loads(response.text)
        main_plan_link = data_json[3][10]['m_name']
        if main_plan_link == 'Floor Plans':
            link = data_json[3][10]['m_url']
            yield scrapy.Request(url=self.start_urls[0] + link, callback=self.parse_planmainlink, dont_filter=True)

    def parse_planmainlink(self,response):
        try:
            url = "http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/models.json"
            header = {
                'Accept': 'application/json, text/plain, */*',
                'Referer': 'http://www.travishomebuilders.com/plans',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'
            }
            yield scrapy.Request(url=url,callback=self.parse_planlink, headers=header, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_planlink(self, response):
        data_json = json.loads(response.text)
        plandetains = {}
        for data in data_json:
            url = data['url']
            yield scrapy.Request(url=self.start_urls[0] + str(url), callback=self.plans_details, meta={'data':data, 'sbdn': self.builderNumber, 'PlanDetails': plandetains}, dont_filter=True)

    def plans_details(self, response):
        try:
            plandetails = response.meta['PlanDetails']
            if '/the-' in response.url:
                data = response.meta['data']
                try:
                    Type = 'SingleFamily'
                except Exception as e:
                    print(e)

                try:
                    SubdivisionNumber = response.meta['sbdn']
                except Exception as e:
                    print(e)

                try:
                    PlanName = data['mod_name']
                except Exception as e:
                    print(e)

                try:
                    PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
                    f = open("html/%s.html" % PlanNumber, "wb")
                    f.write(response.body)
                    f.close()
                except Exception as e:
                    print(e)

                try:
                    PlanNotAvailable = 0
                except Exception as e:
                    print(e)

                try:
                    PlanTypeName = 'Single Family'
                except Exception as e:
                    print(e)

                try:
                    BasePrice = '0'
                except Exception as e:
                    print(e)

                try:
                    try:
                        Baths = str(data['mod_bathsDisplay'])
                        if '-' in Baths:
                            Baths = Baths.split('-')[1]
                    except:
                        Baths = str(data['mod_baths'])
                    tmp = re.findall(r"(\d+)", Baths)
                    Baths = tmp[0]
                    if len(tmp) > 1:
                        HalfBaths = 1
                    else:
                        HalfBaths = 0
                except Exception as e:
                    print(e)

                try:
                    try:
                        Bedrooms = str(data['mod_bedsDisplay'])
                        Bedrooms = re.findall(r'(\d+)', Bedrooms)[1]
                    except:
                        Bedrooms = str(data['mod_beds'])
                        Bedrooms = re.findall(r'(\d+)', Bedrooms)[0]
                except Exception as e:
                    print(e)

                try:
                    Garage = str(data['mod_garages'])
                    Garage = re.findall(r"(\d+)", Garage)[0]
                    BaseSqft = str(data['mod_sqft'])
                    BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
                except Exception as e:
                    print(e)
                if response.url == 'http://www.travishomebuilders.com/the-ettelbrook':
                    print("")
                try:
                    ElevationImage_list = []
                    try:
                        elevation_list = data['elevations']
                    except:
                        elevation_list = data['source']
                    if type(elevation_list) == list:
                        for elevation in elevation_list:
                            ElevationImage = self.start_urls[0] + str(elevation['imageSource'])
                            ElevationImage_list.append(ElevationImage)
                        ElevationImage = '|'.join(ElevationImage_list)
                        ElevationImage = ElevationImage.strip('|')
                    else:
                        ElevationImage = 'http://www.travishomebuilders.com/'+ elevation_list
                except Exception as e:
                    print(e)

                try:
                    PlanWebsite = response.url
                except Exception as e:
                    print(e)

                SubdivisionNumber = SubdivisionNumber  # if subdivision is there
                # SubdivisionNumber = self.builderNumber #if subdivision is not available
                unique = str(PlanNumber) + str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                plandetails[PlanName] = unique_number
                item = BdxCrawlingItem_Plan()
                item['Type'] = Type
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = PlanTypeName
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = Garage
                item['Description'] = 'Homes range from 1,300 to over 5,000 square feet and each of our plans can be customized to fit your specific needs.'
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item

            try:
                link = "http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/common.json"
                header = {
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': 'http://www.travishomebuilders.com/plans',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'
                }
                yield scrapy.Request(url=link, callback=self.home_parselink, headers=header,meta={"PN": plandetails}, dont_filter=True)
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def home_parselink(self, response):
        data_json = json.loads(response.text)
        for data in data_json[3]:
            if data['m_name'] == 'Available Homes':
                link = data['m_url']
                yield scrapy.Request(url=self.start_urls[0] + link, callback=self.parse_homelist, meta={"PN": response.meta['PN']}, dont_filter=True)
                break

    def parse_homelist(self, response):
        try:
            url = "http://www.travishomebuilders.com/templates/Veranda/travishomebuilders/API/homes.json"
            header = {
                'Accept': 'application/json, text/plain, */*',
                'Referer': 'http://www.travishomebuilders.com/plans',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'
            }
            yield scrapy.Request(url=url,callback=self.home_list, headers=header, meta={"PN": response.meta['PN']}, dont_filter=True)
        except Exception as e:
            print(e)

    def home_list(self, response):
        data_json = json.loads(response.text)
        for data in data_json:
            if data['inv_status'] != 'Under Construction':
                planname = data['mod_name']
                for key, value in response.meta['PN'].items():
                    PlanName = key
                    PlanNumber = value
                    if planname == PlanName:
                        try:
                            PN = response.meta['PN']
                            link = data['url']
                            if link:
                                street = data['inv_street1']
                                address = ''
                                price = str(data['inv_price'])
                                price = re.findall(r"(\d+)", price)[0]
                                yield scrapy.Request(url=self.start_urls[0] + str(link), callback=self.HomesDetails,
                                                     meta={'data':data, 'street': street, 'address': address, 'PN': PN, 'price': price},
                                                     dont_filter=True)
                        except Exception as e:
                            print(e)
                    else:
                        print("other plan")

    def HomesDetails(self, response):
        try:
            PN = response.meta['PN']
            planName = response.meta['data']['mod_name']
            try:
                PlanNumber = PN[planName]
            except Exception as e:
                print(e)

            SpecStreet1 = response.meta['street']
            SpecCity = response.meta['data']['city_name']
            SpecState = response.meta['data']['state_code']
            SpecZIP = response.meta['data']['inv_zip']

            try:
                unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % SpecNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                SpecCountry = "USA"
            except Exception as e:
                print(e)

            try:
                SpecPrice = response.meta['price']
            except Exception as e:
                print(e)

            try:
                SpecSqft = str(response.meta['data']['inv_sqft'])
                SpecSqft = re.findall(r"(\d+)", SpecSqft)[0]
            except Exception as e:
                print(e)

            try:
                SpecBaths = str(response.meta['data']['inv_bathsDisplay'])
                tmp = re.findall(r"(\d+)", SpecBaths)
                SpecBaths = tmp[0]
                if len(tmp) > 1:
                    SpecHalfBaths = 1
                else:
                    SpecHalfBaths = 0
            except Exception as e:
                print(e)

            try:
                SpecBedrooms = str(response.meta['data']['inv_beds'])
                SpecBedrooms = re.findall(r'(\d+)', SpecBedrooms)[0]
            except Exception as e:
                print(e)

            try:
                MasterBedLocation = "Down"
            except Exception as e:
                print(e)

            try:
                SpecGarage = str(response.meta['data']['inv_garages'])
                SpecGarage = re.findall(r"(\d+)", SpecGarage)[0]
            except Exception as e:
                print(e)

            try:
                SpecDescription = 'Homes range from 1,300 to over 5,000 square feet and each of our plans can be customized to fit your specific needs.'
            except Exception as e:
                print(e)

            try:
                ElevationImage_list = []
                ElevationImage = self.start_urls[0] + str(response.meta['data']['inv_image'])
                print(response.meta['data'])
                photos_key = response.meta['data'].keys()
                if 'photos' in photos_key:
                    ElevationImage_photos = response.meta['data']['photos']
                    for i in ElevationImage_photos:
                        ElevationImage_list.append(self.start_urls[0]+ i['imageSource'])
                ElevationImage_list.append(ElevationImage)
                SpecElevationImage = '|'.join(ElevationImage_list)
                SpecElevationImage = SpecElevationImage.strip('|')
            except Exception as e:
                print(e)

            try:
                SpecWebsite = response.url
            except Exception as e:
                print(e)

                # ----------------------- Don't change anything here ---------------- #
            item = BdxCrawlingItem_Spec()
            item['SpecNumber'] = SpecNumber
            item['PlanNumber'] = PlanNumber
            item['SpecStreet1'] = SpecStreet1
            item['SpecCity'] = SpecCity
            item['SpecState'] = SpecState
            item['SpecZIP'] = SpecZIP
            item['SpecCountry'] = SpecCountry
            item['SpecPrice'] = SpecPrice
            item['SpecSqft'] = SpecSqft
            item['SpecBaths'] = SpecBaths
            item['SpecHalfBaths'] = SpecHalfBaths
            item['SpecBedrooms'] = SpecBedrooms
            item['MasterBedLocation'] = MasterBedLocation
            item['SpecGarage'] = SpecGarage
            item['SpecDescription'] = SpecDescription
            item['SpecElevationImage'] = SpecElevationImage
            item['SpecWebsite'] = SpecWebsite
            yield item
        except Exception as e:
            print(e)

if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl Travis_Homes'.split())

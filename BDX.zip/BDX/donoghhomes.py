# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
import requests
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class DonoghhomesSpider(scrapy.Spider):
    name = 'donoghhomes'
    allowed_domains = []
    start_urls = ['http://www.donoghhomes.com/']

    builderNumber = "485458696274147134033995362089"

    def parse(self, response):

        res_cp = requests.get('https://www.donoghhomes.net/community-sitemap.xml')
        response_cp = HtmlResponse(url=res_cp.url,body=res_cp.content)

        comm_page_links = re.findall('<loc>(.*?)</loc>',str(response_cp.body))
        # --------------- response of comm pages
        for cmp_link in comm_page_links:
            # cmp_link='https://www.donoghhomes.net/community/newcastle-wa/'
            print('# ------------- com : '+str(cmp_link))
            res_c = requests.get(cmp_link)
            response_c = HtmlResponse(url=res_c.url, body=res_c.content)

            if response_c.xpath('//*[@class="homes"]')==[]:
                print("No homes available")
                continue

            # ------------------- If communities found ---------------------- #
            # ------------------- Creating Communities ---------------------- #
            subdivisonName = response_c.xpath('//h1/text()').extract_first(default="")
            subdivisonNumber = int(hashlib.md5(bytes(subdivisonName,"utf8")).hexdigest(), 16) % (10 ** 30)

            f = open("html/%s.html" % subdivisonNumber, "wb")
            f.write(response_c.body)
            f.close()
            try:
                City = re.findall('City\:(.*?)<br',str(response_c.body))
                if City!=[]:
                    City=str(City[0]).strip()
                else:
                    print("No address available")
                    continue
                if response_c.url=='https://www.donoghhomes.net/community/magnolia-place/':
                    City = 'Renon'
                add = response_c.xpath('//*[@class="map-wrapper"]/iframe/@src').extract_first(default='').strip()
                addf = str(add.split('q=')[-1]).replace("'","").strip()
                add_f = addf.split(City)
                Street1 = add_f[0]
                if len(add_f)!=1:
                    State = re.findall(r'\D+',add_f[1])
                    if State!=[]:
                        State = str(State[0]).strip()
                        if len(State)!=2:
                            Street1 = Street1+' '+str(State[:-3]).replace(',','').strip()
                            State = State[-2:]
                    else:
                        State='WA'
                    print("com-" + State)
                    ZIP = re.findall(r'\d+', add_f[1])
                    if ZIP!=[]:
                        ZIP = ZIP[0]
                    else:
                        ZIP = '98059'
                else:
                    Street1 = City
                    State = re.findall(r'\D+', add_f[0])
                    if State != []:
                        State = State[0]
                        if len(State)!=2:
                            Street1 = Street1+' '+str(State[:-3]).replace(',','').strip()
                            State = State[-2:]
                    else:
                        State = 'WA'
                    print("com-" + State)
                    ZIP = re.findall(r'\d+', add_f[0])
                    if ZIP != []:
                        ZIP = ZIP[0]
                    else:
                        ZIP = '98056'
            except Exception as e:
                print(e)


            item2 = BdxCrawlingItem_subdivision()
            item2['sub_Status'] = "Active"
            item2['SubdivisionName'] = subdivisonName
            item2['SubdivisionNumber'] = subdivisonNumber
            item2['BuilderNumber'] = self.builderNumber
            item2['BuildOnYourLot'] = 0
            item2['OutOfCommunity'] = 1
            item2['Street1'] = str(Street1).strip()
            item2['City'] = str(City).strip()
            item2['State'] = str(State).strip()
            item2['ZIP'] = str(ZIP).strip()
            item2['AreaCode'] = '206'
            item2['Prefix'] = '793'
            item2['Suffix'] = '9424'
            item2['Extension'] = ""
            item2['Email'] = 'info@donoghhomes.net'
            item2['SubDescription'] = response_c.xpath('//*[@class="content"]/p/text()').extract_first(default="")
            item2['SubImage'] = ""
            item2['SubWebsite'] = response_c.url
            item2['AmenityType'] = ''
            yield item2

            home_check = response_c.xpath('//*[@class="details"]')
            if home_check!=[]:

                for ch in home_check:
                    home_status = ch.xpath('.//span[contains(@class,"home-status")]/text()').extract_first(default="").strip()
                    if home_status == 'SOLD':
                        home_check.remove(ch)

                for hch in home_check:
                    # ------------------- If NO Plan Found found ---------------------- #

                    # In case you have found the communities (subdivision) and Homes (Specs) but you are not able to find the plan details then,
                    # please use this line of code, and reference this unique_number  in All Home(Specs)

                    unique = str("Plan Unknown") + str(subdivisonNumber)
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                    item = BdxCrawlingItem_Plan()
                    item['unique_number'] = unique_number
                    item['Type'] = "SingleFamily"
                    item['PlanNumber'] = "Plan Unknown"
                    item['SubdivisionNumber'] = subdivisonNumber
                    item['PlanName'] = "Plan Unknown"
                    item['PlanNotAvailable'] = 1
                    item['PlanTypeName'] = "Single Family"
                    item['BasePrice'] = 0
                    item['BaseSqft'] = 0
                    item['Baths'] = 1
                    item['HalfBaths'] = 0
                    item['Bedrooms'] = 1
                    item['Garage'] = 0
                    item['Description'] = ""
                    item['ElevationImage'] = ""
                    item['PlanWebsite'] = ""
                    yield item

                    specs_links = set(hch.xpath('.//a[contains(text(),"View details ")]/@href').extract())
                    for specs_link in specs_links:
                        # if "204-CYPRESS-POINTE-DRIVE-LENOIR-CITY-TN-37772" in specs_link:
                        yield scrapy.Request(url=specs_link, callback=self.HomesDetails, meta={"PN": unique_number})

    def HomesDetails(self, response):

        # ------------------------------------------- Extract Homedetails ------------------------------ #
        print('##### ------------ home : '+str(response.url))
        try:
            address_f = []
            address = response.xpath('//*[@class="left address"]/text()').extract()
            for i in address:
                temp = i.strip()
                if temp!='':
                    address_f.append(temp)
            address_f = ', '.join(address_f)
            # print(address_f)
            address_f  =address_f.split(',')
            SpecStreet1 = address_f[0]
            SpecCity = address_f[1]
            SpecState = re.findall('(\D+)',address_f[-1])[0]
            print("homee-"+SpecState)
            SpecZIP = re.findall('(\d+)',address_f[-1])[0]

            unique = SpecStreet1 + SpecCity + SpecState + SpecZIP + str(response.url)
            SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)

            f = open("html/%s.html" % SpecNumber, "wb")
            f.write(response.body)
            f.close()

        except Exception as e:
            print(e)

        try:
            PlanNumber = response.meta['PN']
        except Exception as e:
            print(e)

        try:
            SpecCountry = "USA"
        except Exception as e:
            print(e)

        try:
            SpecPrice = response.xpath('//*[@class="price"]/text()').extract_first(default=0)
            if SpecPrice!=0:
                SpecPrice = SpecPrice.replace("Offered At:", "").replace(',','')
                SpecPrice = re.findall(r"(\d+)", SpecPrice)[0]
        except Exception as e:
            print(e)

        try:
            SpecSqft = str(response.xpath('normalize-space(//li[contains(text(),"Lot Size")]/text())').extract_first(default=0).strip()).replace(",", "")
            SpecSqft = re.findall(r"(\d+)", SpecSqft)[0]
        except Exception as e:
            SpecSqft = 0


        try:
            SpecBaths = str(response.xpath('normalize-space(//li[contains(text(),"Bath")]/text())').extract_first(default=0).strip()).replace(",", "")
            tmp = re.findall(r"(\d+)", SpecBaths)
            SpecBaths = tmp[0]
            if len(tmp) > 1:
                SpecHalfBaths = 1
            else:
                SpecHalfBaths = 0
        except Exception as e:
            SpecBaths = 0
            SpecHalfBaths = 0


        try:
            SpecBedrooms = str(response.xpath('normalize-space(//li[contains(text(),"Bedroom")]/text())').extract_first(default=0).strip()).replace(",", "")
            SpecBedrooms = re.findall(r"(\d+)", SpecBedrooms)[0]
        except Exception as e:
            SpecBedrooms = 0


        try:
            MasterBedLocation = "Down"
        except Exception as e:
            print(e)

        try:
            SpecGarage = 0
        except Exception as e:
            SpecGarage = 0


        try:
            SpecDescription = ''.join(response.xpath('normalize-space(//*[@class="home-description white"]/p/text())').extract_first(default='').strip())
        except Exception as e:
            print(e)

        try:
            ElevationImage = response.xpath('//*[@class="cycle-slideshow"]//img/@src').extract()
            ElevationImage = "|".join(ElevationImage)
            SpecElevationImage = ElevationImage
        except Exception as e:
            print(e)

        try:
            SpecWebsite = response.url
        except Exception as e:
            print(e)
        try:
            # ----------------------- Don't change anything here ---------------- #
            item = BdxCrawlingItem_Spec()
            item['SpecNumber'] = SpecNumber
            item['PlanNumber'] = PlanNumber
            item['SpecStreet1'] = str(SpecStreet1).strip()
            item['SpecCity'] = str(SpecCity).strip()
            item['SpecState'] = str(SpecState).strip()
            item['SpecZIP'] = str(SpecZIP).strip()
            item['SpecCountry'] = SpecCountry
            item['SpecPrice'] = SpecPrice
            item['SpecSqft'] = SpecSqft
            item['SpecBaths'] = SpecBaths
            item['SpecHalfBaths'] = SpecHalfBaths
            item['SpecBedrooms'] = SpecBedrooms
            item['MasterBedLocation'] = MasterBedLocation
            item['SpecGarage'] = SpecGarage
            item['SpecDescription'] = str(SpecDescription).encode('ascii','ignore').strip()
            item['SpecElevationImage'] = SpecElevationImage
            item['SpecWebsite'] = SpecWebsite
            yield item
            # --------------------------------------------------------------------- #
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl donoghhomes".split())

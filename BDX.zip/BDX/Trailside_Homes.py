# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class TrailsideHomesSpider(scrapy.Spider):
    name = 'Trailside_Homes'
    allowed_domains = ['www.trailsidehomes.com']
    start_urls = ['http://www.trailsidehomes.com/']

    builderNumber = "19804"


    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        image = '|'.join(response.xpath('//img/@src').extract())
        images = image.strip('|')
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "116 1/2 S Washington St"
        item['City'] = "Seattle"
        item['State'] = "WA"
        item['ZIP'] = "98104"
        item['AreaCode'] = "206"
        item['Prefix'] = "388"
        item['Suffix'] = "3121"
        item['Extension'] = ""
        item['Email'] = "Discover@TrailsideHomes.com"
        item['SubDescription'] = "Trailside Homes is owned and operated by Washington natives with deep roots on both sides of the Cascade Mountain Range. Our team offers decades of new home construction, design, land planning and development experience."
        item['SubImage'] = images
        item['SubWebsite'] = ""
        item['AmenityType'] = ''
        yield item
        try:
            all_link = []
            other_link = 'http://www.trailsidehomes.com/trailside-homes-custom-home-designs/'
            all_link.append(other_link)
            links = response.xpath('//a[text()="AVAILABLE NOW "]/../ul/li/a/@href').extract()
            all_link.extend(links)
            for link in all_link:
                yield scrapy.Request(url=link, callback=self.parse_planlink, dont_filter=True)
                # break
        except Exception as e:
            print(e)

    def parse_planlink(self,response):
        plandetails = {}
        try:
            unique = str("Plan Unknown") + str(self.builderNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails["Plan Unknown"] = unique_number
            item = BdxCrawlingItem_Plan()
            item['unique_number'] = unique_number
            item['Type'] = "SingleFamily"
            item['PlanNumber'] = "Plan Unknown"
            item['SubdivisionNumber'] = self.builderNumber
            item['PlanName'] = "Plan Unknown"
            item['PlanNotAvailable'] = 1
            item['PlanTypeName'] = "Single Family"
            item['BasePrice'] = 0
            item['BaseSqft'] = 0
            item['Baths'] = 0
            item['HalfBaths'] = 0
            item['Bedrooms'] = 0
            item['Garage'] = 0
            item['Description'] = ""
            item['ElevationImage'] = ""
            item['PlanWebsite'] = ""
            yield item
        except Exception as e:
            print(e)
        try:
            plans_divs = response.xpath('//*[@class="c3-vc-home-design-wrapper clearfix"]')
            for plan_div in plans_divs:
                if not plan_div.xpath('.//*[contains(text(),"SOLD")]'):
                    PlanName = plan_div.xpath('.//*[@class="c3-hd-name"]/text()').extract()
                    if "," in PlanName[0]:
                        bed_bath_garrage = plan_div.xpath('.//*[@class="c3-hd-rooms"]/text()').extract()
                        sqft = plan_div.xpath('.//*[@class="c3-hd-feet"]/text()').extract()
                        prices = plan_div.xpath('.//*[@class="c3-hd-price"]/text()').extract()
                        Description = plan_div.xpath('.//*[@class="c3-hd-description"]//text()').extract()
                        ElevationImage = plan_div.xpath('.//*[@class="c3-hd-gallery-wrapper"]/a/img/@src').extract()
                        home_link = plan_div.xpath('.//*[@class="c3-hd-pdf-link"]/a/@href').extract()
                        if 'Coming-Soon' not in ElevationImage[0]:
                            if bed_bath_garrage != [' Under Design'] and 'Coming Soon' not in prices[0] and 'UNDER CONSTRUCTION' not in ''.join(Description):
                                yield scrapy.Request(url=response.url, callback=self.HomesDetails, dont_filter=True,
                                                     meta={'sbdn': self.builderNumber, 'PlanDetails': plandetails,
                                                           'PlanName': PlanName, 'sqft': sqft, 'prices': prices,
                                                           'bed_bath_garrage': bed_bath_garrage, 'Description': Description,
                                                           'ElevationImage': ElevationImage,
                                                           'home_link': home_link})
                    else:
                        bed_bath_garrage = plan_div.xpath('.//*[@class="c3-hd-rooms"]/text()').extract()
                        sqft = plan_div.xpath('.//*[@class="c3-hd-feet"]/text()').extract()
                        prices = plan_div.xpath('.//*[@class="c3-hd-price"]/text()').extract()
                        Description = plan_div.xpath('.//*[@class="c3-hd-description"]//text()').extract()
                        ElevationImage = plan_div.xpath('.//*[@class="c3-hd-gallery-wrapper"]/a/img/@src').extract()
                        if 'Coming-Soon' not in ElevationImage[0]:
                            if bed_bath_garrage != [' Under Design'] and 'Coming Soon' not in prices[0] and 'UNDER CONSTRUCTION' not in ''.join(Description):
                                yield scrapy.Request(url=response.url, callback=self.plans_details, dont_filter=True,
                                                     meta={'sbdn': self.builderNumber, 'PlanDetails': plandetails,'PlanName': PlanName, 'sqft': sqft, 'prices': prices,
                                                           'bed_bath_garrage': bed_bath_garrage, 'Description': Description, 'ElevationImage': ElevationImage,
                                                           'PlanWebsite':response.url})

        except Exception as e:
            print(e)

    def plans_details(self,response):
        try:
            plandetails = response.meta['PlanDetails']
            try:
                Type = 'SingleFamily'
            except Exception as e:
                print(e)

            try:
                SubdivisionNumber = response.meta['sbdn']
            except Exception as e:
                print(e)

            try:
                PlanName = response.meta['PlanName'][0]
                if 'Telluride' in PlanName:
                    print('')
                if PlanName == 'The McCall (Suncadia)':
                    print('')
                if PlanName == 'The McCall':
                    print('')
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(bytes(PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % PlanNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                PlanTypeName = 'Single Family'
            except Exception as e:
                print(e)

            try:
                BasePrice = '0'
            except Exception as e:
                print(e)


            try:
                Baths = response.meta['bed_bath_garrage'][0]
                if '|' in Baths:
                    Baths = Baths.split('|')
                    for bath in Baths:
                        if 'Baths' in bath or 'Bathrooms' in bath or 'bathroom' in bath:
                            tmp = re.findall(r"(\d+)", bath)
                            Baths = tmp[0]
                            if len(tmp) > 1:
                                HalfBaths = 1
                            else:
                                HalfBaths = 0
                            break
                elif ',' in Baths:
                    Baths = Baths.split(',')
                    for bath in Baths:
                        if 'Bath' in bath or 'Bathroom' in bath or 'bathroom' in bath or 'Bathrooms' in bath:
                            if '-' in bath:
                                bath_tmp = bath.split('-')
                                bath_list = []
                                for bath_tmp1 in bath_tmp:
                                    bathi = bath_tmp1.strip().split(' ')[0]
                                    bath_list.append(bathi)
                                if len(bath_list) > 1:
                                    bath = bath_list[1]
                                    tmp = re.findall(r"(\d+)", bath)
                                    if len(tmp) > 1:
                                        if '.' in bath:
                                            Baths = tmp[0]
                                        else:
                                            Baths = tmp[1]
                                    else:
                                        Baths = tmp[0]
                                    if len(tmp) > 1:
                                        HalfBaths = 1
                                    else:
                                        HalfBaths = 0
                                    break
                            else:
                                tmp = re.findall(r"(\d+)", bath)
                                if len(tmp) > 1:
                                    Baths=tmp[0]
                                    HalfBaths = 1
                                else:
                                    Baths = tmp[0]
                                    HalfBaths = 0
                                break
                else:
                    Baths = '0'
                    HalfBaths = 0
            except Exception as e:
                print(e)

            try:
                Bedrooms = response.meta['bed_bath_garrage'][0]
                if '|' in Bedrooms:
                    Bedrooms = Bedrooms.split('|')
                    for Bedroom in Bedrooms:
                        if 'Bed' in Bedroom:
                            Bedrooms = re.findall(r'(\d+)',Bedroom)[0]
                            break
                elif ',' in Bedrooms:
                    Bedrooms = Bedrooms.split(',')
                    for Bedroom in Bedrooms:
                        if 'Bed' in Bedroom:
                            if '-' in Bedroom:
                                bed_tmp = Bedroom.split('-')
                                bed_list = []
                                for bed_tmp1 in bed_tmp:
                                    bedi = bed_tmp1.strip().split(' ')[0]
                                    bed_list.append(bedi)
                                if len(bed_list) > 1:
                                    Bedrooms = bed_list[1]
                            else:
                                Bedrooms = re.findall(r'(\d+)',Bedroom)[0]
                            break
                else:
                    Bedrooms = '0'
            except Exception as e:
                print(e)

            try:
                Garage = ''
                Garage_tmp = response.meta['bed_bath_garrage'][0]
                if '|' in Garage_tmp:
                    Garage_tmp = Garage_tmp.split('|')
                    for garage_tmp in Garage_tmp:
                        if 'Garage' in garage_tmp:
                            Garage = re.findall(r"(\d+)", garage_tmp)[0]
                            break
                if ',' in Garage_tmp and 'Garage' in Garage_tmp:
                    Garage_tmp = Garage_tmp.split(',')
                    for garage_tmp in Garage_tmp:
                        if 'Garage' in garage_tmp:
                            Garage = re.findall(r"(\d+)", garage_tmp)[0]
                            break
                if Garage == '':
                    Garage = '0'
                BaseSqft = response.meta['sqft'][0].replace(',','')
                if ' Call for Details' in BaseSqft:
                    BaseSqft = '0'
                else:
                    if '-' in BaseSqft:
                        BaseSqft = BaseSqft.split('-')[1].strip()
                    else:
                        BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                Description = response.meta['Description']
                if len(Description) > 1:
                    Description = Description[1]
                    if '\n' in Description:
                        Description = Description.replace('\n', '')
                elif len(Description) == 1:
                    Description = Description[0]
                    if '\n' in Description:
                        Description = Description.replace('\n', '')
                else:
                    Description = 'Bring your designer, architect and plans or collaborate with one of our award winning local architect and design partners who’ve created spectacular homes through the Pacific Northwest.  Or, review our extensive library of plans and wide range of finish packages to streamline your project, start your home sooner, and reduce your costs.'

            except Exception as e:
                print(e)

            try:
                ElevationImage = '|'.join(response.meta['ElevationImage'])
                ElevationImage = ElevationImage.strip('|')
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.meta['PlanWebsite']
            except Exception as e:
                print(e)

            SubdivisionNumber = SubdivisionNumber #if subdivision is there
            #SubdivisionNumber = self.builderNumber #if subdivision is not available
            unique = str(PlanNumber)+str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails[PlanName] = unique_number
            try:
                item = BdxCrawlingItem_Plan()
                item['Type'] = Type
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = PlanTypeName
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = Garage
                item['Description'] = Description
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def HomesDetails(self, response):
        try:
            pn = response.meta['PlanDetails']
            try:
                PlanNumber = pn["Plan Unknown"]
            except Exception as e:
                print(e)

            SpecStreet1 = response.meta['PlanName'][0].split(',')[0]
            SpecCity = response.meta['PlanName'][0].split(',')[1].strip()
            SpecState = response.meta['PlanName'][0].split(',')[2].strip()
            SpecZIP = '00000'

            try:
                unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % SpecNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                SpecCountry = "USA"
            except Exception as e:
                print(e)

            try:
                SpecPrice = 0
            except Exception as e:
                print(e)

            try:
                SpecSqft = response.meta['sqft'][0].strip().replace(',','')
                SpecSqft = re.findall(r"(\d+)", SpecSqft)[0]
            except Exception as e:
                print(e)

            try:
                SpecBaths = response.meta['bed_bath_garrage'][0]
                if '|' in SpecBaths:
                    SpecBaths = SpecBaths.split('|')
                    for Specbath in SpecBaths:
                        if 'Baths' in Specbath or 'Bathrooms' in Specbath or 'bathroom' in Specbath:
                            tmp = re.findall(r"(\d+)", Specbath)
                            SpecBaths = tmp[0]
                            if len(tmp) > 1:
                                SpecHalfBaths = 1
                            else:
                                SpecHalfBaths = 0
                            break
                elif ',' in SpecBaths:
                    SpecBaths = SpecBaths.split(',')
                    for Specbath in SpecBaths:
                        if 'Bath' in Specbath or 'Bathroom' in Specbath or 'bathroom' in Specbath or 'Bathrooms' in Specbath:
                            if '-' in Specbath:
                                specbath_tmp = Specbath.split('-')
                                specbath_list = []
                                for specbath_tmp1 in specbath_tmp:
                                    specbathi = specbath_tmp1.strip().split(' ')[0]
                                    specbath_list.append(specbathi)
                                if len(specbath_list) > 1:
                                    specbath = specbath_list[1]
                                    tmp = re.findall(r"(\d+)", specbath)
                                    if len(tmp) > 1:
                                        if '.' in specbath:
                                            SpecBaths = tmp[0]
                                        else:
                                            SpecBaths = tmp[1]
                                    else:
                                        SpecBaths = tmp[0]
                                    if len(tmp) > 1:
                                        SpecHalfBaths = 1
                                    else:
                                        SpecHalfBaths = 0
                                    break
                            else:
                                tmp = re.findall(r"(\d+)", Specbath)
                                if len(tmp) > 1:
                                    SpecBaths=tmp[0]
                                    SpecHalfBaths = 1
                                else:
                                    SpecBaths = tmp[0]
                                    SpecHalfBaths = 0
                                break
                else:
                    SpecBaths = '0'
                    SpecHalfBaths = 0
            except Exception as e:
                print(e)

            try:
                SpecBedrooms = response.meta['bed_bath_garrage'][0]
                if '|' in SpecBedrooms:
                    SpecBedrooms = SpecBedrooms.split('|')
                    for SpecBedroom in SpecBedrooms:
                        if 'Bed' in SpecBedroom:
                            SpecBedrooms = re.findall(r'(\d+)',SpecBedroom)[0]
                            break
                elif ',' in SpecBedrooms:
                    SpecBedrooms = SpecBedrooms.split(',')
                    for SpecBedroom in SpecBedrooms:
                        if 'Bed' in SpecBedroom:
                            if '-' in SpecBedroom:
                                bed_tmp = SpecBedroom.split('-')
                                bed_list = []
                                for bed_tmp1 in bed_tmp:
                                    bedi = bed_tmp1.strip().split(' ')[0]
                                    bed_list.append(bedi)
                                if len(bed_list) > 1:
                                    SpecBedrooms = bed_list[1]
                            else:
                                SpecBedrooms = re.findall(r'(\d+)',SpecBedroom)[0]
                            break
                else:
                    SpecBedrooms = '0'
            except Exception as e:
                print(e)

            try:
                MasterBedLocation = "Down"
            except Exception as e:
                print(e)

            try:
                SpecGarage = ''
                SpecGarage_tmp = response.meta['bed_bath_garrage'][0]
                if '|' in SpecGarage_tmp:
                    SpecGarage_tmp = SpecGarage_tmp.split('|')
                    for specgarage_tmp in SpecGarage_tmp:
                        if 'Garage' in specgarage_tmp:
                            SpecGarage = re.findall(r"(\d+)", specgarage_tmp)[0]
                            break
                if ',' in SpecGarage_tmp and 'Garage' in SpecGarage_tmp:
                    SpecGarage_tmp = SpecGarage_tmp.split(',')
                    for specgarage_tmp in SpecGarage_tmp:
                        if 'Garage' in specgarage_tmp:
                            SpecGarage = re.findall(r"(\d+)", specgarage_tmp)[0]
                            break
                if SpecGarage == '':
                    SpecGarage = '0'
            except Exception as e:
                print(e)

            try:
                SpecDescription = 'Trailside Homes is excited to showcase this new custom construction Lake Washington view home located in the highly desirable Holmes Point neighborhood of Kirkland, Washington. This striking home by McCullough Architects beckons lake enthusiasts and entertainers alike. Located on Holmes Point Drive just steps from Lake Washington, your new home will feature breathtaking lake views from most rooms including the generous sized entertainment loft.'
            except Exception as e:
                print(e)

            try:
                SpecElevationImage = '|'.join(response.meta['ElevationImage'])
                SpecElevationImage = SpecElevationImage.strip('|')
            except Exception as e:
                print(e)

            try:
                SpecWebsite = response.meta['home_link'][0]
            except Exception as e:
                print(e)

                # ----------------------- Don't change anything here ---------------- #
            item = BdxCrawlingItem_Spec()
            item['SpecNumber'] = SpecNumber
            item['PlanNumber'] = PlanNumber
            item['SpecStreet1'] = SpecStreet1
            item['SpecCity'] = SpecCity
            item['SpecState'] = SpecState
            item['SpecZIP'] = SpecZIP
            item['SpecCountry'] = SpecCountry
            item['SpecPrice'] = SpecPrice
            item['SpecSqft'] = SpecSqft
            item['SpecBaths'] = SpecBaths
            item['SpecHalfBaths'] = SpecHalfBaths
            item['SpecBedrooms'] = SpecBedrooms
            item['MasterBedLocation'] = MasterBedLocation
            item['SpecGarage'] = SpecGarage
            item['SpecDescription'] = SpecDescription
            item['SpecElevationImage'] = SpecElevationImage
            item['SpecWebsite'] = SpecWebsite
            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl Trailside_Homes".split())
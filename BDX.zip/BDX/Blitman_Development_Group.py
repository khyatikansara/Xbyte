
# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class BlitmanDevelopmentGroupSpider(scrapy.Spider):
    name = 'blitman_development_group'
    allowed_domains = ['http://blitmandevelopment.com/']
    start_urls = ['http://blitmandevelopment.com/']

    builderNumber = "12776"


    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        image = '|'.join(response.xpath('//img[contains(@src,"http://randomridgemahopac.com/")]/@src').extract())
        images = image.strip('|')
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "426 Kennicut Hill Road"
        item['City'] = "Mahopac"
        item['State'] = "NY"
        item['ZIP'] = "10541"
        item['AreaCode'] = "845"
        item['Prefix'] = "621"
        item['Suffix'] = "2200"
        item['Extension'] = ""
        item['Email'] = "mike@mahopacrealestate.com"
        item['SubDescription'] = "Blitman Development Corporation (BDC) has been building homes for over 50 years and is responsible for many of the region’s most exceptional communities. Founded by award-winning engineer, Howard N. Blitman, former President of both the New York State Society of Professional Engineers and the National Society of Professional Engineers, BDC built their reputation by combining the highest level of design and construction with outstanding pricing. This value is made possible by decades of experience teaming up with the most quality building professionals around."
        item['SubImage'] = images
        item['SubWebsite'] = response.url
        item['AmenityType'] = ''
        yield item
        try:
            links = response.xpath('//a[contains(text(),"Home Designs")]/following-sibling::ul/li/a/@href').extract()
            plandetains = {}
            for link in links:
                yield scrapy.Request(url=link,callback=self.plans_details,meta={'sbdn':self.builderNumber,'PlanDetails':plandetains},dont_filter=True)
        except Exception as e:
            print(e)

    def plans_details(self,response):
        plandetails = response.meta['PlanDetails']
        try:
            Type = 'SingleFamily'
        except Exception as e:
            print(e)

        try:
            SubdivisionNumber = response.meta['sbdn']
        except Exception as e:
            print(e)

        try:
            PlanName = response.xpath('//h1[@class="entry-title"]/text()').extract_first(default='').strip()
            if '–' in PlanName:
                PlanName = PlanName.split('–')[0].strip()
        except Exception as e:
            print(e)

        try:
            PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
            f = open("html/%s.html" % PlanNumber, "wb")
            f.write(response.body)
            f.close()
        except Exception as e:
            print(e)

        try:
            PlanNotAvailable = 0
        except Exception as e:
            print(e)

        try:
            PlanTypeName = 'Single Family'
        except Exception as e:
            print(e)

        try:
            BasePrice = '0'
        except Exception as e:
            print(e)

        try:
            Baths = str(response.xpath('//h1[@class="entry-title"]/text()').extract_first(default='0').strip()).replace(",", "")
            Baths = re.findall('bedrooms (.*?) baths', Baths)[0]
            tmp = re.findall(r"(\d+)", Baths)
            Baths = tmp[0]
            if len(tmp) > 1:
                HalfBaths = 1
            else:
                HalfBaths = 0
        except Exception as e:
            print(e)

        try:
            Bedrooms = str(response.xpath('//h1[@class="entry-title"]/text()').extract_first(default='0').strip()).replace(",", "")
            Bedrooms = re.findall('– (.*?) bedrooms', Bedrooms)[0]
            Bedrooms = re.findall(r'(\d+)',Bedrooms)[0]
        except Exception as e:
            print(e)

        try:
            # Garage = response.xpath('normalize-space(//*[contains(text(),"Garage")]/following-sibling::text())').extract_first(default='0')
            Garage = 0 #re.findall(r"(\d+)", Garage)[0]
            BaseSqft = str(response.xpath('//h1[@class="entry-title"]/text()').extract_first(default='0').strip()).replace(",", "")
            BaseSqft = re.findall('baths (.*?) SF', BaseSqft)[0]
            BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
        except Exception as e:
            print(e)

        try:
            Description = ''.join(response.xpath('//*[@class="entry-content"]//p/text()').extract())
            Description = Description.strip()
        except Exception as e:
            print(e)

        try:
            ElevationImage = '|'.join(response.xpath('//img[@class="attachment-thumbnail"]/@src').extract())
            ElevationImage = ElevationImage.strip('|')
        except Exception as e:
            print(e)

        try:
            PlanWebsite = response.url
        except Exception as e:
            print(e)

        SubdivisionNumber = SubdivisionNumber #if subdivision is there
        #SubdivisionNumber = self.builderNumber #if subdivision is not available
        unique = str(PlanNumber)+str(SubdivisionNumber)
        unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
        plandetails[PlanName] = unique_number
        item = BdxCrawlingItem_Plan()
        item['Type'] = Type
        item['PlanNumber'] = PlanNumber
        item['unique_number'] = unique_number
        item['SubdivisionNumber'] = SubdivisionNumber
        item['PlanName'] = PlanName
        item['PlanNotAvailable'] = PlanNotAvailable
        item['PlanTypeName'] = PlanTypeName
        item['BasePrice'] = BasePrice
        item['BaseSqft'] = BaseSqft
        item['Baths'] = Baths
        item['HalfBaths'] = HalfBaths
        item['Bedrooms'] = Bedrooms
        item['Garage'] = Garage
        item['Description'] = Description
        item['ElevationImage'] = ElevationImage
        item['PlanWebsite'] = PlanWebsite
        yield item


if __name__ == '__main__':
    
    from scrapy.cmdline import execute
    execute("scrapy crawl blitman_development_group".split())
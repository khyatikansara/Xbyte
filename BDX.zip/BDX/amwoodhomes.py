import hashlib
import re

import requests
import scrapy
from scrapy.http import HtmlResponse

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan


class AmwoodHomesSpider(scrapy.Spider):
    name = 'amwoodhomes'
    allowed_domains = []
    start_urls = ['https://www.amwoodhomes.com']

    builderNumber = "51248"

    def parse(self, response):

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            # 'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            # 'cache-control': 'max-age=0',
            # 'cookie': '_ga=GA1.2.182974974.1617355449; _gid=GA1.2.894081391.1617355449; _pk_ses.36.4203=1; _pk_id.36.4203=7f464eb019714388.1617355450.1.1617358533.1617355450.',
            'referer': 'https://www.amwoodhomes.com/',
            # 'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
            # 'sec-ch-ua-mobile': '?0',
            # 'sec-fetch-dest': 'document',
            # 'sec-fetch-mode': 'navigate',
            # 'sec-fetch-site': 'same-origin',
            # 'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
        }
        res = requests.get(url='https://www.amwoodhomes.com/inspiration-gallery/', headers=headers)
        response1 = HtmlResponse(url=res.url, body=res.content)
        images = response1.xpath('//div[@id="child-gallery"]//a/@href').extract()
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = '2017 N Harmony Town Hall Rd'
        item['City'] = 'Janesville'
        item['State'] = 'WI'
        item['ZIP'] = '53546'
        item['AreaCode'] = "608"
        item['Prefix'] = "756"
        item['Suffix'] = "2989"
        item['Extension'] = ""
        item['Email'] = "info@amwoodhomes.com"
        item['SubDescription'] = 'Over the past 50 years, Amwood Homes has established a reputation for expert construction, quality craftsmanship, and personalized customer service. We work with over 100 local builders in six Midwestern states to provide our customers with custom-designed and skillfully-constructed homes.'
        item['SubImage'] = '|'.join(images)+'|https://www.amwoodhomes.com/wp-content/uploads/2020/02/Jason-Thomas-Homes-2-scaled.jpg'
        item['SubWebsite'] = 'https://www.amwoodhomes.com/'
        item['AmenityType'] = ''
        yield item

        link = 'https://www.amwoodhomes.com/our-floorplans/'
        yield scrapy.Request(url=link, callback=self.mid)


    def mid(self, response):
        links = response.xpath('//div[@class="child-div col-sm-6 col-xs-6"]/a/@href').getall()
        for link in links:
            if 'commercial' not in link:
                yield scrapy.Request(url=link, callback=self.mid2)

    def mid2(self, response):
        links = response.xpath('//div[@id="sort-target"]/div/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.plans)

    def plans(self, response):
        try:PlanName = response.xpath('//h1/text()').get(default='').strip()
        except Exception as e:print(e)

        SubdivisionNumber = self.builderNumber

        try:BaseSqft = ''.join(response.xpath('//div[@class="square-feet col-sm-4"]/text()').getall()).strip().replace(',','').replace('Sq. Ft.','').strip()
        except:BaseSqft = ''

        PlanNumber = int(hashlib.md5(bytes(str(PlanName + SubdivisionNumber + BaseSqft) + response.url, "utf8")).hexdigest(), 16) % (10 ** 30)

        Baths = ''.join(response.xpath('//div[@class="bathrooms col-sm-4"]/text()').getall()).replace('Bath','').strip()
        if '1/2' in Baths or '.' in Baths:
            HalfBaths = 1
            Baths = re.findall(r'(\d+)', Baths)[0]
        else:
            HalfBaths = 0
        if Baths == '':
            Baths = 0

        try:
            Bedrooms = ''.join(response.xpath('//div[@class="bedrooms col-sm-4"]/text()').getall())
            Bedrooms = re.findall(r'(\d+)', Bedrooms)
            if len(Bedrooms) == 1:
                Bedrooms = Bedrooms[0].strip()
            else:
                Bedrooms = Bedrooms[1].strip()
        except:
            Bedrooms = 0

        Description = response.xpath('//div[@class="content"]/p/text()').extract_first()
        if Description == None:
            Description = 'Over the past 50 years, Amwood Homes has established a reputation for expert construction, quality craftsmanship, and personalized customer service. We work with over 100 local builders in six Midwestern states to provide our customers with custom-designed and skillfully-constructed homes.'
        else:
            Description = Description.encode('ascii','ignore').decode('utf8')
        try:Images = '|'.join(response.xpath('//div[@class="floorplan-wrapper"]/img/@src').getall())
        except:Images = ''

        try:
            unique = str(PlanNumber) + str(SubdivisionNumber)  # < -------- Changes here
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
            item = BdxCrawlingItem_Plan()
            item['Type'] = 'SingleFamily'
            item['PlanNumber'] = PlanNumber
            item['unique_number'] = unique_number  # < -------- Changes here
            item['SubdivisionNumber'] = SubdivisionNumber
            item['PlanName'] = PlanName
            item['PlanNotAvailable'] = 0
            item['PlanTypeName'] = 'Single Family'
            item['BasePrice'] = 0
            item['BaseSqft'] = BaseSqft
            item['Baths'] = Baths
            item['HalfBaths'] = HalfBaths
            item['Bedrooms'] = Bedrooms
            item['Garage'] = 0
            item['Description'] = Description
            item['ElevationImage'] = Images
            item['PlanWebsite'] = response.url
            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl amwoodhomes'.split())
# -*- coding: utf-8 -*-
import hashlib
import re
import json
import scrapy
import requests
from scrapy.http import HtmlResponse
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class GuentherhomesSpider(scrapy.Spider):
    name = 'guentherhomes'
    allowed_domains = []
    start_urls = ['http://www.guentherhomes.com/']

    builderNumber = "821034748137778866151091299667"

    def parse(self, response):
        comm_name, comm_id = [] , []
        head = {'Host': 'api.mybuildercloud.com',
			'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0',
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'en-US,en;q=0.5',
			'Accept-Encoding': 'gzip, deflate, br',
			'Referer': 'https://www.guentherhomes.com/communities',
			'Origin': 'https://www.guentherhomes.com'}
        comm_link = 'https://api.mybuildercloud.com/api/v1/communities?where={"published":true,"builder":"57347718371e2f491e8847a0"}&max_results=9999'
        res_cj = requests.get(comm_link,headers=head)
        response_cj = HtmlResponse(url=res_cj.url,body=res_cj.content)

        df_c = json.loads(response_cj.text)
        comm_loop = df_c['_items']
        for comm in comm_loop :
            website = self.start_urls[0]+comm['_links']['self']['href']

            subdivisonName = comm['name']
            print('# ------------ '+subdivisonName)
            subdivisonNumber = int(hashlib.md5(bytes(subdivisonName, "utf8")).hexdigest(), 16) % (10 ** 30)

            comm_name.append(subdivisonName.strip())
            comm_id.append(website.split('/')[-1].strip())

            try:
                Street1 = comm['address']['streetAddress']
                city = comm['address']['addressLocality']
                State = comm['address']['addressRegion']
                ZIP = comm['address']['postalCode']

                email = comm['modifier_email']
                if 'telephone' in comm:
                    tele = comm['telephone']
                    if type(tele)== str:
                        tele = tele.replace('(','').replace(')','-').strip().split('-')
                        tele1 = tele[0].strip()
                        tele2 = tele[1].strip()
                        tele3 = tele[2].strip()
                    else:
                        tele = str(tele)
                        tele1 = tele[:3]
                        tele2 = tele[3:6]
                        tele3 = tele[6:]
                else:
                    tele1 = '734'
                    tele2 = '260'
                    tele3 = '2119'

                img1 = comm['photos'][0]['contentUrl']
                if 'zPlatMap' and 'image' in comm:
                    img = img1 + '|' + comm['zPlatMap']['image']
                else:
                    img = img1

                f = open("html/%s.html" % subdivisonNumber, "wb")
                f.write(response.body)
                f.close()

                item2 = BdxCrawlingItem_subdivision()
                item2['sub_Status'] = "Active"
                item2['SubdivisionName'] = subdivisonName
                item2['SubdivisionNumber'] = subdivisonNumber
                item2['BuilderNumber'] = self.builderNumber
                item2['BuildOnYourLot'] = 0
                item2['OutOfCommunity'] = 1
                item2['Street1'] = Street1
                item2['City'] = city
                item2['State'] = State
                item2['ZIP'] = ZIP
                item2['AreaCode'] = tele1
                item2['Prefix'] = tele2
                item2['Suffix'] = tele3
                item2['Extension'] = ""
                item2['Email'] = email
                item2['SubDescription'] = comm['description']
                item2['SubImage'] = img
                item2['SubWebsite'] = website
                yield item2
            except Exception as e:
                print(e)

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()

        comm_name.append('No Sub Division')
        comm_id.append('0000')

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "2864 Carpenter Road Suite 300"
        item['City'] = "Ann Arbor"
        item['State'] = "MI"
        item['ZIP'] = "48108"
        item['AreaCode'] = "734"
        item['Prefix'] = "260"
        item['Suffix'] = "2119"
        item['Extension'] = ""
        item['Email'] = ""
        item['SubDescription'] = "No matter what 'home' means to you, Guenther Homes can take you there. For more than 70 years, our family has been building homes, communities, condos and apartment buildings for Michigan's residents. We build, live, and volunteer in Michigan. Choose a builder that is committed to working in partnership with you from finalizing the design and details to building with quality, moving in on time, and being there when you need us, after the sale. Contact Guenther Homes so we can build your future together."
        item['SubImage'] = "https://d3nmokoxrgzai9.cloudfront.net/1650/1650/aHR0cHM6Ly9zMy5hbWF6b25hd3MuY29tL2J1aWxkZXJjbG91ZC8yY2QzYzVlMjExYmZmOTJiMzViODI5OWUwZTNlOWVhMi5qcGVn|https://s3.amazonaws.com/buildercloud/1e440732f01649a47203bb9bcabc0fce.jpeg"
        item['SubWebsite'] = "https://www.guentherhomes.com/"
        yield item

        comm_dct = dict(zip(comm_id,comm_name))
        print(comm_dct)

        plan_name, plan_id, unique_fl = [], [], []
        head = {'Host': 'api.mybuildercloud.com',
                'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://www.guentherhomes.com/plan',
                'Origin': 'https://www.guentherhomes.com'}
        plan_link = 'https://api.mybuildercloud.com/api/v1/plans?where={"published":true,"builder":"57347718371e2f491e8847a0"}&max_results=9999'
        res_pj = requests.get(plan_link, headers=head)
        response_pj = HtmlResponse(url=res_pj.url, body=res_pj.content)

        df_p = json.loads(response_pj.text)
        plan_loop = df_p['_items']
        for plan in plan_loop:

            plan_id.append(plan['_id'])

            plan_website = self.start_urls[0]+ plan['_links']['self']['href']
            PlanNumber = int(hashlib.md5(bytes(plan_website, "utf8")).hexdigest(), 16) % (10 ** 30)

            plan_name.append(plan_website)

            copm_loop = plan['communities']
            unique_list = []
            if copm_loop!=[]:
                for cpl in copm_loop:

                    try:
                        subdivisonName_rw = cpl['community']
                        subdivisonName = comm_dct.get(subdivisonName_rw)
                        SubdivisionNumber = int(hashlib.md5(bytes(subdivisonName, "utf8")).hexdigest(), 16) % (10 ** 30)
                        unique = str(PlanNumber)+str(SubdivisionNumber)
                        unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                        unique_list.append(str(unique_number))
                        if 'type' in plan:
                            PlanTypeName = plan['type']
                        else:
                            PlanTypeName = 'Single Family'

                        if 'Single' in PlanTypeName:
                            Type = 'SingleFamily'
                        else:
                            Type = 'MultiFamily'

                        PlanName = plan['name']
                        print(str(plan_loop.index(plan))+' -- plan name : '+PlanName + ' -- '+ str(len(copm_loop)))
                        PlanNotAvailable = 0
                        BaseSqft = plan['sqft']
                        Baths = plan['bathsFull']
                        if 'bathsHalf' in plan:
                            HalfBaths = plan['bathsHalf']
                        else:
                            HalfBaths = 0
                        Bedrooms = plan['beds']
                        if 'garages' in plan:
                            Garage = plan['garages']
                        else:
                            Garage = 0

                        if 'description' in plan:
                            Description = plan['description']
                        else:
                            Description = ''

                        imgp = []
                        ele_img = plan['elevationPhotos']
                        if ele_img!=[]:
                            for img in ele_img:
                                url = img['contentUrl']
                                imgp.append(url.strip())
                        fp_img = plan['floorplanPhotos']
                        if fp_img!=[]:
                            for img in fp_img:
                                url = img['contentUrl']
                                imgp.append(url.strip())
                        if imgp!=[]:
                            ElevationImage = '|'.join(imgp)
                        else:
                            ElevationImage = ''

                        if 'price' in plan:
                            BasePrice = plan['price']
                        else:
                            BasePrice = 0

                        item = BdxCrawlingItem_Plan()
                        item['Type'] = Type
                        item['PlanNumber'] = PlanNumber
                        item['unique_number'] = unique_number
                        item['SubdivisionNumber'] = SubdivisionNumber
                        item['PlanName'] = PlanName
                        item['PlanNotAvailable'] = PlanNotAvailable
                        item['PlanTypeName'] = PlanTypeName
                        item['BasePrice'] = BasePrice
                        item['BaseSqft'] = BaseSqft
                        item['Baths'] = Baths
                        item['HalfBaths'] = HalfBaths
                        item['Bedrooms'] = Bedrooms
                        item['Garage'] = Garage
                        item['Description'] = Description
                        item['ElevationImage'] = ElevationImage
                        item['PlanWebsite'] = plan_website
                        yield item
                    except Exception as e:
                        print(e)
                try:
                    unique_fl.append(str('|'.join(unique_list)))
                except Exception as e:
                    print(e)


            else:
                SubdivisionNumber = self.builderNumber
                unique = str(PlanNumber)+str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                unique_list.append(unique_number)
                try:
                    if 'type' in plan:
                        PlanTypeName = plan['type']
                    else:
                        PlanTypeName = 'Single Family'

                    if 'Single' in PlanTypeName:
                        Type = 'SingleFamily'
                    else:
                        Type = 'MultiFamily'

                    PlanName = plan['name']
                    print(str(plan_loop.index(plan)) + ' -- plan name : ' + PlanName + ' -- 0')
                    PlanNotAvailable = 0
                    BaseSqft = plan['sqft']
                    Baths = plan['bathsFull']
                    if 'bathsHalf' in plan:
                        HalfBaths = plan['bathsHalf']
                    else:
                        HalfBaths = 0
                    Bedrooms = plan['beds']
                    if 'garages' in plan:
                        Garage = plan['garages']
                    else:
                        Garage = 0
                    if 'description' in plan:
                        Description = plan['description']
                    else:
                        Description = ''

                    imgp = []
                    ele_img = plan['elevationPhotos']
                    if ele_img!=[]:
                        for img in ele_img:
                            url = img['contentUrl']
                            imgp.append(url.strip())
                    fp_img = plan['floorplanPhotos']
                    if fp_img!=[]:
                        for img in fp_img:
                            url = img['contentUrl']
                            imgp.append(url.strip())
                    if imgp!=[]:
                        ElevationImage = '|'.join(imgp)
                    else:
                        ElevationImage = ''

                    if 'price' in plan:
                        BasePrice = plan['price']
                    else:
                        BasePrice = 0

                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = BasePrice
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = Baths
                    item['HalfBaths'] = HalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = Garage
                    item['Description'] = Description
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = plan_website
                    yield item
                except Exception as e:
                    print(e)
                try:
                    unique_fl.append(str(unique_list[0]))
                except Exception as e:
                    print(e)

        plan_unique_dict = dict(zip(plan_id,unique_fl))
        print(plan_unique_dict)

        # ----------------------------------------------- HOMES

        head = {'Host': 'api.mybuildercloud.com',
                'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://www.guentherhomes.com/homes',
                'Origin': 'https://www.guentherhomes.com'}
        spec_link = 'https://api.mybuildercloud.com/api/v1/homes?where={%22published%22:true,%22builder%22:%2257347718371e2f491e8847a0%22}&max_results=9999'
        res_sj = requests.get(spec_link, headers=head)
        response_sj = HtmlResponse(url=res_sj.url, body=res_sj.content)

        df_p = json.loads(response_sj.text)
        spec_loop = df_p['_items']

        for spec in spec_loop:

            SpecWebsite = self.start_urls[0] + spec['_links']['self']['href']
            print('home : '+ SpecWebsite)
            status = spec['status']
            if status =='Sold':
                continue
            elif 'plan' not in spec:
                continue
            else:
                SpecStreet1 = spec['address']['streetAddress']
                SpecCity = spec['address']['addressLocality']
                SpecState = spec['address']['addressRegion']
                SpecZIP = spec['address']['postalCode']

                try:
                    plan_no = spec['plan']
                    PlanNumber = plan_unique_dict.get(plan_no)
                except Exception as e:
                    print(e)

                if 'price' in spec:
                    SpecPrice = spec['price']
                else:
                    SpecPrice = 0

                if 'sqft' in spec:
                    SpecSqft = spec['sqft']
                else:
                    SpecSqft = 0

                if 'bathsFull' in spec:
                    SpecBaths = spec['bathsFull']
                else:
                    SpecBaths = 0

                if 'bathsHalf' in spec:
                    SpecHalfBaths = spec['bathsHalf']
                else:
                    SpecHalfBaths = 0

                if 'beds' in spec:
                    SpecBedrooms = spec['beds']
                else:
                    SpecBedrooms = 0

                if 'garages' in spec:
                    SpecGarage = spec['garages']
                else:
                    SpecGarage = 0

                if 'description' in spec:
                    SpecDescription = spec['description']
                else:
                    SpecDescription = ''

                if 'masterBedLocation' in spec:
                    MasterBedLocation = spec['masterBedLocation']
                else:
                    MasterBedLocation = 'Down'

                imgs = []
                ele_img = spec['elevationPhotos']
                if ele_img != []:
                    for img in ele_img:
                        url = img['contentUrl']
                        imgs.append(url.strip())
                fp_img = spec['floorplanPhotos']
                if fp_img != []:
                    for img in fp_img:
                        url = img['contentUrl']
                        imgs.append(url.strip())
                p_img = spec['photos']
                if p_img != []:
                    for img in p_img:
                        url = img['contentUrl']
                        imgs.append(url.strip())
                if imgs != []:
                    SpecElevationImage = '|'.join(imgs)
                else:
                    SpecElevationImage = ''


                # ----------------------- Don't change anything here ---------------- #
                if '|' in PlanNumber:
                    PlanNumber = PlanNumber.split('|')
                    for PN in PlanNumber:
                        unique = SpecStreet1 + SpecCity + SpecState + SpecZIP + SpecWebsite + str(PN)
                        SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)

                        f = open("html/%s.html" % SpecNumber, "wb")
                        f.write(response.body)
                        f.close()

                        item = BdxCrawlingItem_Spec()
                        item['SpecNumber'] = SpecNumber
                        item['PlanNumber'] = int(PN)
                        item['SpecStreet1'] = SpecStreet1
                        item['SpecCity'] = SpecCity
                        item['SpecState'] = SpecState
                        item['SpecZIP'] = SpecZIP
                        item['SpecCountry'] = 'USA'
                        item['SpecPrice'] = SpecPrice
                        item['SpecSqft'] = SpecSqft
                        item['SpecBaths'] = SpecBaths
                        item['SpecHalfBaths'] = SpecHalfBaths
                        item['SpecBedrooms'] = SpecBedrooms
                        item['MasterBedLocation'] = MasterBedLocation
                        item['SpecGarage'] = SpecGarage
                        item['SpecDescription'] = SpecDescription
                        item['SpecElevationImage'] = SpecElevationImage
                        item['SpecWebsite'] = SpecWebsite
                        yield item
                        # --------------------------------------------------------------------- #
                else:

                    unique = SpecStreet1 + SpecCity + SpecState + SpecZIP + SpecWebsite + str(PlanNumber)
                    SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)

                    f = open("html/%s.html" % SpecNumber, "wb")
                    f.write(response.body)
                    f.close()

                    item = BdxCrawlingItem_Spec()
                    item['SpecNumber'] = SpecNumber
                    item['PlanNumber'] = int(PlanNumber)
                    item['SpecStreet1'] = SpecStreet1
                    item['SpecCity'] = SpecCity
                    item['SpecState'] = SpecState
                    item['SpecZIP'] = SpecZIP
                    item['SpecCountry'] = 'USA'
                    item['SpecPrice'] = SpecPrice
                    item['SpecSqft'] = SpecSqft
                    item['SpecBaths'] = SpecBaths
                    item['SpecHalfBaths'] = SpecHalfBaths
                    item['SpecBedrooms'] = SpecBedrooms
                    item['MasterBedLocation'] = MasterBedLocation
                    item['SpecGarage'] = SpecGarage
                    item['SpecDescription'] = SpecDescription
                    item['SpecElevationImage'] = SpecElevationImage
                    item['SpecWebsite'] = SpecWebsite
                    yield item

if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl guentherhomes".split())


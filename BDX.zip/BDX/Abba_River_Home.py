# # -*- coding: utf-8 -*-
# import hashlib
# import re
# import requests
# from scrapy.http import HtmlResponse
# import scrapy
# from scrapy.utils.response import open_in_browser
# from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec
#
#
# class AbbaRiverHomeSpider(scrapy.Spider):
#     name = 'Abba_River_Home'
#     allowed_domains = ['http://www.almonthomes.com/']
#     start_urls = ['http://www.almonthomes.com/']
#     builderNumber = 53901
#
#
#
#     def parse(self, response):
#         links = response.xpath('//div[@class="comm-menu-column"]/li/a/@href').extract()
#         for link in links:
#             link = 'http://www.almonthomes.com' + str(link)
#             print(link)
#             yield scrapy.FormRequest(url=link,callback=self.parse2,dont_filter=True)
#
#
#     def parse2(self,response):
#         # IF you do not have Communities and you are creating the one
#         # ------------------- If No communities found ------------------- #
#
#
#         subdivison_name = response.xpath('//div[@class="comm-header-row"]/h2/text()').extract_first()
#         print(subdivison_name)
#
#         subdivisonNumber = int(hashlib.md5(bytes(subdivison_name, "utf8")).hexdigest(), 16) % (10 ** 30)
#         print(subdivisonNumber)
#
#
#         loc = response.xpath('//span[contains(text(),"Location")]/../text()').extract_first()
#         print(loc)
#         if ',' in loc:
#             city = loc.split(",")[0].strip()
#             print(city)
#
#             state = loc.split(",")[1].strip()
#             print(state)
#             if len(state) > 2:
#                 state =''
#
#         phon = response.xpath('//span[contains(text(),"Call Now:")]/../text()').extract_first()
#         print(phon)
#
#         AreaCode = phon.split("-")[0].strip()
#         print(AreaCode)
#
#
#         Prefix = phon.split("-")[1]
#         print(Prefix)
#
#         Suffix = phon.split("-")[2]
#         print(Suffix)
#
#
#         email = response.xpath('//span[contains(text(),"Email:")]/../a/text()').extract_first()
#         print(email)
#
#         Ameniity = "|".join(response.xpath('//div[@class="sidebar-wrapper"]/ul/li/a/text()').extract()).strip()
#         print(Ameniity)
#
#         desc = response.xpath('//div[@class="textbox"]/p/text()').extract_first()
#         print(desc)
#
#         img = response.xpath('//div[@class="thumb_wrapper"]/a/@href').extract()
#         images = []
#         if img != []:
#             for i in img:
#                 i = 'http://www.almonthomes.com' + i
#                 images.append(i)
#
#         print(images)
#
#
#
#         f = open("html/%s.html" % self.builderNumber, "wb")
#         f.write(response.body)
#         f.close()
#         item = BdxCrawlingItem_subdivision()
#         item['sub_Status'] = "Active"
#         item['SubdivisionNumber'] = subdivisonNumber
#         item['BuilderNumber'] = self.builderNumber
#         item['SubdivisionName'] = subdivison_name
#         item['BuildOnYourLot'] = 0
#         item['OutOfCommunity'] = 0
#         item['Street1'] = 'P.O. Box 459'
#         item['City'] = city
#         item['State'] = state
#         item['ZIP'] = '30024'
#         item['AreaCode'] = AreaCode
#         item['Prefix'] = Prefix
#         item['Suffix'] = Suffix
#         item['Extension'] = ""
#         item['Email'] = email
#         item['AmenityType'] = Ameniity
#         item['SubDescription'] = desc
#         item['SubImage'] = '|'.join(images)
#         item['SubWebsite'] = response.url
#         yield item
#
#
# from scrapy.cmdline import execute
# execute("scrapy crawl Abba_River_Home1".split())

# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
import requests
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class BuiltwrightSpider(scrapy.Spider):
    name = 'builtwright'
    allowed_domains = ['builtwright-construction.com']
    start_urls = ['http://www.builtwright-construction.com/']

    builderNumber = "784686301238566736007844204120"

    def parse(self, response):

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "301 Elk Park Dr."
        item['City'] = "Asheville"
        item['State'] = "NC"
        item['ZIP'] = "28804"
        item['AreaCode'] = "828"
        item['Prefix'] = "545"
        item['Suffix'] = "0052"
        item['Extension'] = ""
        item['Email'] = "info@builtwright-construction.com"
        item['SubDescription'] = "".join(response.xpath('//*[@class="avia_textblock  "]//span/text()').extract())
        item['SubImage'] = "|".join(response.xpath('//*[@class="avia-slide-wrap"]/img/@src').extract())
        item['SubWebsite'] = "http://www.builtwright-construction.com/"
        item['AmenityType'] = ''
        yield item



        # ------------------- If Plan Found found ------------------------- #

        # ------------------------------------ Extract_Plans ----------------------------#
        plan_urls = response.xpath('//*[@id="avia-menu"]/li[2]/a/@href').extract_first(default='').strip()
        try:

            headers = {'Host': 'www.builtwright-construction.com','User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language': 'en-US,en;q=0.5','Accept-Encoding': 'gzip, deflate, br'}
            res = requests.get(plan_urls,headers=headers)
            response = HtmlResponse(url=res.url, body=res.content)
            urls = response.xpath('//a[@itemscope="itemscope"]/@href').extract()
            for i in range(0,len(urls)):
                # url = 'https://jeffburnsdesigns.com/?page_id=874'
                # res = requests.get(url, headers=headers)
                headers_p={'Host': 'www.builtwright-construction.com','User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language': 'en-US,en;q=0.5','Accept-Encoding': 'gzip, deflate, br'}
                res = requests.get(urls[i],headers=headers_p)
                response = HtmlResponse(url=res.url, body=res.content)
                # Plans == > available plans in that communities

                # ------------------------------------- Extracting Plans ------------------------- #

                try:
                    Type = 'SingleFamily'
                except Exception as e:
                    print(e)

                try:
                    PlanNumber = int(hashlib.md5(bytes(response.url,"utf8")).hexdigest(), 16) % (10 ** 30)
                except Exception as e:
                    print(e)

                try:
                    SubdivisionNumber = self.builderNumber
                except Exception as e:
                    print(e)

                try:
                    PlanName = response.xpath('//*[@itemprop="text"]/h1/text()').extract_first(default='').strip()
                except Exception as e:
                    print(e)

                try:
                    PlanNotAvailable = 0
                except Exception as e:
                    print(e)

                try:
                    PlanTypeName = 'SingleFamily'
                except Exception as e:
                    print(e)

                try:
                    BasePrice = 0
                    # BasePrice = re.findall(r"(\d+)", BasePrice)[0]
                except Exception as e:
                    print(e)


                try:
                    Description = ""
                except Exception as e:
                    print(e)

                try:
                    ElevationImage = response.xpath('//a[@itemprop="thumbnailUrl"]/@href').extract()
                    if ElevationImage !=[]:
                        ElevationImage = "|".join(ElevationImage)
                except Exception as e:
                    print(e)

                try:
                    PlanWebsite = str(response.url)
                    print(PlanWebsite)
                except Exception as e:
                    print(e)

                # ----------------------- Don't change anything here --------------
                try:
                    unique = str(PlanName)+str(response.url)+str(self.builderNumber)   # < -------- Changes here
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number  # < -------- Changes here
                    item['SubdivisionNumber'] = self.builderNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = 0
                    item['BaseSqft'] = 0
                    item['Baths'] = 0
                    item['HalfBaths'] = 0
                    item['Bedrooms'] = 0
                    item['Garage'] = 0
                    item['Description'] = Description
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = PlanWebsite
                    yield item
                except Exception as e:
                    print(e)
                    # --------------------------------------------------------------------- #
        except Exception as e:
            print(e)
        # --------------------------------------------------------------------- #


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl builtwright".split())
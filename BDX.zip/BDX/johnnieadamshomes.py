# -*- coding: utf-8 -*-
import hashlib
import re
import uuid

import scrapy
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec
import requests
import random
class johnnieadamshomesSpider(scrapy.Spider):
    name = 'johnnieadamshomes'
    # allowed_domains = ['johnnieadamshomes.com']
    start_urls = ['http://johnnieadamshomes.com/communities/']

    builderNumber = "606869197113355355718301830467"

    def parse(self, response):
        subdivisonName = 'Oak Run'
        subdivisonNumber = int(hashlib.md5(bytes(subdivisonName,"utf8")).hexdigest(), 16) % (10 ** 30)
        f = open("html/%s.html" % subdivisonNumber, "wb")
        f.write(response.body)
        f.close()

        item2 = BdxCrawlingItem_subdivision()
        item2['sub_Status'] = "Active"
        item2['SubdivisionName'] = subdivisonName
        item2['SubdivisionNumber'] = subdivisonNumber
        item2['BuilderNumber'] = self.builderNumber
        item2['BuildOnYourLot'] = 0
        item2['OutOfCommunity'] = 1
        item2['Street1'] = '14960 S. Red Bird St'
        item2['City'] = 'Olathe'
        item2['State'] = 'KS'
        item2['ZIP'] = '66061'
        item2['AreaCode'] = '913'
        item2['Prefix'] = '738'
        item2['Suffix'] = '7768'
        item2['Extension'] = ""
        item2['Email'] = "info@johnnieadamshomes.com"
        item2['SubDescription'] = 'While excellent products and excellent client relationships are important in nearly any business or profession, they are absolutely essential in home building. Johnnie Adams knows that and has built his company, and reputation on providing both. How does he accomplish that? First, he builds uncommon homes with standard features many other builders offer as upgrades. Magnificent trim packages and elegant cabinetry are but two examples. Innovative, gracious floor plans and extraordinary attention to detail are others.'
        item2['SubImage'] = 'https://johnnieadamshomes.com/wp-content/uploads/2017/05/kansas-city-homes.jpg'
        item2['SubWebsite'] = 'www.oakrunolathe.com'
        item2['AmenityType'] = ""
        yield item2

        # url = ['http://johnnieadamshomes.com/all-floor-plans/terry/','http://johnnieadamshomes.com/all-floor-plans/raised-ranch/','http://johnnieadamshomes.com/all-floor-plans/stratford/',
        #        'http://johnnieadamshomes.com/all-floor-plans/whitney/','http://johnnieadamshomes.com/all-floor-plans/mesa-iii/','http://johnnieadamshomes.com/all-floor-plans/brookside/',
        #        'http://johnnieadamshomes.com/all-floor-plans/brantford/','http://johnnieadamshomes.com/all-floor-plans/sedona/','http://johnnieadamshomes.com/all-floor-plans/alcott/',
        #        'http://johnnieadamshomes.com/all-floor-plans/wyndham-ii/','http://johnnieadamshomes.com/all-floor-plans/siena-2/','http://johnnieadamshomes.com/all-floor-plans/sedona-ii/',
        #        'http://johnnieadamshomes.com/all-floor-plans/costello-ii/','http://johnnieadamshomes.com/all-floor-plans/brantford/']
        # url = ['https://johnnieadamshomes.com/all-floor-plans/raised-ranch/',
        #         'https://johnnieadamshomes.com/all-floor-plans/stratford/',
        #         'https://johnnieadamshomes.com/all-floor-plans/whitney/',
        #         'https://johnnieadamshomes.com/all-floor-plans/brightwood/',
        #         'https://johnnieadamshomes.com/all-floor-plans/austin/',
        #         'https://johnnieadamshomes.com/all-floor-plans/laurelwood/',
        #         'https://johnnieadamshomes.com/all-floor-plans/mesa-iii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/brookside/',
        #         'https://johnnieadamshomes.com/all-floor-plans/laurelwood-ii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/brantford/',
        #         'https://johnnieadamshomes.com/all-floor-plans/sedona/',
        #         'https://johnnieadamshomes.com/all-floor-plans/alcott/',
        #         'https://johnnieadamshomes.com/all-floor-plans/terry/',
        #         'https://johnnieadamshomes.com/all-floor-plans/wyndham-ii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/northbend-ii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/siena-2/',
        #         'https://johnnieadamshomes.com/all-floor-plans/springbrook-2/',
        #         'https://johnnieadamshomes.com/all-floor-plans/ashland/',
        #         'https://johnnieadamshomes.com/all-floor-plans/woodland-ii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/coronado/',
        #         'https://johnnieadamshomes.com/all-floor-plans/greystone-2/',
        #         'https://johnnieadamshomes.com/all-floor-plans/northbrook/',
        #         'https://johnnieadamshomes.com/all-floor-plans/sedona-ii/',
        #         'https://johnnieadamshomes.com/all-floor-plans/woodland/',
        #         'https://johnnieadamshomes.com/all-floor-plans/costello-ii/']
        #
        # for us in url:
        planurl = 'https://johnnieadamshomes.com/all-floor-plans/'
        yield scrapy.Request(url=planurl,callback=self.plan_ulr,dont_filter=True,meta={'sbdn':self.builderNumber})

    def plan_ulr(self,response):
        sbdn = response.meta['sbdn']
        links = response.xpath('//*[@class="vc_btn3-container vc_btn3-left vc_btn"]/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link,callback=self.plan_details, dont_filter=True,meta={'sbdn':sbdn})

    def plan_details(self, response):

        a = response.meta['sbdn']
        try:
            Type = 'SingleFamily'
        except Exception as e:
            print(e)

        try:
            PlanName = ''.join(response.xpath('//*[@class="wpb_text_column wpb_content_element  vc_column_text"]/div/p/span/strong/text()').extract()).strip()
            if not PlanName:
                PlanName = ''.join(re.findall(r'<h1><span style="font-size: 24pt; color: #493829;"><strong>(.*?)<br',response.text)).strip()
        except Exception as e:
            print(e)

        try:
            PlanNotAvailable = 0
        except Exception as e:
            print(e)

        try:
            PlanTypeName = 'Single Family'
        except Exception as e:
            print(e)

        try:
            BasePrice = ''.join(re.findall(r'Base Price: \$(\d+,\d+)',response.text)).replace(',','') or ''.join(re.findall(r'Base Price: \$(\d+,\d+)<',response.text)).replace(',','')
            #
            if not BasePrice.isdigit():
                BasePrice = 0

        except Exception as e:
            BasePrice = 0

        try:
            BaseSqft = ''.join(re.findall(r'Square Feet: (\d+,\d+)</span>|Square Feet: (\d+,\d+)|Square Feet: (\d+,\d+) </span>',response.text)[0]).replace(',','')
        except Exception as e:
            BaseSqft = 0

        try:
            Baths = ''.join(re.findall(r'Baths: (\d+)|Baths: (\d+)</span>|(\d+.\d+) Baths',response.text)[0])
            if '.' in Baths:
                Baths = Baths.split('.')[0]
                HalfBaths = 1
            else:
                Baths = Baths
                HalfBaths = 0
        except Exception as e:
            Baths = 0
            HalfBaths = 0

        try:
            Bedrooms = ''.join(re.findall(r'Bedrooms: (\d+)|Bedrooms: (\d+)</span>',response.text)[0])
        except Exception as e:
            Bedrooms = 0

        try:
            Garage = ''.join(re.findall(r'Garage: (\d+)-Car',response.text)[0])
            if not Garage:
                Garage = 0
        except Exception as e:
            print(e)

        try:
            Description = ' '.join(re.findall(r'<p><span style="font-size: 14pt;">(.*?)</span></p>',response.text)).replace('*','').strip()
        except Exception as e:
            print(str(e))
        try:
            # PN=response.meta['PN']

            # a = uuid.uuid4()
            PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
        except Exception as e:
            print(e)

        try:
            ElevationImage = response.xpath('//*[@class="wpb_wrapper"]/div/figure/div/img/@src').extract()
            if ElevationImage != []:
                ElevationImage = "|".join(ElevationImage).replace(',','|')
            else:
                ElevationImage = ''
        except Exception as e:
            print(e)

        try:
            PlanWebsite = response.url
        except Exception as e:
            print(e)

        # ----------------------- Don't change anything here --------------
        unique = str(PlanNumber) + str(a) # < -------- Changes here
        unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
        item = BdxCrawlingItem_Plan()
        item['Type'] = Type
        item['PlanNumber'] = PlanNumber
        item['unique_number'] = unique_number  # < -------- Changes here
        item['SubdivisionNumber'] = a
        item['PlanName'] = PlanName
        item['PlanNotAvailable'] = PlanNotAvailable
        item['PlanTypeName'] = PlanTypeName
        item['BasePrice'] = BasePrice
        item['BaseSqft'] = BaseSqft
        item['Baths'] = int(Baths)
        item['HalfBaths'] = HalfBaths
        item['Bedrooms'] = int(Bedrooms)
        item['Garage'] = Garage
        item['Description'] = Description.replace('   ',' ').replace('\xa0','')
        item['ElevationImage'] = ElevationImage
        item['PlanWebsite'] = PlanWebsite
        yield item

if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute("scrapy crawl johnnieadamshomes".split())
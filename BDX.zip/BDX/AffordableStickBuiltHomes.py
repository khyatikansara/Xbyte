# -*- coding: utf-8 -*-
import hashlib
import re

import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class AffordableStickBuiltHomesSpider(scrapy.Spider):
    name = 'AffordableStickBuiltHomes'
    allowed_domains = ['www.affordablestickbuilthomes.com']
    start_urls = ['https://www.affordablestickbuilthomes.com/']

    builderNumber = "62136"


    def parse(self, response):
        try:
            # IF you do not have Communities and you are creating the one
            # ------------------- If No communities found ------------------- #
            image_list = []
            gallery_link = response.xpath('//a[contains(@href,"gallery")]/@href').extract_first()
            res_gl = requests.get(url=gallery_link)
            response_gl = HtmlResponse(url=res_gl.url, body=res_gl.content)
            view_gallery = response_gl.xpath('//span[text()="VIEW GALLERY"]/../@href').extract()
            for view_gal in view_gallery:
                res_vg = requests.get(url=view_gal)
                response_vg = HtmlResponse(url=res_vg.url, body=res_vg.content)
                images_tmp = response_vg.xpath('//div[@class="thumbnailItem"]/@style').extract()
                for img in images_tmp:
                    img = re.findall(r'image:url\((.*?)\/v1\/',img)[0]
                    image_list.append(img)
            images = '|'.join(image_list)
            about_link = response.xpath('//a[contains(@href,"about-us")]/@href').extract_first()
            res_des = requests.get(url=about_link)
            response_des = HtmlResponse(url=res_des.url, body=res_des.content)
            SubDescription = ''.join(response_des.xpath('//p//span/text()').extract()[:2])
            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = ''
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = "No Sub Division"
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 0
            item['Street1'] = "1950 B Belmont Loop"
            item['City'] = "Woodland"
            item['State'] = "WA"
            item['ZIP'] = "98674"
            item['AreaCode'] = ""
            item['Prefix'] = ""
            item['Suffix'] = ""
            item['Extension'] = ""
            item['Email'] = ""
            item['SubDescription'] = SubDescription
            item['SubImage'] = images
            item['SubWebsite'] = ""
            item['AmenityType'] = ''
            yield item
            plan_link = response.xpath('//a[contains(@href,"floor-plan")]/@href').extract_first()
            yield scrapy.Request(url=plan_link, callback=self.parse_planlink, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_planlink(self,response):
        try:
            plan_links = response.xpath('//span[text()="VIEW PLAN"]/../@href').extract()
            plandetails = {}
            for plan_link in plan_links:
                yield scrapy.Request(url=plan_link, callback=self.plans_details, dont_filter=True,
                                    meta={'sbdn': self.builderNumber, 'PlanDetails': plandetails})
        except Exception as e:
            print(e)

    def plans_details(self,response):
        try:
            if response.url == 'https://www.affordablestickbuilthomes.com/plan-4308':
                print("stop")
            plandetails = response.meta['PlanDetails']
            try:
                Type = 'SingleFamily'
            except Exception as e:
                print(e)

            try:
                SubdivisionNumber = response.meta['sbdn']
            except Exception as e:
                print(e)

            try:
                PlanName = response.xpath('//h1/span/text()').extract_first()
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(bytes(PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % PlanNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                PlanTypeName = 'Single Family'
            except Exception as e:
                print(e)

            try:
                BasePrice = '0'
            except Exception as e:
                print(e)


            try:
                Baths = response.xpath('//span[contains(text(),"ath")]/text()').extract_first()
                tmp = re.findall(r"(\d+)", Baths)
                Baths = tmp[0]
                if len(tmp) > 1:
                    HalfBaths = 1
                else:
                    HalfBaths = 0
            except Exception as e:
                print(e)
                Baths = '0'
                HalfBaths = 0

            try:
                Bedrooms = response.xpath('//span[contains(text(),"Bedroom")]/text()').extract_first()
                Bedrooms = re.findall(r'(\d+)',Bedrooms)[0]
            except Exception as e:
                print(e)
                Bedrooms = '0'

            try:
                BaseSqft = response.xpath('//span[contains(text(),"sq ft")]/text()').extract_first()
                BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                ElevationImage_list = []
                elevation_list = response.xpath('//section//img')
                for ele in elevation_list:
                    if not ele.xpath('.//img[contains(@alt,"pdf.")]'):
                        ele_list = ele.xpath('./@src').extract_first()
                        ElevationImage_list.append(ele_list)
                ElevationImage = '|'.join(ElevationImage_list)
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.url
            except Exception as e:
                print(e)

            try:
                about_link = response.xpath('//a[contains(@href,"about-us")]/@href').extract_first()
                res_desc = requests.get(url=about_link)
                response_desc = HtmlResponse(url=res_desc.url, body=res_desc.content)
                Description = response_desc.xpath('//p//span/text()').extract()[3]
            except Exception as e:
                print(e)

            SubdivisionNumber = SubdivisionNumber #if subdivision is there
            #SubdivisionNumber = self.builderNumber #if subdivision is not available
            unique = str(PlanNumber)+str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails[PlanName] = unique_number
            try:
                item = BdxCrawlingItem_Plan()
                item['Type'] = Type
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = PlanTypeName
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = 0
                item['Description'] = Description
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl AffordableStickBuiltHomes".split())
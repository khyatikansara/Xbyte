# -*- coding: utf-8 -*-
import hashlib
import re
import json
import scrapy
import requests
from scrapy.http import HtmlResponse
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class TriPointHomesSpider(scrapy.Spider):
    name = 'tripointhomes'
    allowed_domains = []
    start_urls = ['https://www.alientoliving.com/']

    builderNumber = "62664"

    def parse(self, response):
        try:
            image_list = ['https://www.alientoliving.com/wp-content/uploads/2016/11/Arista-2-featured-1500x893-homepage.jpg',
                          'https://www.alientoliving.com/wp-content/uploads/2016/11/community-location-aliento.jpg',
                          'https://www.alientoliving.com/wp-content/uploads/2016/11/CMF-5753-2.jpg',
                          'https://www.alientoliving.com/wp-content/uploads/2016/11/nature-1.png',
                          'https://www.alientoliving.com/wp-content/uploads/2016/11/CMF-5718-1.jpg']

            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = ''
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = "No Sub Division"
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 0
            item['Street1'] = "25227 Oak Crest Drive"
            item['City'] = "Santa Clarita"
            item['State'] = "CA"
            item['ZIP'] = "91387"
            item['AreaCode'] = "661"
            item['Prefix'] = "243"
            item['Suffix'] = "0654"
            item['Extension'] = ""
            item['Email'] = "newhomesla@pardeehomes.com"
            item['SubDescription'] = "A new home community in an ideal location, close to work, retail, entertainment and the LA lifestyle, yet tucked away in its own exclusive enclave. We’re close to I-5 via the 14/Antelope Valley Freeway as well as shopping and dining."
            item['SubImage'] = '|'.join(image_list)
            item['SubWebsite'] = ""
            item['AmenityType'] = ''
            yield item

            yield scrapy.Request(url='https://www.alientoliving.com/find-a-home/', callback=self.process_plan_link, dont_filter=True)
        except Exception as e:
            print(e)

    def process_plan_link(self, response):
        try:
            plandetails = {}
            divs = response.xpath('//div[@class="contentBlock"]')
            for div in divs:
                text_data = div.xpath('..//div[contains(@class,"content-text")]//text()').extract()
                for text in text_data:
                    text = text.strip().replace(',', '')
                    if 'Price' in text:
                        if 'Million' in text:
                            BasePrice = re.findall(r"(\d+)", text)[0] + '000000'
                        else:
                            BasePrice = re.findall(r"(\d+)", text)[0]
                PlanWebsite = div.xpath('..//a/@href').extract_first()
                yield scrapy.Request(url=PlanWebsite, callback=self.plans_details,dont_filter=True,meta={'PlanDetails': plandetails, 'BasePrice':BasePrice})
        except Exception as e:
            print(e)

    def plans_details(self, response):
        try:
            plandetails = response.meta['PlanDetails']
            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                Type = 'SingleFamily'
            except Exception as e:
                print(e)

            try:
                PlanTypeName = 'Single Family'
            except Exception as e:
                print(e)

            divs = response.xpath('//div[@class="contentBlock"]')
            for div in divs:

                try:
                    PlanName = div.xpath('..//h3/text()').extract_first()
                except Exception as e:
                    print(e)

                try:
                    PlanNumber = int(hashlib.md5(bytes(PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                    f = open("html/%s.json" % PlanNumber, "wb")
                    f.write(response.body)
                    f.close()
                except Exception as e:
                    print(e)

                try:
                    ElevationImage = div.xpath('..//figure/img/@src').extract_first()
                except Exception as e:
                    print(e)

                try:
                    PlanWebsite = response.url
                except Exception as e:
                    print(e)

                try:
                    BasePrice = response.meta['BasePrice']
                except Exception as e:
                    print(e)

                try:
                    text_data = div.xpath('..//div[contains(@class,"content-text")]//text()').extract()
                    for text in text_data:
                        text = text.strip().replace(',','')
                        if 'sq ft' in text:
                            if '-' in text:
                                BaseSqft = re.findall(r"(\d+)", text)[1]
                            else:
                                BaseSqft = re.findall(r"(\d+)", text)[0]
                        if 'Bedroom' in text:
                            if '-' in text:
                                Bedrooms = re.findall(r"(\d+)", text)[1]
                            else:
                                Bedrooms = re.findall(r"(\d+)", text)[0]
                        if 'Bath' in text:
                            if '-' in text:
                                Baths_tmp = text.split('-')
                                Baths = re.findall(r"(\d+)", Baths_tmp[1])
                                if len(Baths) == 1:
                                    Baths = Baths[0]
                                else:
                                    Baths = '.'.join(Baths)
                            else:
                                Baths = re.findall(r"(\d+)", text)[0]
                            tmp = re.findall(r"(\d+)", Baths)
                            Baths = tmp[0]
                            if len(tmp) > 1:
                                HalfBaths = 1
                            else:
                                HalfBaths = 0
                        if 'Garage' in text:
                            if '-' in text:
                                Garage = re.findall(r"(\d+)", text)[1]
                            else:
                                Garage = re.findall(r"(\d+)", text)[0]
                except Exception as e:
                    print(e)

                # SubdivisionNumber = SubdivisionNumber  # if subdivision is there
                SubdivisionNumber = self.builderNumber  # if subdivision is not available
                unique = str(PlanNumber) + str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                plandetails[PlanName] = unique_number
                try:
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = BasePrice
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = Baths
                    item['HalfBaths'] = HalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = Garage
                    item['Description'] = 'It’s a modern, unique take on timeless, resort-style living. Aliento means Breath in Spanish. And it’s a place to catch yours.'
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = PlanWebsite
                    yield item
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl tripointhomes".split())

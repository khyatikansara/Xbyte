# -*- coding: utf-8 -*-
import hashlib
import os

import requests
import scrapy
import re

from w3lib.http import basic_auth_header

from BDX_Crawling.export_xml import genxml
import BDX_Crawling.database_config as dbc
from BDX_Crawling.items import BdxCrawlingItem_Builder, BdxCrawlingItem_Corporation, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec, BdxCrawlingItem_subdivision


class MhbwySpiderSpider(scrapy.Spider):
    name = 'mhbwy_spider'
    # allowed_domains = ['https://www.mhbwy.com/']
    # start_urls = ['https://www.mhbwy.com']

    builderNumber = "30203388572341822129340545842"

    def start_requests(self):
        url = "https://www.mhbwy.com/"
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9',
            # 'Cookie': '__utma=23908710.1421065785.1622537440.1622537440.1622537440.1; __utmc=23908710; __utmz=23908710.1622537440.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __utmt=1; __utmb=23908710.2.10.1622537440',
            # 'Host': 'mhbwy.com',
            'Upgrade-Insecure-Requests': '1',
            'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us','0gi0pioy3oey'),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
        }
        yield scrapy.Request(url=url, callback=self.parse, headers=self.headers, meta={'proxy': 'zproxy.lum-superproxy.io:22225'})

    def parse(self, response):
        if response.url != "https://mhbwy.com/":
            yield scrapy.Request(url="https://mhbwy.com/", callback=self.parse, headers=self.headers, meta={'proxy': 'zproxy.lum-superproxy.io:22225'})
        else:
            # IF you do not have Communities and you are creating the one
            # ------------------- If No communities found ------------------- #

            f = open("html/%s.html" % self.builderNumber, "wb")
            f.write(response.body)
            f.close()
            image_list = ['https://mhbwy.com/files/2021/04/Templeton.jpg', 'https://mhbwy.com/files/2021/04/Crown.jpg', 'https://mhbwy.com/files/2021/04/Templeton3.jpg', 'https://mhbwy.com/files/2021/04/Fireplace2.jpg', 'https://mhbwy.com/files/2021/04/3-BedroomTwin.jpg']
            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = ''
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = "No Sub Division"
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 0
            item['Street1'] = "140 Walterscheid Boulevard"
            item['City'] = "Cheyenne"
            item['State'] = "WY"
            item['ZIP'] = "82007"
            item['AreaCode'] = "307"
            item['Prefix'] = "778"
            item['Suffix'] = "0400"
            item['Extension'] = ""
            item['Email'] = "brianna@mhbwy.com"
            item['SubDescription'] = "We strive to build the highest-quality new homes at a price that’s attainable. Through our partners and sister companies, we have the unique opportunity to take care of everything under one roof—including HVAC, concrete, excavation, paint and drywall. This saves us money, and we pinch our pennies in order to pass on these savings to you."
            item['SubImage'] = "|".join(image_list)
            item['SubWebsite'] = "https://www.mhbwy.com/"
            item['AmenityType'] = ''
            yield item


            # ------------------- If Plan Found ------------------------- #
            urls = list(set(response.xpath('//li[@id="menu-item-511861"]/ul[@class="sub-menu"]/li/a/@href').getall()))
            all_links = list(set(urls))
            for url in all_links:
                if url != 'https://mhbwy.com/our-neighborhoods/':
                    yield scrapy.Request(url=url, callback=self.parse_plan,headers=self.headers, meta={'url':url, 'SubdivisionNumber':self.builderNumber, 'proxy': 'zproxy.lum-superproxy.io:22225'})

    def parse_plan(self, response):
        if response.url == "https://mhbwy.com/site-cannot-be-accessed-from-your-current-location.html":
            yield scrapy.Request(url=response.meta['url'], callback=self.parse_plan, headers=self.headers, meta=response.meta)
        else:
            links = response.xpath('//section[@id="section_2"]//article/a/@href').extract()
            for link in links:
                if 'https://mhbwy.com' in link:
                    link = link
                else:
                    link = 'https://mhbwy.com' + link
                yield scrapy.Request(url=link, callback=self.plan_details, headers=self.headers,
                                     meta={'url':link, 'SubdivisionNumber': self.builderNumber,'proxy': 'zproxy.lum-superproxy.io:22225','Type':response.url})

    def plan_details(self, response):
        # Plans == > available plans in that communities
        # ------------------------------------- Extracting Plans ------------------------- #
        if response.url == "https://mhbwy.com/site-cannot-be-accessed-from-your-current-location.html":
            yield scrapy.Request(url=response.meta['url'], callback=self.plan_details, headers=self.headers, meta=response.meta)
        else:
            try:
                Type = response.meta['Type']
                if "single-family" in Type:
                    Type = "SingleFamily"
                elif "multi-family" in Type:
                    Type = "MultiFamily"
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
            except Exception as e:
                print(e)

            try:
                SubdivisionNumber = response.meta['SubdivisionNumber']
            except Exception as e:
                print(e)

            try:
                PlanName = response.xpath('//h1[@class="tsI_hd"]/text()').extract_first(default='').strip()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                PlanTypeName = response.xpath('//h2[@class="tsI_sh"]/text()').extract_first(default='SingleFamily').strip()
                if "SINGLE-FAMILY" in PlanTypeName:
                    PlanTypeName = "Single Family"
                elif "MULTI-FAMILY" in PlanTypeName:
                    PlanTypeName = "Condominium"
            except Exception as e:
                print(e)

            try:
                BasePrice = 0
            except Exception as e:
                print(e)

            try:
                BaseSqft = str(response.xpath('//th[text()="SQUARE FOOTAGE"]/../td/text()').extract_first(default=0))
                BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                Baths = str(response.xpath('//th[text()="BATHS"]/../td/text()').extract_first(default=0))
                b = Baths.split(' ')
                if len(b)>1:
                    Baths = b[-1]
                if 'To' in Baths:
                    Baths = Baths[:1]
                if 'to' in Baths:
                    Baths = Baths[:1]
                tmp = re.findall(r"(\d+)", Baths)
                Baths = tmp[0]
                if len(tmp) > 1:
                    HalfBaths = 1
                else:
                    HalfBaths = 0
            except Exception as e:
                print(e)

            try:
                Bedrooms = str(response.xpath('//th[text()="BEDROOMS"]/../td/text()').extract_first(default=0))
                Bedrooms = re.findall(r"(\d+)", Bedrooms)
                if len(Bedrooms) >1:
                    Bedrooms = Bedrooms[1]
                else:
                    Bedrooms = Bedrooms[0]
            except Exception as e:
                print(e)

            try:
                Garage = str(response.xpath('//th[text()="GARAGE"]/../td/text()').extract_first(default=0))
                if Garage != 0:
                    Garage = re.findall(r"(\d+)", Garage)[0]
            except Exception as e:
                print(e)

            try:
                Description = response.xpath('//h2[text()="Highlights"]/../ul/li/text()').extract()
                Description = ','.join(Description)
            except Exception as e:
                print(e)

            try:
                I1,I2=[],[]
                Image1 = response.xpath('//article/@data-image').extract()
                if Image1 == []:
                    Image1 = response.xpath('//figure/@data-image').extract()
                if Image1 != []:
                    for image in Image1:
                        I1.append(f"https://mhbwy.com{image}")
                    ElevationImage = '|'.join(I1)
                else:
                    print("STOP")
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.url
            except Exception as e:
                print(e)

            # ----------------------- Don't change anything here --------------
            unique = str(PlanNumber) + str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            try:
                item = BdxCrawlingItem_Plan()
                item['Type'] = Type.replace(' ','')
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = PlanTypeName
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = int(Garage)
                item['Description'] = Description
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item
            except Exception as e:
                print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl mhbwy_spider".split())

'''
https://www.mhbwy.com/wp-content/uploads/2016/10/Westgate-4-plex-front-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-08-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-09-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-10-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-21-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-22-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-01-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-23-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-24-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-04-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-25-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-05-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-02-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-03-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-16-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-15-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-17-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-19-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-20-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-18-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-12-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-13-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-14-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-06-150x150.jpg|https://www.mhbwy.com/wp-content/uploads/2016/10/westgate-4plex-07-150x150.jpg|https://www.mhbwy.com
'''
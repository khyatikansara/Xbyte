import hashlib
import re

import scrapy

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan


class BosgraafHomesSpider(scrapy.Spider):
    name = 'carolina'
    allowed_domains = []
    start_urls = ['http://www.cshaiken.com/']

    builderNumber = "542641597756347090342768959658"

    def parse(self, response):

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = '230 Village Green Blvd.'
        item['City'] = 'Aiken'
        item['State'] = 'SC'
        item['ZIP'] = '29803'
        item['AreaCode'] = "803"
        item['Prefix'] = "643"
        item['Suffix'] = "0136"
        item['Extension'] = ""
        item['Email'] = ""
        item['SubDescription'] = ''.join(response.xpath('//div[@class="wrapper"]/div/p/text()').extract())
        item['SubImage'] = '|'.join(response.xpath('//div[@class="rsContent"]/a/@href').extract())
        item['SubWebsite'] = 'http://cshaiken.com/'
        item['AmenityType'] = ""
        yield item

        link = 'http://www.cshaiken.com/collections/'
        yield scrapy.Request(url=link, callback=self.mid)


    def mid(self, response):
        links = response.xpath('//div[@class="grid-objects wrapper collections"]/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.plans)
            # yield scrapy.Request(url='http://www.cshaiken.com/collection/courtyard/', callback=self.plans)
            # yield scrapy.Request(url='http://www.cshaiken.com/collection/village-home/', callback=self.plans)
            # yield scrapy.Request(url='http://www.cshaiken.com/collection/meadows-collection/', callback=self.plans)
            # yield scrapy.Request(url='http://www.cshaiken.com/collection/quick-move-in/', callback=self.plans)


    def plans(self, response):
        links = response.xpath('//div[@class="floorplans"]/article')
        for link in links:
            PlanName = link.xpath('./div/h2/text()').extract_first(default='').strip()

            PlanNumber = int(hashlib.md5(bytes(str(PlanName) + response.url, "utf8")).hexdigest(), 16) % (10 ** 30)

            SubdivisionNumber = self.builderNumber

            site_text = ''.join(link.xpath('.//div[@class="floorplan-description"]//text()').extract())

            try:BasePrice = re.findall(r'\$(\d+,\d+)', site_text)[0].replace(',','').strip()
            except Exception as e:print(e)

            try:
                BaseSqft = link.xpath('./div//ul/li[contains(text(),"Square")]/text()').extract_first(default='')
                if ',' in BaseSqft:
                    BaseSqft = re.findall(r'(\d+,\d+)', BaseSqft)[0].replace(',','').strip()
                elif '.' in BaseSqft:
                    BaseSqft = re.findall(r'(\d+.\d+)', BaseSqft)[0].replace('.','').strip()
            except:BaseSqft = ''

            try:
                Baths = link.xpath('.//div[@class="floorplans"]/article/div//ul/li[contains(text(),"Baths")]/text()|//div[@class="floorplans"]/article/div//ul/li[contains(text(),"Bathrooms")]/text()').extract_first(default='')
                Baths = re.findall(r'(\d+)', Baths)[0].strip()
            except:Baths = 0

            try:
                HalfBaths = link.xpath('./div//ul/li[contains(text(),"Half")]/text()').extract_first(default='')
                HalfBaths = re.findall(r'(\d+)', HalfBaths)[0].strip()
            except:HalfBaths = 0

            try:
                Bedrooms = link.xpath('./div//ul/li[contains(text(),"Bedrooms")]/text()').extract_first(default='')
                Bedrooms = re.findall(r'(\d+)', Bedrooms)[0].strip()
            except:
                Bedrooms = 0

            try:Description = link.xpath('./div//p/text()').extract_first(default='')
            except:Description = ''

            try:Images = '|'.join(link.xpath('.//div/img/@src|.//div[@class="floorplan-button"]/a/@href').extract())
            except Exception as e:print(e)

            try:
                unique = str(PlanNumber) + str(SubdivisionNumber)  # < -------- Changes here
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                item = BdxCrawlingItem_Plan()
                item['Type'] = 'SingleFamily'
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number  # < -------- Changes here
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = 0
                item['PlanTypeName'] = 'Single Family'
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = 0
                item['Description'] = Description
                item['ElevationImage'] = Images
                item['PlanWebsite'] = response.url
                yield item
            except Exception as e:print(e)

if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl carolina'.split())
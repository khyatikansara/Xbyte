# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
import requests
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class DwelldesignedconstructionSpider(scrapy.Spider):
    name = 'dwelldesignedconstruction'
    allowed_domains = []
    start_urls = ['http://www.dwelldesignedconstruction.com/']

    builderNumber = "822370049488303348379378792603"

    def parse(self, response):

        # ------------------- If communities found ---------------------- #
        # ------------------- Creating Communities ---------------------- #
        com_check = response.xpath('//*[@id="mainNavigation"]//div[contains(text(),"Communities")]/ancestor::div[1]')
        if com_check!=[]:
            comch = com_check.xpath('.//*[@class="collection"]/a/@href').extract()
        for link in comch:
            res = requests.get("https://www.dwelldesignedconstruction.com"+str(link))
            response = HtmlResponse(url=res.url,body=res.content)

            subdivisonName = response.xpath('//meta[@itemprop="name"]/@content').extract_first(default='').split('—')[0].strip()
            subdivisonNumber = int(hashlib.md5(bytes(subdivisonName,"utf8")).hexdigest(), 16) % (10 ** 30)

            f = open("html/%s.html" % subdivisonNumber, "wb")
            f.write(response.body)
            f.close()

            item2 = BdxCrawlingItem_subdivision()
            item2['sub_Status'] = "Active"
            item2['SubdivisionName'] = subdivisonName
            item2['SubdivisionNumber'] = subdivisonNumber
            item2['BuilderNumber'] = self.builderNumber
            item2['BuildOnYourLot'] = 0
            item2['OutOfCommunity'] = 1
            item2['Street1'] = '1900 EAST MAIN STREET'
            item2['City'] = 'CHATTANOOGA'
            item2['State'] = 'TN'
            item2['ZIP'] = '37404'
            item2['AreaCode'] = '423'
            item2['Prefix'] = '207'
            item2['Suffix'] = '4510'
            item2['Extension'] = ""
            item2['Email'] = "lydia@dwelldesignedconstruction.com"
            item2['SubDescription'] = ''.join(response.xpath('//*[@id="content"]//*[@class="sqs-block-content"]//p[1]//text()').extract())
            item2['SubImage'] = ""
            item2['SubWebsite'] = response.url
            item2['AmenityType'] = ''
            yield item2

            print(response.url)
            plan_check = response.xpath('//*[@id="content"]//*[@class="sqs-block-content"]//p[3]/a[contains(text(),"here")]/@href').extract_first(default='').strip()
            if plan_check=='':
                plan_check = response.xpath('//*[@id="content"]//*[@class="sqs-block-content"]//a[contains(text(),"here")]/@href').extract_first(default='').strip()
                if plan_check == '':
                    continue
            head_p = {'Host': 'www.dwelldesignedconstruction.com',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-GB,en;q=0.5',
                        'Accept-Encoding': 'gzip, deflate, br'}
            resp = requests.get(plan_check, headers=head_p)
            response_p = HtmlResponse(url=resp.url,body=resp.content)

            f = open("html/%s.html" % subdivisonNumber + '_' + plan_check.split('/')[-1], "wb")
            f.write(response_p.body)
            f.close()

            plan_links_row = response_p.xpath('//nav[@class="folder-nav"]//a/@href').extract()
            subdivisonName_new = subdivisonName.split(' ')[0]
            for link in plan_links_row:
                name_p = response_p.xpath('//a[contains(@href,"'+str(link)+'")]/text()').extract_first(default='').strip()
                if subdivisonName_new.title() in name_p:
                    resplan = requests.get("https://www.dwelldesignedconstruction.com"+link, headers=head_p)
                    response_plan = HtmlResponse(url=resplan.url, body=resplan.content)

                    f = open("html/%s.html" % subdivisonNumber + '_' + link.split('/')[-1], "wb")
                    f.write(response_plan.body)
                    f.close()

                    try:
                        PlanName = name_p
                        Type = 'SingleFamily'
                        PlanNotAvailable = 0
                        PlanTypeName = 'Single Family'
                        BasePrice = 0

                    except Exception as e:
                        print(e)

                    try:
                        Description = response_plan.xpath('//*[@id="content"]//*[@class="sqs-block-content"]//p[1]/text()').extract_first(default='').strip()
                    except Exception as e:
                        print(e)

                    try:
                        BaseSqft = re.findall(r'\s(\d+)\ssquare feet', Description)
                        if BaseSqft == []:
                            BaseSqft = 0
                        else:
                            BaseSqft = BaseSqft[0]

                        Bedrooms = re.findall('\s(\d)\s\wedroom',Description)
                        if Bedrooms!=[]:
                            Bedrooms=Bedrooms[0].strip()
                        else:
                            Bedrooms=0

                        bath = re.findall('\w.*\s(\d.*)\s+bath',Description)
                        if bath!=[]:
                            temp = bath[0].strip()
                            Baths = temp[0].strip()
                            if len(temp) > 1:
                                HalfBaths = 1
                            else:
                                HalfBaths = 0
                        else:
                            Baths = HalfBaths=0

                        garage = re.findall('(\d+)\s?car garage',Description)
                        if garage!=[]:
                            Garage = garage[0].strip()
                        else:
                            Garage = 0
                    except Exception as e:
                        print(e)

                    try:
                        ElevationImage = response_plan.xpath('//img[@class="thumb-image"]/@data-src').extract_first(default='').strip()
                        PlanWebsite = response_plan.url
                    except Exception as e:
                        print(e)


                    # ------------------- If Plan Found found ------------------------- #

                    PlanNumber = int(hashlib.md5(bytes(response_plan.url+PlanName,"utf8")).hexdigest(), 16) % (10 ** 30)
                    SubdivisionNumber = subdivisonNumber
                    unique = str(PlanNumber)+str(SubdivisionNumber)
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)

                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = BasePrice
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = Baths
                    item['HalfBaths'] = HalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = Garage
                    item['Description'] = Description
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = PlanWebsite
                    yield item

        # --------------------------------------------------------------------- #


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl dwelldesignedconstruction --nolog".split())

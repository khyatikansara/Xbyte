# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
from scrapy.utils.response import open_in_browser

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class KerleyHomeSpider(scrapy.Spider):
    name = 'kerley_home'
    allowed_domains = ['http://www.kerleyhomes.com/']
    start_urls = ['http://www.kerleyhomes.com/']

    builderNumber = "36606"


    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        final_images = []
        image_list = response.xpath('//*[@id="mega-slider"]//img/@src').extract()
        for image_tmp in image_list:
            image = self.start_urls[0] + image_tmp
            final_images.append(image)
        image = '|'.join(final_images)
        images = image.strip('|')
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "3801 Kerley Drive"
        item['City'] = "Yuma"
        item['State'] = "AZ"
        item['ZIP'] = "85365"
        item['AreaCode'] = "928"
        item['Prefix'] = "726"
        item['Suffix'] = "5496"
        item['Extension'] = ""
        item['Email'] = "info@kerleyhomes.com"
        item['SubDescription'] = "The Kerley family has been building quality homes in Arizona for over 35 years. Owner Sean Kerley continues the tradition of undisputed quality construction. A Kerley Home combines elegance and energy-efficiency while offering buyers a wide range of options, allowing for customization while preserving the economic advantages of buying a tract home.Visit our model home to speak with a Kerley representative and discover the beauty, comfort, and value of a Kerley Home."
        item['SubImage'] = images
        item['SubWebsite'] = response.url
        item['AmenityType'] = ''
        yield item
        try:
            links = response.xpath('//a[contains(text(),"Models ")]/../ul/li/a/@href').extract()
            plandetains = {}
            for link in links:
                yield scrapy.Request(url="http://www.kerleyhomes.com/"+link,callback=self.plans_details,meta={'sbdn':self.builderNumber,'PlanDetails':plandetains},dont_filter=True)
        except Exception as e:
            print(e)

    def plans_details(self,response):
        plandetails = response.meta['PlanDetails']
        try:
            Type = 'SingleFamily'
        except Exception as e:
            print(e)

        try:
            SubdivisionNumber = response.meta['sbdn']
        except Exception as e:
            print(e)

        try:
            PlanName = response.xpath('//h2/text()').extract_first(default='').strip()
            if PlanName:
                PlanName = PlanName.strip()
        except Exception as e:
            print(e)

        try:
            PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
            f = open("html/%s.html" % PlanNumber, "wb")
            f.write(response.body)
            f.close()
        except Exception as e:
            print(e)

        try:
            PlanNotAvailable = 0
        except Exception as e:
            print(e)

        try:
            PlanTypeName = 'Single Family'
        except Exception as e:
            print(e)

        try:
            BasePrice = '0'
        except Exception as e:
            print(e)
        featurs = response.xpath('//h2[contains(text(),"Features")]/..//ul')
        try:
            Baths = str(featurs.xpath('./li[contains(text(),"Baths")]/text()').extract_first(default='0').strip())
            Baths = re.findall('^(.*?) Baths', Baths)[0]
            tmp = re.findall(r"(\d+)", Baths)
            Baths = tmp[0]
            if len(tmp) > 1:
                HalfBaths = 1
            else:
                HalfBaths = 0
        except Exception as e:
            print(e)

        try:
            Bedrooms = str(featurs.xpath('./li[contains(text(),"Bedrooms")]/text()').extract_first(default='0').strip())
            Bedrooms = re.findall('^(.*?) Bedrooms', Bedrooms)[0]
            Bedrooms = re.findall(r'(\d+)',Bedrooms)[0]
        except Exception as e:
            print(e)

        try:
            Garage = featurs.xpath('./li[contains(text(),"Garage")]/text()').extract_first(default='0')
            Garage = re.findall(r"(\d+)", Garage)[0]
            BaseSqft = str(featurs.xpath('./li[contains(text(),"SqFt")]/text()').extract_first(default='0').strip()).replace(',','')
            BaseSqft = re.findall('^(.*?) SqFt', BaseSqft)[0]
        except Exception as e:
            print(e)

        try:
            Description = 'The Kerley family has been building quality homes in Arizona for over 35 years. Owner Sean Kerley continues the tradition of undisputed quality construction. A Kerley Home combines elegance and energy-efficiency while offering buyers a wide range of options, allowing for customization while preserving the economic advantages of buying a tract home.'
        except Exception as e:
            print(e)

        try:
            ElevationImage = 'http://www.kerleyhomes.com/'+response.xpath('//li/img/@src').extract_first()
        except Exception as e:
            print(e)

        try:
            PlanWebsite = response.url
        except Exception as e:
            print(e)

        SubdivisionNumber = SubdivisionNumber #if subdivision is there
        #SubdivisionNumber = self.builderNumber #if subdivision is not available
        unique = str(PlanNumber)+str(SubdivisionNumber)
        unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
        plandetails[PlanName] = unique_number
        item = BdxCrawlingItem_Plan()
        item['Type'] = Type
        item['PlanNumber'] = PlanNumber
        item['unique_number'] = unique_number
        item['SubdivisionNumber'] = SubdivisionNumber
        item['PlanName'] = PlanName
        item['PlanNotAvailable'] = PlanNotAvailable
        item['PlanTypeName'] = PlanTypeName
        item['BasePrice'] = BasePrice
        item['BaseSqft'] = BaseSqft
        item['Baths'] = Baths
        item['HalfBaths'] = HalfBaths
        item['Bedrooms'] = Bedrooms
        item['Garage'] = Garage
        item['Description'] = Description
        item['ElevationImage'] = ElevationImage
        item['PlanWebsite'] = PlanWebsite
        yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl kerley_home".split())
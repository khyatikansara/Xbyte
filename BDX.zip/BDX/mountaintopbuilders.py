import re
import os
import hashlib
import scrapy
from BDX_Crawling.items import BdxCrawlingItem_Plan, BdxCrawlingItem_subdivision

class MountainTopBuildersSpider(scrapy.Spider):
    name = 'mountaintopbuilders'
    allowed_domains = []
    start_urls = ['https://www.mountaintopbuildersinc.com/']

    builderNumber = '644518811549486893269247707965'

    def parse(self, response):

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = 'No Sub Division'
        item['SubdivisionNumber'] = ''
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 1
        item['Street1'] = "67 County Road 524"
        item['City'] = "Tabernash"
        item['State'] = "CO"
        item['ZIP'] = "80478"
        item['AreaCode'] = '970'
        item['Prefix'] = '726'
        item['Suffix'] = '0155'
        item['Extension'] = ""
        item['Email'] = "info@mountaintopbuildersinc.com"
        item['SubDescription'] = response.xpath('//*[@class="col-sm-8 col-lg-7 text-left"]//p/text()').get()
        item['SubImage'] = ''
        item['SubWebsite'] = response.url
        item['AmenityType'] = ''
        yield item


        # ------------------------------------ PLANS----------------------------#

        plan_urls = response.xpath('//*[@class="dropdown-menu"]/li/a/@href').extract()[1:]
        for plan in plan_urls:
            plans = 'https://www.mountaintopbuildersinc.com/' + plan
            yield scrapy.Request(url=plans, callback=self.plans_details,dont_filter=True, meta={'sbdn': item['SubdivisionNumber']})

    def plans_details(self, response):
        # print(response.url)

        # ------------------------------------- Extracting Plans ------------------------- #
        site_text = response.text

        try:
            Type = 'SingleFamily'
        except Exception as e:
            print(e)

        try:
            PlanNumber = int(hashlib.md5(bytes(response.url,"utf8")).hexdigest(), 16) % (10 ** 30)
        except Exception as e:
            print(e)

        try:
            SubdivisionNumber = response.meta['sbdn']
        except Exception as e:
            print(e)

        try:
            PlanNotAvailable = 0
        except Exception as e:
            print(e)

        try:
            PlanTypeName = 'Single Family'
        except Exception as e:
            print(e)

        try:
            BasePrice = 0.00
        except Exception as e:
            print(e)

        try:
            PlanWebsite = response.url
        except Exception as e:
            print(e)

        try:
            PlanName = response.xpath('//*[@class="bodyTitles"]/text()').extract_first()
            PlanName = PlanName.split('-')[0]
            PlanName = PlanName.strip()
            # print(PlanName)
        except Exception as e:
            print(e)

        try:
            BaseSqft1 = response.xpath('//*[@class="bodyHighlightProjDetails"]/text()').extract_first()
            BaseSqft = re.findall(r'(\d+\,\d+)', BaseSqft1)[0]
            BaseSqft = re.sub(',','',BaseSqft)
            BaseSqft = BaseSqft.strip()
        except:
            BaseSqft = 0

        Description = ''

        Baths = 0


        try:
            Bedrooms1 = response.xpath('//*[@class="bodyHighlightProjDetails"]/text()[2]').extract_first(default='')
            Bedrooms = re.findall(r'(\d+) Bedrooms', Bedrooms1)[0]
        except:
            Bedrooms = 0

        try:
            Garage1 = response.xpath('//*[@class="bodyHighlightProjDetails"]/text()[2]').extract_first(default='')
            Garage = re.findall('Garage', Garage1)
            if Garage != []:
                Garage = 1
            else:
                Garage = 0.00
        except:
            Garage = 0.00

        try:
            ElevationImages = []
            imagess = response.xpath('//*[@id="carousel"]/li/@data-preview').extract()
            for imgs in imagess:
                images = 'https://www.mountaintopbuildersinc.com/' + imgs
                ElevationImages.append(images)
            ElevationImage = "|".join(ElevationImages)
        except Exception as e:
            print(e)


        # ----------------------- Don't change anything here --------------
        unique = str(PlanNumber)+str(SubdivisionNumber)   # < -------- Changes here
        unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
        item = BdxCrawlingItem_Plan()
        item['Type'] = Type
        item['PlanNumber'] = PlanNumber
        item['unique_number'] = unique_number  # < -------- Changes here
        item['SubdivisionNumber'] = self.builderNumber
        item['PlanName'] = PlanName
        item['PlanNotAvailable'] = PlanNotAvailable
        item['PlanTypeName'] = PlanTypeName
        item['BasePrice'] = BasePrice
        item['BaseSqft'] = BaseSqft
        item['Baths'] = Baths
        item['HalfBaths'] = 0
        item['Bedrooms'] = Bedrooms
        item['Garage'] = Garage
        item['Description'] = Description
        item['ElevationImage'] = ElevationImage
        item['PlanWebsite'] = PlanWebsite
        yield item
        # --------------------------------------------------------------------- #


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl mountaintopbuilders".split())
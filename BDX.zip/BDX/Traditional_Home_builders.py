# -*- coding: utf-8 -*-
import hashlib
import re

import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class TraditionalHomebuildersSpider(scrapy.Spider):
    name = 'Traditional_Home_builders'
    allowed_domains = ['www.traditionalhomebuilders.com/']
    start_urls = ['https://traditionalhomebuilders.com/gallery.php']

    builderNumber = "19792"


    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        image_list = []
        gallary_list = ['https://traditionalhomebuilders.com/custom-home-gallery.php','https://traditionalhomebuilders.com/community-home-gallery.php']
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cookie': '_ga=GA1.1.1277658114.1617448444; _ga_444LHRQ1V4=GS1.1.1617787068.4.1.1617787431.0',
            'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
        }
        for gallary_link in gallary_list:
            res_gl = requests.get(url=gallary_link,headers=headers)
            response_gl = HtmlResponse(url=res_gl.url, body=res_gl.content)

        # images = ''
            images = response_gl.xpath('//a[@class="gallery-image"]/@href').extract()
            for img in images:
                img = "https://traditionalhomebuilders.com/" + img
                image_list.append(img)
        # for i in image:
        #     images = images + self.start_urls[0] + i + '|'
        images = '|'.join(image_list)
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "1304 Professional Drive, Suite A"
        item['City'] = "Myrtle Beach"
        item['State'] = "SC"
        item['ZIP'] = "29577"
        item['AreaCode'] = "843"
        item['Prefix'] = "839"
        item['Suffix'] = "3888"
        item['Extension'] = ""
        item['Email'] = "leighthi@gmail.com"
        item['SubDescription'] = "Traditional Homebuilders, Inc, locally and owned and operated by Robert Hughes and Warren Smith, has earned a reputation as one of the finest builders in the Carolinas. For two decades, Traditional Homebuilders has been driven by 2 things; your satisfaction and the old saying “it’s what’s inside that counts”."
        item['SubImage'] = images
        item['SubWebsite'] = ""
        item['AmenityType'] = ''
        yield item
        try:
            links = ['https://traditionalhomebuilders.com/the-cape.php','https://traditionalhomebuilders.com/cipriana-park.php']
            plandetains = {}
            for link in links:
                yield scrapy.Request(url=str(link), callback=self.plans_details, dont_filter=True, meta={'sbdn':self.builderNumber,'PlanDetails':plandetains})
        except Exception as e:
            print(e)

    # def parse_planlink(self,response):
    #     try:
    #         links = response.xpath('//h3/a/@href').extract()
    #         plandetains = {}
    #         for link in links:
    #             yield scrapy.Request(url=link,callback=self.plans_details, meta={'sbdn':self.builderNumber,'PlanDetails':plandetains},dont_filter=True)
    #     except Exception as e:
    #         print(e)

    def plans_details(self,response):
        divs = response.xpath('//div[@class="floor-plans-block"]')
        for div in divs:
            plandetails = response.meta['PlanDetails']
            try:
                Type = 'SingleFamily'
            except Exception as e:
                print(e)

            try:
                SubdivisionNumber = response.meta['sbdn']
            except Exception as e:
                print(e)

            try:
                PlanName = div.xpath('./div/h3/text()').extract_first(default='').strip()
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(bytes(PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % PlanNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                PlanTypeName = 'Single Family'
            except Exception as e:
                print(e)

            try:
                BasePrice = '0'
            except Exception as e:
                print(e)

            try:
                Baths_text = '|'.join(div.xpath('.//*[contains(text(),"BEDS")]/text()').extract()).strip()
                Baths_text_list = Baths_text.split('|')
                for Baths_text1 in Baths_text_list:
                    Baths_text1_list = Baths_text1.split('/')
                    for Bath_word in Baths_text1_list:
                        print()
                        if 'BATHS' in Bath_word:
                            tmp = re.findall(r"(\d+)", Bath_word)
                            Baths = tmp[0]
                            if len(tmp) > 1:
                                HalfBaths = 1
                            else:
                                HalfBaths = 0
                        if 'BEDS' in Bath_word:
                            Bedrooms = re.findall(r'(\d+)', Bath_word)[0]
                        if 'TOTAL SF' in Bath_word:
                            BaseSqft = int(Bath_word.split(' ')[0].replace(',',''))
            except Exception as e:
                print(e)

            # try:
            #     Bedrooms = '0'
            #     Bedrooms = re.findall(r'(\d+)',Bedrooms)[0]
            # except Exception as e:
            #     print(e)

            try:
                Garage = '0'
                Garage = re.findall(r"(\d+)", Garage)[0]
                # BaseSqft = str(response.xpath('//p[text()="Total: "]/strong/text()').extract_first(default='0').strip()).replace(",", "")
                # BaseSqft = re.findall(r"(\d+)", BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                Description = ''.join(div.xpath('.//p[@class="paragraph"]/text()').extract())
            except Exception as e:
                print(e)

            try:
                ele_images = []
                ElevationImages1 = div.xpath('./div[@class="floor-plans-bg"]/@style').extract_first()
                ElevationImages1 = 'https://traditionalhomebuilders.com/' + re.findall(r'url\((.*?)\);',ElevationImages1)[0]
                ele_images.append(ElevationImages1)
                ElevationImages = div.xpath('./div/div/a/@href').extract()
                for ele_img in ElevationImages:
                    ele_img = 'https://traditionalhomebuilders.com/' + ele_img
                    ele_images.append(ele_img)
                ElevationImage = '|'.join(ele_images)
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.url
            except Exception as e:
                print(e)

            SubdivisionNumber = SubdivisionNumber #if subdivision is there
            #SubdivisionNumber = self.builderNumber #if subdivision is not available
            unique = str(PlanNumber)+str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails[PlanName] = unique_number
            item = BdxCrawlingItem_Plan()
            item['Type'] = Type
            item['PlanNumber'] = PlanNumber
            item['unique_number'] = unique_number
            item['SubdivisionNumber'] = SubdivisionNumber
            item['PlanName'] = PlanName
            item['PlanNotAvailable'] = PlanNotAvailable
            item['PlanTypeName'] = PlanTypeName
            item['BasePrice'] = BasePrice
            item['BaseSqft'] = BaseSqft
            item['Baths'] = Baths
            item['HalfBaths'] = HalfBaths
            item['Bedrooms'] = Bedrooms
            item['Garage'] = Garage
            item['Description'] = Description
            item['ElevationImage'] = ElevationImage
            item['PlanWebsite'] = PlanWebsite
            yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl Traditional_Home_builders".split())
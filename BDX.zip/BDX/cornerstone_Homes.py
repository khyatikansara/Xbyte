# -*- coding: utf-8 -*-
import hashlib
import json
import re
import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from unidecode import unidecode
from w3lib.http import basic_auth_header

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan


class CornerstoneHomesSpider(scrapy.Spider):
    name = 'cornerstone_Homes'
    allowed_domains = []
    start_urls = ['https://www.mycornerstonehomes.com/category/build-on-your-lot/']
    builderNumber = 374377555547601390676082809823

    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        image_list = []
        file = open("cornerstone_Homes.txt","r",encoding="utf-8")
        file_read = file.read()
        file.close()
        images = re.findall(r'image\:url\((.*?)\)',file_read)
        for img in images:
            if '.png' in img or '.jpg' in img:
                image_list.append(img)
        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "1421 North Loop Parkway"
        item['City'] = "St Augustine"
        item['State'] = "FL"
        item['ZIP'] = "32095"
        item['AreaCode'] = "904"
        item['Prefix'] = "295"
        item['Suffix'] = "8873"
        item['Extension'] = ""
        item['Email'] = "mark.downing@cornerstonehomesjax.com"
        item['SubDescription'] = "You also get a beautiful neighborhood, convenient amenities, and the kinds of neighbors who become lifelong friends. CornerStone specializes in building on individually owned homesites in planned unit developments."
        item['SubImage'] = '|'.join(image_list)
        item['SubWebsite'] = "https://www.mycornerstonehomes.com/build/communities/"
        item['AmenityType'] = ''
        yield item

        try:
            self.headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Upgrade-Insecure-Requests': '1',
                'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
            }
            links = response.xpath('//h2/a/@href').extract()
            plandetains = {}
            for link in links:
                yield scrapy.Request(url=link, callback=self.plans_details, headers=self.headers,
                                     meta={'sbdn': self.builderNumber, 'PlanDetails': plandetains,'proxy': 'zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def plans_details(self, response):
        plandetails = response.meta['PlanDetails']

        try:
            PlanName = response.xpath('//h1/text()').extract_first(default='').strip()
            if '–' in PlanName:
                PlanName = PlanName.split('–')[0].strip()
        except Exception as e:
            print(e)

        try:
            BasePrice = response.xpath('//*[contains(text(),"$")]/text()').extract_first(default='0').strip()
            BasePrice = BasePrice.replace("$", '').replace(",", '').strip()
        except Exception as e:
            print(e)

        try:
            PlanNumber = int(hashlib.md5(bytes(response.url + str(PlanName) + str(BasePrice), "utf8")).hexdigest(),16) % (10 ** 30)
            PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
            f = open("html/%s.html" % PlanNumber, "wb")
            f.write(response.body)
            f.close()
        except Exception as e:
            print(e)

        try:
            PlanNotAvailable = 0
        except Exception as e:
            print(e)

        try:
            Baths = str(response.xpath('//*[contains(text(),"baths")]/text()').extract_first(default='0').strip())
            if '/' in Baths:
                Baths = Baths.split('/')[1]
                tmp = re.findall(r"(\d+)", Baths)
                Baths = tmp[0]
                if len(tmp) > 1:
                    HalfBaths = 1
                else:
                    HalfBaths = 0
            else:
                Baths = '0'
        except Exception as e:
            print(e)

        try:
            Bedrooms = str(response.xpath('//*[contains(text(),"baths")]/text()').extract_first(default='0').strip())
            if '/' in Bedrooms:
                Bedrooms = Bedrooms.split('/')[0]
                Bedrooms = re.findall(r'(\d+)', Bedrooms)[0]
            else:
                Bedrooms = '0'
        except Exception as e:
            print(e)

        try:
            Garage_tmp = '|'.join(response.xpath('//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).replace('\n','')
            Garage_list = Garage_tmp.split("|")
            BaseSqft,Garage = '',''
            for value in Garage_list:
                if Garage == '' and 'car' in value.lower():
                    Garage = value
                    Garage = re.findall(r'(\d+)', Garage)[0]
                if BaseSqft == '' and 'Sq. Feet' in value:
                    BaseSqft = value.replace(',','')
                    BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
            if BaseSqft == '':
                BaseSqft = response.xpath('//*[contains(text(),"sq ft")]/text()').extract_first().replace(',','').strip()
                BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
        except Exception as e:
            print(e)

        try:
            Description = unidecode(''.join(response.xpath('//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).strip().replace('\n',','))
        except Exception as e:
            print(e)

        try:
            ele_list = []
            ElevationImage1_tmp = response.xpath('//*[contains(text(),"Elevations")]/../../../div//img/@src').extract()
            for ele in ElevationImage1_tmp:
                if 'data:image' not in ele:
                    ele_list.append(ele)
            ElevationImage1 = '|'.join(ele_list)
            GallaryImage = response.xpath('//*[@class="elementor-image"]/img/@src').extract_first()
            floorplanImage = '|'.join(response.xpath('//*[contains(text(),"Model Home")]/../../../div//a/@href').extract())
            ElevationImage = ElevationImage1.strip('|') + GallaryImage.strip('|') + floorplanImage.strip('|')
        except Exception as e:
            print(e)

        try:
            PlanWebsite = response.url
        except Exception as e:
            print(e)
        try:
            # SubdivisionNumber = response.meta['SubdivisionNumber']  # if subdivision is there
            SubdivisionNumber = self.builderNumber #if subdivision is not available
            unique = str(PlanNumber) + str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails[PlanName] = unique_number
            item = BdxCrawlingItem_Plan()
            item['Type'] = 'SingleFamily'
            item['PlanNumber'] = PlanNumber
            item['unique_number'] = unique_number
            item['SubdivisionNumber'] = SubdivisionNumber
            item['PlanName'] = PlanName
            item['PlanNotAvailable'] = PlanNotAvailable
            item['PlanTypeName'] = 'Single Family'
            item['BasePrice'] = BasePrice
            item['BaseSqft'] = BaseSqft
            item['Baths'] = Baths
            item['HalfBaths'] = HalfBaths
            item['Bedrooms'] = Bedrooms
            item['Garage'] = Garage
            item['Description'] = Description
            item['ElevationImage'] = ElevationImage
            item['PlanWebsite'] = PlanWebsite
            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl cornerstone_Homes".split())

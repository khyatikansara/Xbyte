# -*- coding: utf-8 -*-
import hashlib
import re
import json
import scrapy
import requests
from scrapy.http import HtmlResponse
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec


class AlderbrookhomesSpider(scrapy.Spider):
    name = 'alderbrookhomes_copy'
    allowed_domains = []
    start_urls = ['https://alderbrookhomes.com/']

    builderNumber = "62653"

    def parse(self, response):
        try:
            image_list = ['https://www.alderbrook-homes.com/media/spencerparadehome3.jpg','https://www.alderbrook-homes.com/media/customhomes.jpg','https://www.alderbrook-homes.com/media/spencerparadehome4.jpg','https://www.alderbrook-homes.com/media/6414-Nocking-Point.jpg']
            image = response.xpath('//meta[contains(@property,"og:image")]/@content').extract_first()
            image_list.append(image)
            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = ''
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = "No Sub Division"
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 0
            item['Street1'] = "87205 East Sagebrush Road"
            item['City'] = "Kennewick"
            item['State'] = "WA"
            item['ZIP'] = "99338"
            item['AreaCode'] = "509"
            item['Prefix'] = "737"
            item['Suffix'] = "3092"
            item['Extension'] = ""
            item['Email'] = "info@alderbrookhomes.biz"
            item['SubDescription'] = "As a family owned and operated business, we understand the importance of home, family, and living the American Dream. With decades of experience and hundreds of homes in our portfolio, we've earned our reputation for quality construction, excellent customer service, and on-schedule delivery."
            item['SubImage'] = '|'.join(image_list)
            item['SubWebsite'] = ""
            item['AmenityType'] = ''
            yield item

            yield scrapy.Request(url='https://alderbrookhomes.com/floor-plans', callback=self.process_plan_link, dont_filter=True)
        except Exception as e:
            print(e)

    def process_plan_link(self, response):
        plandetails = {}
        try:
            unique = str("Plan Unknown") + str(self.builderNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            plandetails["Plan Unknown"] = unique_number
            item = BdxCrawlingItem_Plan()
            item['unique_number'] = unique_number
            item['Type'] = "SingleFamily"
            item['PlanNumber'] = "Plan Unknown"
            item['SubdivisionNumber'] = self.builderNumber
            item['PlanName'] = "Plan Unknown"
            item['PlanNotAvailable'] = 1
            item['PlanTypeName'] = "Single Family"
            item['BasePrice'] = 0
            item['BaseSqft'] = 0
            item['Baths'] = 0
            item['HalfBaths'] = 0
            item['Bedrooms'] = 0
            item['Garage'] = 0
            item['Description'] = ""
            item['ElevationImage'] = ""
            item['PlanWebsite'] = ""
            yield item
        except Exception as e:
            print(e)

        try:
            url = "https://alderbrookhomes.com/php/get-file.php"

            payload = {'files': '[{"location":"web/web-content/homes","type":"home","date":"","label":"webU+002Fweb-contentU+002FhomesU+003Ahome","cache-name":"webU+002Fweb-contentU+002FhomesU+003Ahome","authentication":null}]'}
            files = []
            headers = {
                'accept': 'application/json, text/javascript, */*; q=0.01',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                'cookie': '_ga=GA1.2.1931500362.1618731612; PHPSESSID=4a1fadb2bea30a6bf68b375d7e33feaa; _gid=GA1.2.179229593.1620214923; _gat=1',
                'origin': 'https://alderbrookhomes.com',
                'referer': 'https://alderbrookhomes.com/floor-plans',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
                'x-requested-with': 'XMLHttpRequest'
            }

            response = requests.request("POST", url, headers=headers, data=payload, files=files)
            json_data = json.loads(response.text)
            for data in json_data['data'][0]['data']:
                data_json = json.loads(data['data'])
                print(data_json)

                try:
                    PlanName = data_json['propertyname']
                except Exception as e:
                    print(e)

                try:
                    PlanNumber = int(hashlib.md5(bytes(PlanName, "utf8")).hexdigest(), 16) % (10 ** 30)
                    f = open("html/%s.json" % PlanNumber, "w")
                    f.write(data['data'])
                    f.close()
                except Exception as e:
                    print(e)

                try:
                    PlanNotAvailable = 0
                except Exception as e:
                    print(e)

                try:
                    Type = 'SingleFamily'
                except Exception as e:
                    print(e)

                try:
                    PlanTypeName = 'Single Family'
                except Exception as e:
                    print(e)

                try:
                    BasePrice = '0'
                except Exception as e:
                    print(e)

                try:
                    BaseSqft = data_json['squarefootage']
                except Exception as e:
                    print(e)

                try:
                    Baths = data_json['bathrooms']
                    tmp = re.findall(r"(\d+)", str(Baths))
                    Baths = int(tmp[0])
                    if len(tmp) > 1:
                        HalfBaths = 1
                    else:
                        HalfBaths = 0
                except Exception as e:
                    print(e)

                try:
                    Bedrooms = data_json['bedrooms']
                except Exception as e:
                    print(e)

                try:
                    Garage = '0'
                    Garage_list = data_json['features']
                    for gar in Garage_list:
                        if "garage" in gar:
                            Garage = re.findall(r"(\d+)", gar)[0]
                except Exception as e:
                    print(e)
                    Garage = '0'

                try:
                    Description = data_json['description']
                    if Description == '':
                        Description = 'Information is deemed reliable but is not guaranteed. Builder reserves the right to change pricing or features at any time, without notice. Final option sheet supersedes floor plans, standard features sheet, and any advertising, including the MLS system. Floor plans and picture may show features not included in base price, but are available at an additional cost.'
                except Exception as e:
                    print(e)

                try:
                    PlanWebsite = 'https://alderbrookhomes.com/home/' + data_json['foldername']
                except Exception as e:
                    print(e)

                foldername = data_json['foldername']
                url1 = "https://alderbrookhomes.com/php/get-file.php"

                payload1 = {'files': '[{"location":"root/media/'+foldername+'","type":"jpg","date":"","label":"rootU+002FmediaU+002Fandersen-2U+003Ajpg","cache-name":"rootU+002FmediaU+002Fandersen-2U+003Ajpg","authentication":null}]'}
                files1 = []
                headers1 = {
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'cookie': '_ga=GA1.2.1931500362.1618731612; PHPSESSID=4a1fadb2bea30a6bf68b375d7e33feaa; _gid=GA1.2.179229593.1620214923',
                    'origin': 'https://alderbrookhomes.com',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                }

                response1 = requests.request("POST", url1, headers=headers1, data=payload1, files=files1)
                json_data1 = json.loads(response1.text)
                ElevationImage_list = []
                for data1 in json_data1['data'][0]['data']:
                    location = 'https://alderbrookhomes.com/' + data1['meta']['location'].replace('../','')
                    ElevationImage_list.append(location)
                ElevationImage = '|'.join(ElevationImage_list)

                # SubdivisionNumber = SubdivisionNumber  # if subdivision is there
                SubdivisionNumber = self.builderNumber #if subdivision is not available
                unique = str(PlanNumber) + str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                plandetails[PlanName] = unique_number
                try:
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number
                    item['SubdivisionNumber'] = SubdivisionNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = BasePrice
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = Baths
                    item['HalfBaths'] = HalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = Garage
                    item['Description'] = Description
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = PlanWebsite
                    yield item
                except Exception as e:
                    print(e)
                # break
            yield scrapy.Request(url='https://alderbrookhomes.com/move-in-ready-search', callback=self.process_home_link, dont_filter=True,meta={"PN":plandetails})
            yield scrapy.Request(url='https://alderbrookhomes.com/model-homes', callback=self.process_home_link, dont_filter=True, meta={"PN": plandetails})
        except Exception as e:
            print(e)

    def process_home_link(self, response):
        pn = response.meta['PN']
        if response.url == "https://alderbrookhomes.com/move-in-ready-search":
            try:
                url_h = "https://alderbrookhomes.com/php/get-file.php"

                payload_h = {'files': ' [{"location":"web/web-content/move-in-ready","type":"item","date":"","label":"webU+002Fweb-contentU+002Fmove-in-readyU+003Aitem","cache-name":"webU+002Fweb-contentU+002Fmove-in-readyU+003Aitem","authentication":null},{"location":"templates/home-card.template","type":"as","date":"","label":"array^templatesU+002Fhome-card.template"}]'}

                files_h = []
                headers_h = {
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'cookie': '_ga=GA1.2.1931500362.1618731612; _gid=GA1.2.179229593.1620214923; PHPSESSID=d98c8c64f0f9ad0e23c21544bedc58df; _gat=1',
                    'origin': 'https://alderbrookhomes.com',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                }

                response_h1 = requests.request("POST", url_h, headers=headers_h, data=payload_h, files=files_h)
                json_data_h = json.loads(response_h1.text)
                for data_h in json_data_h['data']:
                    for data_h1 in data_h['data']:
                        try:
                            data_json_h = json.loads(data_h1['data'])
                            try:status = data_json_h['status']
                            except:status = ''
                            if status != 'under construction':
                                try:
                                    try:planName = data_json_h['plan']
                                    except:planName = data_json_h['floorplan']
                                    PlanNumber = pn[planName]
                                    # PlanNumber = pn["Plan Unknown"]
                                except Exception as e:
                                    print(e)
                                    PlanNumber = pn["Plan Unknown"]

                                try:
                                    SpecStreet1 = data_json_h['address1']
                                except Exception as e:
                                    print(e)
                                try:
                                    SpecCity = data_json_h['city']
                                except Exception as e:
                                    print(e)
                                try:
                                    SpecState = data_json_h['state-abbr']
                                except Exception as e:
                                    print(e)
                                try:
                                    SpecZIP = data_json_h['zip']
                                except Exception as e:
                                    print(e)

                                try:
                                    unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                                    SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                                    f = open("html/%s.html" % SpecNumber, "w")
                                    f.write(data_h1['data'])
                                    f.close()
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecCountry = "USA"
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecPrice = data_json_h['price'].replace(',', '')
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecSqft = data_json_h['square-feet']
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecBaths = data_json_h['bathrooms']
                                    SpecBaths = re.findall(r"(\d+)", SpecBaths)[0]
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecBaths = data_json_h['bathrooms']
                                    SpecBaths = re.findall(r"(\d+)", SpecBaths)[0]
                                    tmp = re.findall(r"(\d+)", SpecBaths)
                                    SpecBaths = tmp[0]
                                    if len(tmp) > 1:
                                        SpecHalfBaths = 1
                                    else:
                                        SpecHalfBaths = 0
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecBedrooms = data_json_h['bedrooms']
                                    SpecBedrooms = re.findall(r"(\d+)", SpecBedrooms)[0]
                                except Exception as e:
                                    print(e)

                                try:
                                    MasterBedLocation = "Down"
                                except Exception as e:
                                    print(e)

                                try:
                                    SpecDescription = data_json_h['description']
                                    if SpecDescription == '':
                                        SpecDescription = 'Information is deemed reliable but is not guaranteed. Builder reserves the right to change pricing or features at any time, without notice. Final option sheet supersedes floor plans, standard features sheet, and any advertising, including the MLS system. Floor plans and picture may show features not included in base price, but are available at an additional cost.'
                                except Exception as e:
                                    print(e)

                                url = "https://alderbrookhomes.com/php/get-file.php"
                                filename = data_h1['meta']['filename']
                                filename1 = 'https://alderbrookhomes.com/move-in-ready/' + filename
                                payload = {'files': '[{"location":"root/media/move-in-ready/'+filename+'","type":"jpg","date":"","label":"rootU+002FmediaU+002Fmove-in-readyU+002F3307-lapis-laneU+003Ajpg","cache-name":"rootU+002FmediaU+002Fmove-in-readyU+002F3307-lapis-laneU+003Ajpg","authentication":null}]'}
                                files = []
                                headers = {
                                    'accept': 'application/json, text/javascript, */*; q=0.01',
                                    'accept-encoding': 'gzip, deflate, br',
                                    'accept-language': 'en-US,en;q=0.9',
                                    'cookie': '_ga=GA1.2.1931500362.1618731612; _gid=GA1.2.179229593.1620214923; PHPSESSID=d98c8c64f0f9ad0e23c21544bedc58df; _gat=1',
                                    'origin': 'https://alderbrookhomes.com',
                                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',
                                    'x-requested-with': 'XMLHttpRequest'
                                }
                                SpecElevationImage_list = []
                                response_ele = requests.request("POST", url, headers=headers, data=payload, files=files)
                                json_data_ele = json.loads(response_ele.text)
                                for data_ele in json_data_ele['data']:
                                    for data_ele1 in data_ele['data']:
                                        SpecElevationImage_tmp = 'https://alderbrookhomes.com/'+ data_ele1['meta']['location'].replace('../','')
                                        SpecElevationImage_list.append(SpecElevationImage_tmp)

                                try:
                                    SpecWebsite = filename1
                                except Exception as e:
                                    print(e)

                                try:
                                    item = BdxCrawlingItem_Spec()
                                    item['SpecNumber'] = SpecNumber
                                    item['PlanNumber'] = PlanNumber
                                    item['SpecStreet1'] = SpecStreet1
                                    item['SpecCity'] = SpecCity
                                    item['SpecState'] = SpecState
                                    item['SpecZIP'] = SpecZIP
                                    item['SpecCountry'] = SpecCountry
                                    item['SpecPrice'] = SpecPrice
                                    item['SpecSqft'] = SpecSqft
                                    item['SpecBaths'] = SpecBaths
                                    item['SpecHalfBaths'] = SpecHalfBaths
                                    item['SpecBedrooms'] = SpecBedrooms
                                    item['MasterBedLocation'] = MasterBedLocation
                                    item['SpecGarage'] = '0'
                                    item['SpecDescription'] = SpecDescription
                                    item['SpecElevationImage'] = '|'.join(SpecElevationImage_list)
                                    item['SpecWebsite'] = SpecWebsite
                                    yield item
                                except Exception as e:
                                    print(e)
                            else:
                                print(data_json_h['status'])
                        except Exception as e:
                            print(e)
            except Exception as e:
                print(e)
        else:
            try:
                unique = '435 S Birch Street' + 'Moses Lake' + 'WA' + '98837'
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % SpecNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)
            try:
                item = BdxCrawlingItem_Spec()
                item['SpecNumber'] = SpecNumber
                item['PlanNumber'] = pn["Plan Unknown"]
                item['SpecStreet1'] = '435 S Birch Street'
                item['SpecCity'] = 'Moses Lake'
                item['SpecState'] = 'WA'
                item['SpecZIP'] = '98837'
                item['SpecCountry'] = "USA"
                item['SpecPrice'] = '0'
                item['SpecSqft'] = '1898'
                item['SpecBaths'] = '2'
                item['SpecHalfBaths'] = '0'
                item['SpecBedrooms'] = '3'
                item['MasterBedLocation'] = "Down"
                item['SpecGarage'] = '3'
                item['SpecDescription'] = 'Information is deemed reliable but is not guaranteed. Builder reserves the right to change pricing or features at any time, without notice. Final option sheet supersedes floor plans, standard features sheet, and any advertising, including the MLS system. Floor plans and picture may show features not included in base price, but are available at an additional cost.'
                item['SpecElevationImage'] = 'https://alderbrookhomes.com/media/move-in-ready/435-birch-street/435-birch-street-cover.jpg'
                item['SpecWebsite'] = 'https://alderbrookhomes.com/model-homes'
                yield item
            except Exception as e:
                print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl alderbrookhomes_copy".split())


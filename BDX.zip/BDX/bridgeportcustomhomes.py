# -*- coding: utf-8 -*-
import hashlib
import re

import requests
import scrapy
import scrapy .utils
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser

from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec

class Benchmarkbuilder(scrapy.Spider):
    name = 'bridgeportcustomhomes'
    allowed_domains = []
    start_urls = ['https://www.bridgeportcustomhomes.com/communities']
    builderNumber = "63669"

    def parse(self,response):
        try:
            link = 'https://www.bridgeportcustomhomes.com'+response.xpath('//*[@class="uk-article"]/h2/text()/../../h1/a/@href').extract_first()
            yield scrapy.Request(url=link,callback=self.comm_data)

        except Exception as e:
            print(e)

    def comm_data(self,response):
        try:
            SubdivisionName = response.xpath('//*[@class="uk-article"]/h1/text()').extract_first().strip()
        except Exception as e:
            print(e)

        try:
            SubdivisionNumber = int(hashlib.md5(bytes(SubdivisionName, "utf8")).hexdigest(), 16) % (10 ** 30)
        except Exception as e:
            print(e)

        try:
            City = response.xpath('//*[@class="uk-article"]/h2/text()').extract_first().strip().split(',')[0].strip()
        except Exception as e:
            City = ''
            print(e)

        try:
            SubImage = 'https://www.bridgeportcustomhomes.com/'+response.xpath('//*[@class="uk-article"]/h1/../p/img/@data-src').extract_first()
        except Exception as e:
            SubImage = ''
            print(e)

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionName'] = SubdivisionName
        item['SubdivisionNumber'] = SubdivisionNumber
        item['BuilderNumber'] = self.builderNumber
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = 'Bonnie Glen Rd'
        item['City'] = City
        item['State'] = 'OH'
        item['ZIP'] = '44256'
        item['AreaCode'] = ''
        item['Prefix'] = ''
        item['Suffix'] = ''
        item['Extension'] = ""
        item['Email'] = ''
        item['SubWebsite'] = response.url
        item['SubDescription'] = ''
        item['SubImage'] = SubImage
        item['AmenityType'] = ''
        yield item

        yield scrapy.Request(url="https://www.bridgeportcustomhomes.com/plans", callback=self.plan, dont_filter=True, meta={"SubdivisionNumber": SubdivisionNumber})

    def plan(self,response):
        try:
            SubdivisionNumber=response.meta['SubdivisionNumber']
            links = response.xpath('//*[@class="uk-article-title"]/a/@href').extract()
            for link1 in links:
                link1 = 'https://www.bridgeportcustomhomes.com'+link1
                yield scrapy.Request(url=link1, callback=self.Plan_details,dont_filter=True, meta={"SubdivisionNumber": SubdivisionNumber})
                # break
        except Exception as e:
            print(e)

    def Plan_details(self,response):
        SubdivisionNumber=response.meta['SubdivisionNumber']
        try:
            planname = response.xpath('//*[@class="uk-article-title"]/text()').extract_first().strip()
            # urrrrl=response.url+'_'+planname
            # print(urrrrl)
            PlanNumber = int(hashlib.md5(bytes(planname, "utf8")).hexdigest(), 16) % (10 ** 30)
            f = open("html/%s.html" % PlanNumber, "wb")
            f.write(response.body)
            f.close()
        except Exception as e:
            print(e)
            planname = ''

        try:
            BasePrice ="0"
        except Exception as e:
            BasePrice = ""
            print("SpecPrice", e, response.url)

        try:
            Baths_text = '|'.join(response.xpath('//article/p[2]/strong/text()').extract())
            if '•' in Baths_text:
                Baths_text = Baths_text.split('•')
                for bath in Baths_text:
                    if 'bath' in bath.lower():
                        Baths_text1 = bath
                        break

            else:
                Baths_text = Baths_text.split(',')
                for bath in Baths_text:
                    if 'bath' in bath.lower():
                        Baths_text1 = bath
                        break
            if "full" in Baths_text1:
                Baths = re.findall(r'(.*?)\s?full',Baths_text1)[0].strip()
                HalfBaths = re.findall(r'full(.*?)half',Baths_text1)[0].replace('+','').strip()
            else:
                tmp = re.findall(r"(\d+)", Baths_text1)
                Baths = tmp[0]
                if len(tmp) > 1:
                    HalfBaths = 1
                else:
                    HalfBaths = 0
        except Exception as e:
            print(e)
            Baths = '0'
            HalfBaths = 0

        try:
            Bedrooms_text = '|'.join(response.xpath('//article/p[2]/strong/text()').extract())
            if '•' in Bedrooms_text:
                Bedrooms_text = Bedrooms_text.split('•')
                for bed in Bedrooms_text:
                    if 'bedroom' in bed.lower():
                        Bedrooms_text1 = bed
                        break
            else:
                Bedrooms_text = Bedrooms_text.split(', ')
                for bed in Bedrooms_text:
                    if 'bedroom' in bed.lower():
                        Bedrooms_text1 = bed
                        break
            if '-' in Bedrooms_text1:
                Bedrooms = ''.join(re.findall(r'(\d+)',Bedrooms_text1)[1])
            else:
                Bedrooms = ''.join(re.findall(r'(\d+)', Bedrooms_text1)[0])
        except Exception as e:
            print(e)
            Bedrooms = '0'

        try:
            BaseSqft_text = '|'.join(response.xpath('//article/p[2]/strong/text()').extract())
            if '•' in BaseSqft_text:
                BaseSqft_text = BaseSqft_text.split('•')
                for sqft in BaseSqft_text:
                    if 'sq.ft' in sqft.lower():
                        BaseSqft_text1 = sqft
                        break
            else:
                BaseSqft_text = BaseSqft_text.split(', ')
                for sqft in BaseSqft_text:
                    if 'sq.ft' in sqft.lower():
                        BaseSqft_text1 = sqft
                        break
            BaseSqft = ''.join(re.findall(r"(\d+)", BaseSqft_text1)).replace(',','')
        except Exception as e:
            print(e)
            BaseSqft = ''

        try:
            # Garage = response.xpath('//div[@itemprop="description"]/p/text()[3]').extract_first('')
            # Garage = re.findall(r"(\d*[three]*[four]*[two]*)[-]*[ ]*car garage", response.text.lower())[0]
            Garage = 0
            Garage_text = '|'.join(response.xpath('//article//ul[1]/li/text()').extract())
            if 'Three-car' in Garage_text or 'three-car' in Garage_text or '3 Car' in Garage_text:
                Garage = '3'
            elif '2-car' in Garage_text:
                Garage = '2'
            elif 'Four-car' in Garage_text or '4 Car' in Garage_text:
                Garage = '4'
            if Garage == 0:
                for gar in Baths_text:
                    if 'garage' in gar.lower():
                        garage_text1 = gar
                        break
                Garage = ''.join(re.findall(r"(\d+)", garage_text1))
        except Exception as e:
            print(e)
            Garage = 0

        try:
            if 'plans/first-floor-masters/the-hickory' in response.url or 'plans/first-floor-masters/the-scarlet' in response.url:
                PDescription = ''.join(response.xpath('//*[@class="uk-article"]/p[4]//text()').extract()).replace('\n','').strip().encode('utf-8').decode('ascii', 'ignore')
                print('PDDEASCRIPTION',PDescription)
            else:
                PDescription = ''.join(response.xpath('//*[@class="uk-article"]/p[4]//text()|//*[@class="uk-article"]/ul/li/text()|//*[@class="layoutArea"]//li/text()').extract()).replace('\n', '').strip().encode('utf-8').decode('ascii', 'ignore')
                print('PDDEASCRIPTION', PDescription)
        except Exception as e:
            print("SpecDescription", e, response.url)

        images = img = ''
        try:
            iiii=response.xpath('//*[@class="uk-article-title"]/following-sibling::p[1]//img/@data-src').get()
            imh='https://www.bridgeportcustomhomes.com'+iiii
        except Exception as e:
            print(e)

        try:
            planElevationImage = response.xpath('//*[@class="sigFreeThumb"]//@href|//*[@title="custom built home sharon township ohio"]//@src|//*[@class=" jch-lazyloaded"]/@src').extract()
            print(planElevationImage)
            if planElevationImage ==[]:
                planElevationImage = response.xpath('//*[@class="sigFreeThumb"]//a/@href|//*[@class="uk-article"]//img/@src').extract()
            img = []
            for s in planElevationImage:
                if 'data:image/svg+xml;' not in s:#
                    s = re.sub('\n|\t|\s\s+', '',s).strip()
                    if s != "":
                        if s not in imh:
                            img.append('https://www.bridgeportcustomhomes.com'+s)
            images = '|'.join(img).replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMzAwIiBoZWlnaHQ9Ijc3NSI+PC9zdmc+','')#.replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjU5LjYyIj48L3N2Zz4=','').replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjIxLjQzIj48L3N2Zz4=','').strip()
        except Exception as e:
            print("SpecElevationImage", e, response.url)

        try:
            if 'plans/first-floor-masters/the-elkwood' in response.url:
                imagess='https://www.bridgeportcustomhomes.com/images/elkwood/elkwoodint.jpg|https://www.bridgeportcustomhomes.com/images/elkwood/elkwood.jpg'
                print(imagess)
            elif 'plans/second-floor-masters/the-estate' in response.url:
                imagess='https://www.bridgeportcustomhomes.com/images/Estate/estate.jpg'
            else:
                imagess = ''.join(imh) + '|' + ''.join(images)
        except Exception as e:
            print(e)
        if imagess == '':
            imagess = imh
            imagess = imagess.replace('|','')
        if '|' == imagess[-1]:
            imagess = imagess.replace('|', '')
        try:
            PlanWebsite = response.url
            print(PlanWebsite)
        except Exception as e:
            print(e)

        try:
            # SubdivisionNumber =SubdivisionNumber
            unique = str(PlanNumber) + str(SubdivisionNumber)
            unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
            item = BdxCrawlingItem_Plan()
            item['unique_number'] = unique_number
            item['Type'] = "SingleFamily"
            item['PlanNumber'] = PlanNumber
            item['SubdivisionNumber'] = SubdivisionNumber
            item['PlanName'] = planname
            item['PlanNotAvailable'] = 1
            item['PlanTypeName'] = "Single Family"
            item['BasePrice'] = BasePrice
            item['BaseSqft'] = BaseSqft
            item['Baths'] = Baths
            item['HalfBaths'] = HalfBaths
            item['Bedrooms'] = Bedrooms
            item['Garage'] = Garage
            item['Description'] = PDescription
            item['ElevationImage'] = imagess
            item['PlanWebsite'] = PlanWebsite
            yield item
        except Exception as e:
            print("Problem in Unknown Plan creation:", e)


        # BaseSqft=''
        # try:
        #     if '/plans/first-floor-masters/the-edinboro' in response.url:
        #         BaseSqft='3520'
        #     elif 'sq.ft' in response.text:
        #         BaseSqft1 = response.xpath('//*[@class="uk-article"]/p[2]/strong/text()').extract()
        #         BaseSqft=''.join(BaseSqft1).split('sq.ft')[0].strip('+').strip().replace(',','').strip()
        #         print(BaseSqft)
        #     else:
        #         BaseSqft='0'
        # except Exception as e:
        #     BaseSqft = 0
        #     print(e)
        #
        #
        # try:
        #     if '/first-floor-masters/the-lodge' in response.url:
        #         Baths='2'
        #         planHalfBaths = '1'
        #     elif '/plans/ranches/the-ridge' in response.url:
        #         Baths = '2'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-turnberry' in response.url:
        #         Baths = '4'
        #         planHalfBaths = '2'
        #     elif '/plans/first-floor-masters/the-madison-ii' in response.url:
        #         Baths = '3'
        #         planHalfBaths = '2'
        #     elif '/plans/first-floor-masters/the-madison' in response.url:
        #         Baths = '3'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-tiburon' in response.url:
        #         Baths = '3'
        #         planHalfBaths = '1'
        #     elif '/plans/ranches/the-belmont' in response.url:
        #         Baths = '2'
        #         planHalfBaths = '1'
        #     elif'/plans/ranches/the-alaskan' in response.url:
        #         Baths = '2'
        #         planHalfBaths = '2'
        #     elif '/plans/first-floor-masters/the-franklin' in response.url:
        #         Baths = '3'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-willow' in response.url:
        #         Baths = '2'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-barnsley' in response.url:
        #         Baths = '4'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-edinboro'  in response.url:
        #         Baths = '4'
        #         planHalfBaths = '1'
        #     elif '/plans/first-floor-masters/the-edinboro' in response.url:
        #         Baths = '4'
        #         planHalfBaths = '1'
        #
        #     elif '/plans/first-floor-masters/the-hickory' in response.url:
        #         Baths = '3'
        #         planHalfBaths = '1'
        #     elif 'plans/first-floor-masters/the-scarlet' in response.url:
        #         Baths = '4'
        #         planHalfBaths = '1'
        #     else:
        #         Baths1 = response.xpath('//*[@class="uk-article"]/p[2]/strong/text()').getall()
        #         Baths1=str(Baths1).replace('\\xa0',' ').strip()
        #         # Baths1=Baths1.strip().split('bath')
        #         print(Baths1)
        #         # if 'full + half' in response.text:
        #         #     Baths =str(Baths1).split('baths')[0].split('•')[-1].split('+')[0].replace('full','').strip()
        #         #     print(Baths)
        #         #     planHalfBaths='1'
        #         # else:
        #         if '•' in Baths1:
        #             Baths = str(Baths1).split('baths')[0].split('•')[-1].strip()
        #             planHalfBaths = '1'
        #         else:
        #             Baths = str(Baths1).split('baths')[0].split(',')[-1].strip()
        #             tmp = re.findall(r"(\d.\d)", Baths) or re.findall(r"(\d)", Baths)
        #             Baths = int(float(tmp[0]))
        #             if len(tmp[0]) > 1:
        #                 planHalfBaths = '1'
        #             else:
        #                 planHalfBaths = '0'
        # except Exception as e:
        #     Baths ='0'
        #     planHalfBaths = '0'
        #     print("Baths", e, response.url)
        # try:
        #    if 'The Ridge II' in planname:
        #         Baths = '3'
        #         planHalfBaths = '1'
        # except Exception as e:
        #     print(e)
        #
        # Bedrooms=''
        # try:
        #     if '/first-floor-masters/the-lodge' in response.url:
        #         Bedrooms='5'
        #     elif '/plans/first-floor-masters/the-willow' in response.url:
        #         Bedrooms='3'
        #     elif '/plans/first-floor-masters/the-edinboro' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/first-floor-masters/the-coventry' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/first-floor-masters/the-cheyenne-ii' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/second-floor-masters/the-dartmouth' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/first-floor-masters/the-elkwood' in response.url:
        #         Bedrooms = '5'
        #     elif '/plans/second-floor-masters/the-estate' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/first-floor-masters/the-highland' in response.url:
        #         Bedrooms = '5'
        #     elif '/plans/second-floor-masters/the-montgomery' in response.url:
        #         Bedrooms = '5'
        #     elif '/plans/second-floor-masters/the-princeton' in response.url:
        #         Bedrooms = '4'
        #     elif '/plans/ranches/the-timberland' in response.url:
        #         Bedrooms = '3'
        #     elif'plans/first-floor-masters/the-brentwood' in response.url:
        #         Bedrooms = '5'
        #     elif 'bedrooms' in response.text or 'Bedrooms'  in response.text:
        #         Bedrooms1 = response.xpath('//*[@class="uk-article"]/p[2]/strong/text()').getall()
        #         Bedrooms=str(Bedrooms1).split('bedrooms')[0].split('•')[-1].strip()
        #         Bedrooms = re.findall(r"(\d)", Bedrooms)[0]
        #     else:
        #         Bedrooms='0'
        # except Exception as e:
        #     Bedrooms = 0
        #     print("SpecBedrooms", e, response.url)
        # ppppp='686559655744476628589710905712'
        # ppppp1='665740989104422993058411736281'
        # pp1=int(ppppp)
        # pp2=int(ppppp1)
        #
        # try:
        #     if '/plans/second-floor-masters/the-estate' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-highland' in response.url:
        #         Garage = '3'
        #     elif '/plans/ranches/the-lexington' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-lodge' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-mapleton' in response.url:
        #         Garage = '3'
        #     elif '/plans/second-floor-masters/the-princeton' in response.url:
        #         Garage = '3'
        #     elif '/plans/ranches/the-timberland' in response.url:
        #         Garage = '3'
        #     elif '/plans/ranches/the-alaskan' in response.url:
        #         Garage = '3'
        #     elif '/plans/ranches/the-andover' in response.url:
        #         Garage = '2'
        #     elif '/plans/first-floor-masters/the-coventry' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-deerfield' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-elkwood' in response.url:
        #         Garage = '3'
        #     elif '/plans/first-floor-masters/the-franklin' in response.url:
        #         Garage = '3'
        #     elif 'https://www.bridgeportcustomhomes.com/plans/ranches/the-ridge_The Ridge' in urrrrl:
        #         Garage = '3'
        #     elif 'plans/second-floor-masters/the-montgomery' in response.url:
        #         Garage = '3'
        #     elif 'https://www.bridgeportcustomhomes.com/plans/ranches/the-ridge-b_The Ridge II' in urrrrl:
        #         Garage = '0'
        #     elif 'Car Garage' in response.text:
        #         Garage =response.xpath('//*[@class="uk-article"]/p[2]/strong/text()').get()
        #         Garage =str(Garage).split('Car Garage')[0].split('•')[-1].strip()
        #         Garage = re.findall(r"(\d)", Garage)[0]
        #     else:
        #         Garage='0'
        # except Exception as e:
        #     print(e)
        #     Garage = 0
        #     print('SpecGarage', e, response.url)
        #
        # try:
        #     if 'plans/first-floor-masters/the-hickory' in response.url or 'plans/first-floor-masters/the-scarlet' in response.url:
        #         PDescription = ''.join(response.xpath('//*[@class="uk-article"]/p[4]//text()').extract()).replace('\n','').strip().encode('utf-8').decode('ascii', 'ignore')
        #         print('PDDEASCRIPTION',PDescription)
        #     else:
        #         PDescription = ''.join(response.xpath('//*[@class="uk-article"]/p[4]//text()|//*[@class="uk-article"]/ul/li/text()|//*[@class="layoutArea"]//li/text()').extract()).replace('\n', '').strip().encode('utf-8').decode('ascii', 'ignore')
        #         print('PDDEASCRIPTION', PDescription)
        #     # PDescription = PDescription.split('HIGHLIGHTS:')[0]
        #     # print(PDescription)
        #     # print(PDescription)
        #
        # except Exception as e:
        #     print("SpecDescription", e, response.url)
        # images=img=''
        # try:
        #     iiii=response.xpath('//*[@class="uk-article-title"]/following-sibling::p[1]//img/@data-src').get()
        #     imh='https://www.bridgeportcustomhomes.com'+iiii
        #     # imh=set(imh1)
        #     print(imh)
        #     # aa = planname.replace('The', '').replace('-b', '').replace('-', '').strip().lower()
        #     # if 'hickory' in aa or 'lodge' in aa or 'ridge' in aa or 'mapleton' in aa or 'estate' in aa or 'highland' in aa or 'andover' in aa:
        #     #     img = f'https://www.bridgeportcustomhomes.com//images/{aa.upper()}/{aa}.jpg'
        #     #     print(img)
        #     # elif '/first-floor-masters/the-willow' in response.url:
        #     #     img='https://www.bridgeportcustomhomes.com/images/willow/WillowEdit.jpg'
        #     # else:
        #     #     img = f'https://www.bridgeportcustomhomes.com//images/{aa}/{aa}.jpg'
        #     # print(img)
        # except Exception as e:
        #     print(e)
        # try:
        #
        #
        #     planElevationImage = response.xpath('//*[@class="sigFreeThumb"]//@href|//*[@title="custom built home sharon township ohio"]//@src|//*[@class=" jch-lazyloaded"]/@src').extract()
        #     print(planElevationImage)
        #     if planElevationImage ==[]:
        #         planElevationImage = response.xpath('//*[@class="sigFreeThumb"]//a/@href|//*[@class="uk-article"]//img/@src').extract()
        #     img = []
        #     for s in planElevationImage:
        #         if 'data:image/svg+xml;' not in s:#
        #             s = re.sub('\n|\t|\s\s+', '',s).strip()
        #             if s != "":
        #                 if s not  in imh:
        #                     img.append('https://www.bridgeportcustomhomes.com'+s)
        #
        #         # print(img)
        #     images = '|'.join(img).replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMzAwIiBoZWlnaHQ9Ijc3NSI+PC9zdmc+','')#.replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjU5LjYyIj48L3N2Zz4=','').replace('https://www.bridgeportcustomhomes.comdata:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjIxLjQzIj48L3N2Zz4=','').strip()
        #     print(images)
        #
        #
        # except Exception as e:
        #     print("SpecElevationImage", e, response.url)
        # try:
        #     if 'plans/first-floor-masters/the-elkwood' in response.url:
        #         imagess='https://www.bridgeportcustomhomes.com/images/elkwood/elkwoodint.jpg|https://www.bridgeportcustomhomes.com/images/elkwood/elkwood.jpg'
        #         print(imagess)
        #     elif 'plans/second-floor-masters/the-estate' in response.url:
        #         imagess='https://www.bridgeportcustomhomes.com/images/Estate/estate.jpg'
        #     else:
        #         imagess = ''.join(imh) + '|' + ''.join(images)
        #         print(imagess)
        # except Exception as e:
        #     print(e)
        # try:
        #     PlanWebsite = response.url
        #     print(PlanWebsite)
        # except Exception as e:
        #     print(e)
        # try:
        #     # SubdivisionNumber =SubdivisionNumber
        #     unique = str(PlanNumber) + str(SubdivisionNumber)
        #     unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
        #     item = BdxCrawlingItem_Plan()
        #     item['unique_number'] = unique_number
        #     item['Type'] = "SingleFamily"
        #     item['PlanNumber'] = PlanNumber
        #     item['SubdivisionNumber'] = SubdivisionNumber
        #     item['PlanName'] = planname
        #     item['PlanNotAvailable'] = 1
        #     item['PlanTypeName'] = "Single Family"
        #     item['BasePrice'] = BasePrice
        #     item['BaseSqft'] = BaseSqft
        #     item['Baths'] = Baths
        #     item['HalfBaths'] = planHalfBaths
        #     item['Bedrooms'] = Bedrooms
        #     item['Garage'] = Garage
        #     item['Description'] = PDescription
        #     item['ElevationImage'] =imagess
        #     item['PlanWebsite'] = PlanWebsite
        #     yield item
        # except Exception as e:
        #     print("Problem in Unknown Plan creation:", e)


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute("scrapy crawl bridgeportcustomhomes".split())
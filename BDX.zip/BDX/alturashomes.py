import hashlib
import json

import requests
import scrapy
import re
from scrapy.http import HtmlResponse
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Spec, BdxCrawlingItem_Plan


class AlturaHomesSpider(scrapy.Spider):
    name = 'alturashomes'
    allowed_domains = []
    start_urls = ['https://www.alturashomes.com/']

    builderNumber = "738504021794446141032025248994"

    def parse(self, response):
        try:
            images = response.xpath('//div[@class="flickr-gallery gallery"]/div/@href').extract()
            try:
                item = BdxCrawlingItem_subdivision()
                item['sub_Status'] = "Active"
                item['SubdivisionNumber'] = ''
                item['BuilderNumber'] = self.builderNumber
                item['SubdivisionName'] = "No Sub Division"
                item['BuildOnYourLot'] = 0
                item['OutOfCommunity'] = 0
                item['Street1'] = '500 E Shore Dr., Suite 100'
                item['City'] = 'Eagle'
                item['State'] = 'ID'
                item['ZIP'] = '83616'
                item['AreaCode'] = '208'
                item['Prefix'] = '391'
                item['Suffix'] = '4445'
                item['Extension'] = ""
                item['Email'] = "marketing@alturas.com"
                item['SubDescription'] = 'Factors that go into choosing our communities are as unique as our clients and their homes; whether it’s walkability, parks, great schools, planned social events, or pools and other facilities, you can rest assured every neighborhood we build in has something that makes it a great place to call home.'
                item['SubImage'] = '|'.join(images)
                item['SubWebsite'] = ''
                item['AmenityType'] = ''
                yield item
            except Exception as e:
                print(e)

            res = requests.request(url='https://www.alturashomes.com/floor-plans/', method='GET')
            response = HtmlResponse(url=res.url,body=res.content)
            selectors = response.xpath('//*[@class="list-card-title"]')
            plandetails = {}
            for selector in selectors:
                link = selector.xpath('./a/@href').extract_first()
                footer_list = selector.xpath('./../ul/li/span/text()').extract()
                if len(footer_list) == 4:
                    BaseSqft = footer_list[0]
                    Bedrooms = footer_list[1]
                    BaseBathrooms = footer_list[2]
                    Garage = footer_list[3]
                    res_plan_details = requests.request("GET", "https://www.alturashomes.com" + link)
                    response_plan_details = HtmlResponse(url=res_plan_details.url, body=res_plan_details.content)
                    PlanName = response_plan_details.xpath('//h1/text()').extract_first(default='').strip()
                    tmp = re.findall(r"(\d+)", BaseBathrooms)
                    if len(tmp) > 1:
                        BaseBathrooms = tmp[0]
                        if tmp[1] != '00':
                            BaseHalfBaths = 1
                        else:
                            BaseHalfBaths = 0
                    else:
                        BaseHalfBaths = 0
                    try:
                        images = []
                        image = response_plan_details.xpath('//div[@id="gallery"]/div/@href').extract()
                        for img in image:
                            if "https:" not in img:
                                images.append("https://www.alturashomes.com" + img)
                            else:
                                images.append(img)
                        Images = '|'.join(images)
                    except:
                        Images = ''
                    PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
                    f = open("html/%s.html" % PlanNumber, "wb")
                    f.write(response_plan_details.body)
                    f.close()
                    unique = str(PlanNumber) + str(PlanName) + str(self.builderNumber) + str(BaseSqft)  # < -------- Changes here
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                    plandetails[PlanName] = unique_number
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = 'SingleFamily'
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number  # < -------- Changes here
                    item['SubdivisionNumber'] = self.builderNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = 0
                    item['PlanTypeName'] = 'Single Family'
                    item['BasePrice'] = 0
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = BaseBathrooms
                    item['HalfBaths'] = BaseHalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = Garage
                    item['Description'] = 'With Alturas Homes, you get more than just a fantastic new home. From start to finish, our team is devoted to providing an exceptional new home experience in the Boise area.'
                    item['ElevationImage'] = Images
                    item['PlanWebsite'] = response_plan_details.url
                    yield item
                else:
                    print(len(footer_list))

            url = "https://www.alturashomes.com/api/v1/alturas/inventory/homes/geodraw?availability=0&bedrooms=0&planType=undefined&filterTo=&filterId=0&bounds=43.675920543512575&bounds=-116.07809829711914&bounds=43.59765168659641&bounds=-116.58449935913086"
            payload = "{\"draw\":1,\"columns\":[{\"data\":\"Title\",\"name\":\"\",\"searchable\":true,\"search\":{\"value\":\"\"}},{\"data\":\"Graphic\",\"name\":\"\"},{\"data\":\"Price\",\"name\":\"\"},{\"data\":\"Beds\",\"name\":\"\"},{\"data\":\"Baths\",\"name\":\"\"},{\"data\":\"Garages\",\"name\":\"\"},{\"data\":\"Sqft\",\"name\":\"\"},{\"data\":\"Plan.Name\",\"name\":\"\"},{\"data\":\"Lot.Title\",\"name\":\"\"},{\"data\":\"Lot.Latitude\",\"name\":\"\"},{\"data\":\"Lot.Longitude\",\"name\":\"\"},{\"data\":\"Lot.Block.Title\",\"name\":\"\"},{\"data\":\"Lot.Block.Phase.Community.Name\",\"name\":\"\"},{\"data\":\"HomeID\",\"name\":\"\"}],\"order\":[{\"column\":0,\"dir\":\"asc\"}],\"start\":0,\"length\":10,\"search\":{\"value\":\"\",\"regex\":false}}"
            self.headers = {
                'Accept': 'application/json, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'text/plain'
            }
            res_home = requests.request("POST", url, headers=self.headers, data=payload)
            response_home = HtmlResponse(url=res_home.url,body=res_home.content)
            home_data = json.loads(response_home.text)
            for home in home_data['data']:
                HomeID = home['HomeID']
                link = f"https://www.alturashomes.com/available-homes/{HomeID}"
                res_home_details = requests.request("GET", link, headers=self.headers)
                response_home_details = HtmlResponse(url=res_home_details.url,body=res_home_details.content)
                text_all = response_home_details.xpath('//dd[2]/text()').extract_first().split('/')
                SpecGarage = text_all[2]
                try:
                    Plan = response_home_details.xpath('//dd/a/text()').extract_first()
                    PlanNumber = plandetails[Plan]
                except:
                    PlanNumber = ''
                    plan_link = response_home_details.xpath('//dd/a/@href').extract_first()
                    res_missing_plan = requests.request(url="https://www.alturashomes.com" + plan_link, method='GET')
                    response_missing_plan = HtmlResponse(url=res_missing_plan.url, body=res_missing_plan.content)
                    PlanName = response_missing_plan.xpath('//h1/text()').extract_first(default='').strip()
                    if PlanName == 'Warm Springs':
                        print("")
                    try:
                        images = []
                        image = response_missing_plan.xpath('//div[@id="gallery"]/div/@href').extract()
                        for img in image:
                            if "https:" not in img:
                                images.append("https://www.alturashomes.com" + img)
                            else:
                                images.append(img)
                        Images = '|'.join(images)
                    except:
                        Images = ''
                    try:
                        details = response_missing_plan.xpath('//div[@class="n-v1-cols"]/div/h3')
                        for d in details:
                            print(d)
                            j = ''.join(d.xpath('./../text()').extract()).strip()
                            if 'Bedrooms' in j:
                                Bedrooms = d.xpath('./text()').extract_first()
                            if 'Bathrooms' in j:
                                BaseBathrooms = d.xpath('./text()').extract_first()
                                tmp = re.findall(r"(\d+)", BaseBathrooms)
                                if len(tmp) > 1:
                                    BaseBathrooms = tmp[0]
                                    if tmp[1] != '00':
                                        BaseHalfBaths = 1
                                    else:
                                        BaseHalfBaths = 0
                                else:
                                    BaseHalfBaths = 0
                            if 'House Size' in j:
                                BaseSqft = d.xpath('./text()').extract_first()
                    except:
                        BaseSqft = 0
                        Bedrooms = 0
                        BaseBathrooms = 0
                    PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
                    f1 = open("html/%s.html" % PlanNumber, "wb")
                    f1.write(response_missing_plan.body)
                    f1.close()
                    unique = str(PlanNumber) + str(PlanName) + str(self.builderNumber) + str(BaseSqft)  # < -------- Changes here
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                    plandetails[PlanName] = unique_number
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = 'SingleFamily'
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number  # < -------- Changes here
                    item['SubdivisionNumber'] = self.builderNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = 0
                    item['PlanTypeName'] = 'Single Family'
                    item['BasePrice'] = 0
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = BaseBathrooms
                    item['HalfBaths'] = BaseHalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = SpecGarage
                    item['Description'] = 'With Alturas Homes, you get more than just a fantastic new home. From start to finish, our team is devoted to providing an exceptional new home experience in the Boise area.'
                    item['ElevationImage'] = Images
                    item['PlanWebsite'] = res_missing_plan.url
                    yield item

            #--------Home code started------------

            h_url = "https://www.alturashomes.com/api/v1/alturas/inventory/homes/geodraw?availability=0&bedrooms=0&planType=undefined&filterTo=&filterId=0&bounds=43.675920543512575&bounds=-116.07809829711914&bounds=43.59765168659641&bounds=-116.58449935913086"
            h_payload = "{\"draw\":1,\"columns\":[{\"data\":\"Title\",\"name\":\"\",\"searchable\":true,\"search\":{\"value\":\"\"}},{\"data\":\"Graphic\",\"name\":\"\"},{\"data\":\"Price\",\"name\":\"\"},{\"data\":\"Beds\",\"name\":\"\"},{\"data\":\"Baths\",\"name\":\"\"},{\"data\":\"Garages\",\"name\":\"\"},{\"data\":\"Sqft\",\"name\":\"\"},{\"data\":\"Plan.Name\",\"name\":\"\"},{\"data\":\"Lot.Title\",\"name\":\"\"},{\"data\":\"Lot.Latitude\",\"name\":\"\"},{\"data\":\"Lot.Longitude\",\"name\":\"\"},{\"data\":\"Lot.Block.Title\",\"name\":\"\"},{\"data\":\"Lot.Block.Phase.Community.Name\",\"name\":\"\"},{\"data\":\"HomeID\",\"name\":\"\"}],\"order\":[{\"column\":0,\"dir\":\"asc\"}],\"start\":0,\"length\":10,\"search\":{\"value\":\"\",\"regex\":false}}"
            self.headers_h = {
                'Accept': 'application/json, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'text/plain'
            }
            response_h = requests.request("POST", h_url, headers=self.headers_h, data=h_payload)
            h_data = json.loads(response_h.text)
            for h in h_data['data']:
                HomeID_h = h['HomeID']
                link_h = f"https://www.alturashomes.com/available-homes/{HomeID_h}"
                res_h_details = requests.request("GET", link_h, headers=self.headers)
                response_h_details = HtmlResponse(url=res_h_details.url, body=res_h_details.content)
                try:
                    SpecStreet1 = response_h_details.xpath('//div[@class="carousel-details"]/h2/text()').extract_first(default='')
                except:
                    SpecStreet1 = ''

                try:
                    SpecCity = 'Eagle'
                except:
                    SpecCity = ''

                SpecState = 'ID'

                try:
                    SpecZIP = '83616'
                except:
                    SpecZIP = ''

                unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
                SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)

                f2 = open("html/%s.html" % SpecNumber, "wb")
                f2.write(response_h_details.body)
                f2.close()

                try:
                    SpecPrice = 0
                except:
                    SpecPrice = 0.00

                try:
                    SpecSqft = 0
                except:
                    SpecSqft = 0

                text_all = response_h_details.xpath('//dd[2]/text()').extract_first().split('/')
                try:
                    SpecBaths = text_all[1]
                    tmp = re.findall(r"(\d+)", SpecBaths)
                    SpecBaths = tmp[0]
                    if len(tmp) > 1:
                        SpecHalfBaths = 1
                    else:
                        SpecHalfBaths = 0
                except Exception as e:
                    SpecBaths = 0
                    SpecHalfBaths = 0

                SpecBedrooms = text_all[0]
                SpecGarage = text_all[2]

                try:
                    ElevationImages = []
                    Elevation_list = response_h_details.xpath('//div[@id="gallery"]/div/@href').extract()
                    for ele in Elevation_list:
                        if 'http' not in ele:
                            ele = 'https://www.alturashomes.com' + ele
                        ElevationImages.append(ele)
                    ElevationImage = '|'.join(ElevationImages)
                except:
                    ElevationImage = ''

                try:
                    SpecDescription = 'Factors that go into choosing our communities are as unique as our clients and their homes; whether it’s walkability, parks, great schools, planned social events, or pools and other facilities, you can rest assured every neighborhood we build in has something that makes it a great place to call home.'
                except:
                    SpecDescription = ''

                try:
                    Plan = response_h_details.xpath('//dd/a/text()').extract_first()
                    PlanNumber = plandetails[Plan]
                    item = BdxCrawlingItem_Spec()
                    item['SpecNumber'] = SpecNumber
                    item['PlanNumber'] = PlanNumber
                    item['SpecStreet1'] = SpecStreet1
                    item['SpecCity'] = SpecCity
                    item['SpecState'] = SpecState
                    item['SpecZIP'] = SpecZIP
                    item['SpecCountry'] = "USA"
                    item['SpecPrice'] = SpecPrice
                    item['SpecSqft'] = SpecSqft
                    item['SpecBaths'] = SpecBaths
                    item['SpecHalfBaths'] = SpecHalfBaths
                    item['SpecBedrooms'] = SpecBedrooms
                    item['MasterBedLocation'] = "Down"
                    item['SpecGarage'] = SpecGarage
                    item['SpecDescription'] = SpecDescription
                    item['SpecElevationImage'] = ElevationImage
                    item['SpecWebsite'] = response_h_details.url
                    yield item
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    # def plans_links(self, response):
    #     selectors = response.xpath('//*[@class="list-card-title"]')
    #     plandetails = {}
    #     for selector in selectors:
    #         link = selector.xpath('./a/@href').extract_first()
    #         # if 'Clearwater-XL' in link:
    #         footer_list = selector.xpath('./../ul/li/span/text()').extract()
    #         if len(footer_list) == 4:
    #             BaseSqft = footer_list[0]
    #             Bedrooms = footer_list[1]
    #             BaseBathrooms = footer_list[2]
    #             Garage = footer_list[3]
    #             yield scrapy.Request(url="https://www.alturashomes.com"+link, callback=self.plan_details, meta={'BaseSqft':BaseSqft,'Bedrooms':Bedrooms,
    #                                                                                                             'BaseBathrooms':BaseBathrooms,'Garage':Garage,
    #                                                                                                             'plandetails':plandetails})
    #         else:
    #             print(len(footer_list))
    #
    # def plan_details(self, response):
    #     blank = 0
    #     plandetails = response.meta['plandetails']
    #     PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
    #     PlanName = response.xpath('//h1/text()').extract_first(default='').strip()
    #     Garage = response.meta['Garage']
    #     Bedrooms = response.meta['Bedrooms']
    #     BaseSqft = response.meta['BaseSqft']
    #     BaseBathrooms = response.meta['BaseBathrooms']
    #     if Bedrooms == '' and BaseSqft == '' and BaseBathrooms == '':
    #         blank = 1
    #         try:
    #             details = response.xpath('//div[@class="n-v1-cols"]/div/h3')
    #             for d in details:
    #                 print(d)
    #                 j = ''.join(d.xpath('./../text()').extract()).strip()
    #                 if 'Bedrooms' in j:
    #                     Bedrooms = d.xpath('./text()').extract_first()
    #                 if 'Bathrooms' in j:
    #                     BaseBathrooms = d.xpath('./text()').extract_first()
    #                 if 'House Size' in j:
    #                     BaseSqft = d.xpath('./text()').extract_first()
    #         except:
    #             BaseSqft = 0
    #             Bedrooms = 0
    #             BaseBathrooms = 0
    #
    #         Garage = response.meta['Garage']
    #     tmp = re.findall(r"(\d+)", BaseBathrooms)
    #     if len(tmp) > 1:
    #         BaseBathrooms = tmp[0]
    #         if tmp[1] != '00':
    #             BaseHalfBaths = 1
    #         else:
    #             BaseHalfBaths = 0
    #     else:
    #         BaseHalfBaths = 0
    #     try:
    #         images = []
    #         image = response.xpath('//div[@id="gallery"]/div/@href').extract()
    #         for img in image:
    #             if "https:" not in img:
    #                 images.append("https://www.alturashomes.com"+img)
    #             else:
    #                 images.append(img)
    #         Images = '|'.join(images)
    #     except:
    #         Images = ''
    #
    #
    #     unique = str(PlanNumber) + str(PlanName) + str(self.builderNumber) + str(BaseSqft)  # < -------- Changes here
    #     unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
    #     item = BdxCrawlingItem_Plan()
    #     item['Type'] = 'SingleFamily'
    #     item['PlanNumber'] = PlanNumber
    #     item['unique_number'] = unique_number  # < -------- Changes here
    #     item['SubdivisionNumber'] = self.builderNumber
    #     item['PlanName'] = PlanName
    #     item['PlanNotAvailable'] = 0
    #     item['PlanTypeName'] = 'Single Family'
    #     item['BasePrice'] = 0
    #     item['BaseSqft'] = BaseSqft
    #     item['Baths'] = BaseBathrooms
    #     item['HalfBaths'] = BaseHalfBaths
    #     item['Bedrooms'] = Bedrooms
    #     item['Garage'] = Garage
    #     item['Description'] = 'With Alturas Homes, you get more than just a fantastic new home. From start to finish, our team is devoted to providing an exceptional new home experience in the Boise area.'
    #     item['ElevationImage'] = Images
    #     item['PlanWebsite'] = response.url
    #     yield item
    #
    #     # home_list1 = response.url.split('/')[-1].replace('-',' ')
    #     # plandetails[home_list1] = unique_number
    #     # comms = response.xpath('//div[@class="six-columns twelve-columns-mobile"]/a[contains(@href,"/communities/")]/@href').extract()
    #     # for comm in comms:
    #     #     yield scrapy.Request(url="https://www.alturashomes.com"+comm, callback=self.home_links, meta={'PN': unique_number,'plandetails':plandetails})
    #     # try:
    #     #     if blank == 1:
    #     #         home_link = response.meta['home_link']
    #     #         yield scrapy.Request(url=home_link, callback=self.homes, meta={'PN': unique_number, 'plandetails': plandetails}, headers=self.headers)
    #     # except Exception as e:
    #     #     print(e)
    #
    # # def home_links(self, response):
    # #     unique_number = response.meta['PN']
    # #     plandetails = response.meta['plandetails']
    # #     url = "https://www.alturashomes.com/api/v1/alturas/inventory/homes/geodraw?availability=0&bedrooms=0&planType=undefined&filterTo=community&filterId=3&bounds=43.71857271856816&bounds=-116.40290123066913&bounds=43.71198129215593&bounds=-116.43455129704486"
    # #     payload = "{\"draw\":1,\"columns\":[{\"data\":\"Title\",\"name\":\"\",\"searchable\":true,\"search\":{\"value\":\"\"}},{\"data\":\"Graphic\",\"name\":\"\"},{\"data\":\"Price\",\"name\":\"\"},{\"data\":\"Beds\",\"name\":\"\"},{\"data\":\"Baths\",\"name\":\"\"},{\"data\":\"Garages\",\"name\":\"\"},{\"data\":\"Sqft\",\"name\":\"\"},{\"data\":\"Plan.Name\",\"name\":\"\"},{\"data\":\"Lot.Title\",\"name\":\"\"},{\"data\":\"Lot.Latitude\",\"name\":\"\"},{\"data\":\"Lot.Longitude\",\"name\":\"\"},{\"data\":\"Lot.Block.Title\",\"name\":\"\"},{\"data\":\"Lot.Block.Phase.Community.Name\",\"name\":\"\"},{\"data\":\"HomeID\",\"name\":\"\"}],\"order\":[{\"column\":0,\"dir\":\"asc\"}],\"start\":0,\"length\":10,\"search\":{\"value\":\"\",\"regex\":false}}"
    # #     self.headers = {
    # #         'Accept': 'application/json, */*; q=0.01',
    # #         'Accept-Language': 'en-US,en;q=0.9',
    # #         'Referer': 'https://www.alturashomes.com/communities/3/homestead',
    # #         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
    # #         'X-Requested-With': 'XMLHttpRequest',
    # #         'Content-Type': 'text/plain'
    # #     }
    # #     response1 = requests.request("POST", url, headers=self.headers, data=payload)
    # #     home_data = json.loads(response1.text)
    # #     for home in home_data['data']:
    # #         HomeID = home['HomeID']
    # #         link = f"https://www.alturashomes.com/available-homes/{HomeID}"
    # #         yield scrapy.Request(url=link, callback=self.check_plan_missing, meta={'PN': unique_number,'plandetails':plandetails}, headers=self.headers)
    # #     for home1 in home_data['data']:
    # #         HomeID1 = home1['HomeID']
    # #         link1 = f"https://www.alturashomes.com/available-homes/{HomeID1}"
    # #         yield scrapy.Request(url=link1, callback=self.homes, meta={'PN': unique_number, 'plandetails': plandetails}, headers=self.headers)
    #
    # def check_plan_missing(self, response):
    #     plandetails = response.meta['plandetails']
    #     text_all = response.xpath('//dd[2]/text()').extract_first().split('/')
    #     SpecGarage = text_all[2]
    #     try:
    #         Plan = response.xpath('//dd/a/text()').extract_first()
    #         PlanNumber = plandetails[Plan]
    #     except:
    #         PlanNumber = ''
    #         plan_link = response.xpath('//dd/a/@href').extract_first()
    #         yield scrapy.Request(url="https://www.alturashomes.com" + plan_link, callback=self.plan_details,
    #                              meta={'BaseSqft': '', 'Bedrooms': '',
    #                                    'BaseBathrooms': '', 'Garage': SpecGarage, 'plandetails': plandetails,
    #                                    'home_link': response.url})
    #
    # def homes(self, response):
    #     if response.url == 'https://www.alturashomes.com/available-homes/38':
    #         print()
    #     plandetails = response.meta['plandetails']
    #     try:
    #         SpecStreet1 = response.xpath('//div[@class="carousel-details"]/h2/text()').extract_first(default='')
    #     except:
    #         SpecStreet1 = ''
    #
    #     try:
    #         SpecCity = 'Eagle'
    #     except:
    #         SpecCity = ''
    #
    #     SpecState = 'ID'
    #
    #     try:SpecZIP = '83616'
    #     except:SpecZIP = ''
    #
    #     unique = SpecStreet1 + SpecCity + SpecState + SpecZIP
    #     SpecNumber = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
    #
    #     f = open("html/%s.html" % SpecNumber, "wb")
    #     f.write(response.body)
    #     f.close()
    #
    #     try:SpecPrice = 0
    #     except:SpecPrice = 0.00
    #
    #     try:SpecSqft = 0
    #     except:SpecSqft = 0
    #
    #     text_all = response.xpath('//dd[2]/text()').extract_first().split('/')
    #     try:
    #         SpecBaths = text_all[1]
    #         tmp = re.findall(r"(\d+)", SpecBaths)
    #         SpecBaths = tmp[0]
    #         if len(tmp) > 1:
    #             SpecHalfBaths = 1
    #         else:
    #             SpecHalfBaths = 0
    #     except Exception as e:
    #         SpecBaths = 0
    #         SpecHalfBaths = 0
    #
    #     SpecBedrooms = text_all[0]
    #     SpecGarage = text_all[2]
    #
    #     try:
    #         ElevationImages = []
    #         Elevation_list = response.xpath('//div[@id="gallery"]/div/@href').extract()
    #         for ele in Elevation_list:
    #             if 'http' not in ele:
    #                 ele = 'https://www.alturashomes.com'+ele
    #             ElevationImages.append(ele)
    #         ElevationImage = '|'.join(ElevationImages)
    #     except:ElevationImage = ''
    #
    #     try:SpecDescription = ''
    #     except:SpecDescription = ''
    #
    #     try:
    #         Plan = response.xpath('//dd/a/text()').extract_first()
    #         PlanNumber = plandetails[Plan]
    #         item = BdxCrawlingItem_Spec()
    #         item['SpecNumber'] = SpecNumber
    #         item['PlanNumber'] = PlanNumber
    #         item['SpecStreet1'] = SpecStreet1
    #         item['SpecCity'] = SpecCity
    #         item['SpecState'] = SpecState
    #         item['SpecZIP'] = SpecZIP
    #         item['SpecCountry'] = "USA"
    #         item['SpecPrice'] = SpecPrice
    #         item['SpecSqft'] = SpecSqft
    #         item['SpecBaths'] = SpecBaths
    #         item['SpecHalfBaths'] = SpecHalfBaths
    #         item['SpecBedrooms'] = SpecBedrooms
    #         item['MasterBedLocation'] = "Down"
    #         item['SpecGarage'] = SpecGarage
    #         item['SpecDescription'] = SpecDescription
    #         item['SpecElevationImage'] = ElevationImage
    #         item['SpecWebsite'] = response.url
    #         yield item
    #     except:
    #         PlanNumber=''
    #         plan_link = response.xpath('//dd/a/@href').extract_first()
    #         yield scrapy.Request(url="https://www.alturashomes.com"+plan_link, callback=self.plan_details, meta={'BaseSqft': '', 'Bedrooms': '',
    #                                     'BaseBathrooms': '', 'Garage': SpecGarage, 'plandetails': plandetails,'home_link':response.url})


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl alturashomes'.split())

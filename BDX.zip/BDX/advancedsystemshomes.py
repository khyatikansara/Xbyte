# -*- coding: utf-8 -*-
import hashlib
import os
import scrapy
from scrapy.utils.response import open_in_browser
# from lxml.html import open_in_browser
import re
from BDX_Crawling.export_xml import genxml
from BDX_Crawling.items import BdxCrawlingItem_Builder, BdxCrawlingItem_Corporation, BdxCrawlingItem_Plan, BdxCrawlingItem_Spec, BdxCrawlingItem_subdivision
import requests
from scrapy.http import HtmlResponse


class advancedsystemshomesSpider(scrapy.Spider):
    name = 'advancedsystemshomes'
    allowed_domains = []
    start_urls = ['https://www.advancedsystemshomes.com/']

    builderNumber = "62158"

    def parse(self, response):

        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #

        f = open("html/%s.html" % self.builderNumber, "wb")
        f.write(response.body)
        f.close()
        SubDescription = response.xpath('//div[@class="introText"]/p/text()').extract_first().strip()

        item = BdxCrawlingItem_subdivision()
        item['sub_Status'] = "Active"
        item['SubdivisionNumber'] = ''
        item['BuilderNumber'] = self.builderNumber
        item['SubdivisionName'] = "No Sub Division"
        item['SubdivisionNumber'] = self.builderNumber
        # item['SubdivisionName'] = subdivisonNumber= "No Sub Division"
        item['BuildOnYourLot'] = 0
        item['OutOfCommunity'] = 0
        item['Street1'] = "4711 S Santa Fe Ave"
        item['City'] = "Chanute"
        item['State'] = "KS"
        item['ZIP'] = "66720"
        item['AreaCode'] = ""
        item['Prefix'] = ""
        item['Suffix'] = ""
        item['Extension'] = ""
        item['Email'] = ""
        item['SubDescription'] = SubDescription
        l = []
        images = response.xpath('//*[@class="hover-image"]/a/@href').extract()
        for image in images:
            image = "https://www.advancedsystemshomes.com/" + image
            res = requests.get(image)
            response1 = HtmlResponse(url='example.@xyz', body=res.content)
            final_images = response1.xpath('//*[@class="imgRtCarousel noPhoto"]//div//@src|//*[@class="imgNoFloatCarousel noPhoto"]//div//@src|//*[@class="imgRtCarousel noPhoto"]//div//@src|//*[@class="imgRtCarousel noPhoto"]//div//@src|//*[@class="imgRtCarousel noPhoto"]//div//@src').extract()
            for final_image in final_images:
                final_image = "https://www.advancedsystemshomes.com/" + final_image
                l.append(final_image)
        sabimages = "|".join(l)

        item['SubImage'] = sabimages
        item['SubWebsite'] = response.url
        item['AmenityType'] = ''
        yield item

        yield scrapy.FormRequest(url="https://www.advancedsystemshomes.com/plan-a-home/floor-plans", callback=self.parse_plan, dont_filter=True)

    def parse_plan(self, response):
        floor_plans = response.xpath('//figcaption/a/@href').extract()
        for floor_plan in floor_plans:
            floor_plan = "https://www.advancedsystemshomes.com"+floor_plan
            yield scrapy.FormRequest(url=floor_plan, callback=self.parse_plan1, dont_filter=True)

    def parse_plan1(self, response):
        plan_links = response.xpath('//figcaption/a/@href').extract()
        for plan_link in plan_links:
            plan_link = "https://www.advancedsystemshomes.com" + plan_link
            yield scrapy.FormRequest(url=plan_link, callback=self.plan_details, dont_filter=True)

    def plan_details(self, response):
        try:
            datas = response.xpath('//*[contains(@class,"contentBlock col-sm-6")]')
            Bed_bath_sqrs = re.findall(r' </figure>(.*?)</div>',response.text)
            for data,Bed_bath_sqr in zip(datas,Bed_bath_sqrs):
                try:
                    Type = 'SingleFamily'
                except Exception as e:
                    print(e)

                a = Bed_bath_sqr.split("|")

                try:
                    PlanName = data.xpath('.//*[@class="content"]/h2/text()').getall()[0]
                except Exception as e:
                    print(e)

                try:
                    PlanNumber = int(hashlib.md5(bytes(str(PlanName)+str(response.url), "utf8")).hexdigest(), 16) % (10 ** 30)
                except Exception as e:
                    print(e)

                try:
                    PlanNotAvailable = 0
                except Exception as e:
                    print(e)

                try:
                    PlanTypeName = 'Single Family'
                except Exception as e:
                    print(e)

                try:
                    Description = "Homes frame our existence. A home keeps us safe from the elements and is where we live out our lives and raise our families. At Advanced Systems Homes, we consider it an honor and a privilege to continue our grandfather's vision of designing and building quality, well-built modular homes for the hardworking people of our community. Thank you for considering ASH in your custom home building journey."
                except Exception as e:
                    print(e)

                try:
                    BaseSqft = a[2].replace('Square Feet:',"").replace('<br>',"").replace('</p>',"").strip()
                    BaseSqft = str(BaseSqft)
                    if "(" in BaseSqft:
                        BaseSqft=BaseSqft.split("(")[0].strip()
                except Exception as e:
                    print(e)

                try:
                    Baths = a[1].replace('Baths:',"").replace('&nbsp;',"").strip()
                    if "." in Baths:
                        Baths = Baths.split(".")[0]
                        HalfBaths = "1"
                    elif Baths == "":
                        Baths="0"
                        HalfBaths = "0"
                    else:
                        HalfBaths="0"
                except Exception as e:
                    Baths = "0"
                    HalfBaths = "0"
                    print(e)

                try:
                    Bedrooms = a[0].replace('Beds:',"").replace('&nbsp;',"").replace('<br>',"").replace('<p>',"").strip()
                    Bedrooms = str(Bedrooms)
                    if Bedrooms=="":
                        Bedrooms="0"
                except Exception as e:
                    Bedrooms = "0"
                    print(e)

                try:
                    ElevationImage = []
                    ElevationImage1 = data.xpath('.//*[@class="carousel-inner"]/div//@src').extract()
                    for i in ElevationImage1:
                        ElevationImage.append('https://www.advancedsystemshomes.com/' + str(i))
                    ElevationImage = "|".join(ElevationImage)
                except Exception as e:
                    print(e)

                try:
                    PlanWebsite = response.url
                    # print(PlanWebsite)
                except Exception as e:
                    print(e)

                # ----------------------- Don't change anything here --------------
                try:
                    unique = str(PlanName) + str(response.url) + str(self.builderNumber)  + str(PlanNumber) # < -------- Changes here
                    unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)  # < -------- Changes here
                    item = BdxCrawlingItem_Plan()
                    item['Type'] = Type
                    item['PlanNumber'] = PlanNumber
                    item['unique_number'] = unique_number  # < -------- Changes here
                    item['SubdivisionNumber'] = self.builderNumber
                    item['PlanName'] = PlanName
                    item['PlanNotAvailable'] = PlanNotAvailable
                    item['PlanTypeName'] = PlanTypeName
                    item['BasePrice'] = 0
                    item['BaseSqft'] = BaseSqft
                    item['Baths'] = Baths
                    item['HalfBaths'] = HalfBaths
                    item['Bedrooms'] = Bedrooms
                    item['Garage'] = 0
                    item['Description'] = Description[0:1500]
                    item['ElevationImage'] = ElevationImage
                    item['PlanWebsite'] = PlanWebsite
                    yield item
                except Exception as e:
                    print(e)
                    # --------------    ------------------------------------------------------- #
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl advancedsystemshomes".split())
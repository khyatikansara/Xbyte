# -*- coding: utf-8 -*-
import hashlib
import json
import re
import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from unidecode import unidecode
from BDX_Crawling.items import BdxCrawlingItem_subdivision, BdxCrawlingItem_Plan


class CornerstoneHomesSpider(scrapy.Spider):
    name = 'cornerstone_Homes_old'
    allowed_domains = []
    start_urls = ['https://www.mycornerstonehomes.com/build/communities/']

    # custom_settings = {
    #     'ITEM_PIPELINES': {
    #
    #     }
    # }

    builderNumber = 374377555547601390676082809823

    def parse(self, response):
        # IF you do not have Communities and you are creating the one
        # ------------------- If No communities found ------------------- #
        # image1 = '|'.join(response.xpath('//*[@class="widget-gem-portfolio-item  "]/img/@src').extract())
        # image = '|'.join(response.xpath('//div[@id="details"]/div[2]//img/@src').extract())
        # images = f"{image1}|{image}"
        # item = BdxCrawlingItem_subdivision()
        # item['sub_Status'] = "Active"
        # item['SubdivisionNumber'] = ''
        # item['BuilderNumber'] = self.builderNumber
        # item['SubdivisionName'] = "No Sub Division"
        # item['BuildOnYourLot'] = 0
        # item['OutOfCommunity'] = 0
        # item['Street1'] = "6703 Greyson Dr"
        # item['City'] = "Papillion"
        # item['State'] = "NE"
        # item['ZIP'] = "68133"
        # item['AreaCode'] = "402"
        # item['Prefix'] = "250"
        # item['Suffix'] = "3431"
        # item['Extension'] = ""
        # item['Email'] = "petersabal1@aol.com"
        # item['SubDescription'] = "At Castlebridge Homes, Inc. we strive to make your home building experience a pleasant one. Our goal is to provide you with an affordable quality custom home which will offer you years of enjoyment."
        # item['SubImage'] = images
        # item['SubWebsite'] = "https://castlebridgehomesomaha.com"
        # yield item
        # try:
        #     link1 = response.xpath('//a[contains(text(),"Home Designs")]/@href').extract_first()
        #     res = requests.get(url=link1)
        #     response1 = HtmlResponse(url=res.url, body=res.content)
        #     links = response1.xpath('//*[@class="portfolio-icons"]/a[1]/@href').extract()
        #     plandetains = {}
        #     for link in links:
        #         yield scrapy.Request(url=link, callback=self.plans_details,
        #                              meta={'sbdn': self.builderNumber, 'PlanDetails': plandetains}, dont_filter=True)
        # except Exception as e:
        #     print(e)

        # IF you have Communities
        links = response.xpath('//*[contains(text(),"SELECT A COMMUNITY")]/../../../../../../div[2]//a/@href').extract()
        Subdivision_dict = {}
        for link in links:
            url = self.start_urls[0] + link
            yield scrapy.Request(url=str(url), callback=self.process_communities, dont_filter=True, meta={'Subdivision_dict':Subdivision_dict})

        plandetails = {}
        # floorplans_links = response.xpath('//span[contains(text(),"Floor Plans")]/../@href').extract_first()
        yield scrapy.Request(url=str(self.start_urls[0]), callback=self.parse_plan, dont_filter=True,
                             meta={'Subdivision_dict': Subdivision_dict, 'plandetails': plandetails})

    def process_communities(self,response):
        try:
            Subdivision_dict = response.meta['Subdivision_dict']
            if 'markland' in response.request.url:
                Street1 = "54 Kirkside Avenue"
                comm_id = 'markland'
                AreaCode = "904"
                Prefix = "342"
                Suffix = "3390"
            else:
                Street1 = "1421 North Loop Parkway"
                comm_id = 'palencia'
                AreaCode = "904"
                Prefix = "295"
                Suffix = "8873"

            images = response.xpath('//*[@property="og:image"]/@content').extract_first()
            SubdivisionName = response.xpath(f'//section[@id="{comm_id}"]/following-sibling::section//h2/text()').extract_first().split()[0].strip()
            SubdivisionNumber = int(hashlib.md5(bytes(SubdivisionName + str(self.builderNumber) + str(comm_id), "utf8")).hexdigest(),16) % (10 ** 30)
            SubDescription = response.xpath(f'//section[@id="{comm_id}"]//div[@class="elementor-text-editor elementor-clearfix"]/text()').extract_first().strip()

            Subdivision_dict[SubdivisionName.lower()] = SubdivisionNumber
            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = SubdivisionNumber
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = SubdivisionName
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 1
            item['Street1'] = Street1
            item['City'] = 'St. Augustine'
            item['State'] = 'FL'
            item['ZIP'] = '32095'
            item['AreaCode'] = AreaCode
            item['Prefix'] = Prefix
            item['Suffix'] = Suffix
            item['Extension'] = ""
            item['Email'] = "mark.downing@cornerstonehomesjax.com"
            item['SubDescription'] = SubDescription
            item['SubImage'] = images
            item['SubWebsite'] = response.url
            item['AmenityType'] = ''
            yield item
        except Exception as e:
            print(e)

    def parse_plan(self, response):
        Subdivision_dict = response.meta['Subdivision_dict']
        plandetails = response.meta['plandetails']
        all_plan_links = []
        plan_links1 = response.xpath('//h2/a/@href').extract()
        for plan_link1 in plan_links1:
            if 'https://www.mycornerstonehomes.com/' in plan_link1:
                all_plan_links.append(plan_link1)
        if response.xpath('//span[text()="Load More"]'):
            url = "https://www.mycornerstonehomes.com/wp-admin/admin-ajax.php"
            payload_list = ["action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=2&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058",
                            "action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=3&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058",
                            "action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=22&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=pal-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=2&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058"]
            headers = {
                'accept': 'application/json, text/javascript, */*; q=0.01',
                'accept-language': 'en-US,en;q=0.9',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',
                'x-requested-with': 'XMLHttpRequest',
                'Cookie': '__cfduid=dee46f0138d8cda64c81be584585bc3f71618319073'
            }
            for payload in payload_list:
                response_more = requests.request("POST", url, headers=headers, data=payload)
                json_data = json.loads(response_more.text)
                html_data = html.fromstring(json_data['data']['html'])
                plan_links11 = html_data.xpath('//h2/a/@href')
                for plan_link11 in plan_links11:
                    if 'https://www.mycornerstonehomes.com/' in plan_link11:
                        all_plan_links.append(plan_link11)

        for plan_link in all_plan_links:
            yield scrapy.Request(url=str(plan_link), callback=self.process_plan, dont_filter=True
                                 ,meta={'plandetails': plandetails, 'Subdivision_dict':Subdivision_dict})
        # if response.xpath('//span[text()="Load More"]'):
        #     url = "https://www.mycornerstonehomes.com/wp-admin/admin-ajax.php"
        #     payload_list = ["action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=2&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058",
        #                     "action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=3&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058",
        #                     ]
        #     # payload1 = "action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=2&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058"
        #     # payload2 = "action=jet_engine_ajax&handler=listing_load_more&query%5Bpost_status%5D%5B%5D=publish&query%5Bpost_type%5D=post&query%5Bposts_per_page%5D=6&query%5Bpaged%5D=1&query%5Bignore_sticky_posts%5D=1&query%5Btax_query%5D%5B0%5D%5Btaxonomy%5D=category&query%5Btax_query%5D%5B0%5D%5Bfield%5D=term_id&query%5Btax_query%5D%5B0%5D%5Bterms%5D%5B%5D=17&query%5Btax_query%5D%5B0%5D%5Boperator%5D=IN&query%5Bsuppress_filters%5D=false&query%5Bjet_smart_filters%5D=jet-engine%2Fdefault&widget_settings%5Blisitng_id%5D=1058&widget_settings%5Bposts_num%5D=6&widget_settings%5Bcolumns%5D=3&widget_settings%5Bcolumns_tablet%5D=3&widget_settings%5Bcolumns_mobile%5D=1&widget_settings%5Bis_archive_template%5D=&widget_settings%5Bpost_status%5D%5B%5D=publish&widget_settings%5Buse_random_posts_num%5D=&widget_settings%5Bmax_posts_num%5D=9&widget_settings%5Bnot_found_message%5D=No+data+was+found&widget_settings%5Bis_masonry%5D=false&widget_settings%5Bequal_columns_height%5D=&widget_settings%5Buse_load_more%5D=yes&widget_settings%5Bload_more_id%5D=markland-more&widget_settings%5Bload_more_type%5D=click&widget_settings%5Buse_custom_post_types%5D=&widget_settings%5Bhide_widget_if%5D=&widget_settings%5Bcarousel_enabled%5D=&widget_settings%5Bslides_to_scroll%5D=1&widget_settings%5Barrows%5D=true&widget_settings%5Barrow_icon%5D=fa+fa-angle-left&widget_settings%5Bdots%5D=&widget_settings%5Bautoplay%5D=true&widget_settings%5Bautoplay_speed%5D=5000&widget_settings%5Binfinite%5D=true&widget_settings%5Beffect%5D=slide&widget_settings%5Bspeed%5D=500&widget_settings%5Binject_alternative_items%5D=&widget_settings%5Bscroll_slider_enabled%5D=&widget_settings%5Bscroll_slider_on%5D%5B%5D=desktop&widget_settings%5Bscroll_slider_on%5D%5B%5D=tablet&widget_settings%5Bscroll_slider_on%5D%5B%5D=mobile&widget_settings%5B_element_id%5D=&post_id=false&queried_id=false&element_id=false&page=3&listing_type=false&isEditMode=false&addedPostCSS%5B%5D=1058&addedPostCSS%5B%5D=1058"
        #     headers = {
        #         'accept': 'application/json, text/javascript, */*; q=0.01',
        #         'accept-language': 'en-US,en;q=0.9',
        #         'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        #         'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',
        #         'x-requested-with': 'XMLHttpRequest',
        #         'Cookie': '__cfduid=dee46f0138d8cda64c81be584585bc3f71618319073'
        #     }
        #     for payload in payload_list:
        #         response_more = requests.request("POST", url, headers=headers, data=payload)
        #         json_data = json.loads(response_more.text)
        #         html_data = html.fromstring(json_data['data']['html'])
        #         plan_links11 = html_data.xpath('//h2/a/@href')
        #         for plan_link11 in plan_links11:
        #             yield scrapy.Request(url=str(plan_link11), callback=self.process_plan, dont_filter=True
        #                                  , meta={'plandetails': plandetails, 'Subdivision_dict': Subdivision_dict})
            # yield scrapy.FormRequest(url=str(url), callback=self.process_plan,formdata=body,headers=headers,method="POST", meta={'plandetails': plandetails, 'Subdivision_dict': Subdivision_dict})

    def process_plan(self, response):
        Subdivision_dict = response.meta['Subdivision_dict']
        plandetails = response.meta['plandetails']
        if '"markland-floorplans"' in response.text:
            comm_id2 = 'markland'
        elif '"palencia-floorplans"' in response.text:
            comm_id2 = 'palencia'
        elif "Palencia" in response.text:
            comm_id2 = 'palencia'
        elif "Markland" in response.text:
            comm_id2 = 'markland'
        else:
            comm_id2 = ''
        if comm_id2 != '':
            try:
                PlanName = response.xpath('//h1/text()').extract_first(default='').strip()
                if '–' in PlanName:
                    PlanName = PlanName.split('–')[0].strip()
            except Exception as e:
                print(e)

            try:
                BasePrice = response.xpath('//*[contains(text(),"$")]/text()').extract_first(default='0').strip()
                BasePrice = BasePrice.replace("$", '').replace(",", '').strip()
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(bytes(response.url + str(PlanName) + str(BasePrice) + str(comm_id2), "utf8")).hexdigest(),16) % (10 ** 30)
                PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % PlanNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                Baths = str(response.xpath('//*[contains(text(),"baths")]/text()').extract_first(default='0').strip())
                if '/' in Baths:
                    Baths = Baths.split('/')[1]
                    tmp = re.findall(r"(\d+)", Baths)
                    Baths = tmp[0]
                    if len(tmp) > 1:
                        HalfBaths = 1
                    else:
                        HalfBaths = 0
                else:
                    Baths = '0'
            except Exception as e:
                print(e)

            try:
                Bedrooms = str(response.xpath('//*[contains(text(),"bed")]/text()').extract_first(default='0').strip())
                if '/' in Bedrooms:
                    Bedrooms = Bedrooms.split('/')[0]
                    Bedrooms = re.findall(r'(\d+)', Bedrooms)[0]
                else:
                    Bedrooms = '0'
            except Exception as e:
                print(e)

            try:
                Garage_tmp = '|'.join(response.xpath('//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).replace('\n','')
                Garage_list = Garage_tmp.split("|")
                BaseSqft,Garage = '',''
                for value in Garage_list:
                    if Garage == '' and 'car' in value.lower():
                        Garage = value
                        Garage = re.findall(r'(\d+)', Garage)[0]
                    if BaseSqft == '' and 'Sq. Feet' in value:
                        BaseSqft = value.replace(',','')
                        BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
                if BaseSqft == '':
                    BaseSqft = response.xpath('//*[contains(text(),"sq ft")]/text()').extract_first().replace(',','').strip()
                    BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                Description = unidecode(''.join(response.xpath('//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).strip().replace('\n',','))
            except Exception as e:
                print(e)

            try:
                ele_list = []
                ElevationImage1_tmp = response.xpath('//*[contains(text(),"Elevations")]/../../../div//img/@src').extract()
                for ele in ElevationImage1_tmp:
                    if 'data:image' not in ele:
                        ele_list.append(ele)
                ElevationImage1 = '|'.join(ele_list)
                GallaryImage = response.xpath('//*[@class="elementor-image"]/img/@src').extract_first()
                floorplanImage = '|'.join(response.xpath('//*[contains(text(),"Model Home")]/../../../div//a/@href').extract())
                ElevationImage = ElevationImage1.strip('|') + GallaryImage.strip('|') + floorplanImage.strip('|')
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.url
            except Exception as e:
                print(e)
            try:
                SubdivisionNumber = Subdivision_dict[comm_id2]
                # SubdivisionNumber = response.meta['SubdivisionNumber']  # if subdivision is there
                # SubdivisionNumber = self.builderNumber #if subdivision is not available
                unique = str(PlanNumber) + str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                plandetails[PlanName] = unique_number
                item = BdxCrawlingItem_Plan()
                item['Type'] = 'SingleFamily'
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = 'Single Family'
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = Garage
                item['Description'] = Description
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item
            except Exception as e:
                print(e)
        else:
            images = "https://www.mycornerstonehomes.com/wp-content/uploads/2020/05/shutterstock_636070442@2x-1024x760.png"
            item = BdxCrawlingItem_subdivision()
            item['sub_Status'] = "Active"
            item['SubdivisionNumber'] = ''
            item['BuilderNumber'] = self.builderNumber
            item['SubdivisionName'] = "No Sub Division"
            item['BuildOnYourLot'] = 0
            item['OutOfCommunity'] = 0
            item['Street1'] = "1421 North Loop Parkway"
            item['City'] = "St Augustine"
            item['State'] = "FL"
            item['ZIP'] = "32095"
            item['AreaCode'] = "904"
            item['Prefix'] = "295"
            item['Suffix'] = "8873"
            item['Extension'] = ""
            item['Email'] = "mark.downing@cornerstonehomesjax.com"
            item['SubDescription'] = "You’ve worked hard for this, and you deserve to work with a custom home builder you can trust. We’re here to guide you through the home building process, prioritize your needs, and deliver a home that fits your vision and lifestyle."
            item['SubImage'] = images
            item['SubWebsite'] = "https://www.mycornerstonehomes.com/build/"
            item['AmenityType'] = ''
            yield item
            try:
                PlanName = response.xpath('//h1/text()').extract_first(default='').strip()
                if '–' in PlanName:
                    PlanName = PlanName.split('–')[0].strip()
            except Exception as e:
                print(e)

            try:
                BasePrice = response.xpath('//*[contains(text(),"$")]/text()').extract_first(default='0').strip()
                BasePrice = BasePrice.replace("$", '').replace(",", '').strip()
            except Exception as e:
                print(e)

            try:
                PlanNumber = int(hashlib.md5(
                    bytes(response.url + str(PlanName) + str(BasePrice) + str(comm_id2), "utf8")).hexdigest(), 16) % (
                                         10 ** 30)
                PlanNumber = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 30)
                f = open("html/%s.html" % PlanNumber, "wb")
                f.write(response.body)
                f.close()
            except Exception as e:
                print(e)

            try:
                PlanNotAvailable = 0
            except Exception as e:
                print(e)

            try:
                Baths = str(response.xpath('//*[contains(text(),"baths")]/text()').extract_first(default='0').strip())
                if '/' in Baths:
                    Baths = Baths.split('/')[1]
                    tmp = re.findall(r"(\d+)", Baths)
                    Baths = tmp[0]
                    if len(tmp) > 1:
                        HalfBaths = 1
                    else:
                        HalfBaths = 0
                else:
                    Baths = '0'
            except Exception as e:
                print(e)

            try:
                Bedrooms = str(response.xpath('//*[contains(text(),"bed")]/text()').extract_first(default='0').strip())
                if '/' in Bedrooms:
                    Bedrooms = Bedrooms.split('/')[0]
                    Bedrooms = re.findall(r'(\d+)', Bedrooms)[0]
                else:
                    Bedrooms = '0'
            except Exception as e:
                print(e)

            try:
                Garage_tmp = '|'.join(response.xpath(
                    '//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).replace(
                    '\n', '')
                Garage_list = Garage_tmp.split("|")
                BaseSqft, Garage = '', ''
                for value in Garage_list:
                    if Garage == '' and 'car' in value.lower():
                        Garage = value
                        Garage = re.findall(r'(\d+)', Garage)[0]
                    if BaseSqft == '' and 'Sq. Feet' in value:
                        BaseSqft = value.replace(',', '')
                        BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
                if BaseSqft == '':
                    BaseSqft = response.xpath('//*[contains(text(),"sq ft")]/text()').extract_first().replace(',',
                                                                                                              '').strip()
                    BaseSqft = re.findall(r'(\d+)', BaseSqft)[0]
            except Exception as e:
                print(e)

            try:
                Description = unidecode(''.join(response.xpath(
                    '//*[contains(text(),"Floor Plan Features:")]/../../following-sibling::div//text()').extract()).strip().replace(
                    '\n', ','))
            except Exception as e:
                print(e)

            try:
                ele_list = []
                ElevationImage1_tmp = response.xpath('//*[contains(text(),"Elevations")]/../../../div//img/@src').extract()
                for ele in ElevationImage1_tmp:
                    if 'data:image' not in ele:
                        ele_list.append(ele)
                ElevationImage1 = '|'.join(ele_list)
                GallaryImage = response.xpath('//*[@class="elementor-image"]/img/@src').extract_first()
                floorplanImage = '|'.join(response.xpath('//*[contains(text(),"Model Home")]/../../../div//a/@href').extract())
                ElevationImage = ElevationImage1.strip('|') + GallaryImage.strip('|') + floorplanImage.strip('|')
            except Exception as e:
                print(e)

            try:
                PlanWebsite = response.url
            except Exception as e:
                print(e)
            try:
                # SubdivisionNumber = Subdivision_dict[comm_id2]
                # SubdivisionNumber = response.meta['SubdivisionNumber']  # if subdivision is there
                SubdivisionNumber = self.builderNumber #if subdivision is not available
                unique = str(PlanNumber) + str(SubdivisionNumber)
                unique_number = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 30)
                plandetails[PlanName] = unique_number
                item = BdxCrawlingItem_Plan()
                item['Type'] = 'SingleFamily'
                item['PlanNumber'] = PlanNumber
                item['unique_number'] = unique_number
                item['SubdivisionNumber'] = SubdivisionNumber
                item['PlanName'] = PlanName
                item['PlanNotAvailable'] = PlanNotAvailable
                item['PlanTypeName'] = 'Single Family'
                item['BasePrice'] = BasePrice
                item['BaseSqft'] = BaseSqft
                item['Baths'] = Baths
                item['HalfBaths'] = HalfBaths
                item['Bedrooms'] = Bedrooms
                item['Garage'] = Garage
                item['Description'] = Description
                item['ElevationImage'] = ElevationImage
                item['PlanWebsite'] = PlanWebsite
                yield item
            except Exception as e:
                print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl cornerstone_Homes_old".split())

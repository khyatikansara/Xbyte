from datetime import date

host = "192.168.1.252"
usernm = "root"
passwd = "xbyte"
database = "nih"
today = date.today()

search_key = "search"
link_table = "links"
unique_link = "unique_links"
data_table = "data"


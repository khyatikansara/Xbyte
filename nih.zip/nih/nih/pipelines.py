# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from itemadapter import ItemAdapter
from nih import db_config as dbc
from nih.items import NihItemLink


class NihPipeline:
    try:
        con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd)
        cursor = con.cursor()
        cursor.execute(f'CREATE DATABASE IF NOT EXISTS {dbc.database}')
    except Exception as e:
        print(str(e))
    con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd, dbc.database)
    cursor = con.cursor()

    try:
        create1 = f"""CREATE TABLE IF NOT EXISTS {dbc.data_table} (`Id` int NOT NULL AUTO_INCREMENT,
                                                        Leagal_Name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Preferred_Name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Email longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Location longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Mail_Stop longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Phone longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Fax longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        IC longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Organization longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Classification longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        URL varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
                                                        html_path longtext DEFAULT NULL,
                                                        UNIQUE KEY (`URL`),
                                                        primary key(`Id`));"""
        cursor.execute(create1)
    except Exception as e:
        print(e)

    def process_item(self, item, spider):
        if isinstance(item, NihItemLink):
            table = item['table']
            del item['table']
            self.insert_item(table, item)

    def insert_item(self, table, item):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print('Data Inserted...')
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))

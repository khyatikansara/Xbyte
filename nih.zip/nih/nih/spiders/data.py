# -*- coding: utf-8 -*-
import hashlib
import os
import re
import time
from os import listdir
from os.path import isfile, join

import requests
import scrapy
from lxml import html

from nih.items import NihItemLink
from selenium import webdriver
from nih import db_config as dbc
from nih.pipelines import NihPipeline as pipe


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ['https://ned.nih.gov/search/']
    start,end = '',''

    def parse(self, response):
        try:
            pipe.cursor.execute(f'select * from {dbc.database}.{dbc.unique_link} where status="data done" and Id>"{self.start}" and Id<"{self.end}"')
            results = pipe.cursor.fetchall()
            for raw in results:
                Leagal_Name = Preferred_Name = Email = Location = Mail_Stop = Phone = Fax = IC = Organization = Classification = ''
                Id = raw[0]
                print("====="+str(Id)+"======")
                url = raw[1]
                url_id = url.split('=')[-1]
                path = f"F:\khyati\Project VM\\NIH_HTML\data\\{url_id}.html"
                headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
                    'Cookie': 'f5_cspm=1234; f5avraaaaaaaaaaaaaaaa_session_=NKJPONLLKHEJLNACIFDNIHIKNFKGANEEEPDKPNBDGGPPNCDCANMGAJMLAEMFBLGLHCNDIADACHPBHKILCACAJLIANKLHOGKBDLAMCGAPEPBODAIIFIOJMBILLIHMLKBK; ASP.NET_SessionId=k5vqa1eppbtvjx3wwcpdjqh5; TS01580513=01a14d5b6e450fbed55526833197081c14dc6e4d54602282fe763b1eed8f0c204ab5dc1ddbc9f5bdac8cb5359706792333e8774054; TS0840911c027=08361e8a1bab20002c00fac7aac27e9a82a2fc4461c9711943ccb637263d1ea3c6b15eb3825d8379082b69c03d1130003110ce0b3423709337da47844f3080fdd180a4564930f903f7f9635cc51644d47f807852c11cb56a32407d6f1c1ca38c'
                }
                response = requests.request("GET", url, headers=headers)
                if response.status_code == 200:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(response.text)
                        f.close()
                    response1 = html.fromstring(response.text)
                    total = response1.xpath('//table[@id="ContentPlaceHolder_dvPerson"]/tr/td')
                    for i in total:
                        try:
                            text = ''.join(i.xpath('..//text()'))
                            if 'Legal Name' in text and Leagal_Name == '':
                                text1 = text.replace('Legal Name:','')
                                Leagal_Name = re.sub(r'\s+',' ',text1).strip()
                            if 'Preferred Name' in text and Preferred_Name == '':
                                text1 = text.replace('Preferred Name:','')
                                Preferred_Name = re.sub(r'\s+',' ',text1).strip()
                            if 'E-mail' in text and Email == '':
                                text1 = text.replace('E-mail:','')
                                Email = re.sub(r'\s+',' ',text1).strip()
                            if 'Location' in text and Location == '':
                                tmp_text = '|'.join(i.xpath('..//text()')).strip()
                                text1 = tmp_text.replace('|Location:|','')
                                Location = re.sub(r'|$','',text1)
                            if 'Mail Stop' in text and Mail_Stop == '':
                                text1 = text.replace('Mail Stop:','')
                                Mail_Stop = re.sub(r'\s+',' ',text1).strip()
                            if 'Phone' in text and Phone == '':
                                text1 = text.replace('Phone:','')
                                Phone = re.sub(r'\s+',' ',text1).strip()
                            if 'Fax' in text and Fax == '':
                                text1 = text.replace('Fax:','')
                                Fax = re.sub(r'\s+',' ',text1).strip()
                            if 'IC:' in text and IC == '':
                                text1 = text.replace('IC:','')
                                IC = re.sub(r'\s+',' ',text1).strip()
                            if 'Organization' in text and Organization == '':
                                text1 = text.replace('Organization:','')
                                Organization = re.sub(r'\s+',' ',text1).strip()
                            if 'Classification' in text and Classification == '':
                                text1 = text.replace('Classification:','')
                                Classification = re.sub(r'\s+',' ',text1).strip()
                        except Exception as e:
                            print(e)
                    html_path = path.replace('\\','\\\\')
                    try:
                        item = NihItemLink()
                        item['Leagal_Name'] = Leagal_Name
                        item['Preferred_Name'] = Preferred_Name
                        item['Email'] = Email
                        item['Location'] = Location
                        item['Mail_Stop'] = Mail_Stop
                        item['Phone'] = Phone
                        item['Fax'] = Fax
                        item['IC'] = IC
                        item['Organization'] = Organization
                        item['Classification'] = Classification
                        item['URL'] = url
                        item['html_path'] = html_path
                        item['table'] = dbc.data_table
                        yield item
                    except Exception as e:
                        print(e)
                    try:
                        pipe.cursor.execute(f'''update {dbc.database}.{dbc.unique_link} set status="data done" where Id="{Id}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl data -a start=61630 -a end=61632'.split())
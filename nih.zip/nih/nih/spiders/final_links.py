# -*- coding: utf-8 -*-
import hashlib
import os
import time
from os import listdir
from os.path import isfile, join

import scrapy
from lxml import html

from nih.items import NihItemLink
from selenium import webdriver
from nih import db_config as dbc
from nih.pipelines import NihPipeline as pipe


class FinalLinksSpider(scrapy.Spider):
    name = 'final_links'
    allowed_domains = []
    start_urls = ['https://ned.nih.gov/search/']

    def parse(self, response):
        try:
            pipe.cursor.execute(f'select * from {dbc.database}.search where status="Done_252"')
            results = pipe.cursor.fetchall()
            for raw in results:
                flag = False
                Id = raw[0]
                print("====="+str(Id)+"======")
                search_key = raw[1]
                mypath = f"F:\khyati\Project VM\\NIH_HTML\link\\{search_key}\\"
                onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
                for files in onlyfiles:
                    print(files)
                    path = mypath+files
                    # path = "F:\khyati\Project VM\\NIH_HTML\link\cy\dept_13_page_0.html"
                    with open(path, 'r', encoding='utf-8') as f:
                        file_open = f.read()
                        f.close()
                    if 'Please enter at least two characters in first name and/or last name.' in file_open:
                        try:
                            pipe.cursor.execute(f'''update {dbc.database}.{dbc.search_key} set status="farithi" where Id="{Id}"''')
                            pipe.con.commit()
                            print("update done")
                        except Exception as e:
                            print(e)
                    else:
                        if 'No matching records found!' in file_open:
                            flag = True
                        else:
                            flag = True
                            response_f = html.fromstring(file_open)
                            links = response_f.xpath('//a[contains(@href,"ViewDetails.aspx?NIHID")]/@href')
                            for link in links:
                                try:
                                    item = NihItemLink()
                                    item['table'] = dbc.link_table
                                    if 'https://ned.nih.gov/search/' in link:
                                        item['url'] = link
                                    else:
                                        item['url'] = 'https://ned.nih.gov/search/'+link
                                    yield item
                                except Exception as e:
                                    print(e)
                                try:
                                    item = NihItemLink()
                                    item['table'] = dbc.unique_link
                                    if 'https://ned.nih.gov/search/' in link:
                                        item['url'] = link
                                    else:
                                        item['url'] = 'https://ned.nih.gov/search/'+link
                                    yield item
                                except Exception as e:
                                    print(e)
                    if flag:
                        try:
                            pipe.cursor.execute(f'''update {dbc.database}.{dbc.search_key} set status="link_done" where Id="{Id}"''')
                            pipe.con.commit()
                            print("update done")
                        except Exception as e:
                            print(e)
                    else:
                        print("STOP")
        except Exception as e:
            print(e)



if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl final_links'.split())
# -*- coding: utf-8 -*-
import hashlib
import os
import time
import scrapy
from nih.items import NihItemLink
from selenium import webdriver
from nih import db_config as dbc
from nih.pipelines import NihPipeline as pipe


class LinksSpider(scrapy.Spider):
    name = 'links'
    allowed_domains = []
    start_urls = ['https://ned.nih.gov/search/']
    start,end = '',''

    def parse(self, response):
        try:
            chrome_options = webdriver.ChromeOptions()
            self.driver = webdriver.Chrome(chrome_options=chrome_options, executable_path="D:\\chromedriver_win32\\chromedriver.exe")
            self.driver.get('https://ned.nih.gov/search/')
            time.sleep(3)
            pipe.cursor.execute(f'select * from {dbc.database}.search where status="pending" and Id>"{self.start}" and Id<"{self.end}"')
            results = pipe.cursor.fetchall()
            for raw in results:
                Id = raw[0]
                print("====="+str(Id)+"======")
                search_key = raw[1]
                path1 = f"F:\khyati\Project VM\\NIH_HTML\link\\{search_key}"
                if not os.path.exists(path1):
                    os.makedirs(path1)

                lastname = self.driver.find_element_by_id("ContentPlaceHolder_txtLastName")
                lastname.clear()
                lastname.send_keys(search_key)
                select_dept = self.driver.find_elements_by_xpath('//select[@id="ContentPlaceHolder_ddlIC"]/option')
                for dept in range(1, len(select_dept)+1):
                    lastname = self.driver.find_element_by_id("ContentPlaceHolder_txtLastName")
                    lastname.clear()
                    lastname.send_keys(search_key)
                    count = 1
                    self.driver.find_element_by_xpath(f'//select[@id="ContentPlaceHolder_ddlIC"]/option[{str(dept)}]').click()
                    time.sleep(3)
                    self.driver.find_element_by_id('ContentPlaceHolder_btnSearchName').click()
                    time.sleep(10)
                    try:
                        self.driver.find_element_by_xpath('//select[@id="ContentPlaceHolder_ddlPageSize"]/option[last()]').click()
                        time.sleep(5)
                        dept_count = dept
                        path = f"{path1}\\dept_{str(dept_count)}_page_{str(count)}.html"
                        with open(path, 'w', encoding='utf-8') as f:
                            f.write(self.driver.page_source)
                            f.close()
                        print("page save done")
                        total_pages = self.driver.find_elements_by_xpath('//tr[@class="GVPager"][1]/td/table/tbody/tr/td')
                        for page in range(2,len(total_pages)+1):
                            print(page)
                            count = page
                            path = f"{path1}\\dept_{str(dept_count)}_page_{str(count)}.html"
                            if os.path.exists(path):
                                print("Already done---"+path)
                            else:
                                self.driver.find_element_by_xpath(f'//tr[@class="GVPager"][1]/td/table/tbody/tr/td[{page}]').click()
                                time.sleep(3)
                                with open(path, 'w', encoding='utf-8') as f:
                                    f.write(self.driver.page_source)
                                    f.close()
                                print("page save done")
                    except:
                        dept_count = dept
                        path = f"{path1}\\dept_{str(dept_count)}_page_0.html"
                        with open(path, 'w', encoding='utf-8') as f:
                            f.write(self.driver.page_source)
                            f.close()
                        print("page save done")
                try:
                    pipe.cursor.execute(f'''update {dbc.database}.{dbc.search_key} set status="Done_252" where Id="{Id}"''')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)

            self.driver.close()
        except Exception as e:
            print(e)
            self.driver.close()


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl links -a start=0 -a end=10001'.split())
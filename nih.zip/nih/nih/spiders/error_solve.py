# -*- coding: utf-8 -*-
import hashlib
import os
import re
import time
from os import listdir
from os.path import isfile, join

import requests
import scrapy
from lxml import html

from nih.items import NihItemLink
from selenium import webdriver
from nih import db_config as dbc
from nih.pipelines import NihPipeline as pipe


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ['https://ned.nih.gov/search/']
    start,end = '',''

    def parse(self, response):
        try:
            links = ['https://ned.nih.gov/search/ViewDetails.aspx?NIHID=0010507398','https://ned.nih.gov/search/ViewDetails.aspx?NIHID=2001831475','https://ned.nih.gov/search/ViewDetails.aspx?NIHID=2001568765']
            pipe.cursor.execute(f'select * from {dbc.database}.{dbc.data_table} where Id>"{self.start}" and Id<"{self.end}"')
            results = pipe.cursor.fetchall()
            for raw in results:
                IC1 = ''
                Id = raw[0]
                print("====="+str(Id)+"======")
                url = raw[-2]
                IC = raw[8]
                print(Id)
                path = raw[-1]
                if url in links:
                    # url_id = url.split('=')[-1]
                    # path = f"F:\khyati\Project VM\\NIH_HTML\data\\{url_id}.html"
                    # headers = {
                    #     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    #     'Accept-Language': 'en-US,en;q=0.9',
                    #     'Upgrade-Insecure-Requests': '1',
                    #     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
                    #     'Cookie': 'f5_cspm=1234; f5avraaaaaaaaaaaaaaaa_session_=NKJPONLLKHEJLNACIFDNIHIKNFKGANEEEPDKPNBDGGPPNCDCANMGAJMLAEMFBLGLHCNDIADACHPBHKILCACAJLIANKLHOGKBDLAMCGAPEPBODAIIFIOJMBILLIHMLKBK; ASP.NET_SessionId=k5vqa1eppbtvjx3wwcpdjqh5; TS01580513=01a14d5b6e450fbed55526833197081c14dc6e4d54602282fe763b1eed8f0c204ab5dc1ddbc9f5bdac8cb5359706792333e8774054; TS0840911c027=08361e8a1bab20002c00fac7aac27e9a82a2fc4461c9711943ccb637263d1ea3c6b15eb3825d8379082b69c03d1130003110ce0b3423709337da47844f3080fdd180a4564930f903f7f9635cc51644d47f807852c11cb56a32407d6f1c1ca38c'
                    # }
                    # response = requests.request("GET", url, headers=headers)
                    # if response.status_code == 200:
                    with open(path, 'r', encoding='utf-8') as f:
                        file = f.read()
                        f.close()
                    response1 = html.fromstring(file)
                    total = response1.xpath('//table[@id="ContentPlaceHolder_dvPerson"]/tr/td')
                    for i in total:
                        try:
                            text = ''.join(i.xpath('..//text()'))
                            if 'IC:' in text and IC1 == '':
                                text1 = text.replace('IC:','')
                                IC1 = re.sub(r'\s+',' ',text1).strip()
                        except Exception as e:
                            print(e)
                    try:
                        pipe.cursor.execute(f'''update {dbc.database}.{dbc.data_table} set IC="{IC1}" where Id="{Id}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl data -a start=0 -a end=26317'.split())
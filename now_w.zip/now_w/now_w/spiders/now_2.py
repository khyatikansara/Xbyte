import hashlib
import json
import pymysql
import requests
import scrapy
from now_w.items import PromotiosIDItem
from scrapy.cmdline import execute

class WebNowSpider(scrapy.Spider):

    name = 'promo_2'

    def __init__(self, name=None, start="", end="", **kwargs):
        super().__init__(name, **kwargs)
        self.con = pymysql.connect("192.168.1.188", "root", "xbyte", "now_web")
        self.crsr = self.con.cursor()
        self.start = start
        self.end = end

    def start_requests(self):
        url = f"https://www.now.vn"
        yield scrapy.Request(url=url)

    def parse(self, response):

        item = PromotiosIDItem()

        self.crsr.execute(f"select url,Id from now_google_search where Id > 258 and status = 'pending' limit {self.start},{self.end}")
        result = self.crsr.fetchall()

        for row in result:
            url = row[0]
            url = "https://gappapi.deliverynow.vn/api/delivery/get_from_url?url=" + url.split('now.vn/')[-1]

            headers = {
                        'host': "gappapi.deliverynow.vn",
                        'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0",
                        'accept': "application/json, text/plain, */*",
                        'accept-language': "en-US,en;q=0.5",
                        'accept-encoding': "gzip, deflate, br",
                        'x-foody-client-id': "eed7fd6f-4e76-4b6b-99d1-e2d60162f1af",
                        'x-foody-client-type': "1",
                        'x-foody-app-type': "1004",
                        'x-foody-client-version': "3.0.0",
                        'x-foody-api-version': "1",
                        'x-foody-client-language': "vi",
                        'origin': "https://www.now.vn",
                        'connection': "keep-alive",
                        'referer': "https://www.now.vn/ha-noi/circle-k-bia-lanh-cac-loai-177-xuan-thuy-hn2021",
                        'te': "Trailers",
                        'cache-control': "no-cache",
                       }

            response = requests.request("GET", url, headers=headers)

            data = json.loads(response.text)
            try:
                de_id = data['reply']['delivery_id']
                if de_id:
                    self.crsr.execute(f"update now_google_search set delivery_id = '{de_id}' where Id = {row[1]}")
                    self.con.commit()
                else:
                    url = 'https://gappapi.test.now.vn/api/delivery/get_from_url?url=' + url.split('now.vn/')[-1]
                    response = requests.request("GET", url, headers=headers)
                    data = json.loads(response.text)
                    try:
                        de_id = data['reply']['delivery_id']
                        if de_id:
                            self.crsr.execute(f"update now_google_search set delivery_id = '{de_id}' where Id = {row[1]}")
                            self.con.commit()
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)
            self.crsr.execute(f"update now_google_search set status = 'checked' where Id = {row[1]}")
            self.con.commit()


# execute("scrapy crawl promo_2 -a start=0 -a end=10".split())
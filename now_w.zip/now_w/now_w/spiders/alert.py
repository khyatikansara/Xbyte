import pandas as pd
import os
from datetime import date, timedelta, datetime
import smtplib
import socket
import scrapy
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import json
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from scrapy.cmdline import execute


class AlertUploadSpider(scrapy.Spider):
    name = 'alert_upload'
    start_urls = ['https://www.now.vn']

    def parse(self, response):
        Authorization1 = ''

        def generate_token():
            chrome_options = Options()
            chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
            driver = webdriver.Chrome(chrome_options=chrome_options)

            # chrome_driver = "chromedriver.exe"
            # chrome_options = Options()
            # driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
            driver.get('https://developers.google.com/oauthplayground/')
            # driver.maximize_window()
            time.sleep(5)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            driver.find_element_by_xpath('//span[text()="Drive API v3"]').click()
            time.sleep(5)
            driver.find_element_by_xpath('//li[@groupid="api-Drive-API-v3"]/span[text()="https://www.googleapis.com/auth/drive"]').click()
            time.sleep(5)
            driver.find_element_by_xpath('//button[@class="op-button op-button-submit"]').click()
            time.sleep(5)
            driver.find_element_by_xpath('//div[@data-identifier="khyati.xbyte@gmail.com"]').click()
            time.sleep(5)
            driver.find_element_by_id("submit_approve_access").click()
            time.sleep(5)
            driver.find_element_by_id("exchangeCode").click()
            time.sleep(5)
            Token = driver.find_element_by_xpath('//span[@class="str"][2]').text
            return Token

        def upload_drive(name):
            try:
                Authorization1 = generate_token()

                Authorization = f"Bearer {Authorization1}"
                headers = {"Authorization": Authorization}
                para = {
                    "name": name,
                    "parents":["1nQJzWgWE7wXRNSBbqeo7XXQ7FNgIY6v3"]
                }
                files = {
                    'data': ('metadata', json.dumps(para), 'application/json; charset=UTF-8'),
                    'file': open(f"D:/khyati-H/CRM/Project_VM/Woowabothers_Now/now_w/now_w/csv/{name}", "rb")
                }
                r = requests.post(
                    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
                    headers=headers,
                    files=files
                )
                print(f"File Uploaded to drive... ... .")
                data = json.loads(r.text)
                id = data['id']
                link = f"https://drive.google.com/file/d/{id}/view?usp=sharing"
                if Authorization1 != '':
                    CC = ['xbyte.qa@gmail.com', 'ricky.jones@xbyte.io', 'alpesh.khunt.xbyte@gmail.com', 'bhavesh.parekh@xbyte.io', 'krupal.patel.xbyte@gmail.com', 'kunals.xbyte@gmail.com', 'manishag.xbyte@gmail.com']
                    #CC = []
                    TO = ['khyati.xbyte@gmail.com', 'mrudulv.xbyte@gmail.com']
                    #TO = ['khyati.xbyte@gmail.com']
                    send_mail(html1, html2, TO, CC, link)
            except Exception as e:
                return "https://drive.google.com/drive/folders/1nQJzWgWE7wXRNSBbqeo7XXQ7FNgIY6v3"

        def html_size(file1, file2):
            df = []
            table_headers = ['Today', 'Yesterday', 'Change']
            file1_size = f"{str(os.stat(file1).st_size / (1024 * 1024))}"
            temp = file1_size.split('.')
            this_week_size = f"{temp[0]}.{temp[-1][:2]} MB"
            file2_size = f"{str(os.stat(file2).st_size / (1024 * 1024))}"
            temp = file2_size.split('.')
            last_week_size = f"{temp[0]}.{temp[-1][:2]} MB"
            change_size = ((float(this_week_size.replace("MB", "")) - float(last_week_size.replace("MB", ""))) / float(last_week_size.replace("MB", ""))) * 100
            change_size = float("{:.2f}".format(change_size))
            df.append([this_week_size,last_week_size,change_size])
            df_size = pd.DataFrame(df, columns=table_headers)
            html = df_size.to_html(index=False)
            return html


        def html_header_count(file1,file2):
            df_final = []
            headers = ['Headers', 'Today' ,'Yesterday', 'Change %']
            df1 = pd.read_csv(file1)
            df2 = pd.read_csv(file2)
            df1.columns = df1.columns.str.lower()
            df2.columns = df2.columns.str.lower()
            data_fields = list(df1.columns)
            data_fields.remove('id')

            for data_field in data_fields:
                count1 = int(df1[data_field].count())
                count2 = int(df2[data_field].count())
                try:
                    change = abs(((count1 - count2) / count2) * 100)
                except:
                    change = 0.0
                change = float("{:.2f}".format(change))


                df_final.append([data_field, count1, count2, change])

            df_html = pd.DataFrame(df_final, columns=headers)
            html = df_html.to_html(index=False)
            return html


        def send_mail(html_size,html_headers,send_to,cc,link):
            print("Building up an email ...")
            mail_content = list()
            mail_content.append("<html>")
            mail_content.append("<head>")
            mail_content.append("""<style>body {font-family: Verdana, Geneva, sans-serif; font-size:110%;} table {font-size:110%; font-family: Verdana, Geneva, sans-serif;} td:hover {background-color:#cccccc;} th, td {text-align: left; padding:1px 5px 1px 5px; border-bottom: 1px solid black;} th {background-color: #cccccc;}</style>""")
            mail_content.append("</head>")
            mail_content.append("<body>")
            mail_content.append("<br>")
            mail_content.append('<h3><b>File Uploaded in Google drive.</b></h3>')
            mail_content.append(f'<h4>Link: <a @href="{link}">{link}</a>')
            mail_content.append("<br>")
            mail_content.append('<h3><b>File Size Comparition</b></h3>')
            mail_content.append('<br>')
            mail_content.append(html_size)
            mail_content.append('<br>')
            mail_content.append('<h3><b>Data Field wise count Difference</b></h3>')
            mail_content.append('<br>')
            mail_content.append(html_headers)
            mail_content.append('<br>')
            mail_content.append('<p><b>Thanks.</b></p>')
            mail_content.append("</body>")
            mail_content.append("</html>")
            body = "".join(mail_content).replace('None', '').replace('NaN', '').replace("<td>No</td>",'<td style="color:red;"><b>No</b></td>').replace("<td>Yes</td>", '<td style="color:green;"><b>Yes</b></td>').replace("***", "<font color='red'>***</font>").replace('<td', '<td bgcolor="#ebf2ea"').replace('<table border="1" class="dataframe">','<table>')
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(('8.8.8.8', 1))
                # emailId = "alerts@xbyte.io"
                # emailpass = "xbyte123"

                try:
                    emailId = "alerts@xbyte.io"
                    emailpass = "Kx]]c6DX*[LO"
                    SMTP_Host = 'smtp.zoho.com'
                    # User = 'alerts@xbyte.io'
                    # Pass = 'Kx]]c6DX*[LO'
                    SSl = True
                    tls = True
                    Port = 587
                    td = datetime.strftime(datetime.now(), '%d/%m/%Y %X')
                    # td = '10/10/2021 14:52:46'
                    msg = MIMEMultipart()
                    msg['From'] = emailId
                    msg['To'] = ",".join(send_to)
                    msg['CC'] = ",".join(cc)
                    msg['Subject'] = "Woowabothers Daily (Now App) : %s" % (str(td))
                    msg.attach(MIMEText(body, 'html'))
                    s = smtplib.SMTP(SMTP_Host, Port)
                    s.starttls()
                    s.login(emailId, emailpass)
                    text = msg.as_string()
                    s.sendmail(emailId, send_to + cc , text)
                    s.quit()
                    print("mail sent")
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

        d = str(date.today()).replace("-", "")
        y = str(date.today() - timedelta(days=1)).replace("-", "")
        # d = '20211010'
        # y = '20211014'
        today = f"D:\khyati-H\CRM\Project_VM\Woowabothers_Now\\now_w\\now_w\csv\\NOW_{d}.csv"
        yesterday = f"D:\khyati-H\CRM\Project_VM\Woowabothers_Now\\now_w\\now_w\csv\\NOW_{y}.csv"

        html1 = html_size(today, yesterday)
        html2 = html_header_count(today, yesterday)

        upload_drive(f"NOW_{d}.csv")


if __name__ == '__main__':

    execute("scrapy crawl alert_upload".split())



import hashlib
import json
import pymysql
import scrapy
from now_w.items import PromotiosIDItem
from scrapy.cmdline import execute
from scrapy.http import FormRequest

class WebNowSpider(scrapy.Spider):
    name = 'promo'

    def __init__(self, name=None, start="", end="", **kwargs):
        super().__init__(name, **kwargs)
        self.con = pymysql.connect("192.168.1.188", "root", "xbyte", "now_web")
        self.crsr = self.con.cursor()
        self.start = start
        self.end = end

    def start_requests(self):
        self.crsr.execute(f"select promotion_id,hashid,city_id from delivery_id_web2 where status = 'pending' limit {self.start},{self.end}")
        result = self.crsr.fetchall()
        headers = {
            'x-foody-client-id': "eed7fd6f-4e76-4b6b-99d1-e2d60162f1af",
            'x-foody-client-type': "4",
            'x-foody-app-type': "1004",
            'x-foody-client-version': "4.32.34",
            'x-foody-api-version': "1",
            'x-foody-client-language': "en",
            'user-agent': "NOW/4.32.0 (Lenovo TB3-710I; android 22; Scale/1)\",",
            'x-foody-client-rn-version': "4.32.0",
            'content-type': "text/plain;charset=UTF-8",
            'host': "gappapi.deliverynow.vn",
            'connection': "Keep-Alive",
            'accept-encoding': "gzip",
        }
        for row in result[:1]:
            promo_id = row[0]
            # url = f"https://gappapi.deliverynow.vn/api/delivery/get_detail?id_type=2&request_id={promo_id}"
            url = f"https://app.now.vn/09ObrNb2gab"
            yield scrapy.Request(url=url,method="GET",headers=headers,callback=self.parse,meta={"promo_id":promo_id,"hashid":row[1],"city_id":row[2]})

    def parse(self, response):

        item = PromotiosIDItem()
        hashid = response.meta['hashid']
        promo_id = response.meta['promo_id']
        city_id = response.meta['city_id']
        data = json.loads(str(response.text))
        item['promotion_id'] = promo_id
        item['city_id'] = city_id

        try:
            item['Merchant_Name'] = data['reply']['delivery_detail']['name']
        except:
            item['Merchant_Name'] = ''
        try:
            item['url'] = data['reply']['delivery_detail']['url']
        except:
            item['url'] = ''

        try:
            item['Address'] = data['reply']['delivery_detail']['address']
        except:
            item['Address'] = ''
        try:

            campaign = data['reply']['delivery_detail']['campaigns']
            if campaign:
                for camp in data['reply']['delivery_detail']['campaigns']:
                    item['promo_code_name'] = camp['title']
                    item['Start_date_end_date'] = camp['expired']
                    try:
                        item['Max_discount'] = camp['max_discount']['message']
                    except Exception as e:
                        print(e)
                    Code_restrictions = []
                    for kk in camp['custom_condition']:
                        Code_restrictions.append(kk['content'])
                    item['Code_restrictions'] =  " | ".join(Code_restrictions)
                    item['hashid'] = int(hashlib.md5(bytes(str(item['promotion_id'])+str(item["promo_code_name"])+str(item["Merchant_Name"]), "utf8")).hexdigest(),16) % (10 ** 30)

                    yield item
        except Exception as e:
            print(e)

        try:
            pro = data['reply']['delivery_detail']['delivery']['promotions']
        except Exception as e:
            print(e)
            pro = None

        if pro:
            for promo in data['reply']['delivery_detail']['delivery']['promotions']:
                item['Mass_promo_and_Merchant_specific_promo'] = ''
                try:
                    item['promo_code_name'] = promo['promo_code']
                except:
                    item['promo_code_name'] = ''
                try:
                    data_s = promo['apply_times'][0]['allow_dates'][0]['start_date']
                    date_e = promo['apply_times'][0]['allow_dates'][0]['end_date']
                    item['Start_date_end_date'] = f"{data_s}/{date_e}"
                except:
                    item['Start_date_end_date'] = ''
                try:
                    item['percentage_or_amount_discount'] = promo['discount']
                except:
                    item['percentage_or_amount_discount'] = ''
                try:
                    item['Min_order_value'] = promo['min_order_amount']
                except:
                    item['Min_order_value'] = ''
                try:
                    item['Max_discount'] = promo['max_discount_value']
                except:
                    item['Max_discount'] = ''
                conditions = list()
                try:
                    for res in promo['custom_condition']:
                        dis = f"{res['label']} : {res['content']}"
                        conditions.append(dis)
                    item['Code_restrictions'] = str(" | ".join(conditions)).replace("\n", "")
                except:
                    item['Code_restrictions'] = ''
                item['hashid'] = int(hashlib.md5(bytes(str(item['promotion_id'])+str(item["promo_code_name"])+str(item["Merchant_Name"]), "utf8")).hexdigest(),16) % (10 ** 30)
                try:
                    with open(f"E:\\now website\\page\\{item['hashid']}.html","w",encoding='utf8') as f:
                        f.write(str(response.text))
                except Exception as e:
                    print(e)

                yield item

                try:
                    qr = f'''update delivery_id_web2 set status='done' where `hashid`="{hashid}"'''
                    self.crsr.execute(qr)
                    self.con.commit()
                except Exception as e:
                    print(e)
        else:
            item['hashid'] = int(hashlib.md5(bytes(str(item['url']),"utf8")).hexdigest(), 16) % (10 ** 30)
            yield item

            try:
                qr = f'''update delivery_id_web2 set status='done' where `hashid`="{hashid}"'''
                self.crsr.execute(qr)
                self.con.commit()
            except Exception as e:
                print(e)

# execute("scrapy crawl promo -a start=0 -a end=1000".split())

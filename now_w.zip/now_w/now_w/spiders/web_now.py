import hashlib
import json
import pymysql
import scrapy
from now_w.items import PromotiosDataItem
from scrapy.cmdline import execute
from scrapy.http import FormRequest

class WebNowSpider(scrapy.Spider):
    name = 'city'
    # allowed_domains = ['www.e.com']
    # start_urls = ['http://www.e.com/']

    def __init__(self, name=None, start="", end="", **kwargs):
        super().__init__(name, **kwargs)
        self.con = pymysql.connect("192.168.1.188", "root", "xbyte", "now_web")
        self.crsr = self.con.cursor()
        self.start = start
        self.end = end

    def start_requests(self):
        self.crsr.execute(f"select city_id from city_id where status = 'pending' limit {self.start},{self.end}")
        result = self.crsr.fetchall()
        headers = {
            'x-foody-client-id': "eed7fd6f-4e76-4b6b-99d1-e2d60162f1af",
            'x-foody-client-type': "4",
            'x-foody-app-type': "1004",
            'x-foody-client-version': "4.32.34",
            'x-foody-api-version': "1",
            'x-foody-client-language': "en",
            'user-agent': "NOW/4.32.0 (Lenovo TB3-710I; android 22; Scale/1)\",",
            'x-foody-client-rn-version': "4.32.0",
            'content-type': "text/plain;charset=UTF-8",
            'host': "gappapi.deliverynow.vn",
            'connection': "Keep-Alive",
            'accept-encoding': "gzip",
        }
        url = "https://gappapi.deliverynow.vn/api/delivery/get_browsing_ids"
        for row in result:
            city_id = row[0]
            payload = '{"city_id":'+ row[0] +',"foody_service_id":1,"sort_type":30,"foody_services":[1]}'
            # {"city_id": 217, "sort_type": 30, "foody_services": [1]}
            yield FormRequest(url=url,method="POST",headers=headers,body=payload,callback=self.parse,dont_filter=True,meta={"city_id":city_id})

    def parse(self, response):
        item = PromotiosDataItem()
        city_id = response.meta['city_id']
        print(response.text)
        data = json.loads(response.text)

        for i in data['reply']['delivery_ids']:
            item['promotion_id'] = i
            item['city_id'] = city_id
            item['hashid'] = int(hashlib.md5(bytes(str(item['promotion_id'])+str(item["city_id"]), "utf8")).hexdigest(),16) % (10 ** 30)
            yield item
            try:
                self.crsr.execute(f"update city_id set status='done' where city_id = '{city_id}'")
                self.con.commit()
            except Exception as e:
                print(e)

# execute("scrapy crawl city -a start=0 -a end=10000".split())
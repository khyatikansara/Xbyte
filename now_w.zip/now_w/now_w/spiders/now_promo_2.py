import hashlib
import json
import os

import pymysql
import scrapy
from now_w.items import PromotiosIDItem
from scrapy.cmdline import execute
from scrapy.http import FormRequest
from now_w import pipelines as pipe


class WebNowSpider(scrapy.Spider):
    name = 'promo__7'

    def __init__(self, name=None, start="", end="", **kwargs):
        super().__init__(name, **kwargs)
        self.con = pymysql.connect("192.168.1.252", "root", "xbyte", "now_web")
        self.crsr = self.con.cursor()
        self.start = start
        self.end = end
        self.table = 'now_google_search'
        # self.table = 'promotions_id'
        self.date = pipe.date
        self.update_query = "UPDATE `now_web`.`now_google_search` SET `final_status` = 'pending'"
        self.crsr.execute(self.update_query)
        self.con.commit()

    def start_requests(self):
        # self.crsr.execute(f"select DISTINCT delivery_id,Id FROM now_google_search where final_status = 'pending' and delivery_id is not null limit {self.start},{self.end}")
        self.crsr.execute(f"select DISTINCT delivery_id,Id,source FROM {self.table} where final_status = 'pending' limit {self.start},{self.end}")
        # self.crsr.execute(f"select delivery_id,Id,source FROM {self.table} where final_status = 'pending'")
        result = self.crsr.fetchall()
        print(len(result))
        headers = {
            'host': "gappapi.deliverynow.vn",
            'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0",
            'accept': "application/json, text/plain, */*",
            'accept-language': "en-US,en;q=0.5",
            'accept-encoding': "gzip, deflate, br",
            'x-foody-client-id': "eed7fd6f-4e76-4b6b-99d1-e2d60162f1af",
            'x-foody-client-type': "1",
            'x-foody-app-type': "1004",
            'x-foody-client-version': "3.0.0",
            'x-foody-api-version': "1",
            'x-foody-client-language': "vi",
            'origin': "https://www.now.vn",
            'connection': "keep-alive",
            'referer': "https://www.now.vn/ha-noi/circle-k-bia-lanh-cac-loai-177-xuan-thuy-hn2021",
            'te': "Trailers",
            'cache-control': "no-cache",
        }

        for row in result[:]:
            del_id = row[0]
            url = f"https://gappapi.deliverynow.vn/api/delivery/get_detail?id_type=2&request_id={del_id}"

            yield scrapy.Request(url=url,method="GET",headers=headers,callback=self.parse,meta={"id":row[1],"source":row[2]})

    def parse(self, response):

        item = PromotiosIDItem()
        table = self.table
        item['Source'] = response.meta['source']
        Id = response.meta['id']
        folder_path = f"E:\\khyati-G\\now website\\{self.date}\\"
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        try:
            with open(f"{folder_path}\\{Id}.html", "w", encoding='utf8') as f:
                f.write(str(response.text))
        except Exception as e:
            print(e)

        data = json.loads(str(response.text))

        try:
            item['Merchant_Name'] = data['reply']['delivery_detail']['name']
        except:
            item['Merchant_Name'] = ''
        try:
            item['url'] = data['reply']['delivery_detail']['url']
        except:
            item['url'] = ''
        if item['url'] != '':
            try:
                item['Address'] = data['reply']['delivery_detail']['address']
            except:
                item['Address'] = ''
            try:
                campaign = data['reply']['delivery_detail']['campaigns']
            except Exception as e:
                print(e)
                campaign = None
            try:
                pro = data['reply']['delivery_detail']['delivery']['promotions']
            except Exception as e:
                print(e)
                pro = None

            if campaign:
                for camp in data['reply']['delivery_detail']['campaigns']:
                    item['promo_code_name'] = camp['title']
                    item['Start_date_end_date'] = camp['expired']
                    try:
                        item['Max_discount'] = camp['max_discount']['message']
                    except Exception as e:
                        print(e)
                    Code_restrictions = []
                    for kk in camp['custom_condition']:
                        Code_restrictions.append(kk['content'])
                    item['Code_restrictions'] = " | ".join(Code_restrictions)
                    item['hashid'] = int(hashlib.md5(bytes(str(item['url'])+str(item["promo_code_name"]), "utf8")).hexdigest(),16) % (10 ** 30)
                    yield item
                    try:
                        qr = f'''update {table} set final_status='done' where `Id`="{Id}"'''
                        self.crsr.execute(qr)
                        self.con.commit()
                    except Exception as e:
                        print(e)

            if pro:
                for promo in data['reply']['delivery_detail']['delivery']['promotions']:
                    item['Mass_promo_and_Merchant_specific_promo'] = ''
                    try:
                        item['promo_code_name'] = promo['promo_code']
                    except:
                        item['promo_code_name'] = ''
                    try:
                        data_s = promo['apply_times'][0]['allow_dates'][0]['start_date']
                        date_e = promo['apply_times'][0]['allow_dates'][0]['end_date']
                        item['Start_date_end_date'] = f"{data_s}/{date_e}"
                    except:
                        item['Start_date_end_date'] = ''
                    try:
                        item['percentage_or_amount_discount'] = promo['discount']
                    except:
                        item['percentage_or_amount_discount'] = ''
                    try:
                        item['Min_order_value'] = promo['min_order_amount']
                    except:
                        item['Min_order_value'] = ''
                    try:
                        item['Max_discount'] = promo['max_discount_value']
                    except:
                        item['Max_discount'] = ''
                    conditions = list()
                    try:
                        for res in promo['custom_condition']:
                            dis = f"{res['label']} : {res['content']}"
                            conditions.append(dis)
                        item['Code_restrictions'] = str(" | ".join(conditions)).replace("\n", "")
                    except:
                        item['Code_restrictions'] = ''
                    item['hashid'] = int(hashlib.md5(bytes(str(item['url'])+str(item["promo_code_name"]), "utf8")).hexdigest(),16) % (10 ** 30)
                    if item['url'] != '':
                        yield item

                    try:
                        qr = f'''update {table} set final_status='done' where `Id`="{Id}"'''
                        self.crsr.execute(qr)
                        self.con.commit()
                    except Exception as e:
                        print(e)

            else:
                item['hashid'] = int(hashlib.md5(bytes(str(item['url']),"utf8")).hexdigest(), 16) % (10 ** 30)
                yield item

                try:
                    qr = f'''update {table} set final_status='done' where `Id`="{Id}"'''
                    self.crsr.execute(qr)
                    self.con.commit()
                except Exception as e:
                    print(e)


if __name__ == '__main__':

    execute("scrapy crawl promo__7 -a start=0 -a end=60000".split())

## ==========================================================================================================
## <============================================ Restuarant links ===========================================>
## ==========================================================================================================
import json
import pymongo
import pymysql
import pandas as pd
from datetime import date,timedelta
import requests
import scrapy
import hashlib
import time
import scrapy
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from now_w.items import ExampleItem
chrome_options = Options()
# chrome_options.add_argument("--headless")
# chrome_driver = "D:\\Mrudul\\ChromDriver\\Version92\\chromedriver_win32\\chromedriver.exe"
# chrome_driver = "D:\\Mrudul\\ChromDriver\\Version92\\chromedriver_win32\\chromedriver.exe"
chrome_driver = "chromedriver.exe"
import datetime
date1 = datetime.datetime.strftime(datetime.datetime.today(),"%d%m%Y")

class NowPromoSpider(scrapy.Spider):
    name = 'resturant_link_selenium'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.now.vn']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymysql.connect("192.168.1.252", "root", "xbyte", "now_web")
        self.crsr = self.con.cursor()


    def parse(self, response):
        item = ExampleItem()

        def pagination():
            response1 = HtmlResponse(url = driver.current_url, body = driver.page_source.encode('utf8'))
            collection_links = response1.xpath('//div[@class="item-restaurant"]/a/@href').getall()
            for cl in collection_links:
                clink = "https://www.now.vn" + str(cl)
                print(clink)
                item['promocode'] = promocode
                item['link'] = link
                yield item
                print(item)

        # client = pymongo.MongoClient("mongodb://mrudul.v:Mrudul#123@51.161.13.140:27017/?authSource=admin")
        # db = client["now"]
        # col = db["collection_links_12-08-2021"]
        # x = col.find({'status': {'$ne': 'done'}}).skip(int(self.a)).limit(500)
        # x = col.find()
        self.crsr.execute(f"select * FROM collection_links_12_08_2021")
        # self.crsr.execute(f"select delivery_id,Id,source FROM {self.table} where final_status = 'pending'")
        x = self.crsr.fetchall()
        print(len(x))
        for data in x:
            clink1 = data[1]
            driver = webdriver.Chrome(chrome_options = chrome_options, executable_path = chrome_driver)
            driver.get(clink1)
            time.sleep(10)
            # driver.minimize_window()
            # response2 = HtmlResponse(url = driver.current_url, body = driver.page_source.encode('utf8'))
            dscr = driver.find_element_by_xpath('//div[@class="header-res-collection"]/p').text
            promocode = list()
            dscr = dscr.split(' ')
            for j in dscr:
                if j.isupper():
                    promocode.append(j)
            print(promocode)
            links = driver.find_elements_by_xpath('//div[@class="item-restaurant"]/a')
            c = len(links)
            if c >= 20:
                for li in links:
                    li = li.get_attribute('href').replace('https://shopeefood.vn','https://www.now.vn')
                    if 'https://www.now.vn' not in li:
                        link = "https://www.now.vn" + str(li)
                    else:
                        link = str(li)
                    item['promocode']=promocode
                    item['link'] = link
                    yield item
                    print(item)
                # driver.quit()
                try:
                    a = driver.find_element_by_xpath('//span[@class="icon icon-paging-next"]/../..')
                    n = driver.find_elements_by_xpath('//ul[@class="pagination"]/li')
                    n_list = []
                    for nt in n:
                        n1 = nt.text
                        if n1 != '':
                            n_list.append(n1)
                    for j in range(1, len(n_list)):
                        if a != 'disabled':
                            a = driver.find_element_by_xpath('//span[@class="icon icon-paging-next"]/../..').click()
                            time.sleep(5)
                            pagination()
                    driver.quit()
                    driver.quit()
                except:
                    continue
            else:
                for li in links:
                    link = "https://www.now.vn" + str(li)
                    item['promocode'] = promocode
                    item['link'] = link
                    print(item)
                    yield item
                driver.quit()
                driver.quit()

    def close(spider, reason):
        d = str(date.today()).replace("-", "")
        # d = '20210905'
        # y = str(date.today() - timedelta(days=1)).replace("-", "")
        con = pymysql.connect("localhost", "root", "xbyte", "now_web")
        table = f'resturants_links_{d}'
        # table = f'delivery_data_web_20210905'

        df = pd.read_sql(
            f"SELECT promocode,link FROM {table}",
            con)
        df.insert(0, 'Id', range(1, 1 + len(df)))

        df.to_csv(f"D:\khyati-H\CRM\Project_VM\Woowabothers_Now\\now_w\\now_w\csv\\resturants_links_{d}.csv", index=False)


if __name__ == '__main__':

    execute("scrapy crawl resturant_link_selenium".split())
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from scrapy.cmdline import execute
from itemadapter import ItemAdapter
from now_w.items import PromotiosIDItem,PromotiosDataItem,ExampleItem
import datetime

date = datetime.datetime.strftime(datetime.datetime.today(),"%Y%m%d")


class NowWPipeline:
    host = "192.168.1.252"
    passwd = "xbyte"
    uname = "root"
    insertcount = 0
    con1 = pymysql.connect(host, uname, passwd)
    db_name = "now_web"
    tb_name = "delivery_id_web2"
    tb_name_2 = f"delivery_data_web_{date}"
    tb_name_3 = f"resturants_links_{date}"
    # tb_name_2 = f"delivery_data_web_20210603"

    def __init__(self):
        try:
            self.con1.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {self.db_name}")
            self.con = pymysql.connect(self.host, self.uname, self.passwd, f'{self.db_name}')
            self.crsr = self.con.cursor()

            CT = f"""CREATE TABLE IF NOT EXISTS {self.tb_name}(`Id` int auto_increment not null primary key,
                                                                hashid varchar (255) unique,
                                                                city_id varchar(255),
                                                                promotion_id varchar(255),
                                                                status varchar(25) default 'pending'
                                                                )"""
            self.crsr.execute(CT)
        except Exception:
            pass
        try:
            CT = f"""CREATE TABLE IF NOT EXISTS {self.tb_name_2}(`Id` int auto_increment not null primary key,
                                                                            Source varchar(255),
                                                                            hashid varchar(255) unique,
                                                                            city_id varchar(255),
                                                                            promotion_id varchar(255),
                                                                            url varchar(255),
                                                                            `Merchant_Name` varchar(255),
                                                                            `Address` longtext,
                                                                            `Mass_promo_and_Merchant_specific_promo` varchar(255),
                                                                            `promo_code_name` varchar(255),
                                                                            `Start_date_end_date` varchar(255),
                                                                            `percentage_or_amount_discount` varchar(255),
                                                                            `Min_order_value` varchar(255),
                                                                            `Max_discount` varchar(255),
                                                                            `Code_restrictions` longtext)
                                                                        ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8"""
            self.crsr.execute(CT)
        except Exception:
            pass
        try:
            CT = f"""CREATE TABLE IF NOT EXISTS {self.tb_name_3}(`Id` int auto_increment not null primary key,
                                                                            promocode longtext,
                                                                            link varchar(255) unique)
                                                                        ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8"""
            self.crsr.execute(CT)
        except Exception:
            pass

    def process_item(self, item, spider):

        if isinstance(item, PromotiosIDItem):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, f'{self.db_name}')
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {self.tb_name_2}" + "( " + fields + " ) values ( '" + values + "' )"
                # print(insert_db)
                crsr.execute(insert_db)
                print(insert_db)
                con.commit()
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, PromotiosDataItem):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, f'{self.db_name}')
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {self.tb_name}" + "( " + fields + " ) values ( '" + values + "' )"
                # print(insert_db)
                crsr.execute(insert_db)
                print(insert_db)
                con.commit()
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, ExampleItem):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, f'{self.db_name}')
                crsr = con.cursor()
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {self.tb_name_3}" + "( " + fields + " ) values ( '" + values + "' )"
                # print(insert_db)
                crsr.execute(insert_db)
                print(insert_db)
                con.commit()
            except Exception as e:
                print(str(e))
            return item

    def close_spider(self, spider):
        try:

            if spider.name == 'promo__7':
                self.crsr.execute(f"select count(id) from now_google_search where final_status='pending'")
                pending_asin = len(self.crsr.fetchall())
                if pending_asin == 0:
                    update_db = f"update now_google_search set Status = 'pending'"
                    self.crsr.execute(update_db)
                    self.con.commit()
                # else:
                #     from subprocess import Popen
                #     Popen("close_bat.bat", cwd=r"D:\khyati-H\CRM\Project VM\Woowabothers Now\now_w\now_w\spiders")
                    # execute("start py -m scrapy  crawl usa_sellerbb -a px=sa -a start=1 -a end=100".split())
                    # execute(f"scrapy crawl promo__7".split())
            self.con.close()
        except Exception as e:
            print(e)
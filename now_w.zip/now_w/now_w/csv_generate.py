import pandas as pd
import pymysql
from datetime import date,timedelta


def export():
    d = str(date.today()).replace("-","")
    # d = '20211008'
    y = str(date.today() - timedelta(days=1)).replace("-","")
    con = pymysql.connect("localhost","root","xbyte","now_web")
    table = f'delivery_data_web_{d}'
    # table = f'delivery_data_web_20210905'

    df = pd.read_sql(f"SELECT Source,url,Merchant_Name,Address,Mass_promo_and_Merchant_specific_promo,promo_code_name,Start_date_end_date,percentage_or_amount_discount,Min_order_value,Max_discount,Code_restrictions FROM {table}",con)
    df.insert(0, 'Id', range(1, 1 + len(df)))

    df.to_csv(f"D:\khyati-H\CRM\Project_VM\Woowabothers_Now\\now_w\\now_w\csv\\NOW_{d}.csv",index=False)
    # df.to_csv(f"csv\\NOW_20210830.csv",index=False)

# export()

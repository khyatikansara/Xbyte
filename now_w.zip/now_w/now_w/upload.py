import json
import requests

def upload_drive():
    headers = {"Authorization": "Bearer ya29.a0AfH6SMCQ8oabBL5tStxy3DfGZKfCbkT1xSnjvREGHKjvouAwrUrINrRG__q2yQUGQ2mtj7FtI_yJzv9MOZ5RENokO5zVLlsmzqFhGij23KXysFQVYgSFUL5Z7f23LXdhG_USzyBihRsF1C27fWeAqWwFN-qt"}
    para = {
        "name": "sample.txt",
        "parents":["1nQJzWgWE7wXRNSBbqeo7XXQ7FNgIY6v3"]
    }
    files = {
        'data': ('metadata', json.dumps(para), 'application/json; charset=UTF-8'),
        'file': open("./csv/sample.txt", "rb")
    }
    r = requests.post(
        "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
        headers=headers,
        files=files
    )
    print(r.text)


upload_drive()
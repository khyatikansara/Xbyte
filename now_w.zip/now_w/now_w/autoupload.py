import hashlib
import json
import os
import time

from bs4 import element
from selenium.webdriver.common.action_chains import ActionChains
import pymysql
import scrapy
from now_w.items import PromotiosIDItem
from scrapy.cmdline import execute
from scrapy.http import FormRequest
from now_w import pipelines as pipe
from datetime import date,timedelta
import pandas as pd
from selenium.webdriver.chrome.options import Options
from selenium import webdriver


def Autoupload():
    # d = str(date.today()).replace("-", "")
    # # d = '20210728'
    # y = str(date.today() - timedelta(days=1)).replace("-", "")
    # con = pymysql.connect("localhost", "root", "xbyte", "now_web")
    # table = f'delivery_data_web_{d}'
    # # table = f'delivery_data_web_20210729'
    #
    # df = pd.read_sql(
    #     f"SELECT Source,url,Merchant_Name,Address,Mass_promo_and_Merchant_specific_promo,promo_code_name,Start_date_end_date,percentage_or_amount_discount,Min_order_value,Max_discount,Code_restrictions FROM {table}",
    #     con)
    # df.insert(0, 'Id', range(1, 1 + len(df)))
    #
    # df.to_csv(f"csv\\NOW_{d}.csv", index=False)
    chrome_options = Options()
    chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
    driver = webdriver.Chrome(chrome_options=chrome_options)

    # chrome_options = webdriver.ChromeOptions()
    # driver = webdriver.Chrome(chrome_options=chrome_options, executable_path="chromedriver.exe")
    driver.get('https://drive.google.com/drive/folders/1nQJzWgWE7wXRNSBbqeo7XXQ7FNgIY6v3')
    driver.maximize_window()
    action = ActionChains(driver)
    action.context_click(on_element=element)
    action.perform()
    time.sleep(5)


if __name__ == '__main__':

    Autoupload()

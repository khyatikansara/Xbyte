host = 'localhost'
user = 'root'
paswd = 'xbyte'
db_name = 'indiamart_contact'

table1 = "putty_link"
table2 = "pipes_link"
table3 = "putty_data"
table4 = "pipes_data"
table5 = "link_tmp"
table6 = "data"
table7 = "link_tmp_check_pipes"
table8 = "link_tmp_check_putty"



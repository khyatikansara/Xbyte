import pandas as pd
import re
from indiamart import dbconfig as dbc
from indiamart.pipelines import IndiamartPipeline as pipe

def export_data():
    try:
        sql = f"Select * from {dbc.db_name}.{dbc.table6}"
        df_all = pd.read_sql(sql, pipe.db_con)
        # file_name_mm-dd-yy.csv
        # today_date = str(datetime.strftime(datetime.now(), '%m-%d-%y'))
        output_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\indiamart_29-09-2020.xlsx"
        # output_path = f"F:\\khyati\\Banner\\Banner_KROGER\\Html_2020_06_09\\CSV\\cat2.csv"
        # df_all.drop(columns=['final_path','Hash_id'], inplace=True)
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', ' ') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        df_all.to_excel(output_path, index=False)
        print('Excel File generated', output_path)
    except Exception as e:
        print(e)

def tmp():
    output_path = "D:\\khyati-H\\CRM\\publix_inventory\\Html_2020_08_16\\CSV\\"
    df = pd.read_excel(output_path+"publix_20-08-2020.xlsx")
    df = df.fillna('')
    list = []
    for index, row in df.iterrows():
        Id = row['Id']
        Unit = row['Unit']
        Per_Unit_Price = row['Per Unit Price']
        if '<' in Per_Unit_Price:
            new_Per_Unit_Price = ''.join(Per_Unit_Price.split()[0:-1])
            Unit = Unit.split()[-1].strip()
        else:
            new_Per_Unit_Price = Per_Unit_Price.replace(Unit,'').strip()
            Unit = row['Unit']
        list.append([Id,new_Per_Unit_Price,Unit])
    gh = pd.DataFrame(list, columns=['Id', 'Per Unit Price','Unit'])
    gh.to_excel(output_path+"tmp_publix_20-08-2020.xlsx", index=False)
    print('Excel File generated', output_path)


export_data()
# tmp()
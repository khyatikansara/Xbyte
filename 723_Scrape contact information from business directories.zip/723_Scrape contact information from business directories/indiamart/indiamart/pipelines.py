# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql

from indiamart import dbconfig as dbc
from indiamart.items import IndiamartDataItem,IndiamartPuttyItem,IndiamartPipesItem,IndiamartPuttyDataItem,IndiamartPipesDataItem,IndiamartLinkItem


class IndiamartPipeline(object):
    con = pymysql.connect(dbc.host, dbc.user, dbc.paswd)
    con.cursor().execute(f'CREATE DATABASE IF NOT EXISTS {dbc.db_name} CHARACTER SET UTF8MB4 COLLATE utf8mb4_general_ci')
    db_con = pymysql.connect(dbc.host, dbc.user, dbc.paswd, dbc.db_name)
    db_cursor = db_con.cursor()

    try:
        create_table5 = f"""CREATE TABLE IF NOT EXISTS {dbc.table5} (Id INT NOT NULL AUTO_INCREMENT ,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    HTML_Path longtext DEFAULT NULL, 
                                                                    Status varchar(55) default 'pending',
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table5)
    except Exception as e:
        print(e)
    try:
        create_table7 = f"""CREATE TABLE IF NOT EXISTS {dbc.table7} (Id INT NOT NULL AUTO_INCREMENT ,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    HTML_Path longtext DEFAULT NULL, 
                                                                    Status varchar(55) default 'pending',
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table7)
    except Exception as e:
        print(e)
    try:
        create_table8 = f"""CREATE TABLE IF NOT EXISTS {dbc.table8} (Id INT NOT NULL AUTO_INCREMENT ,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    HTML_Path longtext DEFAULT NULL, 
                                                                    Status varchar(55) default 'pending',
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table8)
    except Exception as e:
        print(e)

    try:
        create_table1 = f"""CREATE TABLE IF NOT EXISTS {dbc.table1} (Id INT NOT NULL AUTO_INCREMENT ,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    HTML_Path longtext DEFAULT NULL, 
                                                                    Status varchar(55) default 'pending',
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table1)
    except Exception as e:
        print(e)

    try:
        create_table2 = f"""CREATE TABLE IF NOT EXISTS {dbc.table2} (Id INT NOT NULL AUTO_INCREMENT ,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    HTML_Path longtext DEFAULT NULL, 
                                                                    Status varchar(55) default 'pending',
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table2)
    except Exception as e:
        print(e)

    try:
        create_table3 = f"""CREATE TABLE IF NOT EXISTS {dbc.table3} (Id INT NOT NULL AUTO_INCREMENT,
                                                                    Business_Name longtext DEFAULT NULL,
                                                                    Address longtext DEFAULT NULL,
                                                                    City longtext DEFAULT NULL,
                                                                    Phone longtext DEFAULT NULL,
                                                                    Mobile longtext DEFAULT NULL,
                                                                    Email longtext DEFAULT NULL,
                                                                    Website longtext DEFAULT NULL,
                                                                    Assocated_Categories longtext DEFAULT NULL,
                                                                    Also_Listed_In longtext DEFAULT NULL,
                                                                    Year_Eshtablished longtext DEFAULT NULL,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table3)
    except Exception as e:
        print(e)

    try:
        create_table4 = f"""CREATE TABLE IF NOT EXISTS {dbc.table4} (Id INT NOT NULL AUTO_INCREMENT,
                                                                    Business_Name longtext DEFAULT NULL,
                                                                    Address longtext DEFAULT NULL,
                                                                    City longtext DEFAULT NULL,
                                                                    Phone longtext DEFAULT NULL,
                                                                    Mobile longtext DEFAULT NULL,
                                                                    Email longtext DEFAULT NULL,
                                                                    Website longtext DEFAULT NULL,
                                                                    Assocated_Categories longtext DEFAULT NULL,
                                                                    Also_Listed_In longtext DEFAULT NULL,
                                                                    Year_Eshtablished longtext DEFAULT NULL,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table4)
    except Exception as e:
        print(e)

    try:
        create_table6 = f"""CREATE TABLE IF NOT EXISTS {dbc.table6} (Id INT NOT NULL AUTO_INCREMENT,
                                                                    Business_Name longtext DEFAULT NULL,
                                                                    Address longtext DEFAULT NULL,
                                                                    Postal_code longtext DEFAULT NULL,
                                                                    City longtext DEFAULT NULL,
                                                                    Phone longtext DEFAULT NULL,
                                                                    Mobile longtext DEFAULT NULL,
                                                                    Email longtext DEFAULT NULL,
                                                                    Website longtext DEFAULT NULL,
                                                                    Assocated_Categories longtext DEFAULT NULL,
                                                                    Also_Listed_In longtext DEFAULT NULL,
                                                                    Year_Eshtablished longtext DEFAULT NULL,
                                                                    URL VARCHAR(250) DEFAULT NULL,
                                                                    UNIQUE KEY (`URL`),
                                                                    PRIMARY KEY (`Id`))"""

        db_cursor.execute(create_table6)
    except Exception as e:
        print(e)

    def process_item(self, item, spider):
        if isinstance(item, IndiamartPuttyItem):
            self.insert_item(dbc.table1, item)
        # if isinstance(item, IndiamartLinkItem):
        #     self.insert_item(dbc.table5, item)
        if isinstance(item, IndiamartLinkItem):
            self.insert_item(dbc.table8, item)
        if isinstance(item, IndiamartPipesItem):
            self.insert_item(dbc.table2, item)
        if isinstance(item, IndiamartPuttyDataItem):
            self.insert_item(dbc.table3, item)
            try:
                self.db_cursor.execute(f"update {dbc.db_name}.{dbc.table1} set Status='Done' where URL='{str(item['URL'])}'")
                self.db_con.commit()
                print("link updated")
            except Exception as e:
                print(e)
        if isinstance(item, IndiamartPipesDataItem):
            self.insert_item(dbc.table4, item)
            try:
                self.db_cursor.execute(f"update {dbc.db_name}.{dbc.table2} set Status='Done' where URL='{str(item['URL'])}'")
                self.db_con.commit()
                print("link updated")
            except Exception as e:
                print(e)
        if isinstance(item, IndiamartDataItem):
            self.insert_item(dbc.table6, item)
            try:
                self.db_cursor.execute(f"update {dbc.db_name}.{dbc.table5} set Status='Done' where URL='{str(item['URL'])}'")
                self.db_con.commit()
                print("link updated")
            except Exception as e:
                print(e)

    def insert_item(self, table, item):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.db_cursor.execute(insert_db)
            self.db_con.commit()
            print('\rdata inserted ')
        except Exception as e:
            print('problem in insertion ', str(e))


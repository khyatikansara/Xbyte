# -*- coding: utf-8 -*-
import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header

from indiamart.items import IndiamartPuttyItem,IndiamartLinkItem


class IndiamartLinksSpider(scrapy.Spider):
    name = 'links'
    allowed_domains = []
    start_urls = ["https://www.example.com"]

    def parse(self, response):
        try:
            self.head={
                'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'accept-encoding': 'gzip, deflate, br','accept-language': 'en-US,en;q=0.9',
                'sec-fetch-dest': 'document','sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none','sec-fetch-user': '?1','upgrade-insecure-requests': '1',

                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36'}

            path = "D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\main\\manufacture-putty - Indiamart.html"
            file_open = open(path, 'r', encoding="utf-8")
            file = file_open.read()
            file_open.close()
            response1 = html.fromstring(file)
            urls = response1.xpath('//ul/li//a[contains(@href,"https://www.indiamart.com/proddetail/")]')
            proxy = {
                'Proxy-Authorization': basic_auth_header("lum-customer-xbyte-zone-zone_india-country-in", "w6zj0g4ikjy3")
            }
            for url in urls:
                url = url.xpath('./@href')[0]
                # res_s = requests.get(url, headers=self.head,proxies=proxy)
                # if res_s.status_code == 200:
                #     response_s = HtmlResponse(url=res_s.url, body=res_s.content)
                #     try:
                #         file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\check_putty\\{url.split('/')[-1]}"
                #         with open(file_path, 'wb') as f:
                #             f.write(response_s.body)
                #             f.close()

                items = IndiamartLinkItem()
                items['URL'] = url
                items['HTML_Path'] = ''
                # items['HTML_Path'] = file_path.replace("\\", "\\\\")
                yield items
                    # except Exception as e:
                    #     print(e)
                # else:
                #     print(" ")
                # yield scrapy.Request(url=url, callback=self.get_data,headers=self.head)
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\data\\{response.url.split('/')[-1]}"
            with open(file_path, 'wb') as f:
                f.write(response.body)
                f.close()

            items = IndiamartLinkItem()
            items['URL'] = response.url
            items['HTML_Path'] = file_path.replace("\\","\\\\")
            yield items

        except Exception as e:
            print(e)

from scrapy.cmdline import execute
execute("scrapy crawl links ".split())
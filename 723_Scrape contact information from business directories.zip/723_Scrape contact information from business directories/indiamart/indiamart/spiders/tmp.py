# import pymysql
# from indiamart import dbconfig as dbc
#
# db_con = pymysql.connect(dbc.host, dbc.user, dbc.paswd, dbc.db_name)
# db_cursor = db_con.cursor()
# db_cursor.execute(f'select * from {dbc.db_name}.{dbc.table6} where category=""')
# results = db_cursor.fetchall()
# for row in results:
#     url = row[-2]
#     # if 'dulux' in url:
#     db_cursor.execute(f'update {dbc.db_name}.{dbc.table6} set category="putty" where URL="{url}"')
#     db_con.commit()
#     print("update done pipe")
#     # else:
#     #     print("null")
# -*- coding: utf-8 -*-
import json

import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header

from indiamart.items import IndiamartPuttyItem,IndiamartLinkItem


class IndiamartLinkupdateSpider(scrapy.Spider):
    name = 'links_update'
    allowed_domains = []
    start_urls = ["https://www.example.com"]

    def parse(self, response):
        try:
            self.head={
                'Referer': 'https://dir.indiamart.com/industry/builders-hardware.html',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36'
            }
            proxy = {
                'Proxy-Authorization': basic_auth_header("lum-customer-xbyte-zone-zone_india-country-in",
                                                         "w6zj0g4ikjy3")
            }
            # url = "https://dir.indiamart.com/search.mp?ss=pipes&src=as-rcnt%3Apos%3D2%3Acat%3D-2%3Amcat%3D-2"
            # url = "https://dir.indiamart.com/search.mp?ss=putty"
            urls_list = ["https://dir.indiamart.com/search.mp?ss=putty&biz=10","https://dir.indiamart.com/search.mp?ss=putty&biz=20","https://dir.indiamart.com/search.mp?ss=putty&biz=30","https://dir.indiamart.com/search.mp?ss=putty&biz=40"]
            for url in urls_list:
                res = requests.get(url, headers=self.head, proxies=proxy)
                if res.status_code == 200:
                    response_s = HtmlResponse(url=res.url, body=res.content)
                    # category = response_s.xpath('//*[contains(text(),"Related Category")]/following-sibling::div//a/@href').extract()
                    # category = response_s.xpath('//*[contains(text(),"Related Brands")]/following-sibling::ul//a/@href').extract()
                    # for cat in category:
                    page = 1
                    #     cat_url = f"https://dir.indiamart.com/{cat}"
                    #     res_cat = requests.get(cat_url, headers=self.head, proxies=proxy)
                    #     if res_cat.status_code == 200:
                    #         response_cat = HtmlResponse(url=res_cat.url, body=res_cat.content)
                    #         ss = response_cat.url.split('?')[-1]
                    biz = response_s.url.split('biz=')[-1]
                    #         # json_url = f"https://dir.indiamart.com/search.mp/next?{ss}&c=IN&scroll=1&language=en&city_only=&cityid=&mcatid=&catid=&skip_context=&pr=0&pg={page}&frsc=15&video="
                    json_url = f"https://dir.indiamart.com/search.mp/next?ss=putty&c=IN&scroll=1&language=en&city_only=&cityid=&mcatid=&catid=&skip_context=&pr=0&biz={biz}&pg={page}&frsc=14&video="
                    res_json = requests.get(json_url, headers=self.head, proxies=proxy)
                    response_json = HtmlResponse(url=res_json.url, body=res_json.content)
                            # file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\indiamart_pages\\pipes\\{ss}_{page}.json"
                            # with open(file_path, 'wb') as f:
                            #     f.write(response_json.body)
                            #     f.close()
                    data_json = json.loads(response_json.text)
                    response1 = html.fromstring(data_json['content'])
                    urls = response1.xpath('//span/a[contains(@href,"https://www.indiamart.com/proddetail/")]')
                    for url in urls:
                        url = url.xpath('./@href')[0]
                        yield scrapy.Request(url=url, callback=self.get_data)
                    if page > 10:
                        break

                            # print(" ")
            # path = "D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\main\\putty - Indiamart.html"
            # file_open = open(path, 'r', encoding="utf-8")
            # file = file_open.read()
            # file_open.close()
            # response1 = html.fromstring(file)
            # urls = response1.xpath('//ul/li//a[contains(@href,"https://www.indiamart.com/proddetail/")]')
            #
            # for url in urls:
            #     url = url.xpath('./@href')[0]
            #     res_s = requests.get(url, headers=self.head,proxies=proxy)
            #     if res_s.status_code == 200:
            #         response_s = HtmlResponse(url=res_s.url, body=res_s.content)
            #         try:
            #             file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\data\\{url.split('/')[-1]}"
            #             with open(file_path, 'wb') as f:
            #                 f.write(response_s.body)
            #                 f.close()
            #
            #             items = IndiamartLinkItem()
            #             items['URL'] = url
            #             items['HTML_Path'] = file_path.replace("\\", "\\\\")
            #             yield items
            #         except Exception as e:
            #             print(e)
            #     else:
            #         print(" ")
                # yield scrapy.Request(url=url, callback=self.get_data,headers=self.head)
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            tmp_check = response.url.split('/')[-1].split('?')[0]
            file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\indiamart_pages\\check_putty\\{tmp_check}"
            with open(file_path, 'wb') as f:
                f.write(response.body)
                f.close()

            items = IndiamartLinkItem()
            items['URL'] = response.url
            items['HTML_Path'] = file_path.replace("\\","\\\\")
            yield items

        except Exception as e:
            print(e)

from scrapy.cmdline import execute
# execute("scrapy crawl links_update".split())
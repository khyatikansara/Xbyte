# -*- coding: utf-8 -*-
import json
import re

import scrapy
from lxml import html
from indiamart.items import IndiamartPipesDataItem,IndiamartPuttyDataItem,IndiamartDataItem
from indiamart.pipelines import IndiamartPipeline as pipe
from indiamart import dbconfig as dbc


class IndiamartDatasSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ["https://www.example.com"]

    def parse(self, response):
        try:
            pipe.db_cursor.execute(f"select * from {dbc.db_name}.{dbc.table5} where Status='pending'")
            result = pipe.db_cursor.fetchall()
            for row in result:
                URL = row[1]
                html_path = row[2]
                file_open = open(html_path, 'r', encoding="utf-8")
                file = file_open.read()
                file_open.close()
                response1 = html.fromstring(file)
                data_list = response1.xpath('//script[contains(@type,"application/ld+json")]//text()')
                flag = True
                Business_Name,Address,Postal_code,City,Phone,Mobile,Email,Website,Assocated_Categories,Also_Listed_In,Year_Eshtablished='','','','','','','','','','',''
                streetAddress,addressLocality,addressRegion,addressCountry = '','','',''
                for data in data_list:
                    try:
                        if 'LocalBusiness' in data:
                            # data_json = json.loads(data)
                            flag = False
                            Business_Name = re.findall(r'"name": "(.*?)",',data)[0]
                            streetAddress = re.findall(r'"streetAddress": "(.*?)",',data)[0]
                            addressLocality = re.findall(r'"addressLocality": "(.*?)",',data)[0]
                            addressRegion = re.findall(r'"addressRegion": "(.*?)",',data)[0]
                            addressCountry = re.findall(r'"addressCountry": "(.*?)"',data)[0]
                            Address = f"{streetAddress}, {addressLocality}, {addressRegion}{addressCountry}"
                            Postal_code = re.findall(r'"postalCode": "(.*?)",',data)[0]
                            City = re.findall(r'"addressRegion": "(.*?)",',data)[0]
                            Mobile = re.findall(r'"telephone": "(.*?)",',data)[0]
                            if 'mailto:' in file:
                                Email = 'yes'
                            Website = re.findall(r'"url": "(.*?)",',data)[0]
                            if response1.xpath('//td[contains(text()," Categories ")]/following-sibling::td/text()'):
                                Assocated_Categories = response1.xpath('//td[contains(text()," Categories ")]/following-sibling::td/text()')[0].strip()
                            if response1.xpath('//*[contains(text(),"Year of Establishment")]/following-sibling::span/text()'):
                                Year_Eshtablished = response1.xpath('//*[contains(text(),"Year of Establishment")]/following-sibling::span/text()')[0].strip()
                    except Exception as e:
                        print(e)
                if flag:
                    text = re.findall(r'<script>var inline_hash = (.*?)</script>',file,re.DOTALL)[0]
                    Business_Name = re.findall(r"rcvName:'(.*?)',",text)[0]
                    City = re.findall(r"rcvCity:'(.*?)',",text)[0]
                    if response1.xpath('//*[@name="gmap_address"]/../p/span'):
                        Address = ''.join(response1.xpath('//*[@name="gmap_address"]/../p/span//text()')).strip()
                        Postal_code = re.findall(r'([0-9]{6}|[0-9]{3}\s[0-9]{3})',Address)
                        if len(Postal_code) == 1:
                            Postal_code = Postal_code[0]
                        else:
                            Postal_code = Postal_code[0]
                    if response1.xpath('//*[@id="contact_number"]/@value'):
                        Mobile = response1.xpath('//*[@id="contact_number"]/@value')[0]
                    if response1.xpath("//*[@id='company_url']/@value"):
                        Website = response1.xpath("//*[@id='company_url']/@value")[0]
                    if response1.xpath('//td[contains(text()," Categories ")]/following-sibling::td/text()'):
                        Assocated_Categories = response1.xpath('//td[contains(text()," Categories ")]/following-sibling::td/text()')[0].strip()
                    if response1.xpath('//*[contains(text(),"Year of Establishment")]/following-sibling::span/text()'):
                        Year_Eshtablished = response1.xpath('//*[contains(text(),"Year of Establishment")]/following-sibling::span/text()')[0].strip()

                items = IndiamartDataItem()
                items['Business_Name'] = Business_Name
                items['Address'] = Address
                items['Postal_code'] = Postal_code
                items['City'] = City
                items['Phone'] = Phone
                items['Mobile'] = Mobile
                items['Email'] = Email
                items['Website'] = Website
                items['Assocated_Categories'] = Assocated_Categories
                items['Also_Listed_In'] = Also_Listed_In
                items['Year_Eshtablished'] = Year_Eshtablished
                items['URL'] = URL
                # try:
                #     pipe.db_cursor.execute(
                #         f'''update {dbc.db_name}.{dbc.table3} set Address="{items['Address']}",Postal_code="{items['Postal_code']}" where URL="{str(items['URL'])}"''')
                #     pipe.db_con.commit()
                #     print("link updated")
                # except Exception as e:
                #     print(e)
                # try:
                #     pipe.db_cursor.execute(
                #         f"update {dbc.db_name}.{dbc.table1} set Status='Done1' where URL='{str(items['URL'])}'")
                #     pipe.db_con.commit()
                #     print("link updated")
                # except Exception as e:
                #     print(e)
                yield items
        except Exception as e:
            print(e)


from scrapy.cmdline import execute
# execute("scrapy crawl data".split())
# -*- coding: utf-8 -*-
import json
from os import listdir
from os.path import isfile, join

import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse

from indiamart.items import IndiamartPuttyItem,IndiamartLinkItem


class IndiamartLinksjsonSpider(scrapy.Spider):
    name = 'links_json'
    allowed_domains = []
    start_urls = ["https://www.example.com"]
    page = 1

    def parse(self, response):
        mypath = "D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\indiamart_pages\\pipes\\"
        onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
        for files in onlyfiles:
            print(files)
            file_open = open(mypath+files, 'r', encoding="utf-8")
            file = file_open.read()
            file_open.close()
            data_json = json.loads(file)
            response1 = html.fromstring(data_json['content'])
            urls = response1.xpath('//span/a[contains(@href,"https://www.indiamart.com/proddetail/")]')
            for url in urls:
                url = url.xpath('./@href')[0]
                items = IndiamartLinkItem()
                items['URL'] = url
                # items['HTML_Path'] = file_path.replace("\\", "\\\\")
                yield items
                # yield scrapy.Request(url=url, callback=self.get_data)
        # self.head = {'accept': '*/*','accept-language': 'en-US,en;q=0.9,es;q=0.8',
        #             'referer': 'https://dir.indiamart.com/search.mp?ss=putty','sec-fetch-dest': 'empty',
        #             'sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin',
        #             'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36',
        #             'x-requested-with': 'XMLHttpRequest'}
        #
        # while True:
        #     try:
        #         page_url = f"https://dir.indiamart.com/search.mp/next?glid=2699053&ss=putty&c=IN&scroll=1&language=en&city_only=&cityid=&mcatid=&catid=&skip_context=&pr=0&pg={self.page}&frsc=28&video="
        #         yield scrapy.Request(url=page_url,headers=self.head, callback=self.get_link)
        #         # res_s = requests.get(page_url,headers=self.head)
        #         # if res_s.status_code == 200:
        #         #     response_s = HtmlResponse(url=res_s.url, body=res_s.content)
        #         #     data = json.loads(response_s.text)
        #         #     if data['status'] != '400':
        #         #         response1 = html.fromstring(data['content'])
        #         #         # path = "D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\main\\putty - Indiamart.html"
        #         #         # file_open = open(path, 'r', encoding="utf-8")
        #         #         # file = file_open.read()
        #         #         # file_open.close()
        #         #         # response1 = html.fromstring(file)
        #         #
        #         #         urls = response1.xpath('//span/a[contains(@href,"https://www.indiamart.com/proddetail/")]')
        #         #         for url in urls:
        #         #             url = url.xpath('./@href')[0]
        #         #             yield scrapy.Request(url=url, callback=self.get_data)
        #         #         page+=1
        #         #     else:
        #         #         page += 1
        #         #         print(" ")
        #         # else:
        #         #     print(" ")
        #     except Exception as e:
        #         print(e)

    def get_link(self,response):
        data = json.loads(response.text)
        if data['status'] != '400':
            response1 = html.fromstring(data['content'])
            urls = response1.xpath('//span/a[contains(@href,"https://www.indiamart.com/proddetail/")]')
            for url in urls:
                url = url.xpath('./@href')[0]
                yield scrapy.Request(url=url, callback=self.get_data)
            self.page+=1
        else:
            self.page += 1
            print(" ")

    def get_data(self,response):
        try:
            file_path = f"D:\\khyati-H\\CRM\\723_Scrape contact information from business directories\\HTML\\data\\{response.url.split('/')[-1]}"
            with open(file_path, 'wb') as f:
                f.write(response.body)
                f.close()

            items = IndiamartLinkItem()
            items['URL'] = response.url
            items['HTML_Path'] = file_path.replace("\\","\\\\")
            yield items

        except Exception as e:
            print(e)

from scrapy.cmdline import execute
# execute("scrapy crawl links_json ".split())
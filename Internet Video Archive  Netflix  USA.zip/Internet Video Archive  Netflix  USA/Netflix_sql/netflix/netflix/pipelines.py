# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from itemadapter import ItemAdapter
from netflix import db_config as dbc
from netflix.items import NetflixItem


class NetflixPipeline:
    try:
        con = pymysql.connect(dbc.host, dbc.user, dbc.pswd)
        cursor = con.cursor()
        cursor.execute(f'CREATE DATABASE IF NOT EXISTS {dbc.db}')
    except Exception as e:
        print(str(e))
    con = pymysql.connect(dbc.host, dbc.user, dbc.pswd, dbc.db)
    cursor = con.cursor()

    try:
        create1 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_final} (`Id` int NOT NULL AUTO_INCREMENT,
                                                            `first_link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                            `final_link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                            `path` longtext,
                                                            `status` varchar(50) DEFAULT 'pending',
                                                            `type` varchar(50) DEFAULT 'pending',
                                                            UNIQUE KEY (`final_link`),
                                                            primary key(`Id`));"""
        cursor.execute(create1)
    except Exception as e:
        print(e)

    try:
        create2 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_home} (`Id` int NOT NULL AUTO_INCREMENT,
                                                              `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                              `path` longtext,
                                                              `status` varchar(50) DEFAULT 'pending',
                                                              PRIMARY KEY (`Id`),
                                                              UNIQUE KEY `url` (`url`));"""
        cursor.execute(create2)
    except Exception as e:
        print(e)

    try:
        create3 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_show} (`Id` int NOT NULL AUTO_INCREMENT,
                                                              `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                              `path` longtext,
                                                              `status` varchar(50) DEFAULT 'pending',
                                                              PRIMARY KEY (`Id`),
                                                              UNIQUE KEY `url` (`url`));"""
        cursor.execute(create3)
    except Exception as e:
        print(e)

    try:
        create4 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_movie} (`Id` int NOT NULL AUTO_INCREMENT,
                                                              `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                              `path` longtext,
                                                              `status` varchar(50) DEFAULT 'pending',
                                                              PRIMARY KEY (`Id`),
                                                              UNIQUE KEY `url` (`url`));"""
        cursor.execute(create4)
    except Exception as e:
        print(e)

    try:
        create5 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_show_cat} (`Id` int NOT NULL AUTO_INCREMENT,
                                                              `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                              `path` longtext,
                                                              `status` varchar(50) DEFAULT 'page done',
                                                              PRIMARY KEY (`Id`),
                                                              UNIQUE KEY `url` (`url`));"""
        cursor.execute(create5)
    except Exception as e:
        print(e)

    try:
        create6 = f"""CREATE TABLE IF NOT EXISTS {dbc.table_movie_cat} (`Id` int NOT NULL AUTO_INCREMENT,
                                                              `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                                              `path` longtext,
                                                              `status` varchar(50) DEFAULT 'page done',
                                                              PRIMARY KEY (`Id`),
                                                              UNIQUE KEY `url` (`url`));"""
        cursor.execute(create6)
    except Exception as e:
        print(e)

    def process_item(self, item, spider):
        try:
            if isinstance(item, NetflixItem):
                table = item['table']
                del item['table']
                self.insert_item(table, item)
        except Exception as e:
            print(e)

    def insert_item(self, table, item):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print('Data Inserted...')
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))

    def page_save(self, path, response):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(response)
            f.close()

    def page_read(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            file_open = file.read()
            file.close()
            return file_open


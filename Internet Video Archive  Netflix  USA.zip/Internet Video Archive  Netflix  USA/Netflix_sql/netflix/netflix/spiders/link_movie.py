import hashlib
import os
import re
import time
import scrapy
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class LinkMovieSpider(scrapy.Spider):
    name = 'link_movie'
    start_urls = ['https://example.com/']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        chrome_options = Options()
        chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
        self.driver = webdriver.Chrome(chrome_options=chrome_options)

    def parse(self, response):
        try:
            movie_url = '/browse/genre/34399'
            self.driver.get("https://www.netflix.com" + movie_url)
            time.sleep(3)
            if '"country":"US"' in self.driver.page_source:
                subgenres = re.findall(r'"subgenres":(.*?)"trackIds":', self.driver.page_source)[0]
                subgenre_list = re.findall(r'"id":{(.*?)}', subgenres)
                for sub in subgenre_list:
                    number = re.findall(r'"value":(.*?)$', sub)
                    if len(number) != 0:
                        link = f"https://www.netflix.com/browse/genre/{number[0]}?so=az"
                        path = f"{dbc.path_login_movie_link_cat}{number[0]}.html"
                        if not os.path.exists(path):
                            self.driver.get(link)
                            time.sleep(5)
                            lenOfPage = self.driver.execute_script(
                                "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
                            match = False
                            while (match == False):
                                lastCount = lenOfPage
                                time.sleep(3)
                                lenOfPage = self.driver.execute_script(
                                    "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
                                if lastCount == lenOfPage:
                                    match = True
                            page_source = self.driver.page_source
                            pipe.page_save(self,path,page_source)
                            print("---page save---")

                            item = NetflixItem()
                            item['url'] = link
                            item['path'] = path.replace('\\', '\\\\')
                            item['table'] = dbc.table_movie_cat
                            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl link_movie'.split())
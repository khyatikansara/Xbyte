import hashlib
import os
import re
import time
import scrapy
from lxml import html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys

from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class LinkMovieFirstPageSaveSpider(scrapy.Spider):
    name = 'link_movie_first_page_save'
    start_urls = ['https://example.com/']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        chrome_options = Options()
        chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
        self.driver = webdriver.Chrome(chrome_options=chrome_options)


    def parse(self, response):
        try:
            pipe.cursor.execute(f'select * from {dbc.db}.{dbc.table_movie} where status="pending"')
            results = pipe.cursor.fetchall()
            for row in results:
                Id = row[0]
                first_link = row[1]
                first_link_id = first_link.split('?')[0].split('/')[-1]
                self.driver.get(first_link)
                time.sleep(5)
                count,new_count =0,0
                count = self.driver.find_elements_by_xpath('//a[@class="slider-refocus"]')
                while True:
                    for i in range(1,50):
                        count = self.driver.find_elements_by_xpath('//a[@class="slider-refocus"]')
                        body = self.driver.find_element_by_css_selector('body')
                        body.send_keys(Keys.PAGE_DOWN)
                        body = self.driver.find_element_by_css_selector('body')
                        body.send_keys(Keys.PAGE_DOWN)
                        new_count = self.driver.find_elements_by_xpath('//a[@class="slider-refocus"]')
                    if len(count) == len(new_count):
                        for j in range(1,50):
                            body = self.driver.find_element_by_css_selector('body')
                            body.send_keys(Keys.PAGE_DOWN)
                            body = self.driver.find_element_by_css_selector('body')
                            body.send_keys(Keys.PAGE_DOWN)
                            new_count = self.driver.find_elements_by_xpath('//a[@class="slider-refocus"]')
                        if len(count) == len(new_count):
                            break
                # lengh = self.driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
                path = f"{dbc.path_login_movie_link}{first_link_id}.html"
                if '"country":"US"' in self.driver.page_source:
                    page_source = self.driver.page_source
                    pipe.page_save(self, path, page_source)
                    print("page save done")
                    final_path = path.replace('\\','\\\\')
                    try:
                        pipe.cursor.execute(f'''update {dbc.db}.{dbc.table_movie} set path="{final_path}",status="page done" where Id="{Id}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl link_movie_first_page_save'.split())
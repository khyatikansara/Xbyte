import hashlib
import os
import re
import time
import scrapy
from lxml import html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class FinalLinkallSpider(scrapy.Spider):
    name = 'final_link_all'
    start_urls = ['https://example.com/']

    def parse(self, response):
        try:
            table_list = [dbc.table_home,dbc.table_movie_cat,dbc.table_show_cat]
            for table in table_list:
                pipe.cursor.execute(f'select * from {dbc.db}.{table} where status="page done"')
                results = pipe.cursor.fetchall()
                for row in results:
                    first_link = row[1]
                    path = row[2]
                    file = pipe.page_read(self,path)
                    response = html.fromstring(file)
                    final_links = response.xpath('//a[contains(@href,"/watch/")]/@href')
                    for link in final_links:
                        final_link = "https://www.netflix.com"+link.replace('/watch/', '/title/').split('?')[0]
                        item = NetflixItem()
                        item['first_link'] = first_link
                        item['final_link'] = final_link
                        item['table'] = dbc.table_final
                        yield item
                    try:
                        pipe.cursor.execute(f'''update {dbc.db}.{table} set status="Done" where url="{first_link}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl final_link_all'.split())
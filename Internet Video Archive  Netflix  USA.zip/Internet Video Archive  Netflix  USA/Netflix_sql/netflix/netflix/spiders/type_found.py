import hashlib
import json
import os
import re
import time
import pandas as pd
import scrapy
from lxml import html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class TypeFoundSpider(scrapy.Spider):
    name = 'type_found'
    start_urls = ['https://example.com/']
    start,end = '',''
    OTT_Platform_Number = 'netflix_us'

    def parse(self, response):
        try:
            pipe.cursor.execute(f"select * from {dbc.db}.{dbc.table_final} where status='page_done' and type='pending' and Id>'{self.start}' and Id<'{self.end}'")
            results = pipe.cursor.fetchall()
            for row in results:
                Id = row[0]
                print(Id)
                movie = False
                Show = False
                url = row[2]
                url_id = url.split('/')[-1]
                path = row[3]
                file = pipe.page_read(self, path)
                file_all = bytes(file, encoding='utf-8')
                count = ''
                if 'netflix.falcorCache =' in file:
                    data = re.findall(b'netflix.falcorCache =(.*?);', file_all)[0].replace(b'\\x24', b'$').replace(
                        b'\\"x\\"', b"'x'").replace(b'\\"y\\"', b"'y'").replace(
                        b'\\x20', b' ').replace(b'\\"', b"'").replace(b"\\x7C", b"|").replace(b"\\x2B",
                                                                                              b"+").replace(
                        b"\\x2F", b"/").replace(b"\\x3F", b"?").replace(b"\\x3D", b"=").replace(
                        b'\\x27', b"'").replace(b'\\x26', b'&').replace(b'\\x21', b'!').replace(b'\\x3B',
                                                                                                b';').replace(
                        b'\\x28', b'(').replace(b'\\x29', b')').replace(
                        b'\\x23', b'#').replace(b'\\x2A', b'*').replace(b'\\x25', b'%').replace(b'\\x7E', b'~').replace(b'\\x40',b'@')
                    data1 = data.decode('utf-8').strip()
                    try:
                        json_data = json.loads(data1)
                        if json_data != {}:
                            for id, value in json_data['videos'].items():
                                if url_id == id:
                                    try:
                                        Type = value['summary']['value']['type']
                                    except:
                                        Type = value['bobSummary']['value']['type']
                                    if Type == 'show':
                                        Show = True
                                    elif Type == 'episode':
                                        Show = True
                                    elif Type == 'movie':
                                        movie = True
                                    break

                    except Exception as e:
                        print(e)
                        json_data = {}
                else:
                    print("STOP")
                    json_data = {}
                if json_data == {}:
                    show_text = response.xpath('//*[@class="duration"]/text()')[0]
                    if 'This movie is' in file:
                        movie = True
                    elif '"@type":"Movie"' in file:
                        movie = True
                    elif '"type":"movie"' in file:
                        movie = True
                    elif 'This show is' in file:
                        Show = True
                    elif '"@type":"TVSeries"' in file:
                        Show = True
                    elif 'Season' in show_text:
                        Show = True
                    elif 'Book' in show_text:
                        if response.xpath('//*[@class="episodeSelector"]'):
                            Show = True
                    elif 'Limited Series' in show_text:
                        if response.xpath('//*[@class="episodeSelector"]'):
                            Show = True
                    elif 'Parts' in show_text:
                        if response.xpath('//*[@class="episodeSelector"]'):
                            Show = True

                    #-----if client want uncomment this lines------
                    # if "Remind Me" in file:
                    #     count = "done_Remind_Me"
                    # elif "Oh no! This title currently isn’t available to watch in your country." in file:
                    #     count = 'remove'
                    # elif "Oh no! This title isn’t currently available to watch in your country." in file:
                    #     count = 'remove'
                    # else:
                    #     count = "baki"

                if movie == True:
                    try:
                        pipe.cursor.execute(f'''update {dbc.db}.{dbc.table_final} set type="Movie" where final_link="{url}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)

                if Show == True:
                    try:
                        pipe.cursor.execute(f'''update {dbc.db}.{dbc.table_final} set type="Show" where final_link="{url}"''')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl type_found -a start=0 -a end=50000'.split())
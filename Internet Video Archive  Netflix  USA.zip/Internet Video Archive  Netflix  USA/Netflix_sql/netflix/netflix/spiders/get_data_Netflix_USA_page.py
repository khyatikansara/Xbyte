import datetime
import hashlib
import json
import re
import pymongo
import pymysql
import scrapy
import requests
from lxml import html
from netflix.items import OTTPlatformsMoviesItem, OTTPlatformsAvailabilitiesItem, OTTPlatformsShowsItem, OTTPlatformsSeasonsItem, OTTPlatformsEpisodesItem
from scraper_api import ScraperAPIClient
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class GetDataNetflixUSAPageSpider(scrapy.Spider):
    name = 'get_data_netflix_usa_page'
    start_urls = ["https://example.com/"]
    handle_httpstatus_list = [503, 502, 501, 500]
    OTT_Platform_Number = 'netflix_us'

    def __init__(self, start='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': self.OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']

        con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = con[f'OTT_{Source}_{Country}']
        self.link_master = self.db[f'OTT_{Source}_{Country}_Links_Master']

        try:
            con = pymysql.connect('localhost', 'root', 'xbyte')
            cursor = con.cursor()
            cursor.execute(f'CREATE DATABASE IF NOT EXISTS netflix_usa')
        except Exception as e:
            print(str(e))
        self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'netflix_usa')
        self.cursor1 = self.con1.cursor()

    def parse(self, response):
        try:
            sql_select_Query = f"select * from {dbc.table_final} where status='page_done'"
            self.cursor1.execute(sql_select_Query)
            links = self.cursor1.fetchall()
            for link in links:
                try:
                    Id=link[0]
                    Url=link[2]
                    url_id = Url.split('/')[-1]
                    path = link[3]
                    file_all_string = pipe.page_read(self, path)
                    file_all = bytes(file_all_string,encoding='utf-8')
                    data = re.findall(b'netflix.falcorCache =(.*?);', file_all)[0].replace(b'\\x24', b'$').replace(
                        b'\\"x\\"', b"'x'").replace(b'\\"y\\"', b"'y'").replace(
                        b'\\x20', b' ').replace(b'\\"', b"'").replace(b"\\x7C", b"|").replace(b"\\x2B",b"+").replace(
                        b"\\x2F", b"/").replace(b"\\x3F", b"?").replace(b"\\x3D", b"=").replace(
                        b'\\x27', b"'").replace(b'\\x26', b'&').replace(b'\\x21', b'!').replace(b'\\x3B', b';').replace(b'\\x28',b'(').replace(b'\\x29',b')').replace(
                        b'\\x23',b'#').replace(b'\\x2A',b'*').replace(b'\\x25',b'%').replace(b'\\x7E',b'~')
                    data1 = data.decode('utf-8').strip()
                    try:
                        json_data = json.loads(data1)
                        pipe.page_save(self, f"{dbc.path_login_data}\\{url_id}.json", data1)
                    except Exception as e:
                        print(e)
                        json_data = {}
                    if json_data != {}:
                        for id, value in json_data['videos'].items():
                            if url_id == id:
                                found_asin = Url.split('/')[-1]
                                try:
                                    Title = value['jawSummary']['value']['title']
                                except:
                                    Title = value['itemSummary']['value']['title']
                                try:
                                    Year = value['jawSummary']['value']['releaseYear']
                                except:
                                    Year = value['itemSummary']['value']['releaseYear']
                                try:
                                    Description = value['jawSummary']['value']['synopsisRegular']
                                except:
                                    Description = value['synopsisRegular']['value']
                                Crew = []
                                for crew in value['jawSummary']['value']['creators']:
                                    Crew.append(crew['name'])
                                for crew in value['jawSummary']['value']['writers']:
                                    Crew.append(crew['name'])
                                Directors = []
                                for director in value['jawSummary']['value']['directors']:
                                    Directors.append(director['name'])

                                PosterUrl = value['jawSummary']['value']['backgroundImage']['url']
                                try:
                                    Quality = ''
                                    Quality = value['bobSummary']['value']['delivery']['quality']
                                    if Quality == '':
                                        Quality = 'NOT_SET'
                                except:
                                    Quality = 'NOT_SET'
                                Actors = []
                                for Actor in value['jawSummary']['value']['cast']:
                                    Actors.append(Actor['name'])
                                try:
                                    Type = value['summary']['value']['type']
                                except:
                                    Type = value['bobSummary']['value']['type']

                                if Type == 'movie':
                                    movie = OTTPlatformsMoviesItem()
                                    # make sure to take unique value for this if found for specific movie. do not generate using any hash function
                                    movie["_id"] = found_asin
                                    movie["Title"] = Title
                                    movie["Actors"] = Actors
                                    movie["Directors"] = Directors
                                    movie["Crew"] = Crew
                                    movie["Year"] = int(Year)
                                    movie["Source"] = 'Netflix'
                                    movie["PosterUrl"] = PosterUrl
                                    movie["Description"] = Description
                                    movie["ProviderUniqueId"] = found_asin
                                    movie["IMDBId"] = None
                                    movie["Url"] = Url
                                    movie["Country"] = 'US'
                                    movie["TMDBId"] = None
                                    movie["Modifier"] = None
                                    movie["Modified"] = datetime.datetime.utcnow()
                                    movie["Scrap_datetime"] = datetime.datetime.now()
                                    movie["SlotNumber"] = 1
                                    yield movie

                                    Quality_len = Quality.split('|')
                                    for qual in Quality_len:
                                        # Movie Availabilities
                                        availabilities = OTTPlatformsAvailabilitiesItem()
                                        availabilities["ProviderUniqueId"] = found_asin
                                        availabilities["PreSale"] = False
                                        availabilities["Modifier"] = None
                                        availabilities["StartDate"] = None
                                        availabilities["Country"] = 'US'
                                        availabilities["DeliveryMethod"] = 'OnDemand'
                                        availabilities["Modified"] = datetime.datetime.utcnow()
                                        Links = list()
                                        Links.append({'Url': movie["Url"], 'Platform': 'Web'})
                                        Links.append({
                                                         'Url': f'{movie["Url"].replace("https", "intent")}#Intent;package=com.netflix.mediaclient;scheme=https;end',
                                                         'Platform': 'Android'})
                                        Links.append({'Url': f'{movie["Url"].replace("https", "nflx")}', 'Platform': 'IOS'})
                                        availabilities["Links"] = Links
                                        availabilities["Price"] = 0
                                        availabilities["Currency"] = 'USD'
                                        availabilities["ExpirationDate"] = None
                                        availabilities["Provider"] = 'Netflix'
                                        availabilities["OfferType"] = 'Subscription'
                                        availabilities["Quality"] = qual
                                        unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                            availabilities["Price"]) + str(
                                            availabilities["Provider"]) + str(availabilities["OfferType"]) + str(
                                            availabilities["Quality"])
                                        availabilities["_id"] = int(
                                            hashlib.md5(bytes(unique_key + 'Movie', encoding='utf8')).hexdigest(), 16) % (
                                                                            10 ** 8)
                                        yield availabilities
                                    self.cursor1.execute(f'''update {dbc.table_final} set status="Done" where Id="{Id}"''')
                                    self.con1.commit()
                                    print("update done")
                                elif Type == 'show':
                                    self.cursor1.execute(f'''update movie_baki set status="season" where Id="{Id}"''')
                                    self.con1.commit()
                                    print("update done")
                                    show_data = re.findall(b'netflix.reactContext =(.*?);', file_all)[
                                        0].replace(b'\\x2F', b'/').replace(
                                        b'\\x40', b'@').replace(b'\\x2A', b'*').replace(b'\\x20', b' ').replace(
                                        b'\\x28', b'(').replace(
                                        b'\\x29', b')').replace(b'\\x3D', b'=').replace(b'\\x27', b"'").replace(
                                        b'\\x21', b'!').replace(
                                        b'\\x2B', b'+').replace(b'\\x3B', b';').replace(b'\\x3F', b'?').replace(
                                        b'\\x26', b'&').decode(
                                        'unicode-escape').encode().replace(b"\xe2\x82\xb9\xc2\xa0",
                                                                           b'').replace(b"\xc3\x9a",
                                                                                        b'U').replace(
                                        b"\xc3\xb3", b'o').replace(b"\xc3\x81", b'A').replace(b"\xc3\xb1",
                                                                                              b'n').replace(
                                        b"\xc2\xa0", b'').replace(b"\xc3\xa9", b'e').replace(
                                        b"\xc3\xa1", b'a').replace(b'\xc3\xad', b'i').replace(b'\xc3\x88',
                                                                                              b'E').replace(
                                        b'\xc3\xae', b'i').replace(
                                        b'\xc5\xa1', b's').replace(b'\xe2\x80\xa6', b'...').replace(
                                        b'\xe2\x80\x99', b',').replace(b'\xc3\xa4', b'a').replace(
                                        b'\xe2\x80\x94', b'-').replace(b'\n', b'').replace(b' "',
                                                                                           b" '").replace(b'" ',
                                                                                                          b"' ").replace(
                                        b'.""', b'."').replace(b'":""', b'":"').replace(b'"?', b'').replace(
                                        b'":",', b'":"",').replace(
                                        b' ":"', b'":"').replace(b"'", b"&quote;").replace(b'& quote;',
                                                                                           b'&quote;').replace(
                                        b' / cookies ', b'/cookies').replace(b'".', b'.&quote;').replace(
                                        b'.&quote;', b'"')

                                    try:
                                        netflix_data = re.findall(b'seasonsAndEpisodes(.*?)\}\]\}\]\}\}', show_data, re.DOTALL)
                                        netflix_data = b'{"type": "seasonsAndEpisodes' + netflix_data[0] + b'}]}]}}'
                                        show_json_data = json.loads(netflix_data)
                                    except Exception as e:
                                        print(e)
                                        show_json_data = {}
                                    if show_json_data != {}:
                                        season_data = value['jawSummary']['value']['seasonCount']
                                        # For show Data
                                        show = OTTPlatformsShowsItem()
                                        show["_id"] = found_asin
                                        show["Title"] = Title
                                        show["Actors"] = Actors
                                        show["Directors"] = Directors
                                        show["Crew"] = None
                                        show["Year"] = int(Year)
                                        show["Source"] = 'Netflix'
                                        show["PosterUrl"] = PosterUrl
                                        show["Description"] = Description
                                        show["ProviderUniqueId"] = found_asin
                                        show["IMDBId"] = None
                                        show["Url"] = Url
                                        show["Country"] = 'US'
                                        show["TMDBId"] = None
                                        show["Modifier"] = None
                                        show["Modified"] = datetime.datetime.utcnow()
                                        show["Scrap_datetime"] = datetime.datetime.now()
                                        show["SlotNumber"] = 1
                                        yield show

                                        # Show Availabilities
                                        availabilities = OTTPlatformsAvailabilitiesItem()
                                        availabilities["ProviderUniqueId"] = found_asin
                                        availabilities["PreSale"] = False
                                        availabilities["Modifier"] = None
                                        availabilities["StartDate"] = None
                                        availabilities["Country"] = 'US'
                                        availabilities["DeliveryMethod"] = 'OnDemand'
                                        availabilities["Modified"] = datetime.datetime.utcnow()

                                        Links = list()
                                        Links.append({'Url': show["Url"], 'Platform': 'Web'})
                                        Links.append({
                                            'Url': f'{show["Url"].replace("https", "intent")}#Intent;package=com.netflix.mediaclient;scheme=https;end',
                                            'Platform': 'Android'})
                                        Links.append(
                                            {'Url': f'{show["Url"].replace("https", "nflx")}', 'Platform': 'IOS'})
                                        availabilities["Links"] = Links
                                        availabilities["Price"] = 0
                                        availabilities["Currency"] = 'USD'
                                        availabilities["ExpirationDate"] = None
                                        availabilities["Provider"] = 'Netflix'
                                        availabilities["OfferType"] = 'Subscription'
                                        availabilities["Quality"] = Quality

                                        unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                            availabilities["Price"]) + str(
                                            availabilities["Provider"]) + \
                                                     str(availabilities["OfferType"]) + str(
                                            availabilities["Quality"])
                                        availabilities["_id"] = int(
                                            hashlib.md5(bytes(unique_key + 'Show', encoding='utf8')).hexdigest(),
                                            16) % (10 ** 8)

                                        yield availabilities
                                        self.cursor1.execute(f'''update show_baki set status="Done" where Id="{Id}"''')
                                        self.con1.commit()
                                        print("update done")

                                        for i in range(len(season_data)):
                                            Season_num = json_data["data"]["seasons"][i]["num"]
                                            season_id = json_data["data"]["seasons"][i]["seasonId"]
                                            season_Description = json_data["data"]["seasons"][i]["synopsis"]
                                            season_Year = json_data["data"]["seasons"][i]["releaseYear"]
                                            # For Season Data

                                            season = OTTPlatformsSeasonsItem()
                                            season["SeasonNumber"] = Season_num
                                            season["_id"] = season_id
                                            season["Modified"] = datetime.datetime.utcnow()
                                            season["Modifier"] = None
                                            season["Description"] = season_Description
                                            season["Country"] = 'US'
                                            season["Title"] = Title
                                            season["Url"] = Url
                                            season["IMDBId"] = None
                                            season["PosterUrl"] = PosterUrl
                                            season["Crew"] = None
                                            season["Source"] = 'Netflix'
                                            season["Directors"] = Directors
                                            season["Actors"] = Actors
                                            season["TMDBId"] = None
                                            season["Year"] = season_Year
                                            season["Scrap_datetime"] = datetime.datetime.now()
                                            season["SlotNumber"] = 1
                                            season["ProviderUniqueId"] = show["ProviderUniqueId"]
                                            season["ProviderUniqueSeasonId"] = season_id
                                            yield season

                                            # Season Availabilities
                                            availabilities_season = OTTPlatformsAvailabilitiesItem()

                                            availabilities_season["PreSale"] = False
                                            availabilities_season["Modifier"] = None
                                            availabilities_season["StartDate"] = None
                                            availabilities_season["Country"] = 'US'
                                            availabilities_season["DeliveryMethod"] = 'OnDemand'
                                            availabilities_season["Modified"] = datetime.datetime.utcnow()

                                            Links = list()
                                            Links.append({'Url': season["Url"], 'Platform': 'Web'})
                                            Links.append({
                                                             'Url': f'{season["Url"].replace("https", "intent")}#Intent;package=com.netflix.mediaclient;scheme=https;end',
                                                             'Platform': 'Android'})
                                            Links.append({'Url': f'{season["Url"].replace("https", "nflx")}',
                                                          'Platform': 'IOS'})
                                            availabilities_season["Links"] = Links
                                            availabilities_season["ProviderUniqueSeasonId"] = season_id
                                            availabilities_season["Price"] = 0
                                            availabilities_season["Currency"] = 'USD'
                                            availabilities_season["ExpirationDate"] = None
                                            availabilities_season["Provider"] = 'Netflix'
                                            availabilities_season["OfferType"] = 'Subscription'
                                            availabilities_season["Quality"] = Quality
                                            unique_key = str(availabilities_season["ProviderUniqueSeasonId"]) + str(
                                                availabilities_season["Price"]) + str(
                                                availabilities_season["Provider"]) + \
                                                         str(availabilities_season["OfferType"]) + str(
                                                availabilities_season["Quality"])
                                            availabilities_season["_id"] = int(hashlib.md5(
                                                bytes(unique_key + 'Season', encoding='utf8')).hexdigest(), 16) % (
                                                                                       10 ** 8)
                                            yield availabilities_season

                                            episode_data = json_data["data"]["seasons"][i]["episodes"]
                                            for j in range(len(episode_data)):
                                                episode = OTTPlatformsEpisodesItem()
                                                Episode_No = json_data["data"]["seasons"][i]["episodes"][j][
                                                    "episodeNum"]
                                                Episode_Title = json_data["data"]["seasons"][i]["episodes"][j][
                                                    "title"]
                                                Episode_Id = json_data["data"]["seasons"][i]["episodes"][j][
                                                    "episodeId"]
                                                Episode_Description = \
                                                json_data["data"]["seasons"][i]["episodes"][j]["synopsis"]
                                                Episode_Year = json_data["data"]["seasons"][i]["episodes"][j][
                                                    "year"]
                                                Episode_ImageUrl = episode_data[j]['artworkUrl']

                                                episode['_id'] = Episode_Id
                                                episode['Modified'] = datetime.datetime.utcnow()
                                                episode['Modifier'] = None
                                                episode['EpisodeNumber'] = Episode_No
                                                episode['Description'] = Episode_Description
                                                episode['Country'] = 'US'
                                                episode['Title'] = Episode_Title
                                                episode['Url'] = f'https://www.netflix.com/watch/{Episode_Id}'
                                                episode['IMDBId'] = None
                                                episode['ImageUrl'] = Episode_ImageUrl
                                                episode['Crew'] = None
                                                episode['Source'] = 'Netflix'
                                                episode['Directors'] = Directors
                                                episode['Actors'] = Actors
                                                episode['TMDBId'] = None
                                                episode['Year'] = Episode_Year
                                                episode['Scrap_datetime'] = datetime.datetime.now()
                                                episode['SlotNumber'] = 1
                                                episode['ProviderUniqueId'] = show["ProviderUniqueId"]
                                                episode['ProviderUniqueSeasonId'] = season["ProviderUniqueSeasonId"]
                                                episode['ProviderUniqueEpisodeId'] = Episode_Id
                                                yield episode

                                                # Episode Availabilities
                                                availabilities_episode = OTTPlatformsAvailabilitiesItem()
                                                availabilities_episode["ProviderUniqueEpisodeId"] = Episode_Id
                                                availabilities_episode["PreSale"] = False
                                                availabilities_episode["Modifier"] = None
                                                availabilities_episode["StartDate"] = None
                                                availabilities_episode["Country"] = 'US'
                                                availabilities_episode["DeliveryMethod"] = 'OnDemand'
                                                availabilities_episode["Modified"] = datetime.datetime.utcnow()

                                                Links = list()
                                                Links.append({'Url': episode["Url"], 'Platform': 'Web'})
                                                Links.append({
                                                                 'Url': f'{episode["Url"].replace("https", "intent")}#Intent;package=com.netflix.mediaclient;scheme=https;end',
                                                                 'Platform': 'Android'})
                                                Links.append({'Url': f'{episode["Url"].replace("https", "nflx")}',
                                                              'Platform': 'IOS'})

                                                availabilities_episode["Links"] = Links
                                                availabilities_episode["Price"] = 0
                                                availabilities_episode["Currency"] = 'USD'
                                                availabilities_episode["ExpirationDate"] = None
                                                availabilities_episode["Provider"] = 'Netflix'
                                                availabilities_episode["OfferType"] = 'Subscription'
                                                availabilities_episode["Quality"] = Quality

                                                unique_key = str(
                                                    availabilities_episode["ProviderUniqueEpisodeId"]) + str(
                                                    availabilities_episode["Price"]) + str(
                                                    availabilities_episode["Provider"]) + str(
                                                    availabilities_episode["OfferType"]) + str(
                                                    availabilities_episode["Quality"])
                                                availabilities_episode["_id"] = int(hashlib.md5(
                                                    bytes(unique_key + 'Episode', encoding='utf8')).hexdigest(),
                                                                                    16) % (10 ** 8)

                                                yield availabilities_episode

                    try:
                        self.link_master.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                        print("---update data done---")
                    except Exception as e:
                        print(e)
                    try:
                        sql_update_Query = f"update netflix_usa.movie_baki1 set status='Done' where link='{Url}'"
                        self.cursor = self.mydb.cursor()
                        self.cursor.execute(sql_update_Query)
                        self.cursor1.execute(f'''update movie_baki1 set status="Done" where Id="{Id}"''')
                        self.con1.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl get_data_netflix_usa_page -a start=0'.split())
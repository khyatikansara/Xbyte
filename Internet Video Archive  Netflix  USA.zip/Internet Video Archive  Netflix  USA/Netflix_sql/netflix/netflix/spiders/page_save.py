import hashlib
import os
import re
import time
import pandas as pd
import scrapy
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class PageSaveSpider(scrapy.Spider):
    name = 'page_save'
    start_urls = ['https://example.com/']
    start,end = '',''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        chrome_options = Options()
        chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
        self.driver = webdriver.Chrome(chrome_options=chrome_options)

    def parse(self, response):
        try:
            pipe.cursor.execute(f"select * from {dbc.db}.{dbc.table_final} where status='Done' and Id>'{self.start}' and Id<'{self.end}'")
            results = pipe.cursor.fetchall()
            for row in results:
                Id = row[0]
                print(Id)
                url = row[2]
                url_id = url.split('/')[-1]
                self.driver.get(url)
                time.sleep(10)
                try:
                    if not self.driver.find_element_by_xpath('//h1[text()="Something went wrong"]'):
                        if self.driver.current_url != 'https://www.netflix.com/browse':
                            path = f"{dbc.path_login_data}{url_id}.html"
                            if '"country":"US"' in self.driver.page_source:
                                page_source = self.driver.page_source
                                pipe.page_save(self,path,page_source)
                                print("page save done")
                                try:
                                    file_path = path.replace('\\','\\\\')
                                    pipe.cursor.execute(f'''update {dbc.db}.{dbc.table_final} set status="page_done1",path="{file_path}" where Id="{Id}"''')
                                    pipe.con.commit()
                                    print("update done")
                                except Exception as e:
                                    print(e)
                except Exception as e:
                    print(e)
                    if self.driver.current_url != 'https://www.netflix.com/browse':
                        path = f"{dbc.path_login_data}{url_id}.html"
                        if '"country":"US"' in self.driver.page_source:
                            page_source = self.driver.page_source
                            pipe.page_save(self, path, page_source)
                            print("page save done")
                            try:
                                file_path = path.replace('\\', '\\\\')
                                pipe.cursor.execute(
                                    f'''update {dbc.db}.{dbc.table_final} set status="page_done11",path="{file_path}" where Id="{Id}"''')
                                pipe.con.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
            self.driver.close()
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl page_save -a start=0 -a end=5'.split())
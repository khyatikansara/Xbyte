import hashlib
import os
import re
import time
import scrapy
from lxml import html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class LinkShowFirstSpider(scrapy.Spider):
    name = 'link_show_first'
    start_urls = ['https://example.com/']

    def parse(self, response):
        try:
            path = f"{dbc.path_login_show}TV Shows - Netflix.html"
            file = pipe.page_read(self, path)
            response = html.fromstring(file)
            final_links = response.xpath('//h2/a/@href')
            for first_link in final_links:
                item = NetflixItem()
                item['url'] = first_link+"?so=az"
                item['table'] = dbc.table_show
                yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl link_show_first'.split())
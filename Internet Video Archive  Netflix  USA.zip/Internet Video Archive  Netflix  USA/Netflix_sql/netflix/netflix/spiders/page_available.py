import hashlib
import os
import re
import time
import scrapy
from lxml import html
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from netflix.items import NetflixItem
from netflix import db_config as dbc
from netflix.pipelines import NetflixPipeline as pipe


class PageAvailableSpider(scrapy.Spider):
    name = 'page_available'
    allowed_domains = ['www.netflix.com']
    handle_httpstatus_list = [503, 502, 501, 500]

    def start_requests(self):
        try:
            url = "https://www.netflix.com/browse"
            self.headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'no-cache',
                'cookie': 'clSharedContext=70b53fbe-09b8-48f4-ad2c-1da21efd4199; memclid=b8a129fb-62ff-4baf-9f86-73bf8b12c8ee; nfvdid=BQFmAAEBEOIx3YBIrzoDd0Y4NNUmz_dgT5G6pjC2UMmRqLoA9-SjuN6zs4mEf2lifiNLupNxvq8HaeV673lMNqUUZ4_ZkZdjPPZsmoSOlO67qjccbSU3APud3CVqQ9HGeSfcMKMaCLAc1whnTS8Qz3GCKGjPQcnA; profilesNewSession=0; lhpuuidh-browse-R7NORHXHXJF7RDPEB4IAVP5OI4=US%3AEN-US%3A8419ea2e-f1df-43b1-a8ca-d566765f5e3e_ROOT; lhpuuidh-browse-R7NORHXHXJF7RDPEB4IAVP5OI4-T=1616396695501; flwssn=08f82890-dc77-4186-8101-c8f2e7a28eb7; lhpuuidh-browse-YADOT574L5H7VNNVY4K53M7WAY=US%3AEN-US%3A2b6acd5b-0510-4e3e-9cf2-ad88f5f083a2_ROOT; lhpuuidh-browse-YADOT574L5H7VNNVY4K53M7WAY-T=1616396765374; playerPerfMetrics=%7B%22uiValue%22%3A%7B%22throughput%22%3A2.61947%7D%2C%22mostRecentValue%22%3A%7B%22throughput%22%3A4.11653%7D%7D; cL=1616397201357%7C161639713290395105%7C161639713292436545%7C%7C11%7CS5MVS3D2O5F2BG6RM2BQFNP2KA; OptanonConsent=isIABGlobal=false&datestamp=Mon+Mar+22+2021+12%3A43%3A22+GMT%2B0530+(India+Standard+Time)&version=6.6.0&consentId=f407bb75-6131-46d6-a611-f9c04cb6a810&interactionCount=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0004%3A0&hosts=H1%3A1%2CH2%3A1%2CH12%3A1%2CH13%3A1%2CH27%3A0%2CH28%3A0%2CH30%3A0&AwaitingReconsent=false; SecureNetflixId=v%3D2%26mac%3DAQEAEQABABS1RWetfRbiDN3ftLOxz5JmlIqntv-_dAw.%26dt%3D1616397203674; NetflixId=v%3D2%26ct%3DBQAOAAEBEMrsIoVYsmQdpFkozXCpbbWB0OL5nfrrkp3-8b3D8GXRpGZf92iC6l0IGWe2fCEDG0BZOgVJgcgikkedTyzK1IC9lce8fn3iPfuw8eOOmMiymtHgA8lBVe9m7p9EM5nHmZ5Oe-PkdN3T5LVCKKQYjIXqMr1oN2kNMdOEQ7eeZqWP3lIvQV-PcSl1HVXjV6gqR03D1jZC14YNxPYFTLt7oNijZUhfK83kWweFSA9R1Zl_PYmZjAqTrjAXXtbXxjOLA9s29juMzAiK_oWFnsg4vfdhU2mVJLlCbf7FsSVB6VRLZB__btMpev34TYw8gFVgqyC0X47Xyjo3pNMbi-6l4o_g5rZh-BXEnz7mXuhHrkaHogdnj2KuNFDLvN1NA0csvjBXBEhBX1TUS9wqF2_HBkIGsQiOM9Op-RckygAx8zUrhmKYnAha9Yl3nMK-g_hx_8JbpcDhljKq1L1YOhdpqsMKNvgt226g8X1Fz6rrCXHH3uFsAXehCF9sDNNrseOn2Nn-5LXMVRWrq0zW3QczwZnDwKvm9TAGjxNzlC6hhQkVhuKnwEsTRfLMGrKNwuUWJwTv1BUMeInEfuK1ik8nP-AmDzoFSxsTJDylkodblp4xVMLLfcB4VbIMT9vUQOUFNvoc%26bt%3Ddbl%26ch%3DAQEAEAABABSjr-xlxK-BGFOHIuDY8ihYCtcyQb368jw.%26mac%3DAQEAEAABABSnGsJzs7RQt0F3xZdCrDwNgeY6TunLNqQ.',
                # 'referer': 'https://www.netflix.com/login',
                'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
            }
            yield scrapy.Request(url=url, headers=self.headers)
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            pipe.cursor.execute(f'select * from {dbc.db}.movie_file_client1 where status="Done"')
            results = pipe.cursor.fetchall()
            for row in results:
                Id = row[0]
                if Id == 4458:
                    print()
                    first_link = row[1]
                    url_id = first_link.split('/')[-1]
                    path = f'D:\khyati-H\CRM\Projects AP\IVA Project\\Netflix_USA\data_2021_05_19\\{url_id}.html'
                    final_path = path.replace('\\','\\\\')
                    if os.path.exists(path):
                        try:
                            pipe.cursor.execute(f'''update {dbc.db}.show_file_client1 set status="page done",path="{final_path}" where final_link="{first_link}"''')
                            pipe.con.commit()
                            print(f"update done {Id}")
                        except Exception as e:
                            print(e)
                    else:
                        try:
                            pipe.cursor.execute(f'''update {dbc.db}.show_file_client1 set status="pending1" where Id="{Id}"''')
                            pipe.con.commit()
                            print(f"update done {Id} pending1")
                        except Exception as e:
                            print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl page_available'.split())
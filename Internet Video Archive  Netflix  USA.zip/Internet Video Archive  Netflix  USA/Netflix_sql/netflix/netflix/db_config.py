import datetime
import os

host = "192.168.1.252"
user = "root"
pswd = "xbyte"
db = "netflix_usa"
table_date = "2021_10_28"
table_home = f"home_link_{table_date}"
table_movie_cat = f"movie_cat_link_{table_date}"
table_movie = f"movie_link_{table_date}"
table_show_cat = f"show_cat_link_{table_date}"
table_show = f"show_link_{table_date}"
table_final = f"finallink{table_date}"

path_date = datetime.datetime.strftime(datetime.datetime.today(),"%Y_%m_%d")
# path_date = "2021_09_14"
path_login = f"D:\khyati-H\CRM\Projects AP\IVA Project\Internet Video Archive  Netflix  USA\\HTML_{path_date}\\login\\"
path_login_data = f"{path_login}data\\"
path_login_movie = f"{path_login}movie\\"
path_login_show = f"{path_login}show\\"
path_login_home = f"{path_login}home\\"
path_login_home_link = f"{path_login_home}link\\"
path_login_show_link = f"{path_login_show}link\\"
path_login_show_link_cat = f"{path_login_show}link_cat\\"
path_login_movie_link = f"{path_login_movie}link\\"
path_login_movie_link_cat = f"{path_login_movie}link_cat\\"

if not os.path.exists(path_login):
    os.makedirs(path_login)
if not os.path.exists(path_login_data):
    os.makedirs(path_login_data)
if not os.path.exists(path_login_movie):
    os.makedirs(path_login_movie)
if not os.path.exists(path_login_show):
    os.makedirs(path_login_show)
if not os.path.exists(path_login_home):
    os.makedirs(path_login_home)
if not os.path.exists(path_login_home_link):
    os.makedirs(path_login_home_link)
if not os.path.exists(path_login_show_link):
    os.makedirs(path_login_show_link)
if not os.path.exists(path_login_show_link_cat):
    os.makedirs(path_login_show_link_cat)
if not os.path.exists(path_login_movie_link):
    os.makedirs(path_login_movie_link)
if not os.path.exists(path_login_movie_link_cat):
    os.makedirs(path_login_movie_link_cat)

path_no_login = f"D:\khyati-H\CRM\Projects AP\IVA Project\Internet Video Archive  Netflix  USA\\HTML_{path_date}\\no login\\"
path_no_login_data = f"{path_no_login}data\\"
if not os.path.exists(path_no_login):
    os.makedirs(path_no_login)
if not os.path.exists(path_no_login_data):
    os.makedirs(path_no_login_data)


import os, platform
from datetime import datetime, timedelta, date

host = "192.168.1.252"
username = "root"
password = "xbyte"
database = "2909_Extract_Food_Menu_data_from_Zomato"

first_level_link = "first_level_link_2020_12_21"
final_link = "finallink_2020_12_21"
data = "data_2021_01_08_1"
final_link_city = "city_180"


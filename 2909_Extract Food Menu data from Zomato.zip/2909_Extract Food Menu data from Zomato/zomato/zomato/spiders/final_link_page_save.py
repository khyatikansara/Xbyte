import json
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class FinalLinkPageSaveSpider(scrapy.Spider):
    name = 'final_link_page_save'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        # self.city_list = ["Aurangabad", "Rajkot", "Dubai", "Madurai", "Thrissur", "Allahabad", "Nashik", "Ooty",
        #                   "Jabalpur", "Patiala", "Gwalior", "Jamshedpur", "Guntur", "Jhansi", "Jalandhar", "Raipur",
        #                   "Ajmer", "Kota", "Gorakhpur", "Meerut", "Vellore", "Salem", "Trichy", "Siliguri", "Varanasi",
        #                   "Udaipur", "Cuttack", "Trivandrum", "Jodhpur", "Puducherry", "Ranchi", "Nasik", "Bareilly"]
        # for city in self.city_list:
        pipe.cursor.execute(f'select * from 2909_extract_food_menu_data_from_zomato.finallink_2020_12_21 where status="pending"')
        # pipe.cursor.execute(f'select * from 2909_extract_food_menu_data_from_zomato.finallink_city_2020_12_21 where status="pending" and city="{city}" limit 0, 280')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                url = row[1]
                res_id = row[2]
                yield scrapy.Request(url=url, callback=self.get_data, dont_filter=True, meta={'res_id': res_id})
            except Exception as e:
                print(e)

    def get_data(self, response):
        try:
            Restaurant_Id = response.meta['res_id']
            if Restaurant_Id == None:
                Restaurant_Id = re.findall(r'\\\"resId\\\":(.*?),',response.text)[0]
            path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Data\\{Restaurant_Id}.html"
            pipe.page_save(self, path, response.text)
            print("page save Done")
            try:
                path = path.replace('\\','\\\\')
                pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.finallink_2020_12_21 set status="Done",html="{path}" where Restaurant_Id="{Restaurant_Id}"')
                pipe.con.commit()
                print("update done")
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

# execute("scrapy crawl final_link_page_save -a start=0 -a end=707532".split())
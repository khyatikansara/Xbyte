import os
import scrapy
from scrapy.cmdline import execute
from zomato.pipelines import ZomatoPipeline as pipe


class MainLinkPageSaveSpider(scrapy.Spider):
    name = 'main_link_page_save'
    allowed_domains = []
    # start_urls = ['https://www.zomato.com/delivery-cities']
    start,end = '',''

    def start_requests(self):
        city = ['Akola','Aligarh','Ambala','Amravati','Anantapur','Baddi','Bahadurgarh','Barabanki','Baramati','Bardhaman','Bareilly','Barnala','Bathinda','Belgaum','Bellary','Bhadrachalam','Bhagalpur','Bharuch','Bhiwadi','Bhuj','Bikaner','Bilaspur','Bokaro','Bulandshahr','Chandrapur','Chhindwara','Damoh','Darbhanga','Dausa','Davanagere','Deoghar','Dhanbad','Dharwad','Dhule','Durg Bhilai','Eluru','Erode','Faridkot','FatehgarhSahib','Fatehpur','Firozabad','Gandhidham','Gaya','Haldwani','Hampi-Hospet','Hazaribagh','Himatnagar','Hisar','Hoshangabad','Hoshiarpur','Hosur','Hubli','Jagdalpur','Jalgaon','Jind','Jorhat','Kadapa','Kaithal','Kakinada','Kanchipuram','Karimnagar','Karnal','Karur','Khammam','Kurnool','Latur','Mandsaur','Mathura','Mehsana','Modinagar','Moga','Moradabad','Muzaffarnagar','Nadiad','Nagercoil','Nanded','Nellore','Ongole','Palakkad','Palwal','Panipat','Phagwara','Rajahmundry','Ratlam','Rewa','Rewari','Rohtak','Roorkee','Ropar','Saharanpur','Sangli','Satara','Satna','Shimoga','Sikar','Solapur','Sonipat','Sri Ganganagar','Tanjore','Tanuku','Tarn Taran','Thiruvalla','Tirunelveli','Tiruppur','Tuni','Ujjain','Vapi','Vizianagaram','Warangal','Yamuna Nagar']
        try:
            pipe.cursor.execute(f'Select * from 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 where status="pending" and Type="Next page"')
            pipe.con.commit()
            product_results = pipe.cursor.fetchall()
            for row_p in product_results:
                Id = row_p[0]
                location_link = row_p[1]
                loc_path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Link\\{Id}.html"
                # if os.path.exists(loc_path):
                #     Loc_Link = 'file://' + loc_path.replace('\\', '/')
                # else:
                Loc_Link = location_link
                yield scrapy.Request(url=Loc_Link, callback=self.parse, dont_filter=True, meta={'loc_path': loc_path, 'source_link': location_link, 'Id':Id})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            loc_path = response.meta['loc_path']
            Id = response.meta['Id']
            if not 'file://' in response.url:
                pipe.page_save(self, loc_path, response.text)
                print("page save done")

            try:
                loc_path = loc_path.replace('\\','\\\\')
                pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 set html="{loc_path}",status="Done" where Id="{Id}"')
                pipe.con.commit()
                print("update done")
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

# execute("scrapy crawl main_link_page_save".split())

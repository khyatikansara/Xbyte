# import pandas as pd
#
# def city_data():
#     unique_list = []
#     duplicate = []
#     try:
#         file = open("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Main\\Mumbai.html", 'r', encoding='utf-8')
#         file_open = file.read()
#         file.close()
#
#
#
#     except Exception as e:
#         print(e)
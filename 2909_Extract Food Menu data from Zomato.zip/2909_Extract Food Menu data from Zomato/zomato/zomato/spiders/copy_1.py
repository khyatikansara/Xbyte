# import shutil
# from os import listdir
# from os.path import isfile, join
# import pandas as pd
#
#
# def copy_page():
#     try:
#         df = pd.read_csv("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\zomato_final_city.csv")
#         df = df.fillna('')
#         final_dict = {}
#         list = []
#         city_less = []
#         city_list = ["Aurangabad", "Rajkot", "Dubai", "Madurai", "Thrissur", "Allahabad", "Nashik", "Ooty",
#                      "Jabalpur", "Patiala", "Gwalior", "Jamshedpur", "Guntur", "Jhansi", "Jalandhar", "Raipur",
#                      "Ajmer", "Kota", "Gorakhpur", "Meerut", "Vellore", "Salem", "Trichy", "Siliguri", "Varanasi",
#                      "Udaipur", "Cuttack", "Trivandrum", "Jodhpur", "Puducherry", "Ranchi", "Nasik"]
#         for city_i in city_list:
#             print(city_i)
#             res_id_list = []
#             for index, row in df.iterrows():
#                 city = row['city']
#                 Id = row['Id']
#                 URL = row['URL']
#                 html = row['html']
#                 status = row['status']
#                 if city_i == city:
#                     res_id = row['Restaurant_Id']
#         mypath='D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Data\\'
#         onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
#         for files in onlyfiles:
#             print(files)
#             dst = 'D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\32_Data\\'
#             first = files.split('_')
#             new_name = f'Walmart_{first[0]}_img{first[1]}'
#             shutil.copyfile(mypath+files,dst+new_name)
#             print("Image copy")
#     except Exception as e:
#         print(e)
# # copy_page()
import json
import os
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
import time
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver


class LoadLinkSpider(scrapy.Spider):
    name = 'load_link'
    allowed_domains = []
    # start_urls = ['https://www.zomato.com/delivery-cities']
    start,end = '',''

    def start_requests(self):
        try:
            options = webdriver.ChromeOptions()
            driver = webdriver.Chrome(chrome_options=options)  # Optional argument, if not specified will search path.
            driver.maximize_window()
            pipe.cursor.execute(f'Select * from 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 where status="Done" and Type="Load more"')
            pipe.con.commit()
            product_results = pipe.cursor.fetchall()
            for row_p in product_results:
                res_list,res_count = 0,0
                Id = row_p[0]
                URL = row_p[1]
                loc_path = row_p[3]
                driver.get(URL)
                time.sleep(5)
                while True:
                    try:
                        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        time.sleep(5)
                        res_count = driver.find_elements_by_xpath('//a/p[1]')
                        res_list = len(res_count)
                        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        time.sleep(5)
                        res_count = driver.find_elements_by_xpath('//a/p[1]')
                    except Exception as e:
                        print(e)
                    if res_list == len(res_count):
                        break
                pipe.page_save(self,loc_path,driver.page_source)
                print(f"page save done {Id}")
            print("Done===========")
        except Exception as e:
            print(e)


# execute("scrapy crawl load_link".split())

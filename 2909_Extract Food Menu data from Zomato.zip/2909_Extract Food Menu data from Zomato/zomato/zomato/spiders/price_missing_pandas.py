import hashlib
import json
import os
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
from scrapy.http import HtmlResponse
from zomato import db_config as dbc


class DataSpider(scrapy.Spider):
    name = 'data_price_iteem'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        df = pd.read_excel("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Files\\Filesupdated\\Book1.xlsx")
        # df = pd.read_excel("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Files\\Filesupdated\\Zomato_2021_01_08_1.xlsx")
        df = df.fillna('')
        list = []
        for index, row in df.iterrows():
            Id = row['Id']
            Restaurant_Id = row['Restaurant Id']
            Restaurant_URL = row['Restaurant URL']
            Restaurant_Name = row['Restaurant Name']
            streetAddress = row['streetAddress']
            addressLocality = row['addressLocality']
            addressRegion = row['addressRegion']
            addressCountry = row['addressCountry']
            Latitude = row['Latitude']
            Longitude = row['Longitude']
            Phone = row['Phone']
            Type_of_Restaurants = row['Type of Restaurants']
            Cuisines = row['Cuisines']
            Top_Dishes_People_Order = row['Top Dishes People Order']
            People_Liked = row['People Liked']
            Average_Cost = row['Average Cost']
            Payment_Info = row['Payment Info']
            More_Info = row['More Info']
            Hours_of_Operation = row['Hours of Operation']
            Reviews = row['Reviews']
            Star_Ratings = row['Star Ratings']
            MenuCategory = row['MenuCategory']
            MenuSubCategory = row['MenuSubCategory']
            MenuItem = row['MenuItem']
            MenuItemType = row['MenuItemType']
            MenuItemPrice = row['MenuItemPrice']
            MenuItemDescription = row['MenuItemDescription']
            MenuItemStarRatings = row['MenuItemStarRatings']
            MenuItemReviewCount = row['MenuItemReviewCount']
            MenuItemTag = row['MenuItemTag']
            page_html = row['page html']
            order_html = row['order html']
            review_html = row['review html']
            status = row['status']
            Hash_id = row['Hash id']

            file = pipe.page_read(self, page_html)
            response = html.fromstring(file)
            try:
                if "’" in MenuItem:
                    MenuItem = MenuItem.replace("’","'")
                MenuItemPrice = response.xpath(f'''//h4[text()="{MenuItem}"]/..//*[contains(@class,"sc-17hyc2s-1")]/text()''')[0].replace('₹','').strip()
            except Exception as e:
                print(e)
                MenuItemPrice = ''
            # if MenuItemPrice=='':
            #     print("blank")
            list.append([Id,Restaurant_Id,Restaurant_URL,Restaurant_Name,streetAddress,addressLocality,addressRegion,addressCountry,Latitude,Longitude,Phone,Type_of_Restaurants,Cuisines,Top_Dishes_People_Order,People_Liked,Average_Cost,Payment_Info,More_Info,Hours_of_Operation,Reviews,Star_Ratings,MenuCategory,MenuSubCategory,MenuItem,MenuItemType,MenuItemPrice,MenuItemDescription,MenuItemStarRatings,MenuItemReviewCount,MenuItemTag,page_html,order_html,review_html,status,Hash_id])

            gh = pd.DataFrame(list, columns=['Id','Restaurant Id','Restaurant URL','Restaurant Name','streetAddress','addressLocality','addressRegion','addressCountry','Latitude','Longitude','Phone','Type of Restaurants','Cuisines','Top Dishes People Order','People Liked','Average Cost','Payment Info','More Info','Hours of Operation','Reviews','Star Ratings','MenuCategory','MenuSubCategory','MenuItem','MenuItemType','MenuItemPrice','MenuItemDescription','MenuItemStarRatings','MenuItemReviewCount','MenuItemTag','page html','order html','review html','status','Hash id'])
            gh.to_excel(f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Files\\Filesupdated\\done\\Zomato_2021_01_12_1.xlsx", index=False)
            print(f"File generated for zomato_link_city_180_list.csv")

        # pipe.cursor.execute(f'select * from {dbc.database}.{dbc.data} where Id>"{self.start}" and Id<"{self.end}"')
        # results = pipe.cursor.fetchall()
        # for row in results:
        #     try:
        #         Id = row[0]
        #         URL = row[2]
        #         Restaurant_Id = row[1]
        #         html_path = row[-4]
        #         MenuItem = row[-12]
        #         try:
        #             file = pipe.page_read(self, html_path)
        #             response = html.fromstring(file)
        #
        #             try:
        #                 # m = f'''//h4[text()="{MenuItem}"]/..//*[contains(@class,"sc-17hyc2s-1")]/text()'''
        #                 # MenuItemPrice = '179'
        #                 if "’" in MenuItem:
        #                     MenuItem = MenuItem.replace("’","'")
        #                 MenuItemPrice = response.xpath(f'''//h4[text()="{MenuItem}"]/..//*[contains(@class,"sc-17hyc2s-1")]/text()''')[0].replace('₹','').strip()
        #             except Exception as e:
        #                 print(e)
        #                 MenuItemPrice = ''
        #
        #             try:
        #                 pipe.cursor.execute(f'update {dbc.database}.{dbc.data} set MenuItemPrice="{MenuItemPrice}" where Id="{Id}"')
        #                 pipe.con.commit()
        #                 print(f"update done1 {Id}")
        #             except Exception as e:
        #                 print(e)
        #
        #         except Exception as e:
        #             print(e)
        #     except Exception as e:
        #         print(e)



execute("scrapy crawl data_price_iteem".split())
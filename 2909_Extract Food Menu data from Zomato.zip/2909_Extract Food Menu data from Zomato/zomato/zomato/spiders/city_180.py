from os import listdir
from os.path import isfile, join

import pandas as pd
import pymysql
from unidecode import unidecode
from zomato import db_config as dbc
from zomato.pipelines import ZomatoPipeline as pipe

def city_data():
    try:
        df = pd.read_csv("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\zomato_city_180.csv")
        df = df.fillna('')
        final_dict = {}
        list = []
        city_less = []
        city_list1 = ["Aurangabad", "Rajkot", "Dubai", "Madurai", "Thrissur", "Allahabad", "Nashik", "Ooty",
                      "Jabalpur", "Patiala", "Gwalior", "Jamshedpur", "Guntur", "Jhansi", "Jalandhar", "Raipur",
                      "Ajmer", "Kota", "Gorakhpur", "Meerut", "Vellore", "Salem", "Trichy", "Siliguri", "Varanasi",
                      "Udaipur", "Cuttack", "Trivandrum", "Jodhpur", "Puducherry", "Ranchi"]

        city_list2 = ["New Delhi","Mumbai","Bengaluru","Pune","Hyderabad","Kochi","Vadodara","Nanded","Warangal","Jorhat","Hazaribagh","Kurnool","Bhiwadi","Bhopal","Visakhapatnam","Nagpur","Phagwara","Amritsar","Kolkata","Palakkad","Solapur","Chennai","Aligarh","Haldwani","Dehradun","Surat","Agra","Kanpur","Tirunelveli","Modinagar","Karnal","Anantapur","Firozabad"]

        city_list3 = ["Jaipur","Nagercoil","Indore","Bhubaneswar","Yamuna Nagar","Coimbatore","Chandigarh","Durg Bhilai","Vizianagaram","Chhindwara","Rewari","Bulandshahr","Bahadurgarh","Tanuku","FatehgarhSahib","Ropar","Tiruppur","Bathinda","Kakinada","Jagdalpur","Himatnagar","Eluru","Barabanki","Ludhiana","Vapi","Rewa","Lucknow","Erode","Moga","Thiruvalla","Ahmedabad","Satna"]

        city_list4 = ["Vijayawada","Jalgaon","Tuni","Fatehpur","Ratlam","Shimoga","Mysore","Mangalore","Ongole","Darbhanga","Roorkee","Kaithal","Barnala","Mathura","Damoh","Belgaum","Kadapa","Bharuch","Akola","Muzaffarnagar","Hisar","Amravati","Palwal","Baddi","Moradabad","Dausa","Nellore","Bokaro","Goa","Kanchipuram","Ujjain","Bareilly"]

        city_list5 = ["Saharanpur","Tanjore","Nadiad","Deoghar","Ambala","Bhagalpur","Karimnagar","Sonipat","Hoshiarpur","Bhuj","Mandsaur","Hampi-Hospet","Gaya","Bardhaman","Hoshangabad","Sri Ganganagar","Khammam","Karur","Bikaner","Guwahati","Patna","Sangli","Baramati","Bhadrachalam","Hubli","Hosur","Latur","Satara","Dhanbad","Davanagere","Bellary","Panipat"]

        city_list6 = ["Rajahmundry","Gandhidham","Sikar","Dharwad","Tarn Taran","Chandrapur","Mehsana","Bilaspur","Jind","Rohtak","Dhule","Faridkot"]

        city_list = ["Aurangabad", "Rajkot", "Dubai", "Madurai", "Thrissur", "Allahabad", "Nashik", "Ooty", "Jabalpur", "Patiala", "Gwalior", "Jamshedpur", "Guntur", "Jhansi", "Jalandhar", "Raipur", "Ajmer", "Kota", "Gorakhpur", "Meerut", "Vellore", "Salem", "Trichy", "Siliguri", "Varanasi", "Udaipur", "Cuttack", "Trivandrum", "Jodhpur", "Puducherry", "Ranchi","New Delhi","Mumbai","Bengaluru","Pune","Hyderabad","Kochi","Vadodara","Nanded","Warangal","Jorhat","Hazaribagh","Kurnool","Bhiwadi","Bhopal","Visakhapatnam","Nagpur","Phagwara","Amritsar","Kolkata","Palakkad","Solapur","Chennai","Aligarh","Haldwani","Dehradun","Surat","Agra","Kanpur","Tirunelveli","Modinagar","Karnal","Anantapur","Firozabad", "Jaipur","Nagercoil","Indore","Bhubaneswar","Yamuna Nagar","Coimbatore","Chandigarh","Durg Bhilai","Vizianagaram","Chhindwara","Rewari","Bulandshahr","Bahadurgarh","Tanuku","FatehgarhSahib","Ropar","Tiruppur","Bathinda","Kakinada","Jagdalpur","Himatnagar","Eluru","Barabanki","Ludhiana","Vapi","Rewa","Lucknow","Erode","Moga","Thiruvalla","Ahmedabad","Satna", "wada","Jalgaon","Tuni","Fatehpur","Ratlam","Shimoga","Mysore","Mangalore","Ongole","Darbhanga","Roorkee","Kaithal","Barnala","Mathura","Damoh","Belgaum","Kadapa","Bharuch","Akola","Muzaffarnagar","Hisar","Amravati","Palwal","Baddi","Moradabad","Dausa","Nellore","Bokaro","Goa","Kanchipuram","Ujjain","Bareilly", "Saharanpur","Tanjore","Nadiad","Deoghar","Ambala","Bhagalpur","Karimnagar","Sonipat","Hoshiarpur","Bhuj","Mandsaur","Hampi-Hospet","Gaya","Bardhaman","Hoshangabad","Sri Ganganagar","Khammam","Karur","Bikaner","Guwahati","Patna","Sangli","Baramati","Bhadrachalam","Hubli","Hosur","Latur","Satara","Dhanbad","Davanagere","Bellary","Panipat", "Rajahmundry","Gandhidham","Sikar","Dharwad","Tarn Taran","Chandrapur","Mehsana","Bilaspur","Jind","Rohtak","Dhule","Faridkot"]
        for city_i in city_list2:
            print(city_i)
            res_id_list = []
            for index, row in df.iterrows():
                city = row['city']
                Id = row['Id']
                URL = row['URL']
                html = row['html']
                status = row['status']
                if city_i == city:
                    res_id = row['Restaurant_Id']
                    res_id_list.append(res_id)
        # print(f"{city_i}:{len(res_id_list)}")
        # print("")
                    if len(res_id_list) == 180:
                        break
                    else:
                        final_dict[city] = res_id_list
                        list.append([Id,URL,res_id,city,html,status])
            # if len(res_id_list) != 180:
            count = len(res_id_list)
            city_less.append([city_i,count])

        gh = pd.DataFrame(list, columns=['Id', 'URL', 'Restaurant_Id','city','html','status'])
        gh.to_csv(f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\zomato_link_city_180_list.csv", index=False)
        print(f"File generated for zomato_link_city_180_list.csv")

        gh1 = pd.DataFrame(city_less, columns=['city', 'count'])
        gh1.to_csv(f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\zomato_city_count.csv", index=False)
        print(f"File generated for zomato_city_count.csv")

    except Exception as e:
        print(e)

# city_data()

def check_available_res():
    try:
        mypath = 'D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Main\\'
        onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
        list = []
        ava = ''
        for files in onlyfiles:
            print(files)
            file = open(mypath+files, 'r', encoding='utf-8')
            file_open = file.read()
            file.close()
            city = files.split('.')[0]
            if 'Popular localities' in file_open:
                ava = 'Available'
            if 'How Zomato works' in file_open:
                ava = 'Not Available'
            list.append([city,ava])
            
        gh = pd.DataFrame(list, columns=['city', 'status'])
        gh.to_excel(f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\city_status1.xlsx", index=True)
        print(f"File generated for city_status.xlsx")
    except Exception as e:
        print(e)
        
# check_available_res()
    


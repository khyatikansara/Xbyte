import json
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class FinalLinkSpider(scrapy.Spider):
    name = 'final_link'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        pipe.cursor.execute(f'select * from 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 where status="Done" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                Id = row[0]
                main_URL = row[1]
                path = row[3]
                Type = row[4]
                file = pipe.page_read(self, path)
                response1 = html.fromstring(file)
                if Type == "Load more":
                    try:
                        json_xpath = re.findall(r'JSON.parse\("(.*?)\<\/script\>',file,re.DOTALL)[0].replace('\\"','"').replace('")','').replace('\\\\"','\\"').strip()
                        data_json = json.loads(json_xpath)
                        ava = 'yes'
                    except Exception as e:
                        print(e)
                        ava = 'no'
                    if ava == 'yes':
                        links = response1.xpath('//a[contains(@href,"/akola/")][1]/@href')
                        for link in links:
                            if 'https://www.zomato.com' not in link:
                                link = 'https://www.zomato.com'+link
                            try:
                                item = ZomatoItem()
                                item['URL'] = link.replace('/order','')
                                # item['Restaurant_Id'] = Restaurant_Id
                                item['table'] = "finallink_2020_12_21"
                                yield item
                            except Exception as e:
                                print(e)
                        # search = main_URL.replace('https://www.zomato.com','')
                        # for res in data_json['pages']['search'][search]['sections']['SECTION_SEARCH_RESULT']:
                        #     try:Restaurant_Id = res['info']['resId']
                        #     except:Restaurant_Id = ''
                        #     if Restaurant_Id != '':
                        #         try:res_link = res['order']['actionInfo']['clickUrl'].replace('/order','')
                        #         except:res_link = res['cardAction']['clickUrl'].replace('/order','')
                        #         if 'https://www.zomato.com' not in res_link:
                        #             URL = 'https://www.zomato.com'+res_link
                        #         else:
                        #             URL = res_link
                        #         try:
                        #             item = ZomatoItem()
                        #             item['URL'] = URL
                        #             item['Restaurant_Id'] = Restaurant_Id
                        #             item['table'] = "finallink_2020_12_21"
                        #             yield item
                        #         except Exception as e:
                        #             print(e)

                    else:
                        #----tmp code
                        if response1.xpath('//a[@aria-label="Next Page"]/@href'):
                            try:
                                pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 set Type="Next page" where Id="{Id}"')
                                pipe.con.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
                        print('stop')

                else:
                    selectors = response1.xpath('//*[@data-result-type="ResCard_Name"]')
                    if selectors != []:
                        ava = 'yes'
                        for selector in selectors:
                            try:
                                URL = unidecode(selector.xpath('./@href')[0])
                                Restaurant_Id = selector.xpath('./../../../../../../../@data-res_id')[0].strip()
                            except Exception as e:
                                print(e)
                            try:
                                item = ZomatoItem()
                                item['URL'] = URL
                                item['Restaurant_Id'] = Restaurant_Id
                                item['table'] = "finallink_2020_12_21"
                                yield item
                            except Exception as e:
                                print(e)
                    else:
                        ava = 'no'
                        try:
                            pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 set Type="Load more" where Id="{Id}"')
                            pipe.con.commit()
                            print("update done")
                        except Exception as e:
                            print(e)
                if ava == 'yes':
                    try:
                        pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 set status="Done1" where Id="{Id}"')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)

# execute("scrapy crawl final_link -a start=0 -a end=50330".split())
import json
import os
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class NextLinkSpider(scrapy.Spider):
    name = 'next_link'
    allowed_domains = []
    # start_urls = ['https://www.zomato.com/delivery-cities']
    start,end = '',''

    def start_requests(self):
        try:
            pipe.cursor.execute(f'Select * from 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 where status="Done"')
            pipe.con.commit()
            product_results = pipe.cursor.fetchall()
            for row_p in product_results:
                Id = row_p[0]
                URL = row_p[1]
                city = row_p[2]
                location_link = row_p[1]
                loc_path = row_p[3]
                type = row_p[4]
                if type == 'Next page':
                    file = pipe.page_read(self, loc_path)
                    response1 = html.fromstring(file)
                    if response1.xpath('//a[@aria-label="Next Page"]/@href'):
                        next_url = response1.xpath('//a[@aria-label="Next Page"]/@href')[0]
                        next_link = f"https://www.zomato.com{next_url}"
                        yield scrapy.Request(url=next_link, callback=self.get_links, dont_filter=True, meta={'source_link':next_link,'city':city,'type':type})
        except Exception as e:
            print(e)

    def get_links(self, response):
        try:
            source_link = response.meta['source_link']
            city = response.meta['city']
            type = response.meta['type']
            try:
                item = ZomatoItem()
                item['URL'] = source_link
                item['city'] = city
                # item['html'] = loc_path.replace("\\", "\\\\")
                item['Type'] = type
                item['table'] = "first_level_link_2020_12_21"
                yield item
            except Exception as e:
                print(e)

            if response.xpath('//a[@aria-label="Next Page"]/@href'):
                next_url = response.xpath('//a[@aria-label="Next Page"]/@href').extract_first()
                next_link = f"https://www.zomato.com{next_url}"
                yield scrapy.Request(url=next_link, callback=self.get_links, dont_filter=True, meta={'source_link': next_link, 'city': city, 'type': type})
        except Exception as e:
            print(e)


# execute("scrapy crawl next_link".split())

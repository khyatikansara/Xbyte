import os
import pandas as pd
import scrapy
from lxml import html
from scrapy.cmdline import execute
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe


class MainLinkSpider(scrapy.Spider):
    name = 'main_link'
    allowed_domains = []
    start_urls = ['https://www.zomato.com/delivery-cities']
    start,end = '',''

    # def parse(self,response):
    #     blank_city = ['Akola', 'Aligarh', 'Ambala', 'Amravati', 'Anantapur', 'Baddi', 'Bahadurgarh', 'Barabanki', 'Baramati',
    #             'Bardhaman', 'Bareilly', 'Barnala', 'Bathinda', 'Belgaum', 'Bellary', 'Bhadrachalam', 'Bhagalpur',
    #             'Bharuch', 'Bhiwadi', 'Bhuj', 'Bikaner', 'Bilaspur', 'Bokaro', 'Bulandshahr', 'Chandrapur',
    #             'Chhindwara', 'Damoh', 'Darbhanga', 'Dausa', 'Davanagere', 'Deoghar', 'Dhanbad', 'Dharwad', 'Dhule',
    #             'Durg Bhilai', 'Eluru', 'Erode', 'Faridkot', 'FatehgarhSahib', 'Fatehpur', 'Firozabad', 'Gandhidham',
    #             'Gaya', 'Haldwani', 'Hampi-Hospet', 'Hazaribagh', 'Himatnagar', 'Hisar', 'Hoshangabad', 'Hoshiarpur',
    #             'Hosur', 'Hubli', 'Jagdalpur', 'Jalgaon', 'Jind', 'Jorhat', 'Kadapa', 'Kaithal', 'Kakinada',
    #             'Kanchipuram', 'Karimnagar', 'Karnal', 'Karur', 'Khammam', 'Kurnool', 'Latur', 'Mandsaur', 'Mathura',
    #             'Mehsana', 'Modinagar', 'Moga', 'Moradabad', 'Muzaffarnagar', 'Nadiad', 'Nagercoil', 'Nanded',
    #             'Nellore', 'Ongole', 'Palakkad', 'Palwal', 'Panipat', 'Phagwara', 'Rajahmundry', 'Ratlam', 'Rewa',
    #             'Rewari', 'Rohtak', 'Roorkee', 'Ropar', 'Saharanpur', 'Sangli', 'Satara', 'Satna', 'Shimoga', 'Sikar',
    #             'Solapur', 'Sonipat', 'Sri Ganganagar', 'Tanjore', 'Tanuku', 'Tarn Taran', 'Thiruvalla', 'Tirunelveli',
    #             'Tiruppur', 'Tuni', 'Ujjain', 'Vapi', 'Vizianagaram', 'Warangal', 'Yamuna Nagar']
    #     try:
    #         all_city_from_sheet = []
    #         self.city_main_links = {'Dubai':'https://www.zomato.com/dubai'}
    #         df = pd.read_excel("D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\restaurant_cities.xlsx")
    #         df = df.fillna('')
    #         for index, row in df.iterrows():
    #             city = row['City'].lower()
    #             all_city_from_sheet.append(city)
    #
    #         cities = response.xpath('//section/div/div/a')
    #         for city in cities:
    #             city_name_tmp = city.xpath('./text()').extract_first().strip()
    #             city_name_tmp1 = city_name_tmp.lower().strip()
    #             city_link_tmp = city.xpath('./@href').extract_first()
    #             if city_name_tmp1 in all_city_from_sheet:
    #                 self.city_main_links[city_name_tmp] = city_link_tmp
    #
    #         for city_name,city_link in self.city_main_links.items():
    #             if city_name in blank_city:
    #                 file_path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Main\\{city_name}.html"
    #                 if os.path.exists(file_path):
    #                     Link = 'file://' + file_path.replace('\\', '/')
    #                 else:
    #                     Link = city_link+'restaurants'
    #                 yield scrapy.Request(url=Link, callback=self.parse_link, dont_filter=True, meta={'path':file_path,'Link':city_link+'restaurants'})
    #     except Exception as e:
    #         print(e)
    #
    # def parse_link(self, response):
    #     try:
    #         path = response.meta['path']
    #         if not 'file://' in response.url:
    #             pipe.page_save(self,path,response.text)
    #             print("page save done")
    #         file = pipe.page_read(self,path)
    #         response1 = html.fromstring(file)
    #         location_links = response1.xpath('//div[@class="title"]/following-sibling::div//a/@href')
    #         if location_links == []:
    #             Loc_Link = response.meta['Link']
    #             # loc_path = ''
    #             try:
    #                 item = ZomatoItem()
    #                 item['URL'] = Loc_Link
    #                 item['city'] = Loc_Link.split('/')[3]
    #                 # item['html'] = loc_path.replace("\\", "\\\\")
    #                 # item['Type'] = type
    #                 item['table'] = "first_level_link_2020_12_21"
    #                 yield item
    #             except Exception as e:
    #                 print(e)
    #         else:
    #             print("")
    #             # loc_name = Loc_Link.split('/')[-1]
    #             # loc_path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Link\\{loc_name}.html"
    #             # if os.path.exists(loc_path):
    #             #     Loc_Link = 'file://' + loc_path.replace('\\', '/')
    #             # else:
    #             #     Loc_Link = Loc_Link
    #             # yield scrapy.Request(url=Loc_Link, callback=self.get_links, dont_filter=True, meta={'loc_path': loc_path, 'source_link': Loc_Link})
    #         # if location_links == []:
    #         #     print("stop")
    #     #     for location_link in location_links:
    #     #         loc_name = location_link.split('/')[-1]
    #     #         loc_path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Link\\{loc_name}.html"
    #     #         if os.path.exists(loc_path):
    #     #             Loc_Link = 'file://' + loc_path.replace('\\', '/')
    #     #         else:
    #     #             Loc_Link = location_link
    #     #
    #     #         yield scrapy.Request(url=Loc_Link, callback=self.get_links, dont_filter=True, meta={'loc_path': loc_path,'source_link':location_link})
    #     except Exception as e:
    #         print(e)

    def parse(self, response):
        pipe.cursor.execute(f'Select * from 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 where status="Done" and Type="Load more"')
        pipe.con.commit()
        product_results = pipe.cursor.fetchall()
        for row_p in product_results:
            Id = row_p[0]
            Type = row_p[4]
            loc_path = row_p[3]
            try:
                # loc_path = response.meta['loc_path']
                # source_link = response.meta['source_link']
                # if not 'file://' in response.url:
                #     pipe.page_save(self, loc_path, response.text)
                #     print("page save done")
                file = pipe.page_read(self, loc_path)
                response1 = html.fromstring(file)
                if response1.xpath('//a[@aria-label="Next Page"]/@href'):
                    type = 'Next page'
                else:
                    type = 'Load more'
                try:
                    pipe.cursor.execute(f'update 2909_extract_food_menu_data_from_zomato.first_level_link_2020_12_21 set Type="{type}" where Id="{Id}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
                # try:
                #     item = ZomatoItem()
                #     item['URL'] = source_link
                #     item['city'] = source_link.split('/')[3]
                #     item['html'] = loc_path.replace("\\", "\\\\")
                #     item['Type'] = type
                #     item['table'] = "first_level_link_2020_12_21"
                #     yield item
                # except Exception as e:
                #     print(e)
            except Exception as e:
                print(e)

# execute("scrapy crawl main_link".split())

import json
import os
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from zomato.pipelines import ZomatoPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse
from zomato import db_config as dbc


class FinalLinkCitySpider(scrapy.Spider):
    name = 'final_link_city'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        pipe.cursor.execute(f'select * from 2909_extract_food_menu_data_from_zomato.finallink_2020_12_21 limit {self.start},{self.end}')
        # pipe.cursor.execute(f'select * from 2909_extract_food_menu_data_from_zomato.finallink_2020_12_21 where status!="not available" and status="Done" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            print(row)
            status = row[4]
            if status == 'Done':
                try:
                    URL = row[1]
                    Restaurant_Id = row[2]
                    path = row[3]
                    if not os.path.exists(path):
                        headers = {
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                            'upgrade-insecure-requests': '1',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                            'Cookie': 'zl=en; fbtrack=7a46203ab3e01fd3446003e69255296b; fre=0; rd=1380000; fbcity=51; ltv=51; lty=city; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A25.12819%2C%22lng%22%3A55.22724%2C%22cityId%22%3A51%2C%22ltv%22%3A51%2C%22lty%22%3A%22city%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A8465%2C%22fen%22%3A%22Dubai%22%7D; AWSALBTG=BpkfEN2fyg/UoadxXvltUeO2tpC5t5q+evnUutlJD2pW7E7GQ+qjNmFUjNvCqxEkhVvVgg/lenp8EVCHO/Hk68ylWjX7kKY42iddBv1XbGBgYvrPt8OMysKNaNNofkvnjMWnGiRiHU0N/DhGEtCHzgUC1/A7MaFm7IEqTKOTjlqz; AWSALBTGCORS=BpkfEN2fyg/UoadxXvltUeO2tpC5t5q+evnUutlJD2pW7E7GQ+qjNmFUjNvCqxEkhVvVgg/lenp8EVCHO/Hk68ylWjX7kKY42iddBv1XbGBgYvrPt8OMysKNaNNofkvnjMWnGiRiHU0N/DhGEtCHzgUC1/A7MaFm7IEqTKOTjlqz; PHPSESSID=8ac7af1459a15d47d21a4ee0f110c402; csrf=040c9d1960cacec595be66061d106413'
                        }
                        res = requests.get(url=URL,headers=headers)
                        response = HtmlResponse(url=res.url,body=res.content)
                        path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Data\\{Restaurant_Id}.html"
                        pipe.page_save(self, path, response.text)
                        print("page save Done")
                    file = pipe.page_read(self, path)
                    response = html.fromstring(file)
                    try:
                        addressRegion = re.findall(r'"addressRegion":"(.*?)","', file)[0]
                    except Exception as e:
                        print(e)
                        addressRegion = ''
                    try:
                        order_url = response.xpath('//a[contains(text(),"Order Online")]/@href')[0]
                    except:
                        order_url = ''
                    if order_url != '':
                        order_path = f"D:\\khyati-H\\CRM\\Projects RD\\2909_Extract Food Menu data from Zomato\\Order\\{Restaurant_Id}.html"
                        try:
                            file_o = pipe.page_read(self, order_path)
                        except Exception as e:
                            print(e)
                        if not os.path.exists(order_path) or Restaurant_Id not in file_o:
                            header_o = {
                                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                                'upgrade-insecure-requests': '1',
                                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                                'Cookie': 'PHPSESSID=f221d98b7a357b040f2935c6c18d6944; fre=0; rd=1380000; zl=en; fbtrack=3feb80d0ae55a2cd55b238514a0460a5; _gcl_au=1.1.1444906348.1608535772; _ga=GA1.2.90178738.1608535773; _gid=GA1.2.1157854073.1608535773; G_ENABLED_IDPS=google; _fbp=fb.1.1608535773745.1662307549; dpr=1; __gads=ID=c4d795ab306e73cc:T=1608705368:S=ALNI_MaAXX1j60EGGpMUo8qSyQUz_tnclw; expab=3; lty=city; fbcity=25; ltv=25; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A19.88%2C%22lng%22%3A75.32%2C%22cityId%22%3A25%2C%22ltv%22%3A25%2C%22lty%22%3A%22city%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A14368%2C%22fen%22%3A%22Aurangabad%22%7D; csrf=387fb8d91fc850cf3d50d80a1d1e8ac2; AWSALBTG=4EJFQNwSXyrfy7Zw2dVmcCcqnbe7T5PR/830/SXXO4F6XThbJrnY9AxsYPS5qAfNXqSMCowqGExYTB9d5El4gL/iLVQsLLMccFAcJRUIVoGwR3LN81V9qGClIFCt3KJ2H/oAGHkt+F89c51jIzokP16yEROCWdqair76uTIUXwNU; AWSALBTGCORS=4EJFQNwSXyrfy7Zw2dVmcCcqnbe7T5PR/830/SXXO4F6XThbJrnY9AxsYPS5qAfNXqSMCowqGExYTB9d5El4gL/iLVQsLLMccFAcJRUIVoGwR3LN81V9qGClIFCt3KJ2H/oAGHkt+F89c51jIzokP16yEROCWdqair76uTIUXwNU; zacpol=1'
                            }

                            res_o = requests.get(url=order_url, headers=header_o)
                            response_o = HtmlResponse(url=res_o.url, body=res_o.content)
                            pipe.page_save(self, order_path, response_o.text)
                            print("page save Done")

                        file_o = pipe.page_read(self, order_path)
                        # response_o = html.fromstring(file_o)
                        try:
                            order_json_text = re.findall(r'JSON.parse\("(.*?)"\)\s+?\<\/script\>', file_o, re.DOTALL)[0].replace('\\"', '"').replace('\\\\"', '\\"').strip()
                            order_json = json.loads(order_json_text)
                        except Exception as e:
                            try:
                                order_json_text = re.findall(r'JSON.parse\("(.*?)"\)\s+?\<\/script\>', file_o, re.DOTALL)[0].replace('\\"', '"').replace('\\\\"', '\\"').replace('\\\\\\"', '"').strip()
                                order_json = json.loads(order_json_text)
                            except Exception as e:
                                print("order_json_text" + str(e))
                                order_json = {}
                        if order_json != {}:
                            try:
                                item = ZomatoItem()
                                item['URL'] = URL
                                item['Restaurant_Id'] = Restaurant_Id
                                item['city'] = addressRegion
                                item['html'] = path.replace('\\','\\\\')
                                item['table'] = dbc.final_link_city
                                yield item
                            except Exception as e:
                                print(e)
                    try:
                        pipe.cursor.execute(f'update {dbc.database}.{dbc.final_link} set status="Done1" where Restaurant_Id="{Restaurant_Id}"')
                        pipe.con.commit()
                        print(f"update done----{Restaurant_Id}")
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)

# execute("scrapy crawl final_link_city -a start=0 -a end=10000".split())
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import datetime
import pymysql
from zomato.items import ZomatoItem
from zomato import db_config as dbc


class ZomatoPipeline:
    counter = 0

    try:
        con = pymysql.connect(dbc.host, dbc.username, dbc.password)
        cursor = con.cursor()
        cursor.execute(f'CREATE DATABASE IF NOT EXISTS {dbc.database}')
    except Exception as e:
        print(str(e))
    con = pymysql.connect(dbc.host, dbc.username, dbc.password, dbc.database)
    cursor = con.cursor()

    try:
        create_first_level_link = f"""CREATE TABLE IF NOT EXISTS {dbc.first_level_link} (`Id` int NOT NULL AUTO_INCREMENT,
                                                                                            URL varchar(255),
                                                                                            city varchar(255),
                                                                                            html longtext DEFAULT NULL,
                                                                                            Type longtext DEFAULT NULL,
                                                                                            status varchar(50) DEFAULT 'pending',
                                                                                            UNIQUE KEY (`URL`),
                                                                                            primary key(`Id`));"""
        cursor.execute(create_first_level_link)
    except Exception as e:
        print(e)

    try:
        create_data = f"""CREATE TABLE IF NOT EXISTS {dbc.data} (`Id` int NOT NULL AUTO_INCREMENT,
                                                            Restaurant_Id varchar(255) DEFAULT NULL,
                                                            Restaurant_URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Restaurant_Name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            streetAddress longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            addressLocality longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            addressRegion longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            addressCountry longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Latitude varchar(255),
                                                            Longitude varchar(255),
                                                            Phone longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Type_of_Restaurants longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Cuisines longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Top_Dishes_People_Order longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            People_Liked longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Average_Cost longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Payment_Info longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            More_Info longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Hours_of_Operation longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Reviews longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            Star_Ratings longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuCategory longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuSubCategory longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItem longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemType longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemPrice longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemDescription longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemStarRatings longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemReviewCount longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            MenuItemTag longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                            page_html longtext DEFAULT NULL,
                                                            order_html longtext DEFAULT NULL,
                                                            review_html longtext DEFAULT NULL,
                                                            status longtext DEFAULT NULL,
                                                            Hash_id varchar(250),
                                                            UNIQUE KEY (`Hash_id`),
                                                            primary key(`Id`));"""
        cursor.execute(create_data)
    except Exception as e:
        print(e)

    try:
        create_final_link = f"""CREATE TABLE IF NOT EXISTS {dbc.final_link} (`Id` int NOT NULL AUTO_INCREMENT,
                                                                        URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                        Restaurant_Id varchar(255) DEFAULT NULL,
                                                                        html longtext DEFAULT NULL,
                                                                        status varchar(50) DEFAULT 'pending',
                                                                        UNIQUE KEY (`Restaurant_Id`),
                                                                        primary key(`Id`));"""
        cursor.execute(create_final_link)
    except Exception as e:
        print(e)

    try:
        create_final_link_city = f"""CREATE TABLE IF NOT EXISTS {dbc.final_link_city} (`Id` int NOT NULL AUTO_INCREMENT,
                                                                        URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                        Restaurant_Id varchar(255) DEFAULT NULL,
                                                                        city longtext DEFAULT NULL,
                                                                        html longtext DEFAULT NULL,
                                                                        status varchar(50) DEFAULT 'pending',
                                                                        UNIQUE KEY (`Restaurant_Id`),
                                                                        primary key(`Id`));"""
        cursor.execute(create_final_link_city)
    except Exception as e:
        print(e)



    def process_item(self, item, spider):
        if isinstance(item, ZomatoItem):
            self.counter += 1
            table = item['table']
            del item['table']
            self.insert_item(table, item, self.counter)

    def insert_item(self, table, item, counter):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print('Data Inserted...', counter)
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))

    def page_save(self, path, response):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(response)
            f.close()

    def page_read(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            file_open = file.read()
            file.close()
            return file_open


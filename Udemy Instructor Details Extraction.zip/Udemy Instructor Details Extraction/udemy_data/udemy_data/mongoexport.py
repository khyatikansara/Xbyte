import numpy as np
import pandas as pd
import pymongo


def export(db_name,table_name):
    try:
        con = pymongo.MongoClient('mongodb://localhost:27017/')
        db = con[db_name]
        data = db[table_name]
        query = {}
        cursor = data.find(query)
        df = pd.DataFrame(cursor)
        # df.pop('_id')

        df.index = np.arange(1, len(df) + 1)
        df.index.name = 'Id'

        writer = pd.ExcelWriter("D:\khyati-H\CRM\Project VM\\Udemy Instructor Details Extraction\\files\\udemy_data.xlsx", engine='xlsxwriter',options={'strings_to_urls': False})
        df.to_excel(writer, 'Sheet1')
        writer.save()
        print("File generated")
    except Exception as e:
        print(e)
        print("Excel File not generated")

export('Udemy_Instructor_Details','data')

import os

import pymongo
import scrapy
import json
import hashlib
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from selenium import webdriver
import requests
import re
import time
from udemy_data.items import *
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
# # chrome_options.add_argument("--headless")
chrome_driver = "chromedriver.exe"

import pandas as pd


class datascrp(scrapy.Spider):
    name = 'email'
    allowed_domains = []
    start_urls = ['http://example.com/']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Udemy_Instructor_Details']
        self.Master_link = self.db[f'Master_link']
        self.data = self.db[f'data']

    def parse(self, response):
        driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
        df = pd.read_csv('data111.csv')
        for index, row in df.iterrows():
            Id = str(row['_id'])
            web = str(row['website'])
            path = f"D:\khyati-H\CRM\Project VM\\Udemy Instructor Details Extraction\EMAIL\\{str(Id)}.html"
            if os.path.exists(path):
                print("Already done")
            else:
                # url =str(row['url'])
                # full_addr=str(row['full_addr'])
                # Name=str(row['Name'])

                if web != 'nan':
                    try:
                        if 'http' in web:
                            web=web
                        else:
                            web = f'https://{web}'


                        # driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        # response1 = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
                        # response=requests.request(method="GET",url=web)
                        #
                        # f = open('E:\\AnyEmailextrct\\emailextract\\Pagesave\\' + str(Name) + '.html', 'wb')
                        # print(f)
                        # f.write(response.text.encode('utf-8'))
                        # f.close()
                        # print("page save")
                        # # item= EmailextractItem()
                        # try:
                        #     if 'mailto' in response.text:
                        #         mail=re.findall('mailto:(.*?)"',response.text)[0]
                        #     elif 'email' in response.text:
                        #         mail=re.findall('"email":"(.*?)"',response.text)[0]
                        #     elif 'Email' in response.text:
                        #         mail = re.findall('Email":"(.*?)"',response.text)[0]
                        #     else:
                        #         pass
                        #
                        #     # mail= mail
                        #     # item['Mail']=mail
                        #     # item['Website']=web
                        #     # item['url'] = url
                        #     # item['full_addr'] = full_addr
                        #     # item['Name']=Name
                        #     # item['status']='Done'
                        #     # item['_id']=url
                        #     # yield item
                        # except:
                        #     try:
                        # response = requests.request(method="GET", url=web)

                        driver.get(web)
                        time.sleep(5)
                        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        response1 = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
                        # driver.quit()

                        f = open(path, 'wb')
                        print(f)
                        f.write(response1.text.encode('utf-8'))
                        f.close()
                        print("page save")

                        if 'mailto' in response1.text:
                            mail = re.findall('mailto:(.*?)"', response1.text)[0]
                            print(mail)
                            self.data.update({'_id': int(Id)}, {'$set': {'Email': mail}}, upsert=False)
                            self.data.update({'_id': int(Id)}, {'$set': {'Status': 'Mail Done'}}, upsert=False)
                        elif 'email' in response1.text:
                            mail = re.findall('"email":"(.*?)"', response1.text)[0]
                            print(mail)
                            self.data.update({'_id': int(Id)}, {'$set': {'Email': mail}}, upsert=False)
                            self.data.update({'_id': int(Id)}, {'$set': {'Status': 'Mail Done'}}, upsert=False)
                        elif 'Email' in response1.text:
                            mail = re.findall('Email":"(.*?)"', response1.text)[0]
                            print(mail)
                            self.data.update({'_id': int(Id)}, {'$set': {'Email': mail}}, upsert=False)
                            self.data.update({'_id': int(Id)}, {'$set': {'Status': 'Mail Done'}}, upsert=False)
                        else:
                            pass

                                # item = EmailextractItem()
                                # item['Mail'] = mail
                                # item['url'] = url
                                # item['Website'] = web
                                # item['full_addr'] = full_addr
                                # item['Name'] = Name
                                # item['status'] = 'Done'
                                # item['_id'] = url
                                # yield item

                            # except Exception as e:
                            #     item = EmailextractItem()
                            #     item['Mail'] = ''
                            #     item['url'] = url
                            #     item['Website'] = web
                            #     item['full_addr'] = full_addr
                            #     item['Name'] = Name
                            #     item['status'] = 'Pending'
                            #     item['_id'] = url
                            #     yield item
                            #     print('error', e)

                    except Exception as e:
                        print('url',e)
                #         try:
                #             requests.request(method="GET", url=web)
                #             driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
                #             driver.get(web)
                #             time.sleep(5)
                #             driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                #             response1 = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
                #             driver.quit()
                #
                #             f = open('E:\\AnyEmailextrct\\emailextract\\Pagesave\\' + str(Name) + '.html', 'wb')
                #             print(f)
                #             f.write(response1.text.encode('utf-8'))
                #             f.close()
                #             print("page save")
                #
                #             if 'mailto' in response1.text:
                #                 mail = re.findall('mailto:(.*?)"', response1.text)[0]
                #             elif 'email' in response1.text:
                #                 mail = re.findall('"email":"(.*?)"', response1.text)[0]
                #             elif 'Email' in response1.text:
                #                 mail = re.findall('Email":"(.*?)"',response1.text)[0]
                #             else:
                #                 pass
                #
                #             item = EmailextractItem()
                #             item['Mail'] = mail
                #             item['url'] = url
                #             item['Website']=web
                #             item['full_addr'] = full_addr
                #             item['Name'] = Name
                #             item['status'] = 'Done'
                #             item['_id'] = url
                #             yield item
                #
                #         except Exception as e:
                #             item = EmailextractItem()
                #             item['Mail'] = ''
                #             item['url'] = url
                #             item['Website'] = web
                #             item['full_addr'] = full_addr
                #             item['Name'] = Name
                #             item['status'] = 'Pending'
                #             item['_id'] = url
                #             yield item
                #             print('error',e)
                # else:
                #     item = EmailextractItem()
                #     item['Mail'] = ''
                #     item['url'] = url
                #     item['Website'] = web
                #     item['full_addr'] = full_addr
                #     item['Name'] = Name
                #     item['status'] = 'Pending'
                #     item['_id'] = url
                #     yield item


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute("scrapy crawl email".split())


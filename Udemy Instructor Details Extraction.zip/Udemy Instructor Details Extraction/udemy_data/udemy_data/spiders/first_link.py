# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from udemy_data.items import UdemyDataItem
from udemy_data.mongoexport import export
import pymongo
import pandas as pd
import requests


class FirstLinkSpider(scrapy.Spider):
    name = 'first_link'
    allowed_domains = []
    # start_urls = ['https://www.udemy.com/']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Udemy_Instructor_Details']
        self.Master_link = self.db[f'Master_link']

    def start_requests(self):
        page = 0
        while True:
            page += 1
            print(page)
            try:
                url = f"https://www.udemy.com/api-2.0/discovery-units/all_courses/?p={page}&page_size=16&subcategory=&instructional_level=&lang=&price=&duration=&closed_captions=&subs_filter_type=&category_id=268&source_page=category_page&locale=en_US&currency=inr&navigation_locale=en_US&skip_price=true&sos=pc&fl=cat"

                payload = {}
                headers = {
                    'accept': 'application/json, text/plain, */*',
                    # 'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'cookie': 'ud_cache_brand=INen_US; __udmy_2_v57r=0f09623ecaa24da88b22384b62927392; ud_cache_modern_browser=1; ud_firstvisit=2021-07-06T10:06:12.386226+00:00:1m0hy0:jFjp_ynW9Cxk7EpB6BvpCSvyLYo; ud_cache_version=1; ud_cache_user=""; ud_cache_language=en; ud_cache_marketplace_country=IN; ud_cache_price_country=IN; ud_cache_logged_in=0; seen=1; __cfruid=6fffaf7bcbf54eef4145566bc3f81cbe6bbf43a5-1625565972; __cf_bm=e1172f6dd4867e913be41b0284991f73c05cd2e1-1625565973-1800-AaZk8ykT6R3vK14Kf26NZwoVuyd/VoPyWbI3w9Y/p83POf5AIczg+nEQGepIA4hxgX4JC+3u3NH/NCL0JKDyry+PaHCy770sZtxtpMIec4qZ6Z+XW5divyMgkA4nX40XsqKTkDkt73qz0ptXj0cW/P9kMLLQiv4f1L7gDsIpsn88; EUCookieMessageState=initial; EUCookieMessageShown=true; ud_cache_device=desktop; _gid=GA1.2.1761286783.1625565975; ud_cache_campaign_code=LIBMT70221A; __ssid=b49d18e268f6c5c0dde31c0a2924880; ud_cache_release=33d90ca6309c99d4801e; _gcl_au=1.1.1019072771.1625565981; blisspoint_fpc=216f45ed-a103-4941-8c0c-4660f73a483e; IR_gbd=udemy.com; IR_5420=1625565981594%7C0%7C1625565981594%7C%7C; _rdt_uuid=1625565981603.8ddcbf25-6656-4cca-9c2e-11aa9a2d3388; _fbp=fb.1.1625565981893.857913085; stc111655=tsa:1625565983268.553484741.0061502.1996215581948817.1:20210706103623|env:1%7C20210806100623%7C20210706103623%7C1%7C1014624:20220706100623|uid:1625565983267.1115482088.0138164.111655.1542478452:20220706100623|srchist:1014624%3A1%3A20210806100623:20220706100623; ki_t=1625565983311%3B1625565983311%3B1625565983311%3B1%3B1; ki_r=; _ga=GA1.2.1520066283.1625565975; ud_rule_vars="eJyFzkEKgzAUBNCrSLat5efHGs1ZAuEbExtaGhqjG_HuDa1ddzUMzIPZWKY0uexGs4Y55JgUeOhbFM4SYTNS1w2IomuGFnuUokdlY7wHx1TFNs0eNGeT42JvJifyPlgzxyVZZ1ZKgYaH02WpWUwTPYPV7FwdKLnX4kqOlI8NAvIaZA1txUFBqzhersBR8BOUDl_sQyrq8_aPFbKTjfzZne1vwJZHXg==:1m0i1d:WqQrNFxn4i3CViYIqhMsbq1cMuo"; evi="2@FEdjVGIRWBZJYUwJEHF1QwJFUCZJHBtHBHtHRQBuZQIWXVsgR0hIVwhxVEhJYDEVFl1falpaVkdIYUxDTz86fT1uSlc="; _ga_7YMFEFLR6Q=GS1.1.1625565979.1.1.1625566198.60; eventing_session_id=JWtOugB8Rcyoku9MfYfpSg-1625567998993; __cf_bm=a1fc1503ecb241e732d5a361cf1d5d5d562e9448-1625567272-1800-AY+AbxirKhlGIiw1odzHH6CYilRvqSKfIXq66ebkGBY4VpRy6UhvVM1obb457vZdP5iRKWNTqYTCd7DASHDoOje21MHBegCOZFm43aM3yqYFOxsa5yqdnmh0eTfBhPinvBnucC7yAc+3wW0mm2Y7JYFJ/7DjlJmxyHOcJzVMYPNj; __udmy_2_v57r=0f09623ecaa24da88b22384b62927392; evi="2@PW5gVGFjAUdNNFRISWB0RgNRSGcQSAxHBHJaUEQjZU4MVl1vFkZYVwx1RFAIOWUCFl1bcUkcG0cEdkFDAj86CRRHSldiSnA="; seen=1; ud_cache_brand=INen_US; ud_cache_device=desktop; ud_cache_language=en; ud_cache_logged_in=0; ud_cache_marketplace_country=IN; ud_cache_modern_browser=1; ud_cache_price_country=IN; ud_cache_release=db5261ae36438748472b; ud_cache_user=""; ud_cache_version=1; ud_rule_vars="eJyFzkEKgzAUBNCrSLat5efHGs1ZAuEbExtaGhqjG_HuDa1ddzUMzIPZWKY0uexGs4Y55JgUeOhbFM4SYTNS1w2IomuGFnuUokdlY7wHx1TFNs0eNGeT42JvJifyPlgzxyVZZ1ZKgYaH02WpWUwTPYPV7FwdKLnX4kqOlI8NAvIaZA1txUFBqzhersBR8BOUDl_sQyrq8_aPFbKTjfzZne1vwJZHXg==:1m0iIy:mqQo5kS-w990PtSQxmmiiy34gGA"',
                    'referer': 'https://www.udemy.com/courses/business/',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }

                response = requests.request("GET", url, headers=headers, data=payload)
                json_data = json.loads(response.text)
                if json_data['detail'] == 'Invalid page size':
                    break
                else:
                    path = f"D:\khyati-H\CRM\Project VM\\Udemy Instructor Details Extraction\JSON\\{page}.json"
                    file = open(path, 'w', encoding='utf-8')
                    file.write(response.text)
                    file.close()
                    print(f"page save done {page}")
                    for data in json_data['unit']['items']:
                        for data1 in data['visible_instructors']:
                            Udemy_profile_URL = data1['url']
                            item = UdemyDataItem()
                            item['Udemy_profile_URL'] = f"https://www.udemy.com{Udemy_profile_URL}"
                            item['_id'] = int(hashlib.md5(bytes(Udemy_profile_URL, "utf8")).hexdigest(), 16) % (10 ** 8)
                            try:
                                self.Master_link.insert(item)
                                print("Data inserted....")
                            except Exception as e:
                                print(e)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute('scrapy crawl first_link'.split())

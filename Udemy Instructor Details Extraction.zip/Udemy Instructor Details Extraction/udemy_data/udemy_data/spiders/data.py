# -*- coding: utf-8 -*-
import json
import hashlib
import pymongo
import requests
import re
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from unidecode import unidecode
from udemy_data.items import UdemyDataItem
from scrapy.cmdline import execute


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start, end = '',''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Udemy_Instructor_Details']
        self.Master_link = self.db[f'Master_link']
        self.data = self.db[f'data']

    def start_requests(self):
        try:
            links = self.Master_link.find({'Status': "pending"}, no_cursor_timeout=True)
            print(self.Master_link.find({'Status': "pending"}).count())
            count = 0
            for row in links:
                count+=1
                print(count)
                _id = row['_id']
                url = row['Udemy_profile_URL']

                payload = {}
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'accept-language': 'en-US,en;q=0.9',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Cookie': '__cf_bm=3b0b2ae6163355c2672877c636e4914843f3c0c6-1625577047-1800-Abk70/q42koj4BoX4AztaY/ffnhDociA6A8sOBDzkpuaaKS2hZ0Xu7OOb5Uy05fV6CbM9H+dzJXDmCP63cw4x1t9JvIKSGW1Pzp0RKRuKXwielRU+9HVZzT+LAeX4edZnkuFyOdlE81C3YHux/7fFVjaYo1braelSQ2RAyJOGq7P; __cfruid=9725d86478f910c0c443ab08264c9f7465d12ae5-1625567541; __udmy_2_v57r=0f09623ecaa24da88b22384b62927392; evi="2@Pm1gVxBICRIceQ1QAXBwQhZdEX8dC1hfBnJBQB5gMVYOVhdxSVhIUwxhTAkQNCZWDlJdbFtGWBMceUcPT25lHVAKGX9REVhWD3tEUAg5ZQJVRVBlWllOSRw1VEgHPzoJFG1jV0tg"; seen=1; ud_cache_brand=INen_US; ud_cache_device=desktop; ud_cache_language=en; ud_cache_logged_in=0; ud_cache_marketplace_country=IN; ud_cache_modern_browser=1; ud_cache_price_country=IN; ud_cache_release=f207e04c192d12eed85d; ud_cache_user=""; ud_cache_version=1; ud_firstvisit=2021-07-06T10:32:21.160629+00:00:1m0iNJ:uM4jORDDO7nppH_70DskxlzHP1s; ud_rule_vars=eJyFjUEOgyAQAL9iuLY2y2JBeYsJWREsaVNSQC_Gv9fY9tzjJDOZlRVKkytuNEvIocSkwUMnUThLhM1IbTsgirYZJHaoRIfaxngPjumKrT17UC6mxNneTEnkfbAmxzlZZxZKgYaH63ezZzFN9Ay2Z-cdfEh7dQzNSOWrICCvQdUgKw4apOZ4EapVjTrBzvBpj2Fyr9nlf_EVOAr-ize2vQG94Ede:1m0kqy:YYmCo1If7FqTvTzYhxCdwdx19Xc'
                }

                response = requests.request("GET", url, headers=headers, data=payload)
                if response.status_code == 200:
                    path = f"D:\khyati-H\CRM\Project VM\\Udemy Instructor Details Extraction\HTML\\{_id}.html"
                    file = open(path, 'w', encoding='utf-8')
                    file.write(response.text)
                    file.close()
                    print(f"page save done {count}")
                    response = html.fromstring(response.text)
                    check = response.xpath('//h1/text()')[0]
                    if 'This profile is private.' in check:
                        self.Master_link.update({'_id': _id}, {'$set': {'Status': 'This profile is private.'}}, upsert=False)
                    else:
                        text_json = response.xpath('//div[@data-component-props]/@data-component-props')[0]
                        json_data = json.loads(text_json)
                        item = UdemyDataItem()
                        item['Udemy_profile_URL'] = url
                        item['name'] = json_data['name']
                        item['website'] = json_data['social_links']['personal_website']
                        item['_id'] = int(hashlib.md5(bytes(url, "utf8")).hexdigest(), 16) % (10 ** 8)
                        try:
                            self.data.insert(item)
                            print("Data inserted....")
                            self.Master_link.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                        except Exception as e:
                            print(e)

        except Exception as e:
            print(e)

if __name__ == '__main__':

    execute("scrapy crawl data".split())


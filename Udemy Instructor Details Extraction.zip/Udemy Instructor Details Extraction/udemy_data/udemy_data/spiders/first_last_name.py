# -*- coding: utf-8 -*-
import json
import hashlib
import pymongo
import requests
import re
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from unidecode import unidecode
from udemy_data.items import UdemyDataItem
from scrapy.cmdline import execute


class FirstLastNameSpider(scrapy.Spider):
    name = 'first_last'
    allowed_domains = []
    start, end = '',''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Udemy_Instructor_Details']
        self.Master_link = self.db[f'Master_link']
        self.data = self.db[f'data']

    def start_requests(self):
        try:
            # self.data.update_many({}, {'$set': {'Status': 'pending'}}, upsert=False)
            links = self.data.find({'Status': "pending"}, no_cursor_timeout=True)
            print(self.data.find({'Status': "pending"}).count())
            for row in links:
                _id = row['_id']
                if _id==50821913:
                    print("STOP")
                name = row['name']
                link = row['Udemy_profile_URL']
                split_name = name.split(' ')
                if link == 'https://www.udemy.com/user/acourseyoullactuallyfinish/':
                    first_name = 'David'
                    last_name = 'Kim'
                    self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                    self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                    self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                if len(split_name) == 2:
                    first_name = split_name[0]
                    last_name = split_name[1]
                    self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                    self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                    self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                else:
                    if ' by ' in name:
                        split_name = re.findall(r'by(.*?)$',name)
                        if len(split_name) == 1:
                            split_name = split_name[0].strip().split(' ')
                            first_name = split_name[0]
                            last_name = split_name[1]
                            self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                            self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                            self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                            print("update done")
                    else:
                        if'|' in name:
                            split_name = name.split('|')
                            if '-' in split_name[0]:
                                split_name = split_name[0].split('-')
                                split_name = split_name[0].strip().split(' ')
                                if len(split_name) == 2:
                                    first_name = split_name[0]
                                    last_name = split_name[1]
                                    self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                    self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                    self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                else:
                                    print("STOP")
                            else:
                                if len(split_name) == 2 and 'The' in split_name[0]:
                                    split_name = split_name[1].strip().split(' ')
                                    if len(split_name) == 2:
                                        first_name = split_name[0]
                                        last_name = split_name[1]
                                        self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                else:
                                    if len(split_name) == 4 and '.' in split_name[0]:
                                        split_name = split_name[0].strip().split(' ')
                                        if len(split_name) == 2:
                                            first_name = split_name[0]
                                            last_name = split_name[1]
                                            self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                        else:
                            if len(split_name) == 3:
                                first_name = split_name[0].replace(',','')
                                last_name = split_name[1].replace(',','')
                                if last_name == '&':
                                    last_name = split_name[2].replace(',', '')
                                self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                            else:
                                if '&' in name:
                                    if len(split_name) == 4:
                                        first_name = split_name[0]
                                        last_name = split_name[3]
                                        self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                    else:
                                        if len(split_name) == 9:
                                            first_name = split_name[0]
                                            last_name = ''
                                            self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                        else:
                                            print("STOP")
                                else:
                                    if len(split_name) == 4:
                                        first_name = split_name[0]
                                        last_name = split_name[1]
                                        self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                        self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                    else:
                                        if len(split_name) == 7 or len(split_name) == 6 and split_name[2] == '•':
                                            first_name = split_name[0]
                                            last_name = split_name[1]
                                            self.data.update({'_id': _id}, {'$set': {'first_name': first_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'last_name': last_name}}, upsert=False)
                                            self.data.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                                        else:
                                            print("STOP")
        except Exception as e:
            print(e)


if __name__ == '__main__':

    execute("scrapy crawl first_last".split())


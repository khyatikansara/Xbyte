import pandas as pd
import pymysql
import datetime
from foodgrab import db_config as dbc
import re

date = datetime.datetime.strftime(datetime.datetime.today(),"%Y%m%d")


def export_data():
    try:
        db_con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd, dbc.database)
        sql = f"Select * from {dbc.database}.{dbc.data_table}"
        df_all = pd.read_sql(sql, db_con)
        output_path = f"{dbc.path}Grab_{date}.csv"
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', ' ') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        df_all.to_csv(output_path, index=False)
        print('CSV File generated', output_path)
        update(output_path)
    except Exception as e:
        print(e)

def update(file_path):
    try:
        list = []
        list1 = []
        df = pd.read_csv(file_path)
        df = df.fillna('')
        for index, row in df.iterrows():
            Id = row['Id']
            print(Id)
            Merchant_Name = row['Merchant Name']
            Address = row['Address']
            Mass_promo_and_Merchant_specific_promo = row['Mass promo and Merchant specific promo']
            promo_code_name = row['promo code name']
            Start_date_end_date = row['Start date end date']
            percentage_or_amount_discount = row['percentage or amount discount']
            Min_order_value = row['Min order value']
            Max_discount = row['Max discount']
            Code_restrictions = row['Code restrictions']
            URL = row['URL']
            html = row['html']
            Hash_id = row['Hash id']
            if promo_code_name != '':
                if '.000' not in promo_code_name:
                    if 'Mua 1 Tặng Off' not in promo_code_name and 'Tặng' not in promo_code_name:
                        for i in promo_code_name.split('.'):
                            if i != '000₫' and i != '':
                            # print(i)
                                try:
                                    if 'giảm' in i:
                                        new_promo = re.findall(r'Nhập(.*?)giảm(.*?)$',i)
                                        if new_promo == []:
                                            new_promo = re.findall(r'(.*?)giảm(.*?)$', i)
                                        new_promo_code_name = new_promo[0][0].strip()
                                        new_percentage_or_amount_discount = new_promo[0][1].strip()
                                        if 'K' in new_percentage_or_amount_discount or 'k' in new_percentage_or_amount_discount:
                                            new_percentage_or_amount_discount = new_percentage_or_amount_discount.replace('K','000').replace('k','000')
                                    elif 'miễn' in i:
                                        new_promo = re.findall(r'Nhập(.*?)miễn', i)
                                        new_promo_code_name = new_promo[0].strip()
                                        new_percentage_or_amount_discount = ''
                                    elif 'khao' in i or 'Khao' in i and 'Khao ngay' not in i:
                                        new_promo = re.findall(r'Nhập(.*?)[khao|Khao](.*?)$', i)
                                        new_promo_code_name = new_promo[0][0].strip().replace('-','')
                                        new_percentage_or_amount_discount = new_promo[0][1].strip().replace('hao','')
                                        if 'K' in new_percentage_or_amount_discount or 'k' in new_percentage_or_amount_discount:
                                            new_percentage_or_amount_discount = new_percentage_or_amount_discount.replace('K','000').replace('k','000')
                                    elif 'Độc' in i:
                                        new_promo = re.findall(r'Nhập(.*?)ưu đãi(.*?)$', i)
                                        new_promo_code_name = new_promo[0][0].strip()
                                        new_percentage_or_amount_discount = new_promo[0][1].strip()
                                    elif 'Menu 1  Giảm' in i:
                                        new_promo = re.findall(r'Giảm(.*?)$', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    elif 'Siêu deal kép: Giảm đến' in i:
                                        new_promo = re.findall(r'Siêu deal kép: Giảm đến(.*?)$', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    elif 'Gà rán nguyên con Giảm' in i:
                                        new_promo = re.findall(r'Gà rán nguyên con Giảm(.*?)$', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    elif 'cho best seller' in i:
                                        new_promo = re.findall(r'Giảm(.*?)cho best seller', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    elif re.search(r'Nhập (.*?) - Khao ngay (.*?). Độc Quyền Thứ 7:Nhập (.*?) ưu đãi (.*?)',promo_code_name):
                                        new_promo = re.findall(r'Nhập(.*?)Khao ngay(.*?)$', i)
                                        new_promo_code_name = new_promo[0][0].replace('-','').strip()
                                        new_percentage_or_amount_discount = new_promo[0][1].strip()
                                        if 'K' in new_percentage_or_amount_discount or 'k' in new_percentage_or_amount_discount:
                                            new_percentage_or_amount_discount = new_percentage_or_amount_discount.replace('K','000').replace('k','000')
                                    elif re.search(r'Món Ngon Giá Gốc (.*?)', i):
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = ''
                                    elif re.search(r'Combo Tết ưu đãi tới (.*?)', i):
                                        new_promo = re.findall(r'Combo Tết ưu đãi tới (.*?)$', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    else:
                                        new_promo = re.findall(r'Giảm(.*?)nhập(.*?)$', i)
                                        new_promo_code_name = new_promo[0][1].strip()
                                        new_percentage_or_amount_discount = new_promo[0][0].strip()
                                except Exception as e:
                                    try:
                                        new_promo = re.findall(r'Giảm(.*?)$', i)
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = new_promo[0].strip()
                                    except Exception as e:
                                        new_promo_code_name = ''
                                        new_percentage_or_amount_discount = ''
                                list.append([Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name, new_promo_code_name,
                                             Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount, Min_order_value, Max_discount,
                                             Code_restrictions, URL, Hash_id, html])
                                list1.append(
                                    [Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name,
                                     new_promo_code_name,Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount,
                                     Min_order_value, Max_discount,Code_restrictions, URL, Hash_id, html])
                    else:
                        try:
                            new_promo = re.findall(r'Mua 1 Tặng Off (.*?)ly thứ 2. Nhập (.*?) để được freeship nhé', promo_code_name)
                            new_promo_code_name = new_promo[0][1].strip()
                            new_percentage_or_amount_discount = new_promo[0][0].strip()
                        except Exception as e:
                            try:
                                new_promo = re.findall(r'nhập(.*?)$', promo_code_name)
                                new_promo_code_name = new_promo[0].strip()
                                new_percentage_or_amount_discount = ''
                            except Exception as e:
                                new_promo_code_name = ''
                                new_percentage_or_amount_discount = ''
                        list.append(
                            [Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name,
                             new_promo_code_name,
                             Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount,
                             Min_order_value, Max_discount,
                             Code_restrictions, URL, Hash_id, html])
                        list1.append(
                            [Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name,
                             new_promo_code_name,
                             Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount,
                             Min_order_value, Max_discount,
                             Code_restrictions, URL, Hash_id, html])
                else:
                    try:
                        if 'khi đặt tối thiểu' in promo_code_name:
                            new_promo = re.findall(r'Giảm(.*?)khi', promo_code_name)
                            new_promo_code_name = ''
                            new_percentage_or_amount_discount = new_promo[0][0].strip()
                        elif 'Cơm Rang Chả Mực  Giảm' in promo_code_name:
                            new_promo = re.findall(r'Cơm Rang Chả Mực  Giảm(.*?)$', promo_code_name)
                            new_promo_code_name = ''
                            new_percentage_or_amount_discount = new_promo[0].strip()
                        elif 'phí giao hàng khi đặt đơn tối thiểu' in promo_code_name:
                            new_promo = re.findall(r'Giảm(.*?)phí', promo_code_name)
                            new_promo_code_name = ''
                            new_percentage_or_amount_discount = new_promo[0][0].strip()
                        elif re.search(r'Đồng giá (.*?)Nhập (.*?) giảm (.*?)', promo_code_name):
                            new_promo = re.findall(r'Nhập(.*?)giảm(.*?) cho', promo_code_name)
                            new_promo_code_name = new_promo[0][0].strip()
                            new_percentage_or_amount_discount = new_promo[0][1].strip()
                        else:
                            new_promo_code_name = ''
                            new_percentage_or_amount_discount = ''
                    except Exception as e:
                        new_promo_code_name = ''
                        new_percentage_or_amount_discount = ''
                    list.append([Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name,
                                 new_promo_code_name,
                                 Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount,
                                 Min_order_value, Max_discount,
                                 Code_restrictions, URL, Hash_id, html])
                    list1.append([Id, Merchant_Name, Address, Mass_promo_and_Merchant_specific_promo, promo_code_name,
                                 new_promo_code_name,
                                 Start_date_end_date, percentage_or_amount_discount, new_percentage_or_amount_discount,
                                 Min_order_value, Max_discount,
                                 Code_restrictions, URL, Hash_id, html])
                    print("")

            else:
                new_promo_code_name = new_percentage_or_amount_discount = ''
                list.append([Id,Merchant_Name,Address,Mass_promo_and_Merchant_specific_promo,promo_code_name,new_promo_code_name,Start_date_end_date,percentage_or_amount_discount,new_percentage_or_amount_discount,Min_order_value,Max_discount,Code_restrictions,URL, Hash_id, html])
                list1.append([Id,Merchant_Name,Address,Mass_promo_and_Merchant_specific_promo,promo_code_name,new_promo_code_name,Start_date_end_date,percentage_or_amount_discount,new_percentage_or_amount_discount,Min_order_value,Max_discount,Code_restrictions,URL, Hash_id, html])

        gh = pd.DataFrame(list, columns=['Id','Merchant_Name','Address','Mass_promo_and_Merchant_specific_promo','promo_code_name','new_promo_code_name','Start_date_end_date','percentage_or_amount_discount','new_percentage_or_amount_discount','Min_order_value','Max_discount','Code_restrictions','URL', 'Hash_id', 'html'])
        output_path = f"{dbc.path}Grab_{date}.csv"
        gh.to_csv(output_path, index=False)
        print(f"File generated for {output_path}")
    except Exception as e:
        print(e)

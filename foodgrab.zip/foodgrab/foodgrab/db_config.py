import datetime
import os

host = "localhost"
usernm = "root"
passwd = "xbyte"
database = "grab_food_daily"

date = datetime.datetime.strftime(datetime.datetime.today(),"%Y_%m_%d")
link_table = f"link_{date}"
data_table = f"data_{date}"

Current_Directory = os.path.dirname(os.path.abspath(__file__))
path = Current_Directory.split('foodgrab\\foodgrab')[0] + f'HTML_Grabfood\\{date}\\'
data_path = f'{path}data\\'

if not os.path.exists(data_path):
    os.makedirs(data_path)
# -*- coding: utf-8 -*-
import re
import requests
import scrapy
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from foodgrab.items import FoodgrabItem
from foodgrab import db_config as dbc
from foodgrab.pipelines import FoodgrabPipeline as pipe
from scraper_api import ScraperAPIClient
client = ScraperAPIClient('ec46668b42a54199b95f52ab3d9ba6f8')


class LinkSiteMapSpider(scrapy.Spider):
    name = 'link_sitemap'
    start_urls = ['https://growth-public.grab.com/grabfood-com/sitemap/sitemap_index.xml']
    start, end = '', ''

    def parse(self, response):
        sitemap_links = re.findall(r'<loc>(.*?)</loc>', response.body.decode('utf8'))
        Id = 0
        for Source_URL in sitemap_links:
            if '/sitemap/vn/' in Source_URL and '/vi/' in Source_URL:
                res_s = requests.get(Source_URL)
                response_s = HtmlResponse(url=res_s.url, body=res_s.content)
                restaurant_links = re.findall(r'<loc>(.*?)</loc>', response_s.body.decode('utf8'))
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36'
                }
                for restaurant_link in restaurant_links:
                    Id += 1
                    path = f'{dbc.data_path}{Id}.html'
                    restaurant_link = restaurant_link.replace('/vn/vi/','/vn/en/')
                    yield scrapy.Request(url=client.scrapyGet(url=restaurant_link), headers=headers, callback=self.get_data, meta={"Id": Id, "URL": restaurant_link, "path": path}, dont_filter=True)

    def get_data(self, response):
        try:
            path = response.meta['path']
            pipe.page_save(self, path, response.text)
            item = FoodgrabItem()
            item['table'] = dbc.link_table
            item['URL'] = response.meta['URL']
            path = path.replace('\\','\\\\')
            item['html'] = path
            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    execute('scrapy crawl link_sitemap'.split())

# -*- coding: utf-8 -*-
from datetime import datetime
import hashlib
import json
import os
import re
import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.http import HtmlResponse
from selenium import webdriver
import time
from unidecode import unidecode
from w3lib.http import basic_auth_header
from foodgrab import export
from foodgrab.items import FoodgrabItem
from foodgrab import db_config as dbc
from foodgrab.pipelines import FoodgrabPipeline as pipe
from scraper_api import ScraperAPIClient
client = ScraperAPIClient('847641580f8a287fcf415713f838796b')

date = datetime.now().strftime("%Y_%m_%d")


class DataSpider(scrapy.Spider):
    name = 'data'
    start_urls = ['https://www.example.com']
    start, end = '', ''

    def parse(self, response):
        pipe.cursor.execute(f'select * from {dbc.database}.{dbc.link_table} where status="pending"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                Id = row[0]
                URL = row[1]
                page_path = row[2]
                file = pipe.page_read(self,page_path)
                response = html.fromstring(file)
                Address = promo_code_name = percentage_or_amount_discount = Start_date_end_date = Min_order_value = Code_restrictions = Merchant_Name = ''
                try:
                    Address = re.findall(r'"streetAddress":"(.*?)","', file)[0].strip()
                except Exception as e:
                    print(e)
                    Address = ''
                if Address == '':
                    try:
                        Address = re.findall(r'address:\s?\'(.*?)\',', file)[0].strip()
                    except Exception as e:
                        print(e)
                        Address = ''
                if Address == '':
                    try:
                        Address = re.findall(r'"addressDetail":"(.*?)",', file)[0].strip()
                    except Exception as e:
                        print(e)
                        Address = ''
                if '"campaigns":' not in file:
                    if '"promoName___2qJQm"' in file:
                        percentage_or_amount_discount = re.findall(r'"promoName___2qJQm">(.*?)<', file)[0].strip()
                        promo_code_name = percentage_or_amount_discount
                    try:
                        item = FoodgrabItem()
                        item['table'] = dbc.data_table
                        item['Merchant_Name'] = Merchant_Name
                        item['Address'] = Address
                        item['Mass_promo_and_Merchant_specific_promo'] = ''
                        item['promo_code_name'] = promo_code_name
                        item['Start_date_end_date'] = Start_date_end_date
                        item['percentage_or_amount_discount'] = ''
                        item['Min_order_value'] = Min_order_value
                        item['Max_discount'] = ''
                        item['Code_restrictions'] = Code_restrictions
                        item['URL'] = URL

                        unique = str(item['Merchant_Name']) + str(item['Address']) + str(
                            item['Mass_promo_and_Merchant_specific_promo']) + str(item['promo_code_name']) + str(
                            item['Start_date_end_date']) + str(item['percentage_or_amount_discount']) + str(
                            item['Min_order_value']) + str(item['Max_discount']) + str(item['Code_restrictions']) + str(
                            item['URL'])
                        item['Hash_id'] = int(hashlib.md5((unique).encode('utf8')).hexdigest(), 16)
                        item['html'] = page_path.replace('\\', '\\\\')
                        yield item
                    except Exception as e:
                        print(e)
                else:
                    campaigns_text = re.findall(r'"campaigns":(.*?)]},"', file)[0] + ']'
                    camp_json = json.loads(campaigns_text)
                    if camp_json != []:
                        for camp_json_tmp in camp_json:
                            try:
                                percentage_or_amount_discount = camp_json_tmp['name']
                            except Exception as e:
                                print(e)
                                percentage_or_amount_discount = ''
                            try:
                                Code_restrictions = ' | '.join(camp_json_tmp['tcDetails'])
                            except Exception as e:
                                print(e)
                                Code_restrictions = ''
                            try:
                                if Code_restrictions != '':
                                    code_restriction_tmp = Code_restrictions.lower()
                                    if 'minimum order' in code_restriction_tmp:
                                        for i in code_restriction_tmp.split("|"):
                                            if 'minimum order' in i:
                                                Min_order_value = ''.join(re.findall(r'[0-9]+', i))
                                                break
                            except Exception as e:
                                print(e)
                                Min_order_value = ''
                            try:
                                if Code_restrictions != '':
                                    code_restriction_tmp = Code_restrictions.lower()
                                    if 'valid' in code_restriction_tmp:
                                        for i in code_restriction_tmp.split("|"):
                                            if 'valid' in i:
                                                Start_date = re.findall(r'valid(.*?)to', i)[0].strip().split()[0]
                                                end_date = re.findall(r'to(.*?)$', i)[0].strip().split()[0]
                                                Start_date_end_date = Start_date + '/' + end_date
                                                break
                            except Exception as e:
                                print(e)
                                Start_date_end_date = ''

                            if promo_code_name == '':
                                data_json = response.xpath('//script[@id="__NEXT_DATA__"]/text()')[0]
                                data = json.loads(data_json)
                                key =URL.split('/')[-1]
                                promo_code_name = data['props']['initialReduxState']['pageRestaurantDetail']['entities'][key]['promo']['description']
                                percentage_or_amount_discount = promo_code_name
                                Merchant_Name = data['props']['initialReduxState']['pageRestaurantDetail']['entities'][key]['name']
                            try:
                                item = FoodgrabItem()
                                item['table'] = dbc.data_table
                                item['Merchant_Name'] = Merchant_Name
                                item['Address'] = Address
                                item['Mass_promo_and_Merchant_specific_promo'] = ''
                                item['promo_code_name'] = promo_code_name
                                item['Start_date_end_date'] = Start_date_end_date
                                item['percentage_or_amount_discount'] = ''  # unidecode(percentage_or_amount_discount)
                                item['Min_order_value'] = Min_order_value
                                item['Max_discount'] = ''
                                item['Code_restrictions'] = Code_restrictions
                                item['URL'] = URL
                                unique = camp_json_tmp['name']
                                item['html'] = page_path.replace('\\', '\\\\')
                                item['Hash_id'] = int(hashlib.md5((str(item) + str(unique)).encode('utf8')).hexdigest(),16)
                                yield item
                            except Exception as e:
                                print(e)
                    else:
                        if promo_code_name == '':
                            data_json = response.xpath('//script[@id="__NEXT_DATA__"]/text()')[0]
                            data = json.loads(data_json)
                            key = URL.split('/')[-1]
                            promo_code_name = data['props']['initialReduxState']['pageRestaurantDetail']['entities'][key]['promo']['description']
                            percentage_or_amount_discount = promo_code_name
                            Merchant_Name = data['props']['initialReduxState']['pageRestaurantDetail']['entities'][key]['name']
                        try:
                            item = FoodgrabItem()
                            item['table'] = dbc.data_table
                            item['Merchant_Name'] = Merchant_Name
                            item['Address'] = Address
                            item['Mass_promo_and_Merchant_specific_promo'] = ''
                            item['promo_code_name'] = promo_code_name
                            item['Start_date_end_date'] = Start_date_end_date
                            item['percentage_or_amount_discount'] = ''  # unidecode(percentage_or_amount_discount)
                            item['Min_order_value'] = Min_order_value
                            item['Max_discount'] = ''
                            item['Code_restrictions'] = Code_restrictions
                            item['URL'] = URL
                            unique = str(item['Merchant_Name']) + str(item['Address']) + str(
                                item['Mass_promo_and_Merchant_specific_promo']) + str(item['promo_code_name']) + str(
                                item['Start_date_end_date']) + str(item['percentage_or_amount_discount']) + str(
                                item['Min_order_value']) + str(item['Max_discount']) + str(
                                item['Code_restrictions']) + str(
                                item['URL'])
                            item['Hash_id'] = int(hashlib.md5((unique).encode('utf8')).hexdigest(), 16)
                            item['html'] = page_path.replace('\\', '\\\\')
                            yield item
                        except Exception as e:
                            print(e)
            except Exception as e:
                print(e)

    def close(spider, reason):
        export.export_data()

if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl data'.split())
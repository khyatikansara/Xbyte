import datetime
TodayToday = datetime.date.today()

host='localhost'
user='root'
password='xbyte'
database='slick_deals'
# table='data_'+str(TodayToday.strftime("%d_%m_%Y"))
table='data_18_08_2021'
table_link='link'
import pymysql
import pandas as pd
import csv
import openpyxl
import platform
os_type = str(platform.system()).lower()
import os
import time
tstamp = time.strftime('%Y%m%d')

Current_Directory = os.path.dirname(os.path.abspath(__file__))
if "windows" in os_type:
    xls_path = Current_Directory + '\\spiders\\' + '\\xls\\'
else :
    xls_path = Current_Directory + '\\spiders\\' + '\\xls\\'

if not os.path.exists(xls_path):
    os.makedirs(xls_path)

try:
    db_host = "localhost"
    db_user = "root"
    db_password = "xbyte"
    db_name = "slick_deals"
    db_table = "data_18_08_2021"
    con = pymysql.connect(db_host,db_user, db_password, db_name)
    cursor = con.cursor()

    sql = f"select * from  {db_table}"

    df = pd.read_sql(sql,con)

    df.to_csv(xls_path+'slickdeals_'+str(tstamp)+'.csv',index=False,encoding="utf-8")
    # df.to_csv(xls_path + 'slickdeals_20200304.csv', index=False, encoding="utf-8")
    # df.to_excel('slickdeals.xlsx', index=False, engine='openpyxl')
except Exception as e:
    print(e)
# -*- coding: utf-8 -*-
import json
import re
import mysql.connector
import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from slickdeals.pipelines import SlickdealsItem
from slickdeals.items import SlickdealsItem
import os
import platform
os_type = str(platform.system()).lower()
import time
# tstamp = time.strftime('%d_%m_%Y')
tstamp = '16_06_2021'


class DataSpider(scrapy.Spider):
    name = 'slick_deal_temp'
    start_urls = ['https://slickdeals.net/coupons/']

    def __init__(self, name=None,a="", b="", **kwargs):
        super().__init__(name, **kwargs)
        self.a = str(a)
        self.b = str(b)


        if "windows" in os_type:
            self.page_save_path = 'E:\\slick_deals_pages\\' + tstamp + '\\'

        if not os.path.exists(self.page_save_path):
            os.makedirs(self.page_save_path)


    def parse(self, response):
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="xbyte",
            database="slick_deals"
        )

        sql_select_Query = f"select * from data_17_06_2021 where Id between {self.a} and {self.b} and Status='pending'"
        self.cursor = self.mydb.cursor()
        self.cursor.execute(sql_select_Query)
        links = self.cursor.fetchall()
        results = links
        print(len(results))

        for raw in results:
            Id = raw[0]
            URL = raw[1]
            Category = raw[2]
            Storename = raw[3]
            Merchant_Name = raw[4]
            Dealname = raw[5]
            Description = raw[6]
            Discounts = raw[7]
            coupencode = raw[8]
            expire_date = raw[9]

            item = SlickdealsItem()
            item['Storename'] = Storename
            item['Category'] = Category
            item['Merchant_Name'] = Merchant_Name
            item['Dealname'] = Dealname
            item['URl'] = URL
            item['Description'] = Description
            item['Discounts'] = Discounts
            item['coupencode'] = coupencode
            item['expire_date'] = expire_date
            yield item

            query = f"update data_17_06_2021 set Status='done' where Id='" + str(Id) + "'"
            self.cursor.execute(query)
            self.mydb.commit()
            print("Record Updated successfully ")


from scrapy.cmdline import execute
# execute('scrapy crawl slick_deal_temp -a a=1 -a b=500000'.split())
import json
import re
import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from slickdeals.items import SlickdealslinkItem

class HinesProperties(scrapy.Spider):
    name='slick_deal_link'
    start_urls = ['https://slickdeals.net/coupons/']

    # 'https://slickdeals.net/attachment/sitemaps/stores-1.xml.gz'


    def parse(self, response):

        try:
            # link='D:\\framework code\\coupen_code\\store_property\\store_property\\spiders\\'
            # 'D:\Dhruv\framework code\coupen_code\store_property\store_property\spiders'
            with open('a.html', "rb") as f:
                text = f.read()
            response_1 = HtmlResponse(url='a.com', body=text)
        except Exception as e:
            print(e)



    #     # linl='file:///D:/all-equipment/Final_page_save/above-all-equipment Online/Pages Saved/656.html'
    #     try:
    #         yield scrapy.Request(url=link,
    #                              callback=self.get_link)
    #
    #     except Exception as e:
    #         print("Nolink found : ", link, '   ', e)
    #
    # def get_link(self,response):
        product_links = re.findall(r'<loc>(.*?)</loc>', response_1.body.decode('utf8'))
        for p_link in product_links:
            item=SlickdealslinkItem()
            item['URl'] = p_link
            yield item
            # print(item)

# from scrapy.cmdline import execute
# execute('scrapy crawl slick_deal_link'.split())
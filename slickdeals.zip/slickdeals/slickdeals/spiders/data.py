# -*- coding: utf-8 -*-
import json
import re
import mysql.connector
import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser
from slickdeals.pipelines import SlickdealsItem
from slickdeals.items import SlickdealsItem
import os
import platform
os_type = str(platform.system()).lower()
import time
# tstamp = time.strftime('%d_%m_%Y')
tstamp = '18_08_2021'


class DataSpider(scrapy.Spider):
    name = 'slick_deal'
    start_urls = ['https://slickdeals.net/coupons/']

    def __init__(self, name=None,a="", b="", **kwargs):
        super().__init__(name, **kwargs)
        self.a = str(a)
        self.b = str(b)


        if "windows" in os_type:
            self.page_save_path = 'E:\\slick_deals_pages\\' + tstamp + '\\'

        if not os.path.exists(self.page_save_path):
            os.makedirs(self.page_save_path)


    def parse(self, response):
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="xbyte",
            database="slick_deals"
        )

        sql_select_Query = f"select * from link where Id between {self.a} and {self.b} and Status='pending'"
        self.cursor = self.mydb.cursor()
        self.cursor.execute(sql_select_Query)
        links = self.cursor.fetchall()
        results = links
        print(len(results))

        for link in results:
            Id = link[0]
            link = link[1]

            yield scrapy.Request(url=link, callback=self.get_data, meta={'Id': Id})

        # links= response.xpath('//div[@class="topCoupons"]/ul/li/ul/li/a/@href').extract()
        # for link in links:
        #     link='https://slickdeals.net'+link
        #     yield scrapy.Request(url=link,callback=self.get_data)


    def get_data(self,response):
        unique_id=response.url.strip('/').split('/')[-1]
        Path = str(unique_id) + '_' + '.html'
        f = open(self.page_save_path + Path, 'wb')
        f.write(response.body)
        f.close()
        item=SlickdealsItem()

        # Storename=response.xpath('//h1/text()').get().strip().split('Coupons')[0].strip()

        slug=response.url

        # category='Slickdeals >Coupons >'+response.xpath('//span[@class="nolinkcrumb"]/text()').get('').strip()
        category =''
        if category!='':

            blocks=response.xpath('//div[@class="main"]/div//div[@class="buttonRight"]')
            for block in blocks:
                tag=block.xpath('./a/text()').get(default='').strip()
                if tag=='Get Offer':
                    item['Storename']=Storename=block.xpath('./../a/@data-product-exitwebsite').get()
                    item['Category']=category
                    item['Merchant_Name']=Storename.split('.')[0].strip().title()
                    item['Dealname']=block.xpath('./../a/@title').get(default='').strip().encode('ascii','ignore').decode('utf8')
                    item['URl']=slug+block.xpath('./../a/@data-href2').get(default='').strip()
                    item['Description']=block.xpath('./..//div[@class="desc"]/span/text()').get(default='').strip().encode('ascii','ignore').decode('utf8')
                    item['Discounts']=Discounts=' '.join(block.xpath('./..//span[@class="intro"]/span//span/text()').getall()).strip()
                    item['coupencode']=''
                    item['expire_date']=''
                    yield item
                    # print(item)
                elif tag=='Get Coupon Code':
                    item['Storename']=Storename = block.xpath('./../a/@data-product-exitwebsite').get()
                    item['Category'] = category
                    item['Merchant_Name'] = Storename.split('.')[0].strip().title()
                    item['Dealname'] = block.xpath('./../a/@title').get(default='').strip().encode('ascii','ignore').decode('utf8')
                    item['URl'] = slug + block.xpath('./../a/@data-href2').get(default='').strip()
                    item['Description'] = block.xpath('./..//div[@class="desc"]/span/text()').get(default='').strip().encode('ascii','ignore').decode('utf8')
                    item['coupencode'] =block.xpath('./../a/@data-clipboard-text').get(default='').strip()
                    item['expire_date']=block.xpath('./..//div[@class="detailsBottom"]/span/@data-expiredate/../text()').get(default='').strip()
                    item['Discounts']=Discounts=' '.join(block.xpath('./..//span[@class="intro"]/span//span/text()').getall()).strip()
                    yield item
                    # print(item)
                else:
                    continue
            query = f"update link set Status='done' where Id='" + str(response.meta['Id']) + "'"
            self.cursor.execute(query)
            self.mydb.commit()
            print("Record Updated successfully ")
        else:

            Storename=response.url.split('/')[-2].title()

            blocks=response.xpath('//section[@class="bp-p-storeContent_section"]/ul/li[contains(@class,"bp-p-offerCard bp-c-card--border bp-p-discountCard bp-c-card")]')
            for block in blocks:

                item['Storename']=Storename
                item['Category']=''
                item['Merchant_Name']=Storename
                item['Dealname']=block.xpath('.//div/h2/text()').get(default='').strip().encode('ascii','ignore').decode('utf8')
                item['URl']='https://slickdeals.net'+block.xpath('./button/@data-href2').get(default='').strip()

                item['Description']=''
                Discounts = block.xpath('./button/div[@class="bp-c-card_preHeader"]/text()').get('').strip()
                if '%' in Discounts:
                    item['Discounts']=Discounts+' Off'
                else:
                    item['Discounts'] = ''
                item['coupencode']=''
                item['expire_date']=''
                yield item
                # print(item)
            c_blocks = response.xpath('//section[@class="bp-p-seoStoreContent_section"]/ul/li[contains(@class,"bp-p-offerCard bp-c-card--border bp-p-couponCard bp-c-card")]')
            for c_block in c_blocks:

                item['Storename'] = Storename
                item['Category'] = ''
                item['Merchant_Name'] = Storename
                item['Dealname'] = c_block.xpath('.//div/h2/text()').get(default='').strip().encode('ascii','ignore').decode('utf8')
                item['URl'] = 'https://slickdeals.net' + c_block.xpath('./button/@data-href2').get(default='').strip()

                res_coupon = requests.get(item['URl'])
                response_coupon = HtmlResponse(url=res_coupon.url, body=res_coupon.content)

                # Cross_dash_sell_Product_Name = s_response.xpath(
                #     '//div[contains(text(),"Completa tu compra")]/following-sibling::div[1]/div//div[@class="swogo-product swogo-accessory"]//div[@class="swogo-product-title"]/text()[normalize-space()]').getall()

                item['Description'] = response_coupon.xpath('//div[contains(@class,"bp-p-storeCouponModal_details js-storeCouponModal_detailsTarget")]/text()').get(default='').strip().encode('ascii','ignore').decode('utf8')
                item['coupencode'] =response_coupon.xpath('//span[@class="bp-p-storeCouponModal_code"]/text()').get(default='').strip()
                item['expire_date']=''
                Discounts = c_block.xpath('./button/div[@class="bp-c-card_preHeader"]/text()').get('').strip()
                if '%' in Discounts:
                    item['Discounts'] = Discounts+' Off'
                else:
                    item['Discounts'] = ''
                yield item
                # print(item)

            query = f"update link set Status='done' where Id='" + str(response.meta['Id']) + "'"
            self.cursor.execute(query)
            self.mydb.commit()
            print("Record Updated successfully ")


from scrapy.cmdline import execute
execute('scrapy crawl slick_deal -a a=1 -a b=500000'.split())
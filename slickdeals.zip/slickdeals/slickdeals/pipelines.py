# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
from slickdeals.items import *
from slickdeals import db_config

class SlickdealsPipeline(object):
    insert_count = 0

    def __init__(self):

        try:
            self.connection = pymysql.connect(host=db_config.host, user=db_config.user, password=db_config.password)
            self.cursor = self.connection.cursor()
            self.cursor.execute('CREATE DATABASE ' + db_config.database)
        except Exception as e:
            print(e)
        self.connection = pymysql.connect(host=db_config.host, user=db_config.user, password=db_config.password,
                                          database=db_config.database)
        self.cursor = self.connection.cursor()
        try:
            table1 = "CREATE TABLE " + db_config.table + """(Id int NOT NULL AUTO_INCREMENT,
                                                                          URl varchar(255) DEFAULT NULL,
                                                                          Category longtext DEFAULT NULL,
                                                                          Storename longtext DEFAULT NULL,
                                                                          Merchant_Name longtext DEFAULT NULL,
                                                                          Dealname longtext DEFAULT NULL,
                                                                          Description longtext DEFAULT NULL,
                                                                          Discounts longtext DEFAULT NULL,
                                                                          coupencode longtext DEFAULT NULL,
                                                                          expire_date longtext DEFAULT NULL,
                                                                          UNIQUE (URl),
                                                                        PRIMARY KEY (Id))
                                                                        DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci"""

            # table1 = "CREATE TABLE " + db_config.table + """(Id int NOT NULL AUTO_INCREMENT,
            #                                                                       URl varchar(255) DEFAULT NULL,
            #                                                                       Category longtext DEFAULT NULL,
            #                                                                       Storename longtext DEFAULT NULL,
            #                                                                       Merchant_Name longtext DEFAULT NULL,
            #                                                                       Dealname longtext DEFAULT NULL,
            #                                                                       Description longtext DEFAULT NULL,
            #                                                                       Discounts longtext DEFAULT NULL,
            #                                                                       coupencode longtext DEFAULT NULL,
            #                                                                       expire_date longtext DEFAULT NULL,
            #                                                                       UNIQUE (URl),
            #                                                                     PRIMARY KEY (Id))"""

            table2 = "CREATE TABLE " + db_config.table_link + """(Id int NOT NULL AUTO_INCREMENT,
                                                                                      URl varchar(255) DEFAULT NULL,
                                                                                      Status varchar(50) DEFAULT 'Pending',
                                                                                      UNIQUE (URl),
                                                                                    PRIMARY KEY (Id))"""
            self.cursor.execute(table1)
            self.cursor.execute(table2)
            self.connection.commit()
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, SlickdealsItem):
            # self.connection = pymysql.connect(host=db_config.host, user=db_config.user, password=db_config.password,
            #                                   database=db_config.database)
            # self.cursor = self.connection.cursor()
            try:
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = "insert into " + db_config.table.replace('.','_') + "( " + fields + " ) values ( '" + values + "' )"
                self.cursor.execute(insert_db)
                self.connection.commit()
                self.insert_count += 1
                print("\rData_Count ...%s" % str(self.insert_count), end="")
            except Exception as e:
                print('problem in data insert ', str(e))
        if isinstance(item, SlickdealslinkItem):
            # self.connection = pymysql.connect(host=db_config.host, user=db_config.user, password=db_config.password,
            #                                   database=db_config.database)
            # self.cursor = self.connection.cursor()
            try:
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = "insert into " + db_config.table_link.replace('.',
                                                                          '_') + "( " + fields + " ) values ( '" + values + "' )"
                self.cursor.execute(insert_db)
                self.connection.commit()
                self.insert_count += 1
                print("\rData_Count ...%s" % str(self.insert_count), end="")
            except Exception as e:
                print('problem in data insert ', str(e))

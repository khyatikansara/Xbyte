import os
from os import listdir
from os.path import isfile, join

import scrapy
from lxml import html
from scrapy.cmdline import execute
from lloydsapotek.items import LloydsapotekItem
from lloydsapotek.pipelines import LloydsapotekPipeline as pipe
from datetime import datetime
import shutil


class LinkSpider(scrapy.Spider):
    name = 'link'
    allowed_domains = []
    start_urls = ['https://www.lloydsapotek.se/produkter/c/seb2c0']

    def parse(self,response):
       links = response.xpath('//ul[@class="list"]/li/a/@href').extract()
       for link in links:
           link = "https://www.lloydsapotek.se" + link
           yield scrapy.Request(url=link, callback=self.parse_link, dont_filter=True)

    def parse_link(self, response):
        try:
            product_links = response.xpath('//article[@class="product-item"]//h2/a/@href').extract()
            for product_link in product_links:
                product_link = "https://www.lloydsapotek.se" + product_link
                item = LloydsapotekItem()
                item['URL'] = product_link
                item['table'] = 'link'
                yield item
            next_page = response.xpath('//a[@rel="next"]/@href').extract_first()
            if next_page:
                next_url = "https://www.lloydsapotek.se" + next_page
                yield scrapy.Request(url=next_url, callback=self.parse_link, dont_filter=True)
        except Exception as e:
            print(e)

# execute("scrapy crawl link".split())
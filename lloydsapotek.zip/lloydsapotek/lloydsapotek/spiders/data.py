import os
import re
from os import listdir
from os.path import isfile, join
import scrapy
import requests
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from unidecode import unidecode
from lloydsapotek.items import LloydsapotekItem
from lloydsapotek.pipelines import LloydsapotekPipeline as pipe
from datetime import datetime
import shutil


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ['https://www.lloydsapotek.se/produkter/c/seb2c0']

    def parse(self,response):
        pipe.cursor.execute(f'select * from lloydsapotek.link where status="pending"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                Id = row[0]
                url = row[1]
                res = requests.get(url=url)
                if res.status_code == 200:
                    response = HtmlResponse(url=res.url,body=res.content)
                    file_path = f"D:\\khyati-H\\GX Advisor\\HTML\\data\\{Id}.html"
                    pipe.page_save(self, file_path, response.text)
                    print("page save Done")
                    file = pipe.page_read(self, file_path)
                    response = html.fromstring(file)
                    try:
                        try:
                            output_source_product_name = response.xpath('//h1/text()')[0].strip()
                        except Exception as e:
                            print(e)
                            output_source_product_name = ''
                        if output_source_product_name != '':
                            try:
                                if "<span>Pris innan rabatt:" in file:
                                    output_source_ordinary_price_text = re.findall(r'<span>Pris innan rabatt:(.*?)</span>', file)[0]
                                    output_source_ordinary_price_text = re.sub(r'[\n\t]', '', output_source_ordinary_price_text)
                                    output_source_ordinary_price = output_source_ordinary_price_text.replace('&nbsp;','').replace(':-', '').strip()
                                else:
                                    output_source_ordinary_price = ''
                            except Exception as e:
                                print(e)
                                output_source_ordinary_price = ''

                            try:
                                output_source_web_price = response.xpath('//*[@itemprop="price"]/@content')[0].strip()
                            except Exception as e:
                                print(e)
                                output_source_web_price = ''

                            try:
                                if "Butikspris" in file:
                                    output_source_instore_price_text = re.findall(r'Butikspris(.*?)</div>', file, re.DOTALL)[0].strip()
                                    output_source_instore_price_text = re.sub(r'[\n\t]', '', output_source_instore_price_text)
                                    output_source_instore_price = output_source_instore_price_text.replace('&nbsp;','').replace(':-','').strip()
                                else:
                                    output_source_instore_price = ''
                            except Exception as e:
                                print(e)
                                output_source_instore_price = ''

                            try:
                                output_source_delivery_time_text = ''.join(response.xpath('//*[@class="row product-details product-status"]/strong/text()'))
                                output_source_delivery_time = re.sub(r'[\n\t]', '', output_source_delivery_time_text).strip()
                            except Exception as e:
                                print(e)
                                output_source_delivery_time = ''

                            try:
                                output_source_comparison_price_text = response.xpath('//*[@class="comparePrice"]/text()')[0].strip()
                                output_source_comparison_price_text = re.sub(r'[\n\t]', '', output_source_comparison_price_text)
                                output_source_comparison_price = unidecode(re.findall(r'Jämförpris(.*?):-', output_source_comparison_price_text)[0]).strip()
                                output_source_comparison_price_unit = "/" + ''.join(re.findall(r':-/(.*?)$', output_source_comparison_price_text))
                            except Exception as e:
                                print(e)
                                output_source_comparison_price = output_source_comparison_price_unit = ''

                            try:
                                output_source_category_text = ' '.join(response.xpath('//ol[@class="breadcrumb"]/li/a/text()'))
                                output_source_category = re.sub(r'[\n\t]', '', output_source_category_text)
                            except Exception as e:
                                print(e)
                                output_source_category = ''

                            try:
                                output_source_brand = response.xpath('//a/@data-brand-name')[0].strip()
                            except Exception as e:
                                print(e)
                                output_source_brand = ''

                            try:
                                output_source_ean_text = response.xpath('//meta[@property="og:image"]/@content')[0].strip()
                                output_source_ean = re.findall(r'/medias/(.*?)-', output_source_ean_text)[0]
                            except Exception as e:
                                print(e)
                                output_source_ean = ''

                            try:
                                item = LloydsapotekItem()
                                item['output_source_product_name'] = output_source_product_name
                                item['output_source_ordinary_price'] = output_source_ordinary_price
                                item['output_source_web_price'] = output_source_web_price
                                item['output_source_instore_price'] = output_source_instore_price
                                item['output_source_comparison_price'] = output_source_comparison_price
                                item['output_source_comparison_price_unit'] = output_source_comparison_price_unit
                                item['output_source_delivery_time'] = output_source_delivery_time
                                item['output_source_category'] = output_source_category
                                item['output_source_brand'] = output_source_brand
                                item['output_source_ean'] = output_source_ean
                                item['output_source_url'] = url
                                item['html'] = file_path.replace('\\', '\\\\')
                                item['table'] = 'data'
                                yield item
                            except Exception as e:
                                print(e)
                            try:
                                pipe.cursor.execute( f'update lloydsapotek.link set status="Done" where URL="{url}"')
                                pipe.con.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
                        else:
                            print("output_source_product_name is blank")
                    except Exception as e:
                        print(e)
                else:
                    print("response issue")
                    try:
                        pipe.cursor.execute(f'update lloydsapotek.link set status="it is currently unavailable." where URL="{url}"')
                        pipe.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)

# execute("scrapy crawl data".split())
import datetime
import json
import pymongo
import dropbox
from scrapy.exceptions import DropItem
import pandas
import pymysql
from lloydsapotek.items import LloydsapotekItem


class LloydsapotekPipeline:
    counter = 0

    try:
        con = pymysql.connect('192.168.1.252', 'root', 'xbyte')
        cursor = con.cursor()
        cursor.execute('CREATE DATABASE IF NOT EXISTS lloydsapotek')
    except Exception as e:
        print(str(e))
    con = pymysql.connect('192.168.1.252', 'root', 'xbyte', 'lloydsapotek')
    cursor = con.cursor()

    try:
        create = f"""CREATE TABLE IF NOT EXISTS link (`Id` int NOT NULL AUTO_INCREMENT,
                                                        URL varchar(255),
                                                        status varchar(50) DEFAULT 'pending',
                                                        UNIQUE KEY (`URL`),
                                                        primary key(`Id`));"""
        cursor.execute(create)
    except Exception as e:
        print(e)

    try:
        create1 = f"""CREATE TABLE IF NOT EXISTS data (`Id` int NOT NULL AUTO_INCREMENT,
                                                        output_source_product_name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_ordinary_price longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_web_price longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_instore_price longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_comparison_price longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_comparison_price_unit longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_delivery_time longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_category longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_brand longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_ean longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        output_source_url varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        html longtext DEFAULT NULL,
                                                        UNIQUE KEY (`output_source_url`),
                                                        primary key(`Id`));"""
        cursor.execute(create1)
    except Exception as e:
        print(e)

    def process_item(self, item, spider):
        if isinstance(item, LloydsapotekItem):
            self.counter+=1
            table = item['table']
            del item['table']
            self.insert_item(table, item, self.counter)

    def insert_item(self, table, item, counter):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print('Data Inserted...', counter)
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))

    def page_save(self, path, response):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(response)
            f.close()

    def page_read(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            file_open = file.read()
            file.close()
            return file_open





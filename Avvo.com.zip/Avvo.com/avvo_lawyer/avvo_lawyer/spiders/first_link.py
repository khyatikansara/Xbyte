# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
import pandas as pd


class FirstLinkSpider(scrapy.Spider):
    name = 'first_link'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, table_name='', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.data = self.db[f'Lawyer_{table_name}']

    # def start_requests(self):
    #     try:
    #         df = pd.read_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Avvo_Laywers_Counts.xlsx")
    #         df = df.fillna('')
    #         for index, row in df.iterrows():
    #             State = row['State']
    #             New_York = row['New York']
    #             Count = row['Count']
    #             item = AvvoLawyerItem()
    #             item['State'] = State
    #             item['New_York'] = New_York
    #             item['Count'] = Count
    #             item['Status'] = 'pending'
    #             item['_id'] = int(hashlib.md5(bytes(New_York, "utf8")).hexdigest(), 16) % (10 ** 8)
    #             try:
    #                 self.data.insert(item)
    #                 print("Data inserted....")
    #             except Exception as e:
    #                 print(e)
    #     except Exception as e:
    #         print(e)

    #-----Less coont File----
    def start_requests(self):
        try:
            df = pd.read_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Missing_Avvo_Laywers_Counts_duplicate.xlsx")
            df = df.fillna('')
            for index, row in df.iterrows():
                client_url = row['client_url']
                count_client = row['count_client']
                count_my = row['count_my']
                difference = row['difference']
                item = AvvoLawyerItem()
                item['client_url'] = client_url
                item['count_client'] = count_client
                item['count_my'] = count_my
                item['difference'] = difference
                item['Status'] = 'pending'
                item['_id'] = int(hashlib.md5(bytes(client_url, "utf8")).hexdigest(), 16) % (10 ** 8)
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

# execute('scrapy crawl first_link -a table_name=Main_link'.split())
# execute('scrapy crawl first_link -a table_name=Less_count_Duplicate'.split())
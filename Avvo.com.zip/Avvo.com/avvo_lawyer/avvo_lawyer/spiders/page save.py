# -*- coding: utf-8 -*-
import hashlib
import json
import re
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
from selenium import webdriver
import time
from lxml import html
from scraper_api import ScraperAPIClient
# Isckon API key = 0f2e50f637e062a098bdf4d0a3e6e0d3
# Gota API key = 23292b2ff2324af3bcb7acab7c63965
client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')


class DataPageSpider(scrapy.Spider):
    name = 'data_page'
    allowed_domains = []
    handle_httpstatus_list = [200]

    def __init__(self, table_name='',skip = '', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.Final_link = self.db[f'Lawyer_Final_link']
        self.Data = self.db[f'Lawyer_{table_name}']
        self.skip = skip

    def start_requests(self):
        try:
            # self.Final_link.update_many({'Status': 'Done6'}, {'$set': {'Status': 'Done5'}}, upsert=False)
            links = self.Final_link.find({"Status":"Done5"}, no_cursor_timeout=True).skip(int(self.skip)).limit(10000)
            print(self.Final_link.find({"Status":"Done5"}).skip(int(self.skip)).limit(10000).count())
            # links = self.Final_link.find({"Status": "Done5"}, no_cursor_timeout=True)
            # print(self.Final_link.find({"Status": "Done5"}).count())
            options = webdriver.ChromeOptions()
            driver = webdriver.Chrome(chrome_options=options)
            for link in links:
                _id = link['_id']
                url = link['Lawyer_link']
                print(_id)
                driver.get(url)
                time.sleep(10)
                response = driver.page_source
                Id = response.meta['Id']
                path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Data\\{Id}.html"
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(response.text)
                    f.close()
                print('page save done')
                file = open(path, 'r', encoding='utf-8')
                file_open = file.read()
                file.close()
                response_r = html.fromstring(file_open)

                item = AvvoLawyerItem()
                Id = response.meta['Id']
                path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Data\\{Id}.html"
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(response.text)
                    f.close()
                print('page save done')

                # --- About section practise area----
                try:
                    practise_text = \
                    re.findall(r'data-react-class="components/AboutSection"(.*?)data-hydrate="t"', response.text)[0]
                    practise1 = re.findall(r'="(.*?)"', practise_text)[0].replace('&quot;', '"')
                    json_practise = json.loads(practise1)
                    practise_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\practise_area\\{Id}.json"
                    with open(practise_path, 'w', encoding='utf-8') as f:
                        f.write(practise1)
                        f.close()
                    print('page save done Practise')
                    lawyer_specialties = json_practise['lawyer_specialties']
                    for pi, practise_dict in enumerate(lawyer_specialties):
                        pi += 1
                        practise_data = f"{practise_dict['display_name']}: {practise_dict['percent']}%"
                        item[f'Practice_Area{pi}'] = practise_data
                except Exception as e:
                    print(e)

                # ---overview section-----
                try:
                    data_text = re.findall(r'data-react-class="components/OverviewCard"(.*?)data-hydrate="t"', response.text)[0]
                    data1 = re.findall(r'="(.*?)"', data_text)[0].replace('&quot;', '"')
                    json_data = json.loads(data1)
                    overview_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\overview\\{Id}.json"
                    with open(overview_path, 'w', encoding='utf-8') as f:
                        f.write(data1)
                        f.close()
                    print('page save done overview')
                    try:
                        Middle_Name = json_data['lawyer']['middlename']
                    except Exception as e:
                        print(e)
                        Middle_Name = ''
                    try:
                        First_Name = json_data['lawyer']['firstname']
                    except Exception as e:
                        print(e)
                        First_Name = ''
                    try:
                        Last_Name = json_data['lawyer']['lastname']
                    except Exception as e:
                        print(e)
                        Last_Name = ''
                    try:
                        Contact_Name = f"{First_Name} {Middle_Name} {Last_Name}"
                    except Exception as e:
                        print(e)
                        Contact_Name = ''
                    try:
                        Website = json_data['lawyer']['website']
                    except Exception as e:
                        print(e)
                        # Website = ''
                except Exception as e:
                    print(e)

                # ---contact section----
                try:
                    contact_text = re.findall(r'data-react-class="components/ContactSection"(.*?)data-hydrate', response.text)[
                        0]
                    contact_data = re.findall(r'="(.*?)"', contact_text)[0].replace('&quot;', '"')
                    contact_json_data = json.loads(contact_data)
                    contact_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\contact\\{Id}.json"
                    with open(contact_path, 'w', encoding='utf-8') as f:
                        f.write(contact_data)
                        f.close()
                    print('page save done contact')
                    Street_Address_list = []
                    City_list = []
                    Phone_list = []
                    Bussines_Name_list = []
                    try:
                        Bussines_Name = contact_json_data['lawyer']['main_address']['firm_name']
                        Bussines_Name_list.append(Bussines_Name)
                    except Exception as e:
                        print(e)
                        Bussines_Name = ''
                    for add in contact_json_data['addresses']:
                        Bussines_Name = add['firm_name']
                        if Bussines_Name == '':
                            if Bussines_Name not in Bussines_Name_list:
                                Bussines_Name_list.append(Bussines_Name)
                        elif Bussines_Name not in Bussines_Name_list:
                            if Bussines_Name != "(By Appointment Only)":
                                Bussines_Name_list.append(Bussines_Name)
                        try:
                            Street_Address1 = add['address_line1']
                            try:
                                Street_Address2 = add['address_line2']
                            except:
                                Street_Address2 = ''
                            Street_Address_tmp = ''
                            if Street_Address2 != '' and Street_Address2 != None:
                                Street_Address_tmp = Street_Address1 + ',' + Street_Address2
                            else:
                                if Street_Address1 != None:
                                    Street_Address_tmp = Street_Address1
                            if Street_Address_tmp != None and Street_Address_tmp != '':
                                Street_Address_list.append(Street_Address_tmp)
                        except Exception as e:
                            print(e)
                            # Street_Address = ''
                        try:
                            City_tmp = add['city']
                            if City_tmp != None and City_tmp != '':
                                City_list.append(City_tmp)
                        except Exception as e:
                            print(e)
                            # City = ''
                        try:
                            area_code = add['phones'][0]['area_code']
                            local_number = add['phones'][0]['local_number']
                            Phone_tmp = f"({area_code}) {local_number}"
                            Phone_list.append(Phone_tmp)
                        except Exception as e:
                            # print(e)
                            Phone_tmp = ''
                        try:
                            if Phone_tmp == '':
                                Phone_tmp = response.xpath('//a[contains(@href,"tel:")]/span/text()').extract_first()
                                if Phone_tmp != None:
                                    Phone_list.append(Phone_tmp)
                        except Exception as e:
                            print(e)
                            # Phone = ''
                    Street_Address = '||'.join(Street_Address_list)
                    Phone = '||'.join(Phone_list)
                    City = '||'.join(City_list)
                    Bussines_Name = '||'.join(Bussines_Name_list)
                except Exception as e:
                    print(e)

                # ----Resume section-----
                try:
                    Liecense_list = []
                    liecense_selector = response.xpath('//*[text()="License"]/../table/tbody/tr')
                    for lic in liecense_selector:
                        state = lic.xpath('./td[@data-title="State"]/text()').extract_first()
                        status = lic.xpath('./td[@data-title="Status"]/text()').extract_first()
                        origin = lic.xpath('./td[@data-title="Origin"]/text()').extract_first()
                        updated = lic.xpath('./td[@data-title="Updated"]/text()').extract_first()
                        Liecense_list.append(f"{state}--{status}--{origin}--{updated}")
                    Liecense = '||'.join(Liecense_list)
                except Exception as e:
                    print(e)
                    # Liecense = ''
                try:
                    Work_Experience_list = []
                    work_exp_selector = response.xpath('//*[text()="Work Experience"]/../table/tbody/tr')
                    for work in work_exp_selector:
                        raw_work = work.xpath('./th/text()').extract_first()
                        company_name = work.xpath('./td[@data-title="Company name"]/text()').extract_first()
                        duration = work.xpath('./td[@data-title="Duration"]/text()').extract_first()
                        Work_Experience_list.append(f"{raw_work}--{company_name}--{duration}")
                    if work_exp_selector.xpath('./../../../div'):
                        work_exp_selector2 = work_exp_selector.xpath('./../../../div/table/tbody/tr')
                        for work2 in work_exp_selector2:
                            raw_work2 = work2.xpath('./th/text()').extract_first()
                            company_name2 = work2.xpath('./td[@data-title="Company name"]/text()').extract_first()
                            duration2 = work2.xpath('./td[@data-title="Duration"]/text()').extract_first()
                            Work_Experience_list.append(f"{raw_work2}--{company_name2}--{duration2}")
                    Work_Experience = '||'.join(Work_Experience_list)
                except Exception as e:
                    print(e)
                    # Work_Experience = ''
                try:
                    Education_list = []
                    education_selector = response.xpath('//*[text()="Education"]/../table/tbody/tr')
                    for edu in education_selector:
                        raw_edu = edu.xpath('./th/text()').extract_first()
                        degree = edu.xpath('./td[@data-title="Degree"]/text()').extract_first()
                        graduated = edu.xpath('./td[@data-title="Graduated"]/text()').extract_first()
                        Education_list.append(f"{raw_edu}--{degree}--{graduated}")
                    Education = '||'.join(Education_list)
                except Exception as e:
                    print(e)
                    # Education = ''
                try:
                    Awards_list = []
                    awards_selector = response.xpath('//*[text()="Awards"]/../table/tbody/tr')
                    for awa in awards_selector:
                        raw_awa = awa.xpath('./th/text()').extract_first()
                        grantor = awa.xpath('./td[@data-title="Grantor"]/text()').extract_first()
                        date_granted = awa.xpath('./td[@data-title="Date granted"]/text()').extract_first()
                        Awards_list.append(f"{raw_awa}--{grantor}--{date_granted}")

                    if awards_selector.xpath('./../../../div'):
                        # awards_selector2 = awards_selector.xpath('//*[text()="Awards"]/../table/tbody/tr/../../../div/table/tbody/tr')
                        awards_selector2 = awards_selector.xpath('./../../following-sibling::div/table/tbody/tr')
                        for awa2 in awards_selector2:
                            raw_awa2 = awa2.xpath('./th/text()').extract_first()
                            grantor2 = awa2.xpath('./td[@data-title="Grantor"]/text()').extract_first()
                            date_granted2 = awa2.xpath('./td[@data-title="Date granted"]/text()').extract_first()
                            tmp = f"{raw_awa2}--{grantor2}--{date_granted2}"
                            if tmp not in Awards_list:
                                Awards_list.append(f"{raw_awa2}--{grantor2}--{date_granted2}")
                    Awards = '||'.join(Awards_list)
                except Exception as e:
                    print(e)
                    # Awards = ''
                try:
                    languages_list = []
                    languages = re.findall(r'languages&quot;:\[(.*?)\]\}', response.text)
                    if languages == ['']:
                        Languages = ''
                    else:
                        languages = languages[0].replace('&quot;', '')
                        for lang in languages.split(','):
                            languages_list.append(lang)
                        Languages = ','.join(languages_list)
                except Exception as e:
                    print(e)
                    # Languages = ''
                try:
                    Fees_and_Payment_Type_list = []
                    Fees_and_Payment_Type_text = \
                    re.findall(r'data-react-class="components/CostsSection"(.*?)data-hydrate', response.text)[0]
                    Fees_and_Payment_Type_data = re.findall(r'="(.*?)"', Fees_and_Payment_Type_text)[0].replace('&quot;', '"')
                    Fees_and_Payment_Type_json = json.loads(Fees_and_Payment_Type_data)
                    Fee_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\Fee\\{Id}.json"
                    with open(Fee_path, 'w', encoding='utf-8') as f:
                        f.write(Fees_and_Payment_Type_data)
                        f.close()
                    print('page save done Fee')
                    if Fees_and_Payment_Type_json['fees'] == []:
                        if Fees_and_Payment_Type_json['free_consultation'] != None:
                            free_consultation = Fees_and_Payment_Type_json['free_consultation']
                            Fees_and_Payment_Type_list.append(f"Fees: Free consultation ({free_consultation} minutes)")
                            # Fees_and_Payment_Type['Fees'] = f"Free consultation ({free_consultation} minutes)"
                    else:
                        if len(Fees_and_Payment_Type_json['fees']) == 1:
                            min_rate = str(Fees_and_Payment_Type_json['fees'][0]['min_rate'])
                            max_rate = str(Fees_and_Payment_Type_json['fees'][0]['max_rate'])
                            name = Fees_and_Payment_Type_json['fees'][0]['name']
                            Fees_and_Payment_Type_list.append(f"Fees: {name} (${min_rate}-{max_rate}/hour)")
                            # Fees_and_Payment_Type['Fees'] = f"{name} (${min_rate}-{max_rate}/hour)"
                        else:
                            for feei in Fees_and_Payment_Type_json['fees']:
                                min_rate = str(feei['min_rate'])
                                max_rate = str(feei['max_rate'])
                                name = feei['name']
                                Fees_and_Payment_Type_list.append(f"Fees: {name} (${min_rate}-{max_rate}/hour)")
                    if Fees_and_Payment_Type_json['free_consultation'] != None:
                        free_consultation = Fees_and_Payment_Type_json['free_consultation']
                        Fees_and_Payment_Type_list.append(f"Fees: Free consultation ({free_consultation} minutes)")
                    if 'PAYMENT METHODS' in response.text:
                        payment_types = Fees_and_Payment_Type_json['payment_types']
                        Fees_and_Payment_Type_list.append(f'Payment types: {",".join(payment_types)}')
                        # Fees_and_Payment_Type['Payment types'] = ','.join(payment_types)
                    Fees_and_Payment_Type = '||'.join(Fees_and_Payment_Type_list)
                except Exception as e:
                    print(e)
                    # Fees_and_Payment_Type = ''
                try:
                    item['Source_Link'] = response.meta['url']
                    item['Contact_Name'] = Contact_Name
                    item['First_Name'] = First_Name
                    item['Middle_Name'] = Middle_Name
                    item['Last_Name'] = Last_Name
                    # item['Image_URL'] = Image_URL
                    # item['Pimium_Member'] = Pimium_Member
                    item['Website'] = Website
                    # item['Review_Count'] = Review_Count
                    # item['Review_URL'] = Review_URL
                    # item['Endorsements_URL'] = Endorsements_URL
                    # item['Contribution_URL'] = Contribution_URL
                    item['Fees_and_Payment_Type'] = Fees_and_Payment_Type
                    item['Bussines_Name'] = Bussines_Name
                    item['Street_Address'] = Street_Address
                    item['City'] = City
                    item['Phone'] = Phone
                    # item['Fax'] = Fax
                    # item['FaceBook'] = FaceBook
                    # item['Twitter'] = Twitter
                    # item['Google +'] = Google
                    # item['Linked In'] = Linked_In
                    item['Languages'] = Languages
                    # item['Aboutme_URL'] = Aboutme_URL
                    # item['Aboutme'] = Aboutme
                    # item['Endosment_Count'] = Endosment_Count
                    # item['Endorsement_Comment'] = Endorsement_Comment
                    item['Liecense'] = Liecense
                    item['Work_Experience'] = Work_Experience
                    item['Education'] = Education
                    item['Awards'] = Awards
                    item['path'] = path
                    item['practise_path'] = practise_path
                    item['overview_path'] = overview_path
                    item['contact_path'] = contact_path
                    item['Fee_path'] = Fee_path
                    # item['Association'] = Association
                    # item['Case'] = Case
                    # item['Case_URL'] = Case_URL
                    # item['Publication'] = Publication
                    # item['Speaking_Engagements'] = Speaking_Engagements
                    # item['Category_tree'] = Category_tree
                    # item['Social_Tools_1'] = Social_Tools_1
                    # item['Social_Tools_2'] = Social_Tools_2
                    # item['Social_Tools_3'] = Social_Tools_3
                    # item['Social_Tools_4'] = Social_Tools_4
                    # item['Social_Tools_5'] = Social_Tools_5
                    # item['Practice_Area'] = Practice_Area
                    # item['Status'] = 'pending'
                    # item['_id'] = int(hashlib.md5(bytes(lawyer_link, "utf8")).hexdigest(), 16) % (10 ** 8)
                    try:
                        self.Data.insert(item)
                        print("Data inserted....")
                    except Exception as e:
                        print(e)
                    try:
                        self.Final_link.update({'_id': Id}, {'$set': {'Status': 'Done6'}}, upsert=False)
                        print('update done')
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


# execute('scrapy crawl data_page -a table_name=Data_6 -a skip=0'.split())

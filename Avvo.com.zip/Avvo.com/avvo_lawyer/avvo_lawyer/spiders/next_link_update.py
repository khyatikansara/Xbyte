# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
from selenium import webdriver
import time
from lxml import html
from scraper_api import ScraperAPIClient
client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')


class NextLinkUpdateSpider(scrapy.Spider):
    name = 'next_links_update'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500, 429]
    start,end = '',''

    def __init__(self, table_name='', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.data = self.db[f'Lawyer_Main_link']
        self.Next_link = self.db[f'Lawyer_{table_name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            # self.data.update_many({'next_count': 1}, {'$set': {'Status': 'pending'}}, upsert=False)
            links = self.data.find({"$and":[{"State":"OH"},{"Status":"baki"}]}, no_cursor_timeout=True)
            print(self.data.find({"$and":[{"State":"OH"},{"Status":"baki"}]}).count())
            self.headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'max-age=0',
                'cookie': 'avvo-login=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKTkwYTFiNzFjLWEyY2QtNDQ4ZS04%0AYmU0LTYzNmMxZWZlNzNiMAY7AFQ%3D%0A--ae2045b2fc5f8ca34bd89c786b3cae8f3a55793b; _persistent_session_id=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKThmOWVlYjc5LThjYzItNGY2ZS1i%0ANTZhLWM5ZjA5NWVmMzc0OAY7AFQ%3D%0A; avvo_cache_context=logged_out; BIGipServeravvo-k8s-20080_POOL=2866005258.28750.0000; s_fid=1E3F57A344CA1E4D-15BDBF68E3367D2D; s_cc=true; aa_persistent_session_id=8f9eeb79-8cc2-4f6e-b56a-c9f095ef3748; _fbp=fb.1.1613047094542.1272792709; _ga=GA1.2.1343523611.1613047100; _ibp=0:kl0ulh37:7bc130c1-e61b-4a52-9999-485c84e5b898; notice_behavior=implied,us; _profile_persistent_session_id=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKTBmYWI2MjY0LWM5MjUtNDExZi1i%0ANzljLWE0YTFlZGZjNWFkNgY7AFQ%3D%0A--6b563fbc0c361578473fe73b9b013462614e4106; __cfduid=d7c798e0d732c5edac65b86ade7b7488d1613108097; _session_id=6a01fb4e353aa7a1b102fb87afcd3b4a; _gid=GA1.2.397259200.1613471099; _attorney_profiles_session=91f67946dfc036a07e24795e03c26766; s_sq=%5B%5BB%5D%5D; _ibs=0:kl0ulh38:79e36a2c-1f04-4482-a716-229b581cd1f4; __cf_bm=71a7bb4dd1454f2bb82009635b884d1f514f3fd4-1613639170-1800-AT/NRzcnvOSWFpn+vT6bw1IVd4tWbQtIqwPaAEN08V59mvmuqtef921KYdIR+fMzfqVK9+2WcNIrQx3MgB0XruU=; aa_session_count=17; aa_session_id=8f9eeb79-8cc2-4f6e-b56a-c9f095ef3748.17; _gat_gtag_UA_4437273_19=1',
                # 'sec-fetch-dest': 'document',
                # 'sec-fetch-mode': 'navigate',
                # 'sec-fetch-site': 'none',
                # 'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
            }
            for link in links:
                _id = link['_id']
                url = link['New_York']
                yield scrapy.Request(client.scrapyGet(url=url), headers=self.headers, meta={'Id': _id, 'url': url, 'page':'1'}, dont_filter=True)
                # break
        except Exception as e:
            print(e)

    def parse(self, response):
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(client.scrapyGet(url=response.url), headers=self.headers, meta=response.meta, dont_filter=True, callback=self.parse)
        else:
            try:
                page = response.meta['page']
                Id = response.meta['Id']
                url = response.meta['url']
                if 'page' in response.url:
                    path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NC\\{Id}_{page}.html'
                else:
                    path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NC\\{Id}.html'
                file = open(path, 'w', encoding='utf-8')
                file.write(response.text)
                file.close()
                print(f"page save done {path}")
                item = AvvoLawyerItem()
                item['Link'] = url
                item['path'] = path
                item['Status'] = 'pending'
                item['_id'] = int(hashlib.md5(bytes(url, "utf8")).hexdigest(), 16) % (10 ** 8)
                try:
                    self.Next_link.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
                file_open = open(path, 'r', encoding='utf-8')
                file1 = file_open.read()
                file_open.close()
                response_f = html.fromstring(file1)
                next_page = response_f.xpath('//li[@class="pagination-next"]/a/@href')
                if next_page != []:
                    page = next_page[0].split('?')[-1].split('=')[1]
                    next_url = f"https://www.avvo.com{next_page[0]}"
                    yield scrapy.Request(client.scrapyGet(url=next_url), callback=self.parse, meta={'Id': Id, 'url': next_url, 'page':page}, dont_filter=True)
            except Exception as e:
                print(e)

# execute('scrapy crawl next_links_update -a table_name=Next_link'.split())

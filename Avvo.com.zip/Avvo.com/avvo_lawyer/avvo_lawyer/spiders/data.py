# -*- coding: utf-8 -*-
import hashlib
import json
import re
import pymysql
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
from selenium import webdriver
import time
from lxml import html
from scraper_api import ScraperAPIClient
# Isckon API key = 0f2e50f637e062a098bdf4d0a3e6e0d3
# Gota API key = 23292b2ff2324af3bcb7acab7c639654
client = ScraperAPIClient('23292b2ff2324af3bcb7acab7c639654')


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    handle_httpstatus_list = [200]
    start,end = '',''

    def __init__(self, table_name='',skip = '', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.Final_link = self.db[f'Lawyer1_Final_link_Duplicate_full']
        self.Data = self.db[f'Lawyer_{table_name}']
        self.skip = skip
        self.con = pymysql.connect('192.168.1.252', 'root', 'xbyte', 'avvo_lawyer')
        self.cursor = self.con.cursor()

    def start_requests(self):
        try:
            # self.Final_link.update_many({'Status': 'Done'}, {'$set': {'Status': 'Pending'}}, upsert=False)
            #links = self.Final_link.find({"Status":"Done5"}, no_cursor_timeout=True).skip(int(self.skip)).limit(10000)
            #print(self.Final_link.find({"Status":"Done5"}).skip(int(self.skip)).limit(10000).count())


            # links = self.Final_link.find({"Status": "pending"}, no_cursor_timeout=True)
            # print(self.Final_link.find({"Status": "pending"}).count())

            #----SQL start-----

            self.cursor.execute(f'select * from avvo_lawyer.final_link where status="pending" and Id>"{self.start}" and Id<"{self.end}"')
            links = self.cursor.fetchall()
            #----SQL end-----
            for link in links:
                # ----SQL start-----
                idt = link[0]
                _id = link[1]
                url = link[2]
                # ----SQL end-----

                # _id = link['_id']
                # url = link['Lawyer_link']
                print(_id)
                # if url == 'https://www.avvo.com/attorneys/12205-ny-jonathan-warner-4426022.html':
                # url = "https://www.avvo.com/attorneys/11746-ny-rosemarie-rotondo-940024.html"
                self.headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    # 'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    # 'cache-control': 'max-age=0',
                    'cookie': '_fbp=fb.1.1614667840486.2137388505; avvo-login=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKWJjODAyZmQ4LTgzODgtNDk4MS04%0AN2IwLWQyNjk3MTk3NjU2NAY7AFQ%3D%0A--caa96d61b7c7a07cb6dca3b83d999950c777977e; _persistent_session_id=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKTA3OTM3OTlkLTU0MGItNGRmZC1h%0AZTc0LWRlMTEyZDU3YzQwYQY7AFQ%3D%0A; avvo_cache_context=logged_out; BIGipServeravvo-k8s-20080_POOL=2815673610.28750.0000; s_fid=636FC41A5F6E464E-0AD95C4BAD19006B; s_cc=true; aa_persistent_session_id=0793799d-540b-4dfd-ae74-de112d57c40a; _ga=GA1.2.1258126167.1614667842; _gid=GA1.2.1804302518.1614667842; _ibp=0:klrnjl04:db9b7d4d-53f9-419c-bb52-c97d532c84f6; serp_search_prev_sig=99914b932bd37a50b983c5e7c90ae93b; _session_id=c5e3ac4665f64ff46c594757bb2267fe; __cfduid=d179f265fefa622e88bf135c2e161e58e1614680724; _profile_persistent_session_id=BAh7BkkiD3Nlc3Npb25faWQGOgZFVEkiKTMzNmI2MTQyLTE3N2EtNDllYi05%0ANzJiLTdlZDM4YTZhODRiYQY7AFQ%3D%0A--8533b6c00cf2c924ad622432315308b7ded17b78; s_sq=%5B%5BB%5D%5D; __cf_bm=ed33acc2c6c6921cdf5a81b85afd6fb821fc7483-1614762665-1800-ATFHkQB7UmVd9DCWXWcxl/B/nI/l7fVpPSVk1tMVilQJEnRnLJHInsg/5hd0TXTC6cUW8FIHrg8wCMtuq9iBLg0=; _attorney_profiles_session=bf0e6a78412ccaeca9dfe867c81b8bf2; aa_session_count=8; aa_session_id=0793799d-540b-4dfd-ae74-de112d57c40a.8; _ibs=0:klrnjl05:e1a7a454-2866-48c6-b5e1-a66e9c264f27; __cf_bm=33bd9647dcf46c9d85df53042ada78c57bc4258b-1614763707-1800-AZGt3sAMhguttQ5j+rXCQs0oU/1WKVetoow6C8jJVgAxkmqVbs3zgWf0sO4A8+ezgAooN3HVq55tAMBtFC92uh0=; __cfduid=dce370bd55e3770fe7915c18beb65179d1613112129',
                    'sec-fetch-dest': 'document',
                    'sec-fetch-mode': 'navigate',
                    'sec-fetch-site': 'none',
                    'sec-fetch-user': '?1',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'
                }
                yield scrapy.Request(client.scrapyGet(url=url), meta={'Id': _id,'idt':idt, 'url': url}, dont_filter=True)
                # yield scrapy.Request(url=url, meta={'Id': _id, 'url': url, "proxy": "http://zproxy.lum-superproxy.io:22225"}, dont_filter=True)
                # yield scrapy.Request(url=url, meta={'Id': _id, 'url': url}, dont_filter=True)
                # break
        except Exception as e:
            print(e)

    def parse(self, response):
        if response.status not in self.handle_httpstatus_list:
            yield scrapy.Request(client.scrapyGet(url=response.meta['url']), headers=self.headers, meta=response.meta, dont_filter=True, callback=self.parse)
        else:
            if "<title>Find a lawyer. The best attorneys near you by specialty" in response.text:
                print("Find a lawyer. The best attorneys near you by specialty")
                yield scrapy.Request(client.scrapyGet(url=response.meta['url']), headers=self.headers, meta=response.meta,
                                     dont_filter=True, callback=self.parse)
            else:
                item = AvvoLawyerItem()
                idt = str(response.meta['idt'])
                Id = response.meta['Id']
                path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Data_duplicate\\{Id}.html"
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(response.text)
                    f.close()
                print('page save done')

                #--- About section practise area----
                try:
                    practise_text = re.findall(r'data-react-class="components/AboutSection"(.*?)data-hydrate="t"', response.text)[0]
                    practise1 = re.findall(r'="(.*?)"', practise_text)[0].replace('&quot;', '"')
                    json_practise = json.loads(practise1)
                    practise_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\practise_area_duplicate\\{Id}.json"
                    with open(practise_path, 'w', encoding='utf-8') as f:
                        f.write(practise1)
                        f.close()
                    print('page save done Practise')
                    lawyer_specialties = json_practise['lawyer_specialties']
                    for pi, practise_dict in enumerate(lawyer_specialties):
                        pi+=1
                        practise_data = f"{practise_dict['display_name']}: {practise_dict['percent']}%"
                        item[f'Practice_Area{pi}'] = practise_data
                except Exception as e:
                    print(e)

                #---overview section-----
                try:
                    data_text = re.findall(r'data-react-class="components/OverviewCard"(.*?)data-hydrate="t"',response.text)[0]
                    data1 = re.findall(r'="(.*?)"',data_text)[0].replace('&quot;','"')
                    json_data = json.loads(data1)
                    overview_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\overview_duplicate\\{Id}.json"
                    with open(overview_path, 'w', encoding='utf-8') as f:
                        f.write(data1)
                        f.close()
                    print('page save done overview')
                    try:
                        Middle_Name = json_data['lawyer']['middlename']
                    except Exception as e:
                        print(e)
                        Middle_Name = ''
                    try:
                        First_Name = json_data['lawyer']['firstname']
                    except Exception as e:
                        print(e)
                        First_Name = ''
                    try:
                        Last_Name = json_data['lawyer']['lastname']
                    except Exception as e:
                        print(e)
                        Last_Name = ''
                    try:
                        Contact_Name = f"{First_Name} {Middle_Name} {Last_Name}"
                    except Exception as e:
                        print(e)
                        Contact_Name = ''
                    try:
                        Website = json_data['lawyer']['website']
                    except Exception as e:
                        print(e)
                        # Website = ''
                except Exception as e:
                    print(e)

                #---contact section----
                try:
                    contact_text = re.findall(r'data-react-class="components/ContactSection"(.*?)data-hydrate', response.text)[0]
                    contact_data = re.findall(r'="(.*?)"', contact_text)[0].replace('&quot;', '"')
                    contact_json_data = json.loads(contact_data)
                    contact_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\contact_duplicate\\{Id}.json"
                    with open(contact_path, 'w', encoding='utf-8') as f:
                        f.write(contact_data)
                        f.close()
                    print('page save done contact')
                    Street_Address_list = []
                    City_list = []
                    State_list = []
                    Phone_list = []
                    Bussines_Name_list = []
                    try:
                        Bussines_Name = contact_json_data['lawyer']['main_address']['firm_name']
                        Bussines_Name_list.append(Bussines_Name)
                    except Exception as e:
                        print(e)
                        Bussines_Name = ''
                    for add in contact_json_data['addresses']:
                        Bussines_Name = add['firm_name']
                        if Bussines_Name == '':
                            if Bussines_Name not in Bussines_Name_list:
                                Bussines_Name_list.append(Bussines_Name)
                        elif Bussines_Name not in Bussines_Name_list:
                            if Bussines_Name != "(By Appointment Only)":
                                Bussines_Name_list.append(Bussines_Name)
                        try:
                            Street_Address1 = add['address_line1']
                            try:Street_Address2 = add['address_line2']
                            except:Street_Address2 = ''
                            Street_Address_tmp = ''
                            if Street_Address2 != '' and Street_Address2 != None:
                                Street_Address_tmp = Street_Address1+','+Street_Address2
                            else:
                                if Street_Address1 != None:
                                    Street_Address_tmp = Street_Address1
                            if Street_Address_tmp != None and Street_Address_tmp != '':
                                Street_Address_list.append(Street_Address_tmp)
                        except Exception as e:
                            print(e)
                            # Street_Address = ''
                        try:
                            City_tmp = add['city']
                            if City_tmp != None and City_tmp != '':
                                City_list.append(City_tmp)
                        except Exception as e:
                            print(e)
                            # City = ''
                        try:
                            State_tmp = add['state']
                            if State_tmp != None and State_tmp != '':
                                State_list.append(State_tmp)
                        except Exception as e:
                            print(e)
                            # State = ''
                        try:
                            area_code = add['phones'][0]['area_code']
                            local_number = add['phones'][0]['local_number']
                            Phone_tmp = f"({area_code}) {local_number}"
                            Phone_list.append(Phone_tmp)
                        except Exception as e:
                            # print(e)
                            Phone_tmp = ''
                        try:
                            if Phone_tmp == '':
                                Phone_tmp = response.xpath('//a[contains(@href,"tel:")]/span/text()').extract_first()
                                if Phone_tmp != None:
                                    Phone_list.append(Phone_tmp)
                        except Exception as e:
                            print(e)
                            # Phone = ''
                    Street_Address = '||'.join(Street_Address_list)
                    Phone = '||'.join(Phone_list)
                    City = '||'.join(City_list)
                    State = '||'.join(State_list)
                    Bussines_Name = '||'.join(Bussines_Name_list)
                except Exception as e:
                    print(e)

                #----Resume section-----
                try:
                    Liecense_list = []
                    liecense_selector = response.xpath('//*[text()="License"]/../table/tbody/tr')
                    for lic in liecense_selector:
                        state = lic.xpath('./td[@data-title="State"]/text()').extract_first()
                        status = lic.xpath('./td[@data-title="Status"]/text()').extract_first()
                        origin = lic.xpath('./td[@data-title="Origin"]/text()').extract_first()
                        updated = lic.xpath('./td[@data-title="Updated"]/text()').extract_first()
                        Liecense_list.append(f"{state}--{status}--{origin}--{updated}")
                    Liecense = '||'.join(Liecense_list)
                except Exception as e:
                    print(e)
                    # Liecense = ''
                try:
                    Work_Experience_list = []
                    work_exp_selector = response.xpath('//*[text()="Work Experience"]/../table/tbody/tr')
                    for work in work_exp_selector:
                        raw_work = work.xpath('./th/text()').extract_first()
                        company_name = work.xpath('./td[@data-title="Company name"]/text()').extract_first()
                        duration = work.xpath('./td[@data-title="Duration"]/text()').extract_first()
                        Work_Experience_list.append(f"{raw_work}--{company_name}--{duration}")
                    if work_exp_selector.xpath('./../../../div'):
                        work_exp_selector2 = work_exp_selector.xpath('./../../../div/table/tbody/tr')
                        for work2 in work_exp_selector2:
                            raw_work2 = work2.xpath('./th/text()').extract_first()
                            company_name2 = work2.xpath('./td[@data-title="Company name"]/text()').extract_first()
                            duration2 = work2.xpath('./td[@data-title="Duration"]/text()').extract_first()
                            Work_Experience_list.append(f"{raw_work2}--{company_name2}--{duration2}")
                    Work_Experience = '||'.join(Work_Experience_list)
                except Exception as e:
                    print(e)
                    # Work_Experience = ''
                try:
                    Education_list = []
                    education_selector = response.xpath('//*[text()="Education"]/../table/tbody/tr')
                    for edu in education_selector:
                        raw_edu = edu.xpath('./th/text()').extract_first()
                        degree = edu.xpath('./td[@data-title="Degree"]/text()').extract_first()
                        graduated = edu.xpath('./td[@data-title="Graduated"]/text()').extract_first()
                        Education_list.append(f"{raw_edu}--{degree}--{graduated}")
                    Education = '||'.join(Education_list)
                except Exception as e:
                    print(e)
                    # Education = ''
                try:
                    Awards_list = []
                    awards_selector = response.xpath('//*[text()="Awards"]/../table/tbody/tr')
                    for awa in awards_selector:
                        raw_awa = awa.xpath('./th/text()').extract_first()
                        grantor = awa.xpath('./td[@data-title="Grantor"]/text()').extract_first()
                        date_granted = awa.xpath('./td[@data-title="Date granted"]/text()').extract_first()
                        Awards_list.append(f"{raw_awa}--{grantor}--{date_granted}")

                    if awards_selector.xpath('./../../../div'):
                        # awards_selector2 = awards_selector.xpath('//*[text()="Awards"]/../table/tbody/tr/../../../div/table/tbody/tr')
                        awards_selector2 = awards_selector.xpath('./../../following-sibling::div/table/tbody/tr')
                        for awa2 in awards_selector2:
                            raw_awa2 = awa2.xpath('./th/text()').extract_first()
                            grantor2 = awa2.xpath('./td[@data-title="Grantor"]/text()').extract_first()
                            date_granted2 = awa2.xpath('./td[@data-title="Date granted"]/text()').extract_first()
                            tmp = f"{raw_awa2}--{grantor2}--{date_granted2}"
                            if tmp not in Awards_list:
                                Awards_list.append(f"{raw_awa2}--{grantor2}--{date_granted2}")
                    Awards = '||'.join(Awards_list)
                except Exception as e:
                    print(e)
                    # Awards = ''
                try:
                    languages_list = []
                    languages = re.findall(r'languages&quot;:\[(.*?)\]\}', response.text)
                    if languages == ['']:
                        Languages = ''
                    else:
                        languages = languages[0].replace('&quot;','')
                        for lang in languages.split(','):
                            languages_list.append(lang)
                        Languages = ','.join(languages_list)
                except Exception as e:
                    print(e)
                    # Languages = ''
                try:
                    fee_flag = True
                    Fees_and_Payment_Type_list = []
                    Fees_and_Payment_Type_text = re.findall(r'data-react-class="components/CostsSection"(.*?)data-hydrate', response.text)[0]
                    Fees_and_Payment_Type_data = re.findall(r'="(.*?)"', Fees_and_Payment_Type_text)[0].replace('&quot;', '"')
                    Fees_and_Payment_Type_json = json.loads(Fees_and_Payment_Type_data)
                    Fee_path = f"D:\khyati-H\CRM\Project VM\Avvo.com\HTML\json\Fee_duplicate\\{Id}.json"
                    with open(Fee_path, 'w', encoding='utf-8') as f:
                        f.write(Fees_and_Payment_Type_data)
                        f.close()
                    print('page save done Fee')
                    if Fees_and_Payment_Type_json['fees'] == []:
                        if Fees_and_Payment_Type_json['free_consultation'] != None:
                            free_consultation = Fees_and_Payment_Type_json['free_consultation']
                            Fees_and_Payment_Type_list.append(f"Fees: Free consultation ({free_consultation} minutes)")
                            fee_flag = False
                            # Fees_and_Payment_Type['Fees'] = f"Free consultation ({free_consultation} minutes)"
                    else:
                        if len(Fees_and_Payment_Type_json['fees']) == 1:
                            min_rate = str(Fees_and_Payment_Type_json['fees'][0]['min_rate'])
                            max_rate = str(Fees_and_Payment_Type_json['fees'][0]['max_rate'])
                            name = Fees_and_Payment_Type_json['fees'][0]['name']
                            Fees_and_Payment_Type_list.append(f"Fees: {name} (${min_rate}-{max_rate}/hour)")
                            # Fees_and_Payment_Type['Fees'] = f"{name} (${min_rate}-{max_rate}/hour)"
                        else:
                            for feei in Fees_and_Payment_Type_json['fees']:
                                min_rate = str(feei['min_rate'])
                                max_rate = str(feei['max_rate'])
                                name = feei['name']
                                Fees_and_Payment_Type_list.append(f"Fees: {name} (${min_rate}-{max_rate}/hour)")
                    if fee_flag:
                        if Fees_and_Payment_Type_json['free_consultation'] != None:
                            free_consultation = Fees_and_Payment_Type_json['free_consultation']
                            Fees_and_Payment_Type_list.append(f"Fees: Free consultation ({free_consultation} minutes)")
                    if 'PAYMENT METHODS' in response.text:
                        payment_types = Fees_and_Payment_Type_json['payment_types']
                        Fees_and_Payment_Type_list.append(f'Payment types: {",".join(payment_types)}')
                        # Fees_and_Payment_Type['Payment types'] = ','.join(payment_types)
                    Fees_and_Payment_Type = '||'.join(Fees_and_Payment_Type_list)
                except Exception as e:
                    print(e)
                    # Fees_and_Payment_Type = ''
                try:
                    # item['_id'] = int(hashlib.md5(bytes(response.meta['url'], encoding='utf8')).hexdigest(),16) % (10 ** 8)
                    item['Source_Link'] = response.meta['url']
                    item['Contact_Name'] = Contact_Name
                    item['First_Name'] = First_Name
                    item['Middle_Name'] = Middle_Name
                    item['Last_Name'] = Last_Name
                    # item['Image_URL'] = Image_URL
                    # item['Pimium_Member'] = Pimium_Member
                    item['Website'] = Website
                    # item['Review_Count'] = Review_Count
                    # item['Review_URL'] = Review_URL
                    # item['Endorsements_URL'] = Endorsements_URL
                    # item['Contribution_URL'] = Contribution_URL
                    item['Fees_and_Payment_Type'] = Fees_and_Payment_Type
                    item['Bussines_Name'] = Bussines_Name
                    item['Street_Address'] = Street_Address
                    item['City'] = City
                    item['State'] = State
                    item['Phone'] = Phone
                    # item['Fax'] = Fax
                    # item['FaceBook'] = FaceBook
                    # item['Twitter'] = Twitter
                    # item['Google +'] = Google
                    # item['Linked In'] = Linked_In
                    item['Languages'] = Languages
                    # item['Aboutme_URL'] = Aboutme_URL
                    # item['Aboutme'] = Aboutme
                    # item['Endosment_Count'] = Endosment_Count
                    # item['Endorsement_Comment'] = Endorsement_Comment
                    item['Liecense'] = Liecense
                    item['Work_Experience'] = Work_Experience
                    item['Education'] = Education
                    item['Awards'] = Awards
                    item['path'] = path
                    item['practise_path'] = practise_path
                    item['overview_path'] = overview_path
                    item['contact_path'] = contact_path
                    item['Fee_path'] = Fee_path
                    # item['Association'] = Association
                    # item['Case'] = Case
                    # item['Case_URL'] = Case_URL
                    # item['Publication'] = Publication
                    # item['Speaking_Engagements'] = Speaking_Engagements
                    # item['Category_tree'] = Category_tree
                    # item['Social_Tools_1'] = Social_Tools_1
                    # item['Social_Tools_2'] = Social_Tools_2
                    # item['Social_Tools_3'] = Social_Tools_3
                    # item['Social_Tools_4'] = Social_Tools_4
                    # item['Social_Tools_5'] = Social_Tools_5
                    # item['Practice_Area'] = Practice_Area
                    # item['Status'] = 'pending'
                    item['_id'] = int(hashlib.md5(bytes(response.meta['url']+Id+idt, "utf8")).hexdigest(), 16) % (10 ** 8)
                    try:
                        self.Data.insert(item)
                        print("Data inserted....")
                        self.Final_link.update({'_id': Id}, {'$set': {'Status': 'Done1'}}, upsert=False)
                        print('update done')
                        self.cursor.execute(f'''update avvo_lawyer.final_link set status="Done1" where Iid="{Id}"''')
                        self.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)

# execute('scrapy crawl data -a table_name=Data_9 -a start=0 -a end=158192'.split())

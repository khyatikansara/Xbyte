# -*- coding: utf-8 -*-
import hashlib
import json
import re

from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
from selenium import webdriver
import time
from lxml import html


class NextLinkSpider(scrapy.Spider):
    name = 'next_links'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]
    start,end = '',''

    def __init__(self, table_name='', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.data = self.db[f'Lawyer_Main_link']
        self.data1 = self.db[f'Lawyer_Less_count_Duplicate']
        self.Next_link = self.db[f'Lawyer_{table_name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            # self.data.update_many({'next_count': 1}, {'$set': {'Status': 'pending'}}, upsert=False)
            # links = self.data.find({"$and":[{"State":"OH"},{"Status":"baki"}]}, no_cursor_timeout=True)
            # print(self.data.find({"$and":[{"State":"OH"},{"Status":"baki"}]}).count())
            links = self.data1.find({"Status": "pending"}, no_cursor_timeout=True)
            print(self.data1.find({"Status": "pending"}).count())
            options = webdriver.ChromeOptions()
            # options.add_argument("--headless")
            driver = webdriver.Chrome(chrome_options=options)  # Optional argument, if not specified will search path.
            # driver.maximize_window()
            for link in links:
                _id = link['_id']
                # url = link['New_York']
                url = link['client_url']
                driver.get(url)
                time.sleep(10)
                # response = driver.page_source
                # path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NC\\{_id}.html'
                # file = open(path, 'w', encoding='utf-8')
                # file.write(response)
                # file.close()
                # print("page save done")
                # item = AvvoLawyerItem()
                # Link = driver.current_url
                # item['Link'] = Link
                # item['path'] = path
                # item['Status'] = 'pending'
                # item['_id'] = int(hashlib.md5(bytes(Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                # try:
                #     self.Next_link.insert(item)
                #     print("Data inserted....")
                # except Exception as e:
                #     print(e)
                page = 430
                while True:
                    path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NY\\{_id}_{page}.html'
                    page += 1
                    file_open = open(path, 'r', encoding='utf-8')
                    file1 = file_open.read()
                    file_open.close()
                    response_f = html.fromstring(file1)
                    # element = driver.find_element_by_xpath('//li[@class="pagination-next"]')
                    # driver.execute_script("arguments[0].scrollIntoView();", element)
                    next_page = response_f.xpath('//li[@class="pagination-next"]/a/@href')
                    if next_page != []:
                        next_url = f"https://www.avvo.com{next_page[0]}"
                        driver.get(next_url)
                        time.sleep(10)
                        response = driver.page_source
                        path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NY\\{_id}_{page}.html'
                        file = open(path, 'w', encoding='utf-8')
                        file.write(response)
                        file.close()
                        print("page save done")
                        item = AvvoLawyerItem()
                        Link = driver.current_url
                        item['Link'] = Link
                        item['path'] = path
                        item['Status'] = 'pending'
                        item['_id'] = int(hashlib.md5(bytes(Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                        try:
                            self.Next_link.insert(item)
                            print("Data inserted....")
                        except Exception as e:
                            print(e)
                    else:
                        break
                    # break
                try:
                    self.data1.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
                    next_count = page-1
                    self.data.update({'_id': _id}, {'$set': {'next_count': next_count}}, upsert=False)
                except Exception as e:
                    print(e)

        except Exception as e:
            print(e)

# execute('scrapy crawl next_links -a table_name=Next_link'.split())

# -*- coding: utf-8 -*-
import hashlib
import json
import os
import re
import numpy as np
from lxml import html
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from avvo_lawyer.items import AvvoLawyerItem
from avvo_lawyer.mongoexport import export
import pymongo
import pandas as pd


class FinalLinkSpider(scrapy.Spider):
    name = 'final_link'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, table_name='', **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['Avvo_Lawyer']
        self.data = self.db[f'Lawyer_{table_name}']
        self.Next_link = self.db[f'Lawyer_Next_link']
        self.Final_link = self.db[f'Lawyer_{table_name}']

    def start_requests(self):
        try:
            # rgx = re.compile('.*bankruptcy-debt-lawyer/nc.*', re.IGNORECASE)
            # self.Final_link.find({"next_url": rgx})
            links = self.Next_link.find({"Status": "pending"}, no_cursor_timeout=True)
            print(self.Next_link.find({"Status": "pending"}).count())
            for link in links:
                try:
                    _id = link['_id']
                    next_url = link['Link']
                    path = link['path']
                    File = path.split('\\')[-1]
                    ny_path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NY\\{File}'
                    nc_path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\NC\\{File}'
                    oh_path = f'D:\khyati-H\CRM\Project VM\Avvo.com\HTML\Main\\OH\\{File}'
                    if os.path.exists(ny_path):
                        path = ny_path
                    elif os.path.exists(nc_path):
                        path = nc_path
                    elif os.path.exists(oh_path):
                        path = oh_path
                    else:
                        print(path)
                        path = path.replace('Main\\NC\\', 'Main\\OH\\')
                    # if "\\OH\\" not in path:
                    #     if "\\OH\\" not in path:
                    #         if "\\NC\\" not in path:
                    #             if "\\NY\\" not in path:
                    #                 path = path.replace('Main\\','Main\\NY\\')
                    try:
                        file_open = open(path, 'r', encoding='utf-8')
                        file1 = file_open.read()
                        file_open.close()
                    except Exception as e:
                        print(e)
                    lawyer_links = re.findall(r'"url": "(.*?)"',file1)
                    inserted_link = 0
                    for lawyer_link in lawyer_links:
                        lawyer_link = f"https://www.avvo.com{lawyer_link}"
                        item = AvvoLawyerItem()
                        item['Lawyer_link'] = lawyer_link
                        item['next_url'] = next_url
                        item['Status'] = 'pending'
                        # item['_id'] = int(hashlib.md5(bytes(lawyer_link, "utf8")).hexdigest(), 16) % (10 ** 8)
                        try:
                            self.Final_link.insert(item)
                            print("Data inserted....")
                            inserted_link += 1
                        except Exception as e:
                            print(e)
                    try:
                        self.Next_link.update({'_id': _id}, {'$set': {'Status': 'Done1'}}, upsert=False)
                        total_links = len(lawyer_links)
                        self.Next_link.update({'_id': _id}, {'$set': {'total_links': total_links}}, upsert=False)
                        self.Next_link.update({'_id': _id}, {'$set': {'inserted_links': inserted_link}}, upsert=False)
                    except Exception as e:
                        print(e)
                    # else:
                    #     print(path)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    # def start_requests(self):
    #     try:
    #         df_next = pd.read_csv("D:\khyati-H\CRM\Project VM\Avvo.com\Lawyer_Next_link.csv")
    #         df_missing = pd.read_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Missing_Avvo_Laywers_Counts.xlsx")
    #         df_next = df_next.fillna('')
    #         df_missing = df_missing.fillna('')
    #         for index, row in df_missing.iterrows():
    #             print(index)
    #             client_url = row['client_url']
    #             find_url = '/'.join(client_url.split('/')[3:])
    #             tmp_next = df_next.query(f'Link.str.contains("{find_url}")', engine='python')
    #             tmp_less_next = np.where(tmp_next['total_links'] != tmp_next['inserted_links'])
    #             print(tmp_less_next[0])
    #
    #             for i in tmp_less_next[0]:
    #                 if '/ny' in client_url:
    #                     path = tmp_next.iloc[i]['path']
    #                     if '\\NY\\' not in path:
    #                         path = tmp_next.iloc[i]['path'].replace('\\Main\\','\\Main\\NY\\')
    #                 elif '/oh' in client_url:
    #                     path = tmp_next.iloc[i]['path']
    #                 elif '/nc' in client_url:
    #                     path = tmp_next.iloc[i]['path']
    #                 else:
    #                     print("NO FILE")
    #                 try:
    #                     file_open = open(path, 'r', encoding='utf-8')
    #                     file1 = file_open.read()
    #                     file_open.close()
    #                 except Exception as e:
    #                     print(e)
    #                 lawyer_links = re.findall(r'"url": "(.*?)"',file1)
    #                 inserted_link = 0
    #                 for lawyer_link in lawyer_links:
    #                     lawyer_link = f"https://www.avvo.com{lawyer_link}"
    #                     item = AvvoLawyerItem()
    #                     item['Lawyer_link'] = lawyer_link
    #                     item['next_url'] = client_url
    #                     item['Status'] = 'pending'
    #                     item['_id'] = int(hashlib.md5(bytes(lawyer_link, "utf8")).hexdigest(), 16) % (10 ** 8)
    #                     try:
    #                         self.Final_link.insert(item)
    #                         print("Data inserted....")
    #                         inserted_link += 1
    #                     except Exception as e:
    #                         print(e)
    #
    #         # self.Next_link.update_many({}, {'$set': {'Status': 'pending'}}, upsert=False)
    #         links = self.Next_link.find({"Status": "pending"}, no_cursor_timeout=True)
    #         print(self.Next_link.find({"Status": "pending"}).count())
    #         for link in links:
    #             try:
    #                 _id = link['_id']
    #                 next_url = link['Link']
    #                 path = link['path']
    #                 if os.path.exists(path):
    #                     print(path)
    #                 else:
    #                     print(path)
    #                     path = path.replace('Main\\NC\\', 'Main\\OH\\')
    #                 # if "\\OH\\" not in path:
    #                 #     if "\\OH\\" not in path:
    #                 #         if "\\NC\\" not in path:
    #                 #             if "\\NY\\" not in path:
    #                 #                 path = path.replace('Main\\','Main\\NY\\')
    #                 try:
    #                     file_open = open(path, 'r', encoding='utf-8')
    #                     file1 = file_open.read()
    #                     file_open.close()
    #                 except Exception as e:
    #                     print(e)
    #                 lawyer_links = re.findall(r'"url": "(.*?)"',file1)
    #                 inserted_link = 0
    #                 for lawyer_link in lawyer_links:
    #                     lawyer_link = f"https://www.avvo.com{lawyer_link}"
    #                     item = AvvoLawyerItem()
    #                     item['Lawyer_link'] = lawyer_link
    #                     item['next_url'] = next_url
    #                     item['Status'] = 'pending'
    #                     item['_id'] = int(hashlib.md5(bytes(lawyer_link, "utf8")).hexdigest(), 16) % (10 ** 8)
    #                     try:
    #                         self.Final_link.insert(item)
    #                         print("Data inserted....")
    #                         inserted_link += 1
    #                     except Exception as e:
    #                         print(e)
    #                 try:
    #                     self.Next_link.update({'_id': _id}, {'$set': {'Status': 'Done'}}, upsert=False)
    #                     total_links = len(lawyer_links)
    #                     self.Next_link.update({'_id': _id}, {'$set': {'total_links': total_links}}, upsert=False)
    #                     self.Next_link.update({'_id': _id}, {'$set': {'inserted_links': inserted_link}}, upsert=False)
    #                 except Exception as e:
    #                     print(e)
    #                 # else:
    #                 #     print(path)
    #             except Exception as e:
    #                 print(e)
    #     except Exception as e:
    #         print(e)

# execute('scrapy crawl final_link -a table_name=Final_link_Duplicate'.split())
import pandas as pd


def missing():
    try:
        df_client = pd.read_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Avvo_Laywers_Counts.xlsx")
        df_my = pd.read_csv("D:\khyati-H\CRM\Project VM\Avvo.com\Lawyer1_Final_link_Duplicate_full.csv")
        df_client = df_client.fillna('')
        df_my = df_my.fillna('')
        list = []
        for index, row in df_client.iterrows():
            print(index)
            count_my = 0
            State = row['State']
            if State != '':
                New_York = row['New York']
                count_client = row['Count']
                find_url = '/'.join(New_York.split('/')[3:])
                tmep = df_my.query(f'next_url.str.contains("{find_url}")', engine='python')
                count_my = tmep.shape[0]
                difference = count_client-count_my
                list.append([New_York,count_client,count_my,difference])
        gh = pd.DataFrame(list, columns=['client_url', 'count_client', 'count_my', 'difference'])
        gh.to_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Missing1_Avvo_Laywers_Counts_duplicate_full.xlsx", index=True)
        print("D:\khyati-H\CRM\Project VM\Avvo.com\Missing1_Avvo_Laywers_Counts_duplicate_full.xlsx")
    except Exception as e:
        print(e)

# missing()

def remove_duplicate():
    df_copy = pd.read_excel("D:\khyati-H\CRM\Project VM\Avvo.com\Files\Avvo_Lawyer_157223_copy.xlsx")
    df_copy = df_copy.fillna('')
    list = []

    for index, row in df_copy.iterrows():
        print(index)
        Street_Address1 = []
        City1 = []
        State1 = []
        Phone1 = []
        Id = row['Id']
        Street_Address = row['Street_Address']
        City = row['City']
        State = row['State']
        Phone = row['Phone']
        Street_Address_list = Street_Address.split('||')
        for st in Street_Address_list:
            if st not in Street_Address1:
                Street_Address1.append(st)
        City_list = City.split('||')
        for c in City_list:
            if c not in City1:
                City1.append(c)
        State_list = State.split('||')
        for sta in State_list:
            if sta not in State1:
                State1.append(sta)
        Phone_list = Phone.split('||')
        for p in Phone_list:
            if p not in Phone1:
                Phone1.append(p)






# remove_duplicate()
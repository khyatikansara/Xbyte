# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# from datetime import timedelta
from datetime import date, timedelta, datetime
from openpyxl import load_workbook
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd
import sqlalchemy as db
# from sqlalchemy_utils import database_exists, create_database
from vetsuccess.db_config import *
from vetsuccess.items import Vetsuccess_Revenue_Item, Vetsuccess_Invoice_Item, Vetsuccess_Revenue_per_Practice_Item, \
    Growth_In_Revenue_And_Visits_Item, YOY_Percentages_Item


# import datetime

class VetsuccessPipeline(object):
    data_insert_1 = 0

    def __init__(self):
        try:
            # connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(
            #     drivername=driver_name, user=db_username, passwd=db_password, host=db_host, port=db_port, dbname=db_name
            # )

            self.connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(
                drivername=driver_name, user=db_user, passwd=db_password, host=db_host, port=db_port, dbname=db_name)
            self.connection_string += '?driver=ODBC+Driver+17+for+SQL+Server'

            self.engine = db.create_engine(self.connection_string)

            # try:
            #     if not database_exists(self.engine.url):
            #         create_database(self.engine.url)
            # except Exception as e:
            #     print('Problem in Database creation', e)

            metadata = db.MetaData()
            self.connect = self.connect = self.engine.connect()
            self.Vetsuccess_Revenue = db.Table(
                Vetsuccess_Revenue, metadata,
                db.Column('Date', db.String(255), primary_key=True),
                db.Column('Last_Year_Revenue', db.String(255)),
                db.Column('This_Year_Revenue', db.String(255)),
                db.Column('Revenue_YOY_Change', db.String(255)),
                db.Column("Rolling_7_Days_Revenue", db.String(255)),

            )
            self.Vetsuccess_Invoice = db.Table(
                Vetsuccess_Invoice, metadata,
                db.Column('Date', db.String(255), primary_key=True),

                db.Column('Last_Year_Invoice', db.String(255)),
                db.Column('This_Year_Invoice', db.String(255)),
                db.Column('Invoices_YOY_Changes', db.String(255)),
                db.Column('Rolling_7_Days_Invoice', db.String(255)),

            )
            self.Vetsuccess_Revenue_Per_Practice = db.Table(
                Vetsuccess_Revenue_Per_Practice, metadata,
                db.Column('Date', db.String(255), primary_key=True),
                db.Column('Last_Year_Revenue', db.String(255)),
                db.Column('This_Year_Revenue', db.String(255)),

            )

            self.Growth_In_Revenue_And_Visits = db.Table(
                Growth_In_Revenue_And_Visits, metadata,
                db.Column('Date', db.String(255), primary_key=True),
                db.Column('Revenue_YOY', db.String(255)),
                db.Column('Visits_YOY', db.String(255)),

            )

            self.YOY_Percentages = db.Table(
                YOY_Percentages, metadata,
                db.Column('Date', db.String(255), primary_key=True),
                db.Column('Heart_Worm_YOY', db.String(255)),
                db.Column('Services_YOY', db.String(255)),
                db.Column('Flea_Tick_YOY', db.String(255)),
                db.Column('Products_YOY', db.String(255)),

            )
            self.summary_table = db.Table(DB_table_summary, metadata,
                                          db.Column('script', db.Text),
                                          db.Column('process_date', db.Text),
                                          db.Column('start_time', db.Text),
                                          db.Column('end_time', db.Text),
                                          db.Column('duration', db.Text))
            metadata.create_all(self.engine)
        except Exception as e:
            print("_init_", e)

    def process_item(self, item, spider):

        if isinstance(item, Vetsuccess_Revenue_Item):
            try:
                query = db.insert(self.Vetsuccess_Revenue)
                self.connect.execute(query, dict(item))
                self.data_insert_1 += 1
                print('data count ... ', self.data_insert_1)
            except Exception as e:
                print(e)
        if isinstance(item, Vetsuccess_Invoice_Item):
            try:
                query = db.insert(self.Vetsuccess_Invoice)
                self.connect.execute(query, dict(item))
                self.data_insert_1 += 1
                print('data count ... ', self.data_insert_1)
            except Exception as e:
                print(e)

        if isinstance(item, Vetsuccess_Revenue_per_Practice_Item):
            try:
                query = db.insert(self.Vetsuccess_Revenue_Per_Practice)
                self.connect.execute(query, dict(item))
                self.data_insert_1 += 1
                print('data count ... ', self.data_insert_1)
            except Exception as e:
                print(e)

        if isinstance(item, Growth_In_Revenue_And_Visits_Item):
            try:
                query = db.insert(self.Growth_In_Revenue_And_Visits)
                self.connect.execute(query, dict(item))
                self.data_insert_1 += 1
                print('data count ... ', self.data_insert_1)
            except Exception as e:
                print(e)

        if isinstance(item, YOY_Percentages_Item):
            try:
                query = db.insert(self.YOY_Percentages)
                self.connect.execute(query, dict(item))
                self.data_insert_1 += 1
                print('data count ... ', self.data_insert_1)
            except Exception as e:
                print(e)

        return item

    def close_spider(self, spider):
        try:

            if 'vetsuccess_Revenue_crawler' in spider.name:

                try:
                    stat = spider.crawler.stats.get_stats()
                    start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                    end_time = datetime.datetime.now()
                    duration = end_time - start_time
                    summary_dict = {
                        "start_time": str(start_time),
                        "end_time": str(end_time),
                        "script": spider.name,
                        "process_date": str(datetime.datetime.today()).split()[0],
                        "duration": str(duration),
                    }
                    query = db.insert(self.summary_table)
                    self.connect.execute(query, dict(summary_dict))


                except Exception as e:
                    print(e)

            if 'vetsuccess_Invoice_crawler' in spider.name:
                try:
                    stat = spider.crawler.stats.get_stats()
                    start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                    end_time = datetime.datetime.now()
                    duration = end_time - start_time
                    summary_dict = {
                        "start_time": str(start_time),
                        "end_time": str(end_time),
                        "script": spider.name,
                        "process_date": str(datetime.datetime.today()).split()[0],
                        "duration": str(duration),
                    }
                    query = db.insert(self.summary_table)
                    self.connect.execute(query, dict(summary_dict))

                except Exception as e:
                    print(e)

                if 'Revenue_Per_Practice_crawler' in spider.name:

                    try:
                        stat = spider.crawler.stats.get_stats()
                        start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                        end_time = datetime.datetime.now()
                        duration = end_time - start_time
                        summary_dict = {
                            "start_time": str(start_time),
                            "end_time": str(end_time),
                            "script": spider.name,
                            "process_date": str(datetime.datetime.today()).split()[0],
                            "duration": str(duration),
                        }
                        query = db.insert(self.summary_table)
                        self.connect.execute(query, dict(summary_dict))


                    except Exception as e:
                        print(e)

                if 'YOY_Percentages_crawler' in spider.name:

                    try:
                        stat = spider.crawler.stats.get_stats()
                        start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                        end_time = datetime.datetime.now()
                        duration = end_time - start_time
                        summary_dict = {
                            "start_time": str(start_time),
                            "end_time": str(end_time),
                            "script": spider.name,
                            "process_date": str(datetime.datetime.today()).split()[0],
                            "duration": str(duration),
                        }
                        query = db.insert(self.summary_table)
                        self.connect.execute(query, dict(summary_dict))


                    except Exception as e:
                        print(e)

                if 'Growth_In_Revenue_And_Visits_crawler' in spider.name:

                    try:
                        stat = spider.crawler.stats.get_stats()
                        start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                        end_time = datetime.datetime.now()
                        duration = end_time - start_time
                        summary_dict = {
                            "start_time": str(start_time),
                            "end_time": str(end_time),
                            "script": spider.name,
                            "process_date": str(datetime.datetime.today()).split()[0],
                            "duration": str(duration),
                        }
                        query = db.insert(self.summary_table)
                        self.connect.execute(query, dict(summary_dict))


                    except Exception as e:
                        print(e)

        except Exception as e:
            print("close_spider", e, )

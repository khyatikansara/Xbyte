import os
import platform
from datetime import date
import datetime
dt = datetime.datetime.today()
day_of_month = dt.day
# db_host = "localhost"
# db_port ="3306"
# db_user = "root"
# db_password = "xbyte"
# db_name = "Vetsuccess"
# driver_name = "mysql+pymysql"
#
db_host = "bc5756vevd.database.windows.net"
db_user = "xbyte"
db_password = "X1b1y1t1e1"
db_name = "XBYTE"
db_port = "1433"
driver_name = "mssql+pyodbc"

NumberOfWeek = (day_of_month - 1) // 7 + 1

runon = str(dt.month)+"_"+str(NumberOfWeek)
Vetsuccess_Revenue = "Vetsuccess_Revenue"

Vetsuccess_Invoice = "Vetsuccess_Invoice"

Vetsuccess_Revenue_Per_Practice = "Vetsuccess_Revenue_Per_Practice"

Growth_In_Revenue_And_Visits = "Growth_In_Revenue_And_Visits"

YOY_Percentages = "YOY_Percentages"



DB_table_summary = "Vetsuccess_summary"

current_directory = os.path.dirname(os.path.abspath(__file__))


if str(platform.system()).lower() == 'windows':
    output_directory = current_directory + '\\' + "OutPut" + '\\' + runon + '\\'
else:
    output_directory = current_directory + '/'+"OutPut"+ '/' + runon+ '/'

if not os.path.exists(output_directory):
    os.makedirs(output_directory)
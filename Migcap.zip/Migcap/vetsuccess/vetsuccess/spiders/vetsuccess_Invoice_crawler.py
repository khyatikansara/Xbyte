# -*- coding: utf-8 -*-
import json
import scrapy
import requests
from vetsuccess.items import Vetsuccess_Revenue_Item, Vetsuccess_Invoice_Item
from datetime import datetime

class VetsuccessCrawlerSpider(scrapy.Spider):
    name = 'vetsuccess_Invoice_crawler'
    allowed_domains = ['www.example.com']
    start_urls = ['http://www.example.com/']

    def parse(self, response):

        try:

            url = "https://wabi-west-us-api.analysis.windows.net/public/reports/querydata"

            querystring = {"synchronous": "true"}

            payload = "{\"version\":\"1.0.0\",\"queries\":[{\"Query\":{\"Commands\":[{\"SemanticQueryDataShapeCommand\":{\"Query\":{\"Version\":2,\"From\":[{\"Name\":\"d\",\"Entity\":\"dates\",\"Type\":0},{\"Name\":\"d4\",\"Entity\":\"daily_tracker_inv_analytics\",\"Type\":0},{\"Name\":\"d1\",\"Entity\":\"daily_tracker_practices\",\"Type\":0}],\"Select\":[{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"},\"Name\":\"dates.record_date\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d4\"}},\"Property\":\"Last Year Invoices Per Practice\"},\"Name\":\"daily_tracker_inv_analytics.Last Year Invoices Per Practice\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d4\"}},\"Property\":\"This Year Invoices Per Practice\"},\"Name\":\"daily_tracker_inv_analytics.This Year Invoices Per Practice\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d4\"}},\"Property\":\"Rolling 7 Days Invoice\"},\"Name\":\"daily_tracker_inv_analytics.Rolling 7 Days Invoice\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d4\"}},\"Property\":\"Invoices YoY Change\"},\"Name\":\"daily_tracker_inv_analytics.Invoices YoY Change\"}],\"Where\":[{\"Condition\":{\"Between\":{\"Expression\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"}},\"LowerBound\":{\"DateSpan\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"Now\":{}},\"Amount\":-1,\"TimeUnit\":0}},\"Amount\":1,\"TimeUnit\":0}},\"Amount\":-1000,\"TimeUnit\":0}},\"TimeUnit\":0}},\"UpperBound\":{\"DateSpan\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"Now\":{}},\"Amount\":-1,\"TimeUnit\":0}},\"TimeUnit\":0}}}}},{\"Condition\":{\"Comparison\":{\"ComparisonKind\":2,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"}},\"Right\":{\"DateSpan\":{\"Expression\":{\"Literal\":{\"Value\":\"datetime'2020-01-12T00:00:00'\"}},\"TimeUnit\":5}}}}},{\"Condition\":{\"And\":{\"Left\":{\"Not\":{\"Expression\":{\"Comparison\":{\"ComparisonKind\":0,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"id\"}},\"Right\":{\"Literal\":{\"Value\":\"5388L\"}}}}}},\"Right\":{\"Not\":{\"Expression\":{\"Comparison\":{\"ComparisonKind\":0,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"id\"}},\"Right\":{\"Literal\":{\"Value\":\"3884L\"}}}}}}}}}]},\"Binding\":{\"Primary\":{\"Groupings\":[{\"Projections\":[0,1,2,3,4]}]},\"DataReduction\":{\"DataVolume\":4,\"Primary\":{\"Sample\":{}}},\"SuppressedJoinPredicates\":[4],\"Version\":1}}}]},\"QueryId\":\"\",\"ApplicationContext\":{\"DatasetId\":\"69133f10-832b-44ad-8f92-a7cd11c1c435\",\"Sources\":[{\"ReportId\":\"da789a59-5d00-47f6-b336-c1ebcaf617b4\"}]}}],\"cancelQueries\":[],\"modelId\":7188174}"
            headers = {
                'accept': "application/json, text/plain, */*",
                'accept-encoding': "gzip, deflate, br",
                'accept-language': "en-US,en;q=0.9",
                'activityid': "f3ed1089-2207-4013-be71-0fc587c08582",
                'content-type': "application/json;charset=UTF-8",
                'host': "wabi-west-us-api.analysis.windows.net",
                'origin': "https://app.powerbi.com",
                'referer': "https://app.powerbi.com/view?r=eyJrIjoiODk3YTJhODUtZTE4NC00M2JlLTlkZTMtYzI2NzVmMGYxODE2IiwidCI6IjM1MWRjNzUyLTM3NGItNDdlMS1hMWNkLWE3NDE5Y2NhZWI5NCIsImMiOjZ9",
                'requestid': "8b004a33-9b0d-77b9-5557-2d7a9af6cf62",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'sec-fetch-site': "cross-site",
                'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36",
                'x-powerbi-resourcekey': "897a2a85-e184-43be-9de3-c2675f0f1816",
                'cache-control': "no-cache",
                'postman-token': "d2324a38-0a0c-192c-dbfc-913459de2574"
            }

            response = requests.request("POST", url, data=payload, headers=headers, params=querystring)
            data = json.loads(response.text)
            dmo = data['results'][0]['result']['data']['dsr']['DS'][0]['PH'][0]['DM0']
            le = len(dmo)
            for i in range(0,le):
                # break
                try:
                    datetmp = dmo[i]['C'][0]
                    timestamp = int(datetmp/1000)
                    dt_object = datetime.fromtimestamp(timestamp)
                    Last_Year_Revenue = dmo[i]['C'][1]
                    This_Year_Revenue = dmo[i]['C'][2]
                    Invoices_YOY_Changes = float(dmo[i]['C'][4])*100
                    Rolling_7_Days_Invoice = float(dmo[i]['C'][3])*100

                    item = Vetsuccess_Invoice_Item()
                    item['Date'] = dt_object
                    item['Last_Year_Invoice'] = Last_Year_Revenue
                    item['This_Year_Invoice'] = This_Year_Revenue
                    item['Invoices_YOY_Changes'] = Invoices_YOY_Changes
                    item['Rolling_7_Days_Invoice'] = Rolling_7_Days_Invoice
                    yield item
                except Exception as e:
                    print("pass",e,datetmp)
        except Exception as e:
            print("parse",e,response.url)



# #
# from scrapy.cmdline import execute
# execute("scrapy crawl vetsuccess_Invoice_crawler".split())

# -*- coding: utf-8 -*-
import json
import scrapy
import requests
from vetsuccess.items import Vetsuccess_Revenue_Item, Vetsuccess_Invoice_Item, Vetsuccess_Revenue_per_Practice_Item, \
    Growth_In_Revenue_And_Visits_Item
from datetime import datetime


class Growth_In_Revenue_And_Visits_crawlerCrawlerSpider(scrapy.Spider):
    name = 'Growth_In_Revenue_And_Visits_crawler'
    allowed_domains = ['www.example.com']
    start_urls = ['http://www.example.com/']

    def parse(self, response):

        try:

            url = "https://wabi-west-us-api.analysis.windows.net/public/reports/querydata"

            querystring = {"synchronous": "true"}

            payload = "{\"version\":\"1.0.0\",\"queries\":[{\"Query\":{\"Commands\":[{\"SemanticQueryDataShapeCommand\":{\"Query\":{\"Version\":2,\"From\":[{\"Name\":\"r\",\"Entity\":\"rolling14\",\"Type\":0}],\"Select\":[{\"Aggregation\":{\"Expression\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"r\"}},\"Property\":\"rev_yoy\"}},\"Function\":0},\"Name\":\"Sum(rolling14.rev_yoy)\"},{\"Aggregation\":{\"Expression\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"r\"}},\"Property\":\"inv_yoy\"}},\"Function\":0},\"Name\":\"Sum(rolling14.inv_yoy)\"},{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"r\"}},\"Property\":\"transaction_date\"},\"Name\":\"rolling14.transaction_date\"}]},\"Binding\":{\"Primary\":{\"Groupings\":[{\"Projections\":[0,1,2]}]},\"DataReduction\":{\"DataVolume\":4,\"Primary\":{\"BinnedLineSample\":{}}},\"Version\":1}}}]},\"CacheKey\":\"{\\\"Commands\\\":[{\\\"SemanticQueryDataShapeCommand\\\":{\\\"Query\\\":{\\\"Version\\\":2,\\\"From\\\":[{\\\"Name\\\":\\\"r\\\",\\\"Entity\\\":\\\"rolling14\\\",\\\"Type\\\":0}],\\\"Select\\\":[{\\\"Aggregation\\\":{\\\"Expression\\\":{\\\"Column\\\":{\\\"Expression\\\":{\\\"SourceRef\\\":{\\\"Source\\\":\\\"r\\\"}},\\\"Property\\\":\\\"rev_yoy\\\"}},\\\"Function\\\":0},\\\"Name\\\":\\\"Sum(rolling14.rev_yoy)\\\"},{\\\"Aggregation\\\":{\\\"Expression\\\":{\\\"Column\\\":{\\\"Expression\\\":{\\\"SourceRef\\\":{\\\"Source\\\":\\\"r\\\"}},\\\"Property\\\":\\\"inv_yoy\\\"}},\\\"Function\\\":0},\\\"Name\\\":\\\"Sum(rolling14.inv_yoy)\\\"},{\\\"Column\\\":{\\\"Expression\\\":{\\\"SourceRef\\\":{\\\"Source\\\":\\\"r\\\"}},\\\"Property\\\":\\\"transaction_date\\\"},\\\"Name\\\":\\\"rolling14.transaction_date\\\"}]},\\\"Binding\\\":{\\\"Primary\\\":{\\\"Groupings\\\":[{\\\"Projections\\\":[0,1,2]}]},\\\"DataReduction\\\":{\\\"DataVolume\\\":4,\\\"Primary\\\":{\\\"BinnedLineSample\\\":{}}},\\\"Version\\\":1}}}]}\",\"QueryId\":\"\",\"ApplicationContext\":{\"DatasetId\":\"162f3151-6361-441a-aa34-c5fef4b1429c\",\"Sources\":[{\"ReportId\":\"571eab9c-5c1d-4988-8c45-8ebd8069e381\"}]}}],\"cancelQueries\":[],\"modelId\":7959083}"
            headers = {
                'accept': "application/json, text/plain, */*",
                'accept-encoding': "gzip, deflate, br",
                'accept-language': "en-US,en;q=0.9,zh-TW;q=0.8,zh;q=0.7",
                'content-type': "application/json;charset=UTF-8",
                'host': "wabi-west-us-api.analysis.windows.net",
                'origin': "https://app.powerbi.com",
                'referer': "https://app.powerbi.com/",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'requestid': "0a8b3344-51f4-3703-ba5e-a93a631ff985",
                'x-powerbi-resourcekey': "561d700c-5832-413e-8331-165af729873e",

                'sec-fetch-site': "cross-site",
                'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
                'cache-control': "no-cache",
                'postman-token': "8d82e972-c245-ab2b-5e0e-63da5f49e060"
            }

            response = requests.request("POST", url, data=payload, headers=headers, params=querystring)

            data = json.loads(response.text)
            dmo = data['results'][0]['result']['data']['dsr']['DS'][0]['PH'][0]['DM0']
            le = len(dmo)
            for i in range(0,le):
                try:
                    datetmp = dmo[i]['C'][0]
                    timestamp = int(datetmp/1000)
                    dt_object = datetime.fromtimestamp(timestamp)
                    Visits_YOY = dmo[i]['C'][2]
                    Revenue_YOY = dmo[i]['C'][1]
                    Visits_YOY = float(Visits_YOY) * 100
                    Revenue_YOY = float(Revenue_YOY) * 100
                    item = Growth_In_Revenue_And_Visits_Item()
                    item['Date'] = dt_object
                    item['Revenue_YOY'] = Revenue_YOY
                    item['Visits_YOY'] = Visits_YOY

                    yield item
                except Exception as e:
                    print("pass",e,datetmp)
        except Exception as e:
            print("parse",e,response.url)



if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl Growth_In_Revenue_And_Visits_crawler".split())

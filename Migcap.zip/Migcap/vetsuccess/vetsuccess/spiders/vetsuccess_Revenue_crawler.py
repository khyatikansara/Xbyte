# -*- coding: utf-8 -*-
import json
import scrapy
import requests
from vetsuccess.items import Vetsuccess_Revenue_Item
from datetime import datetime

class VetsuccessCrawlerSpider(scrapy.Spider):
    name = 'vetsuccess_Revenue_crawler'
    allowed_domains = ['www.example.com']
    start_urls = ['http://www.example.com/']

    def parse(self, response):

        try:

            url = "https://wabi-west-us-api.analysis.windows.net/public/reports/querydata"

            querystring = {"synchronous": "true"}

            payload = "{\"version\":\"1.0.0\",\"queries\":[{\"Query\":{\"Commands\":[{\"SemanticQueryDataShapeCommand\":{\"Query\":{\"Version\":2,\"From\":[{\"Name\":\"d\",\"Entity\":\"dates\",\"Type\":0},{\"Name\":\"d1\",\"Entity\":\"daily_tracker_rev_analytics\",\"Type\":0},{\"Name\":\"d11\",\"Entity\":\"daily_tracker_practices\",\"Type\":0}],\"Select\":[{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"},\"Name\":\"dates.record_date\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"Revenue Last Year Per Practice\"},\"Name\":\"daily_tracker_rev_analytics.Revenue Last Year Per Practice\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"Revenue This Year Per Practice\"},\"Name\":\"daily_tracker_rev_analytics.Revenue This Year Per Practice\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"Rev YoY Change\"},\"Name\":\"daily_tracker_rev_analytics.Rev YoY Change\"},{\"Measure\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d1\"}},\"Property\":\"Rolling 7 Days Rev\"},\"Name\":\"daily_tracker_rev_analytics.Rolling 7 Days Rev\"}],\"Where\":[{\"Condition\":{\"Comparison\":{\"ComparisonKind\":2,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"}},\"Right\":{\"DateSpan\":{\"Expression\":{\"Literal\":{\"Value\":\"datetime'2020-01-12T00:00:00'\"}},\"TimeUnit\":5}}}}},{\"Condition\":{\"Between\":{\"Expression\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d\"}},\"Property\":\"record_date\"}},\"LowerBound\":{\"DateSpan\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"Now\":{}},\"Amount\":-1,\"TimeUnit\":0}},\"Amount\":1,\"TimeUnit\":0}},\"Amount\":-1000,\"TimeUnit\":0}},\"TimeUnit\":0}},\"UpperBound\":{\"DateSpan\":{\"Expression\":{\"DateAdd\":{\"Expression\":{\"Now\":{}},\"Amount\":-1,\"TimeUnit\":0}},\"TimeUnit\":0}}}}},{\"Condition\":{\"And\":{\"Left\":{\"Not\":{\"Expression\":{\"Comparison\":{\"ComparisonKind\":0,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d11\"}},\"Property\":\"id\"}},\"Right\":{\"Literal\":{\"Value\":\"5388L\"}}}}}},\"Right\":{\"Not\":{\"Expression\":{\"Comparison\":{\"ComparisonKind\":0,\"Left\":{\"Column\":{\"Expression\":{\"SourceRef\":{\"Source\":\"d11\"}},\"Property\":\"id\"}},\"Right\":{\"Literal\":{\"Value\":\"3884L\"}}}}}}}}}]},\"Binding\":{\"Primary\":{\"Groupings\":[{\"Projections\":[0,1,2,3,4]}]},\"DataReduction\":{\"DataVolume\":4,\"Primary\":{\"Sample\":{}}},\"SuppressedJoinPredicates\":[3],\"Version\":1}}}]},\"QueryId\":\"\",\"ApplicationContext\":{\"DatasetId\":\"69133f10-832b-44ad-8f92-a7cd11c1c435\",\"Sources\":[{\"ReportId\":\"da789a59-5d00-47f6-b336-c1ebcaf617b4\"}]}}],\"cancelQueries\":[],\"modelId\":7188174}"
            headers = {
                'accept': "application/json, text/plain, */*",
                'accept-encoding': "gzip, deflate, br",
                'accept-language': "en-US,en;q=0.9",
                'activityid': "77b46938-8135-4ef6-b878-8bbb89fd1558",
                'connection': "keep-alive",
                'content-type': "application/json;charset=UTF-8",
                'host': "wabi-west-us-api.analysis.windows.net",
                'origin': "https://app.powerbi.com",
                'referer': "https://app.powerbi.com/view?r=eyJrIjoiODk3YTJhODUtZTE4NC00M2JlLTlkZTMtYzI2NzVmMGYxODE2IiwidCI6IjM1MWRjNzUyLTM3NGItNDdlMS1hMWNkLWE3NDE5Y2NhZWI5NCIsImMiOjZ9",
                'requestid': "253a7eb3-f0f0-ae98-e0a2-9d502f6b06b8",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'sec-fetch-site': "cross-site",
                'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36",
                'x-powerbi-resourcekey': "897a2a85-e184-43be-9de3-c2675f0f1816",
                'cache-control': "no-cache",
                'postman-token': "eb5cee1b-21ff-7076-788c-77d94fd7c9c6"
            }

            response = requests.request("POST", url, data=payload, headers=headers, params=querystring)

            # print(response.text)
            data = json.loads(response.text)
            # print(data)
            dmo = data['results'][0]['result']['data']['dsr']['DS'][0]['PH'][0]['DM0']
            le = len(dmo)
            for i in range(0,le):
                try:
                    datetmp = dmo[i]['C'][0]
                    timestamp = int(datetmp/1000)
                    dt_object = datetime.fromtimestamp(timestamp)
                    Last_Year_Revenue = dmo[i]['C'][1]
                    This_Year_Revenue = dmo[i]['C'][2]
                    Revenue_YOY_Change = float(dmo[i]['C'][3])*100
                    Rolling_7_Days_Revenue = float(dmo[i]['C'][4])*100

                    item = Vetsuccess_Revenue_Item()
                    item['Date'] = dt_object
                    item['Last_Year_Revenue'] = Last_Year_Revenue
                    item['This_Year_Revenue'] = This_Year_Revenue
                    item['Revenue_YOY_Change'] = Revenue_YOY_Change
                    item['Rolling_7_Days_Revenue'] = Rolling_7_Days_Revenue
                    yield item
                except Exception as e:
                    print("pass",e,datetmp)
        except Exception as e:
            print("parse",e,response.url)




# from scrapy.cmdline import execute
# execute("scrapy crawl vetsuccess_Revenue_crawler".split())

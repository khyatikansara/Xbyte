# -*- coding: utf-8 -*-
import datetime
import json
import re
import time

import scrapy
import requests
from scrapy.http import HtmlResponse

from vetsuccess.items import Vetsuccess_Revenue_Item, Vetsuccess_Invoice_Item, Vetsuccess_Revenue_per_Practice_Item, \
    Growth_In_Revenue_And_Visits_Item, YOY_Percentages_Item
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
options = Options()
options.add_argument('--headless')
dt = datetime.datetime.today().date()

class YOY_Percentages_crawlerSpider(scrapy.Spider):
    name = 'YOY_Percentages_crawler'
    allowed_domains = ['www.example.com']
    start_urls = ['https://vetsuccess.com/resources/veterinary-industry-tracker/']

    def parse(self, response):

        try:
            urltmp = response.text.split('https://app.powerbi.com/view?r=')[1]
            ur1tmp1 = urltmp.split('"')[0]
            url = "https://app.powerbi.com/view?r="+str(ur1tmp1)
            driver = webdriver.Chrome('C://XBYTE//chromedriver.exe', chrome_options=options)
            driver.get(url)
            driver.maximize_window()
            time.sleep(30)

            pagesrc = driver.page_source
            response = HtmlResponse(url='', body=bytes(pagesrc.encode("utf8")))
            Heart_Worm_YOY = response.xpath('//*[contains(text(),"Heartworm YoY")]/../../preceding-sibling::*/*/*/text()').get()
            Services_YOY = response.xpath('//*[contains(text(),"Services YoY")]/../../preceding-sibling::*/*/*/text()').get()
            Flea_Tick_YOY = response.xpath('//*[contains(text(),"Flea/Tick YoY")]/../../preceding-sibling::*/*/*/text()').get()
            Products_YOY = response.xpath('//*[contains(text(),"Products YoY")]/../../preceding-sibling::*/*/*/text()').get()
            item = YOY_Percentages_Item()
            item['Date'] = dt
            item['Heart_Worm_YOY'] = Heart_Worm_YOY
            item['Services_YOY'] = Services_YOY
            item['Flea_Tick_YOY'] = Flea_Tick_YOY
            item['Products_YOY'] = Products_YOY

            yield item

        except Exception as e:
            print("parse",e,response.url)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl YOY_Percentages_crawler".split())

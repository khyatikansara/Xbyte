# -*- coding: utf-8 -*-
import openpyxl
from json2html import *
import scrapy
from vetsuccess.db_config import *
import sqlalchemy as db
from sqlalchemy_utils import database_exists, create_database
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd
from openpyxl import load_workbook
from datetime import date, timedelta, datetime
import smtplib,ssl
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import dropbox
class PlacerCrawlerSpider(scrapy.Spider):
    name = 'mail_excel'
    allowed_domains = ['www.examle.com']
    start_urls = []
    def start_requests(self):
        try:
            # process_date = str(datetime.now()).split()[0]

            self.connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(
                drivername=driver_name, user=db_user, passwd=db_password, host=db_host, port=db_port, dbname=db_name)
            self.connection_string += '?driver=ODBC+Driver+17+for+SQL+Server'

            self.engine = db.create_engine(self.connection_string)

            try:
                if not database_exists(self.engine.url):
                    create_database(self.engine.url)
            except Exception as e:
                print('Problem in Database creation', e)

            self.connect = self.connect = self.engine.connect()


            sql1= ("Select * from " + Vetsuccess_Revenue_Per_Practice)
            df1 = pd.read_sql(sql1, self.connect)

            sql2 = ("Select * from " + Growth_In_Revenue_And_Visits)
            df2 = pd.read_sql(sql2, self.connect)

            status_df = pd.DataFrame(columns=['Name', 'Count'])
            status_df = status_df.append({'Name': "Vetsuccess Revenue Per Practice Count :", 'Count': str(len(df1))}, ignore_index=True)
            status_df = status_df.append({'Name': "Growth And Revenue And Visit Count : ", 'Count': str(len(df2))},
                                         ignore_index=True)


            try:

                sel_query = db.sql.text(
                    f"SELECT * FROM Vetsuccess_summary where process_date='" + str(str(datetime.today()).split()[0]) + "'")  # " where PROCESS_DATE='"+str(tdate)+"'")
                df = pd.read_sql(sel_query, self.connect)
                # print(df)

                # s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                # s.connect(('8.8.8.8', 1))
                # local_ip_address = s.getsockname()[0]
                port = 587
                smtp_server = "smtp.zeptomail.com"
                username = "emailapikey"
                emailpass = "wSsVR61/+hP5DKcszTH5Jbhpml9dVlL0HEV6iVSn7XSpTKzLoMdukkCdVlWjGPgfRDRpHDAWrLIhnBZShztYjdQszVtSDiiF9mqRe1U4J3x17qnvhDzPV2RdlhuAJYgIwwlqmWVoE88k+g=="

                emailId = "alerts@xbyte.io"
                # emailpass = "xbyte123"

                send_to = [
                    'tcai@migcap.com',
                    'yjeon@migcap.com',
                    # 'rahul.sardhara.xbyte@gmail.com',
                    'hiral.trivedi.xbyte@gmail.com',
                    'nikhilt.xbyte@gmail.com',
					'khyati.xbyte@gmail.com',
                    'xbyte.qa@gmail.com'

                ]
                bcc = [
                    # 'foram.patel.xbyte@gmail.com',
                    # 'hiral.trivedi.xbyte@gmail.com',
                    # 'alpesh.khunt.xbyte@gmail.com',
                    # 'rahul.sardhara.xbyte@gmail.com',
                    # 'vikram.chauhan.xbyte@gmail.com',
                    # 'alpesh.khalas.xbyte@gmail.com'
                    # 'rahul.sardhara.xbyte@gmail.com'
                ]

                mail_content = list()
                mail_content.append("<html>")
                mail_content.append("<head>")

                mail_content.append("""<style>
                                            body{
                                              font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                                            }
                                            table {
                                              font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                                              border: 1px solid black;
                                              border-collapse: collapse;
                                            }
                                            table th{
                                              padding-top: 12px;
                                              padding-bottom: 12px;
                                              text-align: left;
                                              background-color: #4CAF50;
                                              color: white;
                                            }
                                            table td, table th {
                                              border: 1px solid #ddd;
                                              padding: 8px;
                                            }

                                          </style>""")
                mail_content.append("</head>")
                mail_content.append("<body>")
                mail_content.append(
                    "<strong><p>Hello Sir/Madam,<br><br> Here is the Data count and summary of This Weekly. (Date : " + str(str(datetime.today()).split()[0]) + ")<br></p></strong>")
                mail_content.append("<br/>")
                # mail_content.append("<br/>")
                mail_content.append('<br><h3>Summary</h3>')
                df = df[['script','start_time','end_time','duration']]

                m_content = df.to_html()
                mail_content.append(m_content)
                mail_content.append("<br/>")
                mail_content.append("<br/>")
                # Data count summary
                summary_dict = {}
                data_counts1 = df1[['Date']].count(axis=0).to_dict()
                data_counts2 = df2[['Date']].count(axis=0).to_dict()


                for key, value in data_counts1.items():
                    summary_dict[str("Vetsuccess Revenue Per Practice Count :")] = value
                for key, value in data_counts2.items():
                    summary_dict[str("Growth And Revenue And Visit Count : ")] = value

                # mail_string_count = (json2html.convert(json=summary_dict))
                mail_content.append('<br><h3>Data Count</h3>')
                m_content = json2html.convert(json=summary_dict)
                m_content = m_content.replace("&lt;", "<")
                m_content = m_content.replace("&gt;", ">")
                m_content = m_content.replace("\n", "")
                m_content = m_content.replace('&quot;', '"')
                mail_content.append(m_content)
                mail_content.append("<br><br>Thank you,<br>")
                mail_content.append("<b>Team Xbyte.</b>")
                mail_content.append("</body>")
                mail_content.append("</html>")

                body = "".join(mail_content)
                with open(f'mail_{runon}.html', 'w') as o:
                    o.write(body)

                try:
                    msg = MIMEMultipart()
                    msg['From'] = emailId
                    msg['To'] = ",".join(send_to)
                    # msg['CC'] = ",".join(cc)
                    msg['BCC'] = ','.join(bcc)
                    msg['Subject'] = "Vetsuccess Dailly Delivery Report ("+str(str(datetime.today()).split()[0])  + ")"
                    msg.attach(MIMEText(body, 'html'))
                    try:
                        if port == 465:
                            context = ssl.create_default_context()
                            with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                                server.login(username, emailpass)
                                server.send_message(msg)
                        elif port == 587:
                            with smtplib.SMTP(smtp_server, port) as server:
                                server.starttls()
                                server.login(username, emailpass)
                                server.send_message(msg)
                        else:
                            print("use 465 / 587 as port value")
                            exit()
                        print("successfully sent")
                    except Exception as e:
                        print(e)
                    # s = smtplib.SMTP('mail.xbyte.io', 587)
                    # s.starttls()
                    # s.login(emailId, emailpass)
                    # text = msg.as_string()
                    # s.sendmail(emailId, send_to + bcc, text)
                    # s.sendmail(emailId, send_to, text)
                    # print("Mail Sent ...")
                    # s.quit()
                except Exception as e:
                    print(e)

            except Exception as e:
                print("Generate Email",e)

        except Exception as e:
            print("start_request",e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute("scrapy crawl mail_excel".split())

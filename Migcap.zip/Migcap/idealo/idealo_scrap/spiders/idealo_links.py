# -*- coding: utf-8 -*-
import requests
import scrapy
import json
import datetime
import scrapy
import sqlalchemy
import random
import time
import hashlib
import os
import re
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from python3_anticaptcha import NoCaptchaTaskProxyless
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent

from idealo_scrap.items import IdealoScrapItem_link
current_directory = os.path.dirname(os.path.abspath(__file__))
# html_data_directory = current_directory +'\\Html\\'+ tstamp + '\\HTML_Data\\'
html_data_directory = current_directory + 'html\\html_data\\'
if not os.path.exists(html_data_directory):
    os.makedirs(html_data_directory)
cookie = 'SSLB=1; ipcuid=019fl0xc00ksa29n73; sessionid=dd5ed9ad-148e-c161-2115-c5d02a8518f0; IDEALO-WISHLIST-XSRF-TOKEN=a0aea35f-e91b-4248-93f5-70b6476b6ef1; _sp_v1_uid=1:73:ee61bce5-7d03-4cc1-833e-f29e71631e5a; _sp_v1_lt=1:; consentUUID=f572d333-5571-4b19-a856-0bf8bc2bf0fc; _sp_v1_csv=null; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; _sp_v1_consent=1!1:1:1:0:0:0; _gcl_au=1.1.324605201.1628841662; _gid=GA1.2.1416242001.1628841662; _hjid=9be40129-5321-48ac-b302-0fa5a2d58461; _hjFirstSeen=1; _hjIncludedInSessionSample=0; _hjAbsoluteSessionInProgress=0; _fbp=fb.1.1628841662306.1344291826; _pin_unauth=dWlkPU1HUXdabVExT0dZdFlUVmhNaTAwWlRRekxUa3hNVEV0WkRBNFpUazVNRGRqTVdaaA; iom_consent=010fff0fff&1628841689649; SSRT=sScWYQADAA; SSID=CABMfh1UAAAAAAC9JhZhq55AAL0mFmEBAAAAAADgtT1hvSYWYQAfvMYFAANorQAAtCcWYQEA7wUAA96rAAC9JhZhAQAEBgABB60AALQnFmEBABcGAAGnrQAAvSYWYQEAxQUAARmqAAC0JxZhAQACBgAB0KwAAL0mFmEBAA; SSSC=1.G6995821664361553579.1|1477.43545:1478.44392:1519.43998:1538.44240:1540.44295:1559.44455; JSESSIONID=8E1A28182D7C09957B835AFCC6AC0192; _sp_v1_data=2:332109:1628841658:0:4:0:4:0:0:_:-1; _uetsid=9a047170fc0c11eba71689ad82975ffe; _uetvid=9a047230fc0c11eb8b0cb1f05367e065; _ga_NHP4SC1CKE=GS1.1.1628841661.1.1.1628841909.57; _ga=GA1.2.1985277579.1628841662; _dc_gtm_UA-75090708-1=1; ioam2018=000a99196b6936491611626d9:1656316889653:1628841689653:.idealo.de:3:cbo:K_100:noevent:1628841909753:tep7t; cto_bundle=70uyZV83OERUTGtNUEp3aTlYSFBFRXolMkJ4WmNJTjNUdUFlR29oQTNnZjAlMkZqdXpvZzRidVc4R0NQU3liS1loYW9sWGdtQTdCb1d0VTJlUnRzNkNTV0J2ak43Z1ZZNGZYJTJCOUdvdlBpY29uS1hVMWgyVkFCd1hVcUZxYyUyRjh0d1dCJTJCY2FKT1JFQlp3VTQ2SmpQcVpiZlZEJTJGM0ZsdHclM0QlM0Q; SSOD=AN1BACgASgMBAAIAAADcJhZhuCcWYQAAAAAAAPA_AAAAAAAA8D8AAAAAAAAAQAAAAAA; SSPV=tVAAAAAAAA0AAgAAAAAAAAAAQAMAAAAAAAAAAAAA'


class IdealoLinkSpider(scrapy.Spider):
    name = 'idealo_link'
    allowed_domains = ['idealo.de']
    # start_urls = ['']
    page = 1

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        while True:
            try:
                pagesave = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                url = "https://www.idealo.de/preisvergleich/MainSearchProductCategory.html?q=Irobot"
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36',
                    'Cookie': cookie
                }
                res = requests.get(url=url, headers=headers)
                if res.status_code == 200:
                    yield scrapy.Request(url=url, callback=self.parse, headers=headers, meta={"pagesave": pagesave})
                    break
                else:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                        'Cookie': cookie
                    }
                    formdata = {
                        'g-recaptcha-response': '03AGdBq267oZqiaJDRpgCOYA1rhz2yTGrUTmVlwMa0BvRUzLEqOzpCbpUMj86dAWFin1wW_kPVTs8E5mGopSStYJUCkYzkOkW_OkvmhmESxF7tHG18isBNaoRI3JlnjK5kLcWpSQ3BvTiVaTo2vaTASSdY6VXgE0nEPR-w68EAffVNmZCXMTn5JVY1CenOUSOZ-t6k2gmun2GT1i23acookRd-AT2il4UGqXNSaO8lbpDh0wo61vz_IkhFLDEYxpRMKU13YN76GYUVjD1356QenEyzuxtUT6A7m-5nM2GrPHKtwq7FTA1k2mLP3OjtoZ81PG_O2wM5To6wIBu_ZRfpqinJLo_GyGOuv5zBvKeLDbdqJAuZlCwR7LU3GLsEGEj_2xWUEo1-SiCauPDjQoyIcWcSFTsoGEsTZqyqCiECjQAkChBBz0jYfVBsz9bGn_OpxECZWtFONskRIYj3bwwVAYMGkEtqKYV1qjtZ6nequCC0sXRusqhYbYo'
                    }
                    res = requests.post(url=url, headers=headers, data=formdata)
                    if res.status_code == 200:
                        yield scrapy.Request(url=url, callback=self.parse, headers=headers, meta={"pagesave": pagesave})
                        break
            except Exception as e:
                print(e)

    def parse(self, response):
        tmp_link = []
        try:
            links = response.xpath('//*[@class="offerList-item"]/a/@href').extract()
            if links == []:
                forms = response.xpath('//form[@class="offerList-item"]/@data-gtm-payload').extract()
                for pid_text in forms:
                    try:
                        pid = re.findall(r'"productId":"(.*?)"', pid_text)[0]
                    except:
                        pid = ''
                    if pid != '':
                        url = "https://www.idealo.de/recentproducts"
                        payload = '[{\"' + pid + '\":\"PRODUCT\"}]'
                        header = {
                            'accept': 'application/json, text/javascript, */*; q=0.01',
                            'accept-encoding': 'gzip, deflate, br',
                            'accept-language': 'en-US,en;q=0.9',
                            'content-length': '25',
                            'content-type': 'application/json',
                            'cookie': cookie,
                            'origin': 'https://www.idealo.de',
                            'referer': 'https://www.idealo.de/preisvergleich/MainSearchProductCategory/100I16-45.html?q=Irobot',
                            'sec-fetch-dest': 'empty',
                            'sec-fetch-mode': 'cors',
                            'sec-fetch-site': 'same-origin',
                            'user-agent': self.get_useragent(),
                            'x-requested-with': 'XMLHttpRequest'
                        }
                        res = requests.post(url=url, data=payload, headers=header)
                        response1 = HtmlResponse(url=res.url, body=res.content)
                        if res.status_code == 200:
                            print(response1.text)
                            try:
                                p_url = re.findall(r'"href":"(.*?)"', response1.text)[0]
                            except:
                                p_url = ''
                            if p_url != '':
                                tmp_link.append(p_url)
                                if 'https://www.idealo.de' not in p_url:
                                    p_url = 'https://www.idealo.de' + p_url
                                yield scrapy.Request(url="https://www.idealo.de" + p_url, callback=self.parse_data, dont_filter=True)
                                # break
            else:
                for link in links:
                    yield scrapy.Request(url="https://www.idealo.de" + link, callback=self.parse_data, dont_filter=True)
                    # break

            if tmp_link == []:
                forms1 = response.xpath('//form[@class="offerList-item"]/@data-gtm-payload').extract()
                for check in forms1:
                    if '"clusterId":' in check:
                        clusterId = re.findall(r'"clusterId":"(.*?)"', check)[0]
                        p_url1 = f'https://www.idealo.de/preisvergleich/Typ/{clusterId}.html'
                        yield scrapy.Request(url="https://www.idealo.de" + p_url1, callback=self.parse_data, dont_filter=True)
                        # break

            next_page = response.xpath('//*[@class="pagination-item next"]/a/@href').extract_first()
            if next_page:
                self.page += 1
                header2 = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'accept-language': 'en-US,en;q=0.9',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36',
                    'Cookie': cookie
                }
                yield scrapy.Request(url=next_page, callback=self.parse, headers=header2, meta={"page": self.page}, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):
        retailer_selector = response.xpath('//a[@class="productOffers-listItemTitle"]/../..')
        for retailer_data in retailer_selector:
            try:
                Retailer_url = "https://www.idealo.de"+retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/@href').extract_first()
            except Exception as e:
                print(e)
                Retailer_url = ''
            if Retailer_url != '':
                try:
                    item_g = IdealoScrapItem_link()
                    item_g['PROCESS_DATE'] = str(datetime.datetime.now().date())
                    item_g['Url'] = Retailer_url
                    item_g['Hash_id'] = str(int(hashlib.md5(bytes(str(Retailer_url), "utf8")).hexdigest(), 16) % (10 ** 20))
                    yield item_g
                except Exception as e:
                    print(e)


from scrapy.cmdline import execute
execute('scrapy crawl idealo_link'.split())

# # -*- coding: utf-8 -*-
# import requests
# import json
# import datetime
# import scrapy
# import random
# import hashlib
# import os
# import sqlalchemy as db
# from scrapy.http import HtmlResponse
# from idealo_scrap.items import IdealoScrapItem_graph
# from idealo_scrap import pipelines as pipe
# from idealo_scrap.spiders import idealo_crawler
#
# current_directory = os.path.dirname(os.path.abspath(__file__))
# html_data_directory = current_directory + 'html\\html_data\\'
# if not os.path.exists(html_data_directory):
#     os.makedirs(html_data_directory)
# proxy = ["lum-customer-migcap-zone-xbyte|bnyl7wqnig9t"]
#
# current_proxy = random.choice(proxy).split("|")
#
#
# class IdealoGraphSpider(scrapy.Spider):
#     name = 'idealo_graph'
#     allowed_domains = ['idealo.de']
#     start_urls = ['https://example.com']
#     page = 1
#     # cookie = 'SSLB=1; ipcuid=01qhjieq00kjmyty96; IDEALO-WISHLIST-XSRF-TOKEN=e166ef88-7691-43a7-b867-b747e278dbb8; _sp_v1_uid=1:74:2dd551a0-dc30-4760-b055-ee2491e70648; _sp_v1_lt=1:; _sp_v1_csv=null; consentUUID=eb8c4a3f-84d2-4e91-b930-e502c873ccb8; euconsent-v2=CO_pzkJO_pzkJAGABCDEBHCsAP_AAEtAAAYgGzwIAAFAAVAA4ACAAE4AKgAWgA0gCKAI4ATAAoABSACyAFsAMIAjgBSACtAGUAOcAeQA_QCBgEFgIOAhABHQEJgKHAW0AvMBkgDZwEIgCgCOAHOAQMAgsBBwEIAKGQBAAVABMAEcAvMRABABUEgGAAVAA4ACAAFQANAAigBMAEcAP0BQ4C8wGSBoAQAKgCCioAgAKgAmACOAXmOgGgAVAA4ACAAFQANAAigBMAEcAMoAfoChwF5gMkIQBQAVABMAEcAMoBbRKAKABwAJgAjgBlALzKQDQAKgAcABAACoAGgARQAmABSAGUAP0BQ4C8wGSFAAIBBw.YAAAAAAAAAAA; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _gcl_au=1.1.991595908.1610030926; _hjTLDTest=1; _hjid=8275f391-c469-4600-802c-6db1f67f34ce; _fbp=fb.1.1610030926597.545855873; iom_consent=010fff00000000&1610030926700; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _ga=GA1.2.1462721208.1610030927; _gid=GA1.2.1669657929.1610030927; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; _sp_v1_consent=1!1:1:1:0:0:-1; __gads=ID=f8118fe9b194fa48:T=1610030933:S=ALNI_MZrie-z_OLJupBnQociIipf-bxwLw; _hjIncludedInSessionSample=0; QSI_SI_8iHvAsIp4n566xf_intercept=true; ak_bmsc=A032AE94516B14EFDCC90A2E8241BDA917D4FE6CD16500002E15F85FD8BCBF4E~plbE07yYkmSnfrXhiUevdDPiDC897KYGTvc06SiLtgZ36rx960dg4R0VfXSi2MVoUk6VI81W9r5a7BIWZNa88FDVaU3E305+bfrjVZ0Pott0CrRfa61TQz3PxYAarIcCZPc3U6iH9iOVy0AIEA4XlyyBjk1tRTYkGdj8jl2Pi8Z+MZuiVmiPV9JKR0r+d+D90fQdvXzAonp3anUR9RYc+rOBr9noBJ5yPho4KpfHZUkMI=; _gat_UA-75090708-1=1; SSID=CAA7wB1UAAAAAABRH_dfxw_DAFEf918EAAAAAAB9rR5gBy_4XwIfvL0EAAEBlAAABy_4XwEAjQQAAYGKAAAHL_hfAQDTBAABF5gAAAcv-F8BAMkEAAHYlgAABy_4XwEArwQAA_ORAABRH_dfBACJBAAB_YgAAAcv-F8BAA; SSRT=By_4XwADAA; sessionid=f56378b2-e713-3f31-0f32-421b3438c50f; AMP_TOKEN=%24NOT_FOUND; _hjAbsoluteSessionInProgress=0; _dc_gtm_UA-75090708-1=1; SSSC=1.G6915030185616281543.4|1066.30667:1161.35069:1163.35388:1165.35457:1199.37363:1213.37889:1225.38616:1235.38935; SSPV=9RcAAAAAAAEAAwAAAAAAAAAAAAIAAAAAAAAAAAAA; JSESSIONID=B8A7DD38C206064EE9317F67CE88D381; bm_sv=4F5EEE721F32816120514490E40D7C69~8KLoHi2Y+QcibryhjJ6uqMp+o2odeCfYIXeu/b2ZtNiAwMGtEKX1U1oEgsiEMRehuTdTy27/Sxz0K6ynk8AGWz6FfdNf3fqjn5FV+9cr6TbZrULbEX+yMd3Sy/qQgJHYmoW5inT116act6bU+DU43TbHBx3SMA2PMo8FSppjHlE=; _sp_v1_data=2:272774:1610030908:0:14:0:14:0:0:_:-1; _uetsid=71e7bed050f711eb8b9c0d9c10b8a7c6; _uetvid=71e7f43050f711eba3476959faec31b2; ioam2018=00162f23b7a629a215ff71f4e:1639320526709:1610030926709:.idealo.de:14:cbo:K_2925:noevent:1610100527225:mztrb1'
#
#     def __init__(self, name=None, **kwargs):
#         super().__init__(name, **kwargs)
#         self.pipe1 = pipe.IdealoScrapPipeline()
#         self.date_today = str(datetime.datetime.now()).split()[0]
#         self.cookie = idealo_crawler.cookie
#
#         def parse():
#             try:
#                 result = self.pipe1.connect.execute(f"select * from [dbo].[Idealo_scrape_retailer_table] where PROCESS_DATE='{self.date_today}'")
#                 headers = {
#                     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
#                     'accept-language': 'en-US,en;q=0.9',
#                     'cookie': self.cookie,
#                     'upgrade-insecure-requests': '1',
#                     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36'
#                     }
#
#                 for data in result:
#                     asin = data[1]
#                     Retailer_name = data[3]
#                     url = data[13]
#                     yield scrapy.Request(url=url, callback=self.parse1, headers=headers, dont_filter=True, meta={'asin':asin, 'Retailer_name':Retailer_name, 'url':url})
#             except Exception as e:
#                 print(e)
#
#         parse()
#
#     def parse1(self,response):
#         try:
#             if "/pricechart/" in response.text:
#                 asin = response.meta['asin']
#                 url = response.meta['url']
#                 Retailer_name = response.meta['Retailer_name']
#                 graph_url = f"https://www.idealo.de/offerpage/pricechart/api/{asin}?period=P1Y"
#                 headers = {
#                     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
#                     'accept-language': 'en-US,en;q=0.9',
#                     'cookie': self.cookie,
#                     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36'
#                     }
#                 res_g = requests.get(url=graph_url, headers=headers)
#                 response_g = HtmlResponse(url=res_g.url, body=res_g.content)
#                 if res_g.status_code == 200:
#                     g_json = json.loads(response_g.text)
#                     data_g = g_json['data']
#                     for data_graph in data_g:
#                         Date = data_graph['x']
#                         Price = data_graph['y']
#                         try:
#                             graph_Hash_id = bytes(str(Retailer_name) + str(graph_url) + str(Date) + str(Price) + str(self.date_today), encoding='utf-8')
#                             g_Hash_id = int(hashlib.md5(graph_Hash_id).hexdigest(), 16) % (10 ** 12)
#                         except Exception as e:
#                             g_Hash_id = ''
#                             print(e, "graph_Hash_id")
#
#                         try:
#                             item_g = IdealoScrapItem_graph()
#                             item_g['PROCESS_DATE'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
#                             item_g['Url'] = url
#                             item_g['asin'] = asin
#                             item_g['Date'] = Date
#                             item_g['Price'] = Price
#                             item_g['graph_url'] = graph_url
#                             item_g['Hash_id'] = g_Hash_id
#                             query2 = db.insert(self.pipe1.Idealo_scrape_graph_table)
#                             self.pipe1.connect.execute(query2, dict(item_g))
#                             self.pipe1.insert_count += 1
#                             print('INSERTED Data in Idealo_scrape_graph_table count ... ', self.pipe1.insert_count)
#                             # yield item_g
#                         except Exception as e:
#                             print(e)
#
#         except Exception as e:
#             print(e)
#
# from scrapy.cmdline import execute
# # execute('scrapy crawl idealo_graph'.split())

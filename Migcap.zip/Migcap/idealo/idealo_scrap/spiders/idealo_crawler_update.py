# -*- coding: utf-8 -*-
import requests
import scrapy
import json
import datetime
import scrapy
import sqlalchemy
import random
import time
import hashlib
import os
import re
import sqlalchemy as db
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from python3_anticaptcha import NoCaptchaTaskProxyless
from w3lib.http import basic_auth_header

from idealo_scrap.graph import Graph
from idealo_scrap.db_config import config
from idealo_scrap.items import IdealoScrapItem_graph, IdealoScrapItem_retailer
current_directory = os.path.dirname(os.path.abspath(__file__))
# html_data_directory = current_directory +'\\Html\\'+ tstamp + '\\HTML_Data\\'
html_data_directory = current_directory + 'html\\html_data\\'
if not os.path.exists(html_data_directory):
    os.makedirs(html_data_directory)
cookie = 'SSLB=0; SSenabled=true; ipcuid=01rjl0xm00kk2ikyvl; _sp_v1_uid=1:836:a878fa20-04ae-4564-acfe-fe5a6edffc66; _sp_v1_lt=1:; _sp_v1_csv=null; consentUUID=47b45eef-41db-4508-b49c-9dc5795083f1; euconsent-v2=CPANq38PANq38AGABCDEBJCsAP_AAEtAAAYgGzwIAAFAAVAA4ACAAE4AKgAWgA0gCKAI4ATAAoABSACyAFsAMIAjgBSACtAGUAOcAeQA_QCBgEFgIOAhABHQEJgKHAW0AvMBkgDZwEIgCgCOAHOAQMAgsBBwEIAKGQBAAVABMAEcAvMRABABUEgGAAVAA4ACAAFQANAAigBMAEcAP0BQ4C8wGSBoAQAKgCCioAgAKgAmACOAXmOgGgAVAA4ACAAFQANAAigBMAEcAMoAfoChwF5gMkIQBQAVABMAEcAMoBbRKAKABwAJgAjgBlALzKQDQAKgAcABAACoAGgARQAmABSAGUAP0BQ4C8wGSFAAIBBw.YAAAAAAAAAAA; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _gcl_au=1.1.572873063.1610971085; _hjid=0a233692-3aee-4557-a6c9-b83f6213810d; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _fbp=fb.1.1610971085129.1289528166; _sp_v1_consent=1!1:1:1:0:0:-1; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; __gads=ID=d79cea8397ad59f0:T=1610971101:S=ALNI_Mbctk77jCP_svG5r9JywDM3CC8fKg; iom_consent=010fff0000&1611061675092; SSOD=ANXbAAAAEAC4HQAABAAAALRyCmDviApgAAA; SSLB=1; IDEALO-WISHLIST-XSRF-TOKEN=98e442d1-5f0d-430b-bc50-969ca9a7d1fe; _hjIncludedInSessionSample=1; _hjTLDTest=1; QSI_SI_8iHvAsIp4n566xf_intercept=true; cbk=6ad6c233edcdecd10f94bbba67800db69fb593463e788097564696995e223b82; _pin_unauth=dWlkPU9XTTBaVEU1TUdJdE9XWmhNaTAwTXpJeExUZ3hOR0l0TkRGaU1XRmxOVFUwWVdObQ; sessionid=4c10020a-d7db-d551-174a-64848997d0c4; ak_bmsc=1D8799ABF14ED857E029D67B74462666B8963A05A16F00001E0015604ABBCC7D~pl+YEngsm+gZQBc5l3+WBvYPJWAmCOU0WxGgKxEVDTauVWWf4/8Cr2JEs6P3gha5E44QbfSHsUwtIk54RSYSPSjZ+ZY4DC49rIWd3l/1NRq/d4hEaD4E5ob35MiiSm4tgjjALNz3iujyJbyfMMvJTUzr8LQYd4pJk+JRJ7ail3BX+QSG8+Qx2G4HQ9ECf/aezpBM89dPEetOqqKTg2HbYPB9ciLpiLCYFmncjYLPl1RTU=; SSID=CADaYR1UAAwAAADOdwVgcglAAM53BWATAAAAAABGcDdgHgAVYAIfvP4DAAO3cAAA_JoPYAoAyQQAAdiWAAAeABVgAQDgBAAB35kAAB4AFWABANUEAAHEmAAAHgAVYAEAjQQAAYGKAAAeABVgAQAWBAADQHQAABriD2AJAK4EAACvBAAAcgQAAA; SSRT=HgAVYAADAA; _hjAbsoluteSessionInProgress=0; AMP_TOKEN=%24NOT_FOUND; _gid=GA1.2.1256816086.1611989023; JSESSIONID=D796EF70C99450C7AB4416946CFDFC3D; SSSC=1.G6919068129175800178.19|1022.28855:1046.29760:1066.30667:1163.35388:1165.35457:1225.38616:1237.39108:1248.39391; SSPV=BPwAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAA; bm_sv=5728897E5D00B9517AD4B79A45138911~EMoYAaXwJT19pwORI1fZYr5i+rbFeYb1znNPWw3N9yyTz61peTmu9N90ytSXQG/K/M91nMFPuZLEV6Q5LVT/IJw/eISGISrMvUD3IS34fOFj/y6SvMPICJe/PMLSBSvDMxf+DBInXpEgQF8XajgRv7vG8D/SWJfS2HvUXyQkq04=; _sp_v1_data=2:274614:1610971073:0:86:0:86:0:0:_:-1; _uetsid=7e65983062c611ebad8aebbd193c9699; _uetvid=6c01d3b0598411eb8fd911b4951f1791; _ga_NHP4SC1CKE=GS1.1.1611989022.26.1.1611989046.36; _ga=GA1.2.1496312809.1610971085; ioam2018=001c2d93df3721b2e600577cc:1637668685059:1610971085059:.idealo.de:87:cbo:K_2925:noevent:1611989046882:9uetzu'
process_date = '2021-01-29' #datetime.datetime.now(pytz.timezone('US/Pacific')).date()
proxy = ["lum-customer-migcap-zone-xbyte2_1|ei7egcun3bbl","lum-customer-migcap-zone-xbyte|bnyl7wqnig9t"]

current_proxy = random.choice(proxy).split("|")


class IdealoSpider(scrapy.Spider):
    name = 'idealo_crawler_update'
    allowed_domains = ['idealo.de']
    # start_urls = ['https://www.idealo.de/']
    page = 1
    # cookie = 'SSLB=1; ipcuid=01qhjieq00kjmyty96; _sp_v1_uid=1:74:2dd551a0-dc30-4760-b055-ee2491e70648; _sp_v1_lt=1:; _sp_v1_csv=null; consentUUID=eb8c4a3f-84d2-4e91-b930-e502c873ccb8; euconsent-v2=CO_pzkJO_pzkJAGABCDEBHCsAP_AAEtAAAYgGzwIAAFAAVAA4ACAAE4AKgAWgA0gCKAI4ATAAoABSACyAFsAMIAjgBSACtAGUAOcAeQA_QCBgEFgIOAhABHQEJgKHAW0AvMBkgDZwEIgCgCOAHOAQMAgsBBwEIAKGQBAAVABMAEcAvMRABABUEgGAAVAA4ACAAFQANAAigBMAEcAP0BQ4C8wGSBoAQAKgCCioAgAKgAmACOAXmOgGgAVAA4ACAAFQANAAigBMAEcAMoAfoChwF5gMkIQBQAVABMAEcAMoBbRKAKABwAJgAjgBlALzKQDQAKgAcABAACoAGgARQAmABSAGUAP0BQ4C8wGSFAAIBBw.YAAAAAAAAAAA; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _gcl_au=1.1.991595908.1610030926; _hjid=8275f391-c469-4600-802c-6db1f67f34ce; _fbp=fb.1.1610030926597.545855873; iom_consent=010fff00000000&1610030926700; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _dcmn_p=TI12Y2lkPW1oY2MwRl8zSDA1RGtzWWpBczg; _ga=GA1.2.1462721208.1610030927; _gid=GA1.2.1669657929.1610030927; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; _sp_v1_consent=1!1:1:1:0:0:-1; __gads=ID=f8118fe9b194fa48:T=1610030933:S=ALNI_MZrie-z_OLJupBnQociIipf-bxwLw; QSI_SI_8iHvAsIp4n566xf_intercept=true; SSID=CACptB1iAAAAAABRH_dfxw_DAFEf918GAAAAAAB9rR5gYJD5XwIfvIkEAAGzkgAAYJD5XwEA1QQAAcSYAABgkPlfAQCvBAAD85EAAFEf918GAL0EAAEDlAAAYJD5XwEA0wQAARaYAABgkPlfAQDJBAAB2JYAAGCQ-V8BAI0EAAGCigAAYJD5XwEA; SSRT=YJD5XwADAA; sessionid=76890ac8-1ddb-d828-50a1-c762e829506d; ak_bmsc=3A36CD6B15E0A3C521D56D55AB0ED23D17D4FE04746F00006090F95F8661AA33~plleRLcKswBj/UnsPk0roiRqqddOC/G9eLKuwRDiF8u4wVgG2ujHb1A7fwc9SfeGHH2EKn/28asodMq5W/tKyxQRyQ9Ri56IAOle2dQBidjIVUXsFqO3I4hqqKJ/IZCFMOyZFS66PAma+6W4xKLZB7jNEaElMpZkh+9tJTW4dIl5lLynbwuQfNM11sN9Q69lg3zPbYnoth8lS9Or/2o4sp7/nsohqJGBarMQz0UDdEIaY=; IDEALO-WISHLIST-XSRF-TOKEN=c7e8c26e-0bff-4359-802c-9d0217084f7a; AMP_TOKEN=%24NOT_FOUND; _hjIncludedInSessionSample=0; _hjTLDTest=1; _hjAbsoluteSessionInProgress=0; _dc_gtm_UA-75090708-1=1; SSSC=1.G6915030185616281543.6|1066.30667:1161.37555:1163.35388:1165.35458:1199.37363:1213.37891:1225.38616:1235.38934:1237.39108; SSPV=9RcAAAAAAAEAAwAAAAAAAAAAAAIAAAAAAAAAAAAA; JSESSIONID=31DC0722F23595B2645BB2BBEE86FCEE; _sp_v1_data=2:272774:1610030908:0:21:0:21:0:0:_:-1; _uetsid=71e7bed050f711eb8b9c0d9c10b8a7c6; _uetvid=71e7f43050f711eba3476959faec31b2; ioam2018=00162f23b7a629a215ff71f4e:1639320526709:1610030926709:.idealo.de:21:cbo:K_2925:noevent:1610190964758:3gif38; bm_sv=AE79FAD9F4C4FEBB663777F16C27F1D4~wCq0WpebfQ3Lo/akvrGKh+fYV6MLcZ5qRWevZg4Wt7NUPKczSLpOE4KhMgOfbQyLM0OD1RDTa//qlJmQLUhENMAd2+B4eLVAILFerXjv4lWyJyMImz7HlVjKpzHIpAJ9eWwhuLRewf4SsM/+txHrLn2tObqgSfYePCjUydtgzRQ='

    # def close(spider, reason):
    #     Graph()

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    # def start_requests(self):
    #     try:
    #         connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(
    #             drivername=config.driver_name, user=config.db_user, passwd=config.db_password, host=config.db_host,
    #             port=config.db_port, dbname=config.db_name)
    #         # if 'mssql' in config.driver_name:
    #         connection_string += '?driver=ODBC+Driver+17+for+SQL+Server'
    #
    #         self.engine = db.create_engine(connection_string)
    #         metadata = db.MetaData()
    #         self.connect = self.connect = self.engine.connect()
    #         results = self.connect.execute("select * from [dbo].[Idealo_scrape_link_table] where status='Pending'")
    #         pagesave = process_date
    #         headers = {
    #             'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    #             'user-agent': self.get_useragent(),
    #             "Proxy-Authorization": basic_auth_header(current_proxy[0], current_proxy[1]),
    #             'Cookie': cookie
    #         }
    #         for j in results:
    #             try:
    #                 try:
    #                     url = j[1]
    #                     # print(url)
    #                 except:
    #                     url = ''
    #                 if url != '':
    #                     yield scrapy.Request(url='https://www.idealo.de/preisvergleich/MainSearchProductCategory.html?q=Irobot', callback=self.parse, headers=headers, dont_filter=True, meta={'pagesave':pagesave, "proxy":"http://zproxy.lum-superproxy.io:22225"})
    #             except Exception as e:
    #                 print(e)
    #             break
    #     except Exception as e:
    #         print(e)

    def parse(self, response):
        data_text = response.xpath('//*[@data-recentproducts]/@data-recentproducts').extract_first()
        data = json.loads(data_text)
        asin = data['id']

        #---data page save
        pagesave = response.meta['pagesave']
        fpath = f"{str(html_data_directory)}{asin}_{str(pagesave)}.html"
        with open(fpath, 'wb') as f:
            f.write(response.body)

        Product_title = data['productName']
        retailer_selector = response.xpath('//a[@class="productOffers-listItemTitle"]/../..')
        # print(retailer_selector)
        # p = response.xpath('//*[@class="productOffers-listItemTitleInner "]/text()').extract()
        for retailer_data in retailer_selector:
            try:
                Product_name = retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/span/@title').extract()[0].strip()
            except Exception as e:
                print(e)
                Product_name = ''
            if Product_name == '' or Product_name == None:
                i=0
            try:
                Delivery_Provider = '|'.join(retailer_data.xpath('.//*[@class="productOffers-listItemOfferGreyBadge productOffers-listItemOfferDeliveryProvider"]/text()').extract()).strip()
            except Exception as e:
                print(e)
                Delivery_Provider = ''

            try:
                Price = '|'.join(retailer_data.xpath('.//a[@class="productOffers-listItemOfferPrice"]/text()').extract()).strip()
            except Exception as e:
                print(e)
                Price = ''

            try:
                Delivery_Status = retailer_data.xpath('.//*[@class="productOffers-listItemOfferDeliveryStatus"]//text()').extract_first().strip()
            except Exception as e:
                print(e)
                Delivery_Status = ''

            try:
                Ratings_text = '|'.join(retailer_data.xpath('.//*[@class="productOffers-listItemOfferRatingstext"]//text()').extract()).strip()
            except Exception as e:
                print(e)
                Ratings_text = ''

            try:
                Retailer_url = "https://www.idealo.de"+retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/@href').extract_first()
            except Exception as e:
                print(e)
                Retailer_url = ''

            retailer_text = retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/@data-gtm-payload').extract_first()
            retailer_json = json.loads(retailer_text)
            try:Retailer_name = retailer_json['shop_name']
            except:Retailer_name = ''

            try:Delivery_time = retailer_json['delivery_time']
            except:Delivery_time = ''

            try:Shop_rating = retailer_json['shop_rating']
            except:Shop_rating = ''

            try:Free_return = retailer_json['free_return']
            except:Free_return = ''

            try:Approved_shipping = retailer_json['approved_shipping']
            except:Approved_shipping = ''

            # date_today = str(datetime.datetime.now()).split()[0]
            try:
                shop_Hash_id = bytes(str(Retailer_name) + str(Retailer_url) + str(Product_name) + str(process_date), encoding='utf-8')
                retailer_Hash_id = int(hashlib.md5(shop_Hash_id).hexdigest(), 16) % (10 ** 12)
            except Exception as e:
                retailer_Hash_id = ''
                print(e, "retailer_Hash_id")

            try:
                item = IdealoScrapItem_retailer()
                item['PROCESS_DATE'] = process_date
                item['Url'] = response.url
                item['asin'] = asin
                item['Product_title'] = Product_title
                item['product_name'] = Product_name
                item['Price'] = Price
                item['retailer_name'] = Retailer_name
                item['retailer_url'] = Retailer_url
                item['delivery_time'] = Delivery_time
                item['shop_rating'] = Shop_rating
                item['free_return'] = Free_return
                item['approved_shipping'] = Approved_shipping
                item['Delivery_Status'] = Delivery_Status
                item['Delivery_Provider'] = Delivery_Provider
                item['Ratings_text'] = Ratings_text
                item['Hash_id'] = retailer_Hash_id
                item['page_path'] = fpath.replace('\\','\\\\')
                # query1 = db.insert(self.pipe1.Idealo_scrape_retailer_table)
                # self.pipe1.connect.execute(query1, dict(item))
                # self.pipe1.insert_count += 1
                # print('INSERTED Data in Idealo_scrape_retailer_table count ... ', self.pipe1.insert_count)
                yield item
            except Exception as e:
                print(e)

            try:
                if "/pricechart/" in response.text:
                    url = response.url
                    graph_url = f"https://www.idealo.de/offerpage/pricechart/api/{asin}?period=P1Y"
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                        'accept-language': 'en-US,en;q=0.9',
                        'cookie': cookie,
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36'
                        }
                    res_g = requests.get(url=graph_url, headers=headers)
                    response_g = HtmlResponse(url=res_g.url, body=res_g.content)
                    if res_g.status_code == 200:
                        g_json = json.loads(response_g.text)
                        data_g = g_json['data']
                        for data_graph in data_g:
                            Date = data_graph['x']
                            Price = data_graph['y']
                            try:
                                graph_Hash_id = bytes(str(Retailer_name) + str(graph_url) + str(Date) + str(Price) + str(process_date), encoding='utf-8')
                                g_Hash_id = int(hashlib.md5(graph_Hash_id).hexdigest(), 16) % (10 ** 12)
                            except Exception as e:
                                g_Hash_id = ''
                                print(e, "graph_Hash_id")

                            try:
                                item_g = IdealoScrapItem_graph()
                                item_g['PROCESS_DATE'] = process_date
                                item_g['Url'] = url
                                item_g['asin'] = asin
                                item_g['Date'] = Date
                                item_g['Price'] = Price
                                item_g['graph_url'] = graph_url
                                item_g['Hash_id'] = g_Hash_id
                                # query2 = db.insert(self.pipe1.Idealo_scrape_graph_table)
                                # self.pipe1.connect.execute(query2, dict(item_g))
                                # self.pipe1.insert_count += 1
                                # print('INSERTED Data in Idealo_scrape_graph_table count ... ', self.pipe1.insert_count)
                                yield item_g
                            except Exception as e:
                                print(e)
                            # break
            except Exception as e:
                print(e)

            # break


        if '"load_offers":"Weitere Angebote anzeigen",' in response.text:
            load_link = f"https://www.idealo.de/offerpage/offerlist/product/{asin}/start/15/sort/default?includeFilters=0&excludeFilters=2062&postcode="
            yield scrapy.Request(url=load_link, callback=self.parse, meta={"pagesave": pagesave}, dont_filter=True)

#
# from scrapy.cmdline import execute
# execute('scrapy crawl idealo_crawler_update'.split())

# -*- coding: utf-8 -*-
import requests
import scrapy
import json
import datetime
import scrapy
import sqlalchemy
import random
import time
import hashlib
import os
import re
import sqlalchemy as db
from idealo_scrap import pipelines as pipe
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from python3_anticaptcha import NoCaptchaTaskProxyless

from idealo_scrap.items import IdealoScrapItem_graph, IdealoScrapItem_retailer
current_directory = os.path.dirname(os.path.abspath(__file__))
# html_data_directory = current_directory +'\\Html\\'+ tstamp + '\\HTML_Data\\'
html_data_directory = current_directory + 'html\\html_data\\'
if not os.path.exists(html_data_directory):
    os.makedirs(html_data_directory)


class IdealoSpider(scrapy.Spider):
    name = 'idealo_crawler'
    allowed_domains = ['idealo.de']
    # start_urls = ['https://www.idealo.de/']
    page = 1
    cookie = 'SSLB=0; SSenabled=true; ipcuid=01rjl0xm00kk2ikyvl; _sp_v1_uid=1:836:a878fa20-04ae-4564-acfe-fe5a6edffc66; _sp_v1_lt=1:; _sp_v1_csv=null; consentUUID=47b45eef-41db-4508-b49c-9dc5795083f1; euconsent-v2=CPANq38PANq38AGABCDEBJCsAP_AAEtAAAYgGzwIAAFAAVAA4ACAAE4AKgAWgA0gCKAI4ATAAoABSACyAFsAMIAjgBSACtAGUAOcAeQA_QCBgEFgIOAhABHQEJgKHAW0AvMBkgDZwEIgCgCOAHOAQMAgsBBwEIAKGQBAAVABMAEcAvMRABABUEgGAAVAA4ACAAFQANAAigBMAEcAP0BQ4C8wGSBoAQAKgCCioAgAKgAmACOAXmOgGgAVAA4ACAAFQANAAigBMAEcAMoAfoChwF5gMkIQBQAVABMAEcAMoBbRKAKABwAJgAjgBlALzKQDQAKgAcABAACoAGgARQAmABSAGUAP0BQ4C8wGSFAAIBBw.YAAAAAAAAAAA; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _gcl_au=1.1.572873063.1610971085; _hjid=0a233692-3aee-4557-a6c9-b83f6213810d; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _dcmn_p=VtPrY2lkPXBTOVpPR0FGZDh5THhpeThBekE; _fbp=fb.1.1610971085129.1289528166; _sp_v1_consent=1!1:1:1:0:0:-1; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; __gads=ID=d79cea8397ad59f0:T=1610971101:S=ALNI_Mbctk77jCP_svG5r9JywDM3CC8fKg; iom_consent=010fff0000&1611061675092; SSOD=ANXbAAAAEAC4HQAABAAAALRyCmDviApgAAA; SSLB=1; IDEALO-WISHLIST-XSRF-TOKEN=98e442d1-5f0d-430b-bc50-969ca9a7d1fe; _hjIncludedInSessionSample=1; _hjTLDTest=1; _gid=GA1.2.272009331.1611462747; QSI_SI_8iHvAsIp4n566xf_intercept=true; cbk=6ad6c233edcdecd10f94bbba67800db69fb593463e788097564696995e223b82; sessionid=124dcda2-9bfe-5c07-3235-b3fac0751f9e; ak_bmsc=4CDAF2A544AD415BC854394E7328ADB8B8963A0C11640000B7AB13605C57BB72~plQPumTbrWCmdgs0xVigWxh47s6o+MP/yG7d4rXlJlVlvrx+yd622MXMtsDaYdWlcYqPJ+k6vxhJj858wVFpX3ztxddXZLtgP+I2iSD4hq2/wQXgBO+WtY/s4RlOxRWGM+sGN4eZl4+vy9FRRDpKaCOjJikM2g6YeEmKwlJyiuQEQNu382lGXILoy2kpJfYGy6PeiLSMPv6e+ImKyW4/hM1K+mDzGF1iYide+mA2gj8Kg=; SSID=CAAzpB1UAAwAAADOdwVgcglAAM53BWASAAAAAABGcDdgt6sTYAIfvNUEAAHEmAAAt6sTYAEA4AQAAd-ZAAC3qxNgAQCNBAABgYoAALerE2ABABYEAANAdAAAGuIPYAgA_gMAA7dwAAD8mg9gCQDJBAAB2JYAALerE2ABAK4EAACvBAAAcgQAAA; _hjAbsoluteSessionInProgress=0; AMP_TOKEN=%24NOT_FOUND; _pin_unauth=dWlkPU9XTTBaVEU1TUdJdE9XWmhNaTAwTXpJeExUZ3hOR0l0TkRGaU1XRmxOVFUwWVdObQ; JSESSIONID=160A8E8061CD8012C1647F8CA408110E; SSRT=_60TYAADAA; SSSC=1.G6919068129175800178.18|1022.28855:1046.29760:1066.30667:1163.35388:1165.35457:1225.38616:1237.39108:1248.39391; SSPV=FC0AAAAAAAAAAQAAAAAAAAAAAAEAAAAAAAAAAAAA; bm_sv=DA7DF1CA7268511E9F0CCAAE8FCAE98C~e71n2+YKDDH3baHjlD4e7g4sX1ILnvBJXIdT2BQSTzqEzmjskIQyrQnwW3OlLkl/Mw0vMxPcO3tr7h/BVLJUoNv7ozn5OVJeTGqmkFzWNnjtXZzU1tlyG8wNkI4TC3VmhNE4V5uHZ/rP0Qx/KW1jVw==; _sp_v1_data=2:274614:1610971073:0:83:0:83:0:0:_:-1; _uetsid=299690d05dfd11ebb2a0c1e577f00dd6; _uetvid=6c01d3b0598411eb8fd911b4951f1791; _ga_NHP4SC1CKE=GS1.1.1611901880.25.1.1611902464.60; _ga=GA1.2.1496312809.1610971085; ioam2018=001c2d93df3721b2e600577cc:1637668685059:1610971085059:.idealo.de:84:cbo:K_2925:noevent:1611902464358:phnirg; _dc_gtm_UA-75090708-1=1'

    def __init__(self):
        self.pipe1 = pipe.IdealoScrapPipeline()

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    # def start_requests(self):
    #     # url = 'https://www.idealo.de/'
    #     # headers = {
    #     #             'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    #     #             'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36'
    #     #             }
    #     # yield scrapy.Request(url=url, callback=self.parse, headers=headers)
    #     while True:
    #         try:
    #             pagesave=datetime.datetime.strftime(datetime.datetime.now(),'%Y-%m-%d')
    #             url = "https://www.idealo.de/preisvergleich/MainSearchProductCategory.html?q=Irobot"
    #             headers = {
    #                         'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    #                         'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
    #                         'Cookie': self.cookie
    #                         }
    #             res = requests.get(url=url, headers=headers)
    #             if res.status_code == 200:
    #                 yield scrapy.Request(url=url, callback=self.parse, headers=headers, meta={"pagesave": pagesave})
    #                 break
    #             else:
    #                 headers = {
    #                     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    #                     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
    #                     'Cookie': self.cookie
    #                 }
    #                 formdata = {
    #                         'g-recaptcha-response': '03AGdBq267oZqiaJDRpgCOYA1rhz2yTGrUTmVlwMa0BvRUzLEqOzpCbpUMj86dAWFin1wW_kPVTs8E5mGopSStYJUCkYzkOkW_OkvmhmESxF7tHG18isBNaoRI3JlnjK5kLcWpSQ3BvTiVaTo2vaTASSdY6VXgE0nEPR-w68EAffVNmZCXMTn5JVY1CenOUSOZ-t6k2gmun2GT1i23acookRd-AT2il4UGqXNSaO8lbpDh0wo61vz_IkhFLDEYxpRMKU13YN76GYUVjD1356QenEyzuxtUT6A7m-5nM2GrPHKtwq7FTA1k2mLP3OjtoZ81PG_O2wM5To6wIBu_ZRfpqinJLo_GyGOuv5zBvKeLDbdqJAuZlCwR7LU3GLsEGEj_2xWUEo1-SiCauPDjQoyIcWcSFTsoGEsTZqyqCiECjQAkChBBz0jYfVBsz9bGn_OpxECZWtFONskRIYj3bwwVAYMGkEtqKYV1qjtZ6nequCC0sXRusqhYbYo'
    #                 }
    #                 res = requests.post(url=url, headers=headers, data=formdata)
    #                 if res.status_code == 200:
    #                     yield scrapy.Request(url=url, callback=self.parse, headers=headers, meta={"pagesave": pagesave})
    #                     break
    #                 # response = HtmlResponse(url=res.url, body=res.content)
    #                 # if response.xpath('//h1[contains(text(),"Sicherheitsprüfung (Spam-Schutz)")]'):
    #                 #     while True:
    #                 #         try:
    #                 #             SITE_KEY = '6LdAKg4TAAAAACsbrjT4aMumPbLZCz-6pslszlrQ'
    #                 #             ANTICAPTCHA_KEY = "b7b60b10c0cc32e34271123387085f0d"
    #                 #             PAGE_URL = url
    #                 #             user_answer = NoCaptchaTaskProxyless.NoCaptchaTaskProxyless(
    #                 #                 anticaptcha_key=ANTICAPTCHA_KEY).captcha_handler(websiteURL=PAGE_URL,
    #                 #                                                                  websiteKey=SITE_KEY)
    #                 #             solve = user_answer['solution']['gRecaptchaResponse']
    #                 #             formdata = {
    #                 #                 'g-recaptcha-response': solve
    #                 #             }
    #                 #             headers['refere'] = 'https://www.idealo.de/preisvergleich/MainSearchProductCategory.html?q=Irobot%E2%80%99'
    #                 #             yield scrapy.FormRequest(url=url, method='POST', formdata=formdata, callback=self.parse, headers=headers, meta={"pagesave": pagesave})
    #                 #             break
    #                 #         except:
    #                 #             pass
    #                 print("ok")
    #                 break
    #         except Exception as e:
    #             print(e)

    def parse(self, response):
        tmp_link = []
        try:
            pagesave = response.meta['pagesave']
            fpath = f"{str(html_data_directory)}Main_{str(self.page)}_{str(pagesave)}.html"
            with open(fpath, 'wb') as f:
                f.write(response.body)
            links = response.xpath('//*[@class="offerList-item"]/a/@href').extract()
            if links == []:
                forms = response.xpath('//form[@class="offerList-item"]/@data-gtm-payload').extract()
                for pid_text in forms:
                    try:
                        pid = re.findall(r'"productId":"(.*?)"', pid_text)[0]
                    except:
                        pid = ''
                    if pid != '':
                        url = "https://www.idealo.de/recentproducts"
                        payload = '[{\"' + pid + '\":\"PRODUCT\"}]'
                        header = {
                            'accept': 'application/json, text/javascript, */*; q=0.01',
                            'accept-encoding': 'gzip, deflate, br',
                            'accept-language': 'en-US,en;q=0.9',
                            'content-length': '25',
                            'content-type': 'application/json',
                            'cookie': self.cookie,
                            'origin': 'https://www.idealo.de',
                            'referer': 'https://www.idealo.de/preisvergleich/MainSearchProductCategory/100I16-45.html?q=Irobot%E2%80%99',
                            'sec-fetch-dest': 'empty',
                            'sec-fetch-mode': 'cors',
                            'sec-fetch-site': 'same-origin',
                            'user-agent': self.get_useragent(),
                            'x-requested-with': 'XMLHttpRequest'
                        }
                        res = requests.post(url=url, data=payload, headers=header)
                        response1 = HtmlResponse(url=res.url, body=res.content)
                        if res.status_code == 200:
                            print(response1.text)
                            try:
                                p_url = re.findall(r'"href":"(.*?)"', response1.text)[0]
                            except:
                                p_url = ''
                            if p_url != '':
                                tmp_link.append(p_url)
                                if 'https://www.idealo.de' not in p_url:
                                    p_url = 'https://www.idealo.de'+p_url
                                yield scrapy.Request(url="https://www.idealo.de" + p_url, callback=self.parse_data,meta={"pagesave": pagesave}, dont_filter=True)
            else:
                for link in links:
                    yield scrapy.Request(url="https://www.idealo.de" + link, callback=self.parse_data, meta={"pagesave": pagesave}, dont_filter=True)

            if tmp_link == []:
                forms1 = response.xpath('//form[@class="offerList-item"]/@data-gtm-payload').extract()
                for check in forms1:
                    if '"clusterId":' in check:
                        clusterId = re.findall(r'"clusterId":"(.*?)"', check)[0]
                        p_url1 = f'https://www.idealo.de/preisvergleich/Typ/{clusterId}.html'
                        yield scrapy.Request(url="https://www.idealo.de" + p_url1, callback=self.parse_data, meta={"pagesave": pagesave}, dont_filter=True)

            next_page = response.xpath('//*[@class="pagination-item next"]/a/@href').extract_first()
            if next_page:
                self.page += 1
                header2 = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'accept-language': 'en-US,en;q=0.9',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36',
                    'Cookie': self.cookie
                }
                yield scrapy.Request(url=next_page, callback=self.parse,headers=header2, meta={"pagesave": pagesave,"page":self.page}, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):
        data_text = response.xpath('//*[@data-recentproducts]/@data-recentproducts').extract_first()
        data = json.loads(data_text)
        asin = data['id']

        #---data page save
        pagesave = response.meta['pagesave']
        fpath = f"{str(html_data_directory)}{asin}_{str(pagesave)}.html"
        with open(fpath, 'wb') as f:
            f.write(response.body)

        Product_title = data['productName']
        retailer_selector = response.xpath('//a[@class="productOffers-listItemTitle"]/../..')
        # print(retailer_selector)
        # p = response.xpath('//*[@class="productOffers-listItemTitleInner "]/text()').extract()
        for retailer_data in retailer_selector:
            try:
                Product_name = retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/span/@title').extract()[0].strip()
            except Exception as e:
                print(e)
                Product_name = ''
            if Product_name == '' or Product_name == None:
                i=0
            try:
                Delivery_Provider = '|'.join(retailer_data.xpath('.//*[@class="productOffers-listItemOfferGreyBadge productOffers-listItemOfferDeliveryProvider"]/text()').extract()).strip()
            except Exception as e:
                print(e)
                Delivery_Provider = ''

            try:
                Price = '|'.join(retailer_data.xpath('.//a[@class="productOffers-listItemOfferPrice"]/text()').extract()).strip()
            except Exception as e:
                print(e)
                Price = ''

            try:
                Delivery_Status = retailer_data.xpath('.//*[@class="productOffers-listItemOfferDeliveryStatus"]//text()').extract_first().strip()
            except Exception as e:
                print(e)
                Delivery_Status = ''

            try:
                Ratings_text = '|'.join(retailer_data.xpath('.//*[@class="productOffers-listItemOfferRatingstext"]//text()').extract()).strip()
            except Exception as e:
                print(e)
                Ratings_text = ''

            try:
                Retailer_url = "https://www.idealo.de"+retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/@href').extract_first()
            except Exception as e:
                print(e)
                Retailer_url = ''

            retailer_text = retailer_data.xpath('.//a[@class="productOffers-listItemTitle"]/@data-gtm-payload').extract_first()
            retailer_json = json.loads(retailer_text)
            try:Retailer_name = retailer_json['shop_name']
            except:Retailer_name = ''

            try:Delivery_time = retailer_json['delivery_time']
            except:Delivery_time = ''

            try:Shop_rating = retailer_json['shop_rating']
            except:Shop_rating = ''

            try:Free_return = retailer_json['free_return']
            except:Free_return = ''

            try:Approved_shipping = retailer_json['approved_shipping']
            except:Approved_shipping = ''

            date_today = str(datetime.datetime.now()).split()[0]
            try:
                shop_Hash_id = bytes(str(Retailer_name) + str(Retailer_url) + str(Product_name) + str(date_today), encoding='utf-8')
                retailer_Hash_id = int(hashlib.md5(shop_Hash_id).hexdigest(), 16) % (10 ** 12)
            except Exception as e:
                retailer_Hash_id = ''
                print(e, "retailer_Hash_id")

            try:
                item = IdealoScrapItem_retailer()
                item['PROCESS_DATE'] = datetime.datetime.strftime(datetime.datetime.now(),'%Y-%m-%d')
                item['Url'] = response.url
                item['asin'] = asin
                item['Product_title'] = Product_title
                item['product_name'] = Product_name
                item['Price'] = Price
                item['retailer_name'] = Retailer_name
                item['retailer_url'] = Retailer_url
                item['delivery_time'] = Delivery_time
                item['shop_rating'] = Shop_rating
                item['free_return'] = Free_return
                item['approved_shipping'] = Approved_shipping
                item['Delivery_Status'] = Delivery_Status
                item['Delivery_Provider'] = Delivery_Provider
                item['Ratings_text'] = Ratings_text
                item['Hash_id'] = retailer_Hash_id
                item['page_path'] = fpath.replace('\\','\\\\')
                query1 = db.insert(self.pipe1.Idealo_scrape_retailer_table)
                self.pipe1.connect.execute(query1, dict(item))
                self.pipe1.insert_count += 1
                print('INSERTED Data in Idealo_scrape_retailer_table count ... ', self.pipe1.insert_count)
                # yield item
            except Exception as e:
                print(e)

        #-----code graph ------
        # if "/pricechart/" in response.text:
        #     while True:
        #         graph_url = f"https://www.idealo.de/offerpage/pricechart/api/{asin}?period=P1Y"
        #         # cookie = response.request.headers['Cookie']
        #         headers = {
        #             'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        #             'accept-language': 'en-US,en;q=0.9',
        #             'cookie': self.cookie,
        #             'upgrade-insecure-requests': '1',
        #             'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36'
        #             }
        #         res_g = requests.get(url=graph_url, headers=headers)
        #         response_g = HtmlResponse(url=res_g.url, body=res_g.content)
        #         if res_g.status_code == 200:
        #             g_json = json.loads(response_g.text)
        #             data_g = g_json['data']
        #             for data_graph in data_g:
        #                 Date = data_graph['x']
        #                 Price = data_graph['y']
        #                 try:
        #                     graph_Hash_id = bytes(str(Retailer_name) + str(Product_title) + str(graph_url) + str(Date) + str(Price), encoding='utf-8')
        #                     g_Hash_id = int(hashlib.md5(graph_Hash_id).hexdigest(), 16) % (10 ** 12)
        #                 except Exception as e:
        #                     g_Hash_id = ''
        #                     print(e, "graph_Hash_id")
        #
        #                 try:
        #                     item_g = IdealoScrapItem_graph()
        #                     item_g['PROCESS_DATE'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
        #                     item_g['Url'] = response.url
        #                     item_g['asin'] = asin
        #                     item_g['Date'] = Date
        #                     item_g['Price'] = Price
        #                     item_g['graph_url'] = graph_url
        #                     item_g['Hash_id'] = g_Hash_id
        #                     query2 = db.insert(self.pipe1.Idealo_scrape_graph_table)
        #                     self.pipe1.connect.execute(query2, dict(item_g))
        #                     self.pipe1.insert_count += 1
        #                     print('INSERTED Data in Idealo_scrape_graph_table count ... ', self.pipe1.insert_count)
        #                     # yield item_g
        #                 except Exception as e:
        #                     print(e)
        #                 # break
        #             break
        if '"load_offers":"Weitere Angebote anzeigen",' in response.text:
            load_link = f"https://www.idealo.de/offerpage/offerlist/product/{asin}/start/15/sort/default?includeFilters=0&excludeFilters=2062&postcode="
            yield scrapy.Request(url=load_link, callback=self.parse_data, meta={"pagesave": pagesave}, dont_filter=True)
            # res_l = requests.get(url=load_link)
            # response_l = HtmlResponse(url=res_l, body=res_l.content)
            # print('l')

from scrapy.cmdline import execute
execute('scrapy crawl idealo_crawler'.split())

from idealo_scrap import pipelines as pipe
# from idealo_scrap.spiders import idealo_crawler
import scrapy
cookie = 'SSLB=1; ipcuid=0120jiv900kk22960i; sessionid=2354edda-ba8f-a13d-5fab-87eb9c38d4a5; IDEALO-WISHLIST-XSRF-TOKEN=ed8b990c-8391-4de1-bbb9-e008f6915069; _sp_v1_uid=1:882:c796e4de-4619-47b2-bb9a-b9e87aa0c13f; _sp_v1_lt=1:; _sp_v1_csv=null; consentUUID=3a0d092c-3ae1-4459-8017-96ffb92f62b4; euconsent-v2=CPAMoEbPAMoEbAGABCDEBJCsAP_AAEtAAAYgGzwIAAFAAVAA4ACAAE4AKgAWgA0gCKAI4ATAAoABSACyAFsAMIAjgBSACtAGUAOcAeQA_QCBgEFgIOAhABHQEJgKHAW0AvMBkgDZwEIgCgCOAHOAQMAgsBBwEIAKGQBAAVABMAEcAvMRABABUEgGAAVAA4ACAAFQANAAigBMAEcAP0BQ4C8wGSBoAQAKgCCioAgAKgAmACOAXmOgGgAVAA4ACAAFQANAAigBMAEcAMoAfoChwF5gMkIQBQAVABMAEcAMoBbRKAKABwAJgAjgBlALzKQDQAKgAcABAACoAGgARQAmABSAGUAP0BQ4C8wGSFAAIBBw.YAAAAAAAAAAA; _sp_v1_opt=1:login|true:last_id|11:; SSenabled=true; _gcl_au=1.1.336340040.1610943722; _hjTLDTest=1; _hjid=73e409df-a848-497a-9290-3495c8cd80ff; _fbp=fb.1.1610943722098.1369415861; _hjIncludedInSessionSample=1; iom_consent=010fff00000000&1610943722184; _dcmn_p=DvP6Y2lkPXdXTWEzV0FGRE9wRGtzWWpBT2M; _dcmn_p=DvP6Y2lkPXdXTWEzV0FGRE9wRGtzWWpBT2M; _dcmn_p=DvP6Y2lkPXdXTWEzV0FGRE9wRGtzWWpBT2M; _gid=GA1.2.1022337081.1610943722; SSID=CACTPx1GAAAAAADwGAVgdKMAAfAYBWABAAAAAAAAAAAA8BgFYAIfvMkEAAHYlgAA8BgFYAEArgQAA4yRAADwGAVgAQByBAADEIYAAPAYBWABAK8EAAPwkQAA8BgFYAEA1QQAAcOYAADwGAVgAQA; _sp_v1_ss=1:H4sIAAAAAAAAAItWqo5RKimOUbKKxsrIAzEMamN1YpRSQcy80pwcILsErKC6lgwJJR08VkIVD2mr8BlMZWWxADQdRuO_AQAA; _sp_v1_consent=1!1:1:1:0:0:-1; __gads=ID=b36ef57619feffaf:T=1610946823:S=ALNI_Mb7F8JVkXtq9lB3ZTkoZNlwKqFRFg; QSI_SI_8iHvAsIp4n566xf_intercept=true; ak_bmsc=E3841937F8519B0AD1BA28662583DF7E17D4FE6CDA250000242905604D0F715B~plxwoeWU0AnxlXr2UFo7O/1T3c6RlAq0pXOp4SNgch6wfyKGHXX7Kwf3GML06Aow09GWn4BZoaD8q9APMqnmigowfQJ4odtmTz9ZKTd2YrRzggAHFhGdYFuqiScFGzj3jYthoRDXHS/DwnaF+2tiUr6nKvxXjVAJVR4G24vY2brpuhuDa5yy7ap4u18c48aMT+y9vulLtkjERGE1N7HkmAoPIIvECKMi5EAzoLaZ2aezI=; _hjAbsoluteSessionInProgress=0; AMP_TOKEN=%24NOT_FOUND; SSRT=azkFYAADAA; _dc_gtm_UA-75090708-1=1; SSSC=1.G6918963821612671860.1|1066.30668:1138.34320:1163.35388:1198.37260:1199.37360:1225.38616:1237.39107; SSPV=ry8AAAAAAC0APAAAAAAAAAAAABAAAAAAAAAAAAAA; JSESSIONID=38F653C8DACB61C6D741235B77F6AFEE; bm_sv=6CE6AC03BE7DDADBA8F403B46099EFC3~LNFBulDl9ocxoWBeuCVgubDhkTpt5O/uoTI2nRcau5a0mTMKVQwfQePgne2QCoiY+kNwnAqB711pKxU/SXWhW40ssgdxKudnZUufRBwOSKNqRPyZoN1Xus/mVo5yXs54hkidzyaqsGTJpaqBI5VFcjAJzuq7lttWnFBh3yGTPKo=; _sp_v1_data=2:274614:1610943651:0:24:0:24:0:0:_:-1; _uetsid=b662ae50594411ebba6c6135acb685a6; _uetvid=b662d620594411eb8b8b8fdf1bd02f5d; _ga_NHP4SC1CKE=GS1.1.1610955117.4.1.1610955125.52; _ga=GA1.2.2121614327.1610943722; ioam2018=0013dde630076988260050ce9:1637122922201:1610943722201:.idealo.de:25:cbo:K_2925:noevent:1610955125394:f8phlp'

def Graph():
    pipe1 = pipe.IdealoScrapPipeline()
    try:
        result = pipe1.connect.execute(
            f"select * from [dbo].[Idealo_scrape_retailer_table] where PROCESS_DATE='{self.date_today}'")
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'en-US,en;q=0.9',
            'cookie': cookie,
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36'
        }

        for data in result:
            asin = data[1]
            Retailer_name = data[3]
            url = data[13]
            yield scrapy.Request(url=url, callback=self.parse1, headers=headers, dont_filter=True,
                                 meta={'asin': asin, 'Retailer_name': Retailer_name, 'url': url})
    except Exception as e:
        print(e)
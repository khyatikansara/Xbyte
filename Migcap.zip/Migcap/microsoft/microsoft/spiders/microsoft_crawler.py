# -*- coding: utf-8 -*-
import requests
import datetime
import scrapy
import hashlib
import os
import re
from scrapy.http import HtmlResponse
from microsoft.items import MicrosoftItem_Data

current_directory = os.path.dirname(os.path.abspath(__file__))
html_data_directory = current_directory.replace("XBYTE\\microsoft\\microsoft\\microsoft\\spiders","XBYTE\\microsoft\\") + 'html\\html_data\\'
if not os.path.exists(html_data_directory):
    os.makedirs(html_data_directory)


class MicrosoftSpider(scrapy.Spider):
    name = 'microsoft_crawler'
    allowed_domains = ['www.microsoft.com']
    start_urls = ['https://www.microsoft.com/en-us/microsoft-365/microsoft-teams/across-devices/devices']

    def parse(self, response):
        try:
            pagesave = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
            fpath = f"{str(html_data_directory)}Main_{str(pagesave)}.html"
            with open(fpath, 'wb') as f:
                f.write(response.body)
            cat_links = response.xpath('//ul[@id="singleSelect"]/li/a/@href').extract()
            for cat_link in cat_links:
                page = 1
                # url = "https://www.microsoft.com/en-us/microsoft-365/microsoft-teams/across-devices/" + cat_link
                # real_url = "https://www.microsoft.com/en-us/microsoft-teams/across-devices/devices/category/headsets/36"
                yield scrapy.Request(url=cat_link, callback=self.parse_data,
                                     meta={"real_url":cat_link,"pagesave": pagesave, "page":page}, dont_filter=True)
                # print(result)
                # break
        except Exception as e:
            print(e)

    def parse_data(self, response):
        try:
            pagesave = response.meta['pagesave']
            page = response.meta['page']
            category = response.xpath('//*[@class="c-refine-item ow-category-selected f-selected"]/span/text()').extract_first().strip()
            fpath = f"{str(html_data_directory)}{category}_{str(page)}_{str(pagesave)}.html"
            with open(fpath, 'wb') as f:
                f.write(response.body)

            product_links = response.xpath('//div/a[contains(@href,"product")]/@href').extract()
            for product_link in product_links:
                yield scrapy.Request(
                    url=product_link,
                    callback=self.get_data, meta={"pagesave": pagesave,"category":category}, dont_filter=True)
                # break
            # else:
            #     return product_links
            # headers = {
            #     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            #     'upgrade-insecure-requests': '1',
            #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36',
            #     'Cookie': 'MUID=1EACA50858C06E600C4BB52A594B6F75; X-FD-FEATURES=ids=sfwaab%2catperf680t2%2c10051t1%2c7371t1%2c10312c%2c9002t2%2c10210t1%2ctasmigration010%2ccartemberpl%2c9630t1%2cdisablenorefunds%2cdaconvertenabled%2cenablescarlettmetadata&imp=30f3719e-6b37-4f70-ae08-1ebb503f7911; X-FD-Time=1; isFirstSession=1'
            # }
            total_next = response.xpath('//ul[@id="pagination-list"]/li[contains(@id,"page-nav-li")]/a/text()').extract()
            real_url = response.meta['real_url']
            for i in total_next:
            # while True:
                if 'page=' in response.url:
                    current_page = response.url.split('?page=')[1]
                    page = int(current_page) + 1
                else:
                    page = int(i) + 1
                if str(page) in total_next:
                    next_page = real_url + "?page=" + str(page)
                    yield scrapy.Request(url=next_page, callback=self.parse_data, meta={"real_url":real_url,"pagesave": pagesave, "page": page}, dont_filter=True)
                # break
                # response = requests.request("GET", next_page, headers=headers, data={})
                # res_n = requests.get(url=next_page,headers=headers)
                # response_n = HtmlResponse(url=res_n.url, body=res_n.content)
                # if res_n.status_code == 200:
                #     next_path = f"{str(html_data_directory)}{category}_{str(page)}_{str(pagesave)}.html"
                #     with open(next_path, 'wb') as nf:
                #         nf.write(response_n.body)
                #     product_links = response_n.xpath('//*[@class="ow-product-area"]//div/a[contains(@href,"product?")]/@href').extract()
                #     if product_links == []:
                #         break
                #     else:
                #         for product_link in product_links:
                #             yield scrapy.Request(
                #                 url="https://www.microsoft.com/en-us/microsoft-365/microsoft-teams/across-devices/devices/"+product_link,
                #                 callback=self.get_data, meta={"pagesave": pagesave,"category":category}, dont_filter=True)
                            # break
        except Exception as e:
            print(e)

    def get_data(self, response):
        pagesave = response.meta['pagesave']
        category = response.meta['category']
        product_path = f"{str(html_data_directory)}{response.meta['category']}_{str(response.url.split('/')[-1])}_{str(pagesave)}.html"
        with open(product_path, 'wb') as pf:
            pf.write(response.body)
        try:
            Product_name = response.xpath('//*[@class="ow-device-data"]//h1/text()').extract_first().strip()
        except Exception as e:
            print(e)
            Product_name = ''
        if Product_name == '':
            print("no product name")
            # yield scrapy.Request(url=response.url, callback=self.get_data, meta={"pagesave": pagesave, "category": category}, dont_filter=True)
        else:
            try:
                SKU = response.url.split('/')[-1]
            except Exception as e:
                print(e)

            try:
                present_url = response.url
                present_id = SKU
                if response.xpath('//*[@class="ow-device-sku-variants"]//button'):
                    button_deviceid = response.xpath('//*[@class="ow-device-sku-variants"]//button/@value').extract()
                    for id in button_deviceid:
                        variation_link = re.sub(rf'/{present_id}',f'/{id}',present_url)
                        print(variation_link)
                        yield scrapy.Request(url=variation_link, callback=self.variation_data, meta={"pagesave": pagesave, "category": response.meta['category'], "SKU":SKU, "Main_url":response.url}, dont_filter=True)

                try:Price = response.xpath('//*[@id="itemPrice"]/text()').extract_first().strip()
                except:Price=""
            except Exception as e:
                print(e)

            try:
                manufacturer_name = response.xpath('//*[contains(@class,"ow-device-manufacturer-name")]/text()').extract_first().strip()
            except Exception as e:
                print(e)
                manufacturer_name = ''

            try:
                if response.xpath('//*[@class="c-paragraph-3"]/text()'):
                    description = response.xpath('//*[@class="c-paragraph-3"]/text()').extract_first().strip()
                elif response.xpath('//*[@class="ow-device-data"]//ul[@class="c-list"]/li/text()'):
                    description = ''.join(response.xpath('//*[@class="ow-device-data"]//ul[@class="c-list"]/li/text()').extract()).strip()
                else:
                    description = ''
            except Exception as e:
                print(e)
                description = ''

            # try:
            #     overview = ''.join(response.xpath('//*[@data-module="ow-devices-device-details-pivot"]/section[contains(@class,"ow-pivot-overview")]/div//text()').extract()).strip()
            #     overview = re.sub(r'\n\s+','\n',overview)
            # except Exception as e:
            #     print(e)
            #     overview = ''

            try:
                overview = ''.join(response.xpath('//*[@class="c-heading"]/..//text()').extract()).strip()
                if overview == '':
                    overview = ''.join(response.xpath('//*[@data-module="ow-devices-device-details-pivot"]/section[contains(@class,"ow-pivot-overview")]/div//text()').extract()).strip()
                overview = re.sub(r'\n\s+', '\n', overview)
            except Exception as e:
                print(e)
                overview = ''

            if response.xpath('//span[text()="BUY NOW"]'):
                avai = 'yes'
            else:
                avai = 'No'

            date_today = str(datetime.datetime.now()).split()[0]
            try:
                retailer_Hash_id = bytes(str(SKU) + str(date_today), encoding='utf-8')
                retailer_Hash_id = int(hashlib.md5(retailer_Hash_id).hexdigest(), 16) % (10 ** 12)
            except Exception as e:
                retailer_Hash_id = ''
                print(e, "graph_Hash_id")

            try:
                item = MicrosoftItem_Data()
                item['PROCESS_DATE'] = datetime.datetime.strftime(datetime.datetime.now(),'%Y-%m-%d')
                item['Product_url'] = response.url
                item['SKU'] = SKU
                item['Product_name'] = Product_name
                item['category'] = category
                item['Price'] = Price
                item['manufacturer_name'] = manufacturer_name
                item['description'] = description
                item['overview'] = overview
                item['inventory_stock'] = avai
                item['Hash_id'] = retailer_Hash_id
                yield item
            except Exception as e:
                print(e)

    def variation_data(self, response):
        pagesave = response.meta['pagesave']
        category = response.meta['category']
        product_path = f"{str(html_data_directory)}{response.meta['category']}_{str(response.url.split('/')[-1])}_{str(pagesave)}.html"
        with open(product_path, 'wb') as pf:
            pf.write(response.body)
        try:
            Product_name = response.xpath('//*[@class="ow-device-data"]//h1/text()').extract_first().strip()
        except Exception as e:
            print(e)
            Product_name = ''
        if Product_name == '':
            yield scrapy.Request(url=response.url, callback=self.variation_data, meta={"pagesave": pagesave, "category": category}, dont_filter=True)
        else:
            try:
                SKU = response.url.split('/')[-1]
            except Exception as e:
                print(e)

            try:
                Price = response.xpath('//*[@id="itemPrice"]/text()').extract_first().strip()
            except:
                Price = ""

            try:
                manufacturer_name = response.xpath('//*[contains(@class,"ow-device-manufacturer-name")]/text()').extract_first().strip()
            except Exception as e:
                print(e)
                manufacturer_name = ''

            try:
                if response.xpath('//*[@class="c-paragraph-3"]/text()'):
                    description = response.xpath('//*[@class="c-paragraph-3"]/text()').extract_first().strip()
                elif response.xpath('//*[@class="ow-device-data"]//ul[@class="c-list"]/li/text()'):
                    description = ''.join(response.xpath('//*[@class="ow-device-data"]//ul[@class="c-list"]/li/text()').extract()).strip()
                else:
                    description = ''
            except Exception as e:
                print(e)
                description = ''

            # try:
            #     overview = ''.join(response.xpath('//*[@data-module="ow-devices-device-details-pivot"]/section[contains(@class,"ow-pivot-overview")]/div//text()').extract()).strip()
            #     overview = re.sub(r'\n\s+', '\n', overview)
            # except Exception as e:
            #     print(e)
            #     overview = ''

            try:
                overview = ''.join(response.xpath('//*[@class="c-heading"]/..//text()').extract()).strip()
                if overview == '':
                    overview = ''.join(response.xpath('//*[@data-module="ow-devices-device-details-pivot"]/section[contains(@class,"ow-pivot-overview")]/div//text()').extract()).strip()
                overview = re.sub(r'\n\s+', '\n', overview)
            except Exception as e:
                print(e)
                overview = ''

            if response.xpath('//span[text()="BUY NOW"]'):
                avai = 'yes'
            else:
                avai = 'No'

            date_today = str(datetime.datetime.now()).split()[0]
            try:
                retailer_Hash_id = bytes(str(SKU) + str(date_today), encoding='utf-8')
                retailer_Hash_id = int(hashlib.md5(retailer_Hash_id).hexdigest(), 16) % (10 ** 12)
            except Exception as e:
                retailer_Hash_id = ''
                print(e, "graph_Hash_id")

            try:
                item = MicrosoftItem_Data()
                item['PROCESS_DATE'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                item['Product_url'] = response.url
                item['SKU'] = SKU
                item['Product_name'] = Product_name
                item['category'] = response.meta['category']
                item['Price'] = Price
                item['manufacturer_name'] = manufacturer_name
                item['description'] = description
                item['overview'] = overview
                item['inventory_stock'] = avai
                item['Hash_id'] = retailer_Hash_id
                yield item
            except Exception as e:
                print(e)

from scrapy.cmdline import execute
execute('scrapy crawl microsoft_crawler'.split())
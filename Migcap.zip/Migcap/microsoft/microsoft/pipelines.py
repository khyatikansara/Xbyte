# -*- coding: utf-8 -*-
import os
import ftplib
import platform
import re
from datetime import datetime
# from json2html import *
import smtplib, ssl
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime
# import dropbox
# import json2html
import dropbox
import pandas
import sqlalchemy
from json2html import json2html
import sqlalchemy as db
os_type = str(platform.system()).lower()
from datetime import timedelta, datetime
import pymysql
import logging
from microsoft.items import MicrosoftItem_Data
from microsoft.db_config import config

class MicrosoftPipeline(object):
    insert_count = 0
    def __init__(self):
        try:
            self.connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(
                drivername=config.driver_name, user=config.db_user, passwd=config.db_password, host=config.db_host,
                port=config.db_port, dbname=config.db_name)
            self.connection_string += '?driver=ODBC+Driver+17+for+SQL+Server'

            self.engine = db.create_engine(self.connection_string)
            metadata = db.MetaData()
            self.connect = self.connect = self.engine.connect()

            self.data = db.Table(config.DB_table_data1, metadata,
                                  # db.Column('ID', db.Integer(), primary_key=True),
                                  db.Column('PROCESS_DATE', db.Date),
                                  db.Column('SKU', db.Text),
                                  db.Column('Product_name', db.Text),
                                  db.Column('category', db.Text),
                                  db.Column('Price', db.Text),
                                  db.Column('manufacturer_name', db.Text),
                                  db.Column('description', db.Text),
                                  db.Column('overview', db.Text),
                                  db.Column('inventory_stock', db.Text),
                                  db.Column('Hash_id', db.String(250), primary_key=True),
                                  db.Column('Product_url', db.Text))
            self.summary_table = db.Table(config.DB_table_summary, metadata,
                                          db.Column('script', db.Text),
                                          db.Column('process_date', db.Text),
                                          db.Column('start_time', db.Text),
                                          db.Column('end_time', db.Text),
                                          db.Column('duration', db.Text))

            metadata.create_all(self.engine)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, MicrosoftItem_Data):
            try:
                query = db.insert(self.data)
                self.connect.execute(query, dict(item))
                self.insert_count += 1
                print('INSERTED Data in MICROSOFT_Data count ... ', self.insert_count)
            except Exception as e:
                print(e)

    def close_spider(self, spider):
        if spider.name == "microsoft_crawler":
            try:
                stat = spider.crawler.stats.get_stats()
                start_time = stat['start_time'] + timedelta(hours=-5, minutes=00)
                end_time = datetime.now()
                duration = end_time - start_time
                summary_dict = {
                    "start_time": str(start_time),
                    "end_time": str(end_time),
                    "script": spider.name,
                    "process_date": str(datetime.now()).split()[0],
                    "duration": str(duration),
                }
                query = db.insert(self.summary_table)
                self.connect.execute(query, dict(summary_dict))

            except Exception as e:
                print(e)


            filename = 'microsoft_data_' + str(start_time).split()[0] + '.csv'
            # filename = 'microsoft_data_2021-08-08.csv'
            dropboxlink = ''
            tdate = str(start_time).split()[0]
            # tdate = '2021-08-08'
            try:
                self.connection_string = "{drivername}://{user}:{passwd}@{host}:{port}/{dbname}".format(drivername=config.driver_name, user=config.db_user, passwd=config.db_password, host=config.db_host,port=config.db_port, dbname=config.db_name)
                self.connection_string += '?driver=ODBC+Driver+17+for+SQL+Server'

                self.engine = db.create_engine(self.connection_string)
                self.connect = self.engine.connect()
                # metadata = db.MetaData()

                pandas.set_option('display.width', 20)
                sel_query = sqlalchemy.sql.text(f"SELECT * FROM [dbo].[MICROSOFT.data] where PROCESS_DATE='{tdate}'")
                import pandas as pd

                Current_Directory = os.path.dirname(os.path.abspath(__file__))
                import time
                xbt = time.strftime('%d-%B-%Y')
                xbtmonth = xbt.split('-')[1]

                if "windows" in os_type:
                    csv_path = Current_Directory + '\\spiders\\' + 'CSV\\' + xbtmonth + '\\'
                    csv_path = csv_path.replace('XBYTE\\microsoft\\microsoft\\microsoft\\spiders',"XBYTE\\microsoft")
                    print(csv_path)
                else:
                    csv_path = Current_Directory + '/spiders/' + '/CSV/' + xbtmonth + '/'

                if not os.path.exists(csv_path):
                    os.makedirs(csv_path)

                df = pd.read_sql(sel_query, self.connect)
                df.to_csv(csv_path + filename, index=False)
                print('output generated at : ', csv_path + filename)
                print('File Uploading ... ')
            except Exception as e:
                print(e)

            try:
                access_token = 'Mw46Be7ueY4AAAAAAAAAAU00jILbPUEiwLeAT38dKe2r4RagMsmHZykPizAFE8VB'
                # access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
                file_to = '/Migcap_Project/Microsoft/' + str(xbtmonth) + '/' + filename  # The full path to upload the file to, including the file name
                dbx = dropbox.Dropbox(access_token)

                with open(csv_path + filename, 'rb') as f:
                    dbx.files_upload(f.read(), file_to)
                print('Csv Uploaded To:' + file_to)

                result = dbx.files_get_temporary_link(file_to)
                dropboxlink = result.link
                print('Output Path: ' + dropboxlink)

                # OLD CSV Path

                previous_file = datetime.strftime(datetime.now() - timedelta(1), '%Y-%m-%d')
                dbx_path = csv_path + 'microsoft_data_' + str(previous_file) + ".csv"
                old_df = pd.read_csv(dbx_path, encoding="ISO-8859-1", converters={'zip code': lambda x: str(x)})
                old_data_counts = old_df.count(axis=0).to_dict()

                # Data Count Summary

                dbx_path_ny = csv_path + 'microsoft_data_' + str(tdate) + ".csv"
                old_df_ny = pd.read_csv(dbx_path_ny, encoding="ISO-8859-1", converters={'zip code': lambda x: str(x)})
                new_data_counts = old_df_ny.count(axis=0).to_dict()
                print(new_data_counts)

                count_df = (pd.DataFrame.from_dict([old_data_counts, new_data_counts])).T
                count_df.columns = ['count_old', 'count_new']
                count_df['difference'] = count_df['count_old'] - count_df['count_new']
                count_df['diff_percentage'] = (count_df['difference'] * 100) / count_df['count_old']
                count_df_html = count_df.to_html(na_rep='0', justify='center', border=1)
                totalsin = new_data_counts['Product_url']
                previou_asin = old_data_counts['Product_url']
            except Exception as e:
                print(e)

        if totalsin > 234:
            port = 587
            smtp_server = "smtp.zeptomail.com"
            username = "emailapikey"
            password = "wSsVR61/+hP5DKcszTH5Jbhpml9dVlL0HEV6iVSn7XSpTKzLoMdukkCdVlWjGPgfRDRpHDAWrLIhnBZShztYjdQszVtSDiiF9mqRe1U4J3x17qnvhDzPV2RdlhuAJYgIwwlqmWVoE88k+g=="
            send_to = [
                'tcai@migcap.com',
                'yjeon@migcap.com'
                # 'khyati.xbyte@gmail.com'

            ]
            cc = [
                # 'foram.patel.xbyte@gmail.com',
                'hiral.trivedi.xbyte@gmail.com',
                'alpesh.khunt.xbyte@gmail.com',
                'xbyte.qa@gmail.com',
                'nikhilt.xbyte@gmail.com',
                'kunals.xbyte@gmail.com',
                'khyati.xbyte@gmail.com'
            ]
            msg = MIMEMultipart()
            msg['Subject'] = "microsoft.com Daily Delivery Report (Date : " + str(tdate) + ")"
            msg['From'] = "alerts@xbyte.io"
            msg['To'] = ",".join(send_to)
            msg['CC'] = ",".join(cc)
            mail_content = list()
            mail_content.append("<html>")
            mail_content.append("<head>")
            mail_content.append("<style>")
            mail_content.append("table {border-collapse: collapse;width: 600px;}")
            mail_content.append("</style>")
            mail_content.append("</head>")
            mail_content.append("<body>")
            mail_content.append("<p>Hello Sir/Madam,<br><br> Here is the count of today's run. (Date : " + str(tdate) + ")<br>")
            mail_content.append("<table border='1'>")
            mail_content.append("<tr><td><b>File Name</b></td><td>microsoft_data_" + str(tdate) + "</td></tr>")
            mail_content.append("<tr><td><b>Table Name</b></td><td>MICROSOFT.data</td></tr>")
            mail_content.append("<tr><td><b>Count</b></td><td>" + str(totalsin) + "</td></tr>")
            mail_content.append("<tr><td><b>Previous Count</b></td><td>" + str(previou_asin) + "</td></tr>")

            mail_content.append("<tr><td><b>Start Time</b></td><td>" + str(start_time) + "</td></tr>")
            mail_content.append("<tr><td><b>End Time</b></td><td>" + str(end_time) + "</td></tr>")
            mail_content.append("<tr><td><b>Time Taken</b></td><td>" + str(duration) + "</td></tr>")
            mail_content.append("<tr><td><b>Dropbox Link</b></td><td><a href='" + str(dropboxlink) + "'>microsoft.com" + str(tdate) + "</a></td></tr>")

            mail_content.append("</table>")
            # Data count summary

            # Data count comparision
            mail_content.append("<br><h3>Data Count Comparision For Microsoft_data</h3>")
            m_content = json2html.convert(json=count_df_html)
            m_content = m_content.replace("&lt;", "<")
            m_content = m_content.replace("&gt;", ">")
            m_content = m_content.replace("\n", "")
            m_content = m_content.replace('&quot;', '"')
            mail_content.append(m_content)
            mail_content.append("<br><br>Thank you,<br>")
            mail_content.append("<b>Team Xbyte.</b>")
            mail_content.append("</body>")
            mail_content.append("</html>")

            body = "".join(mail_content)
            with open(f'mail_{tdate}.html', 'w') as o:
                o.write(body)
            msg.attach(MIMEText(body, 'html'))
            try:
                if port == 465:
                    context = ssl.create_default_context()
                    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                        server.login(username, password)
                        server.send_message(msg)
                elif port == 587:
                    with smtplib.SMTP(smtp_server, port) as server:
                        server.starttls()
                        server.login("emailapikey", password)
                        server.send_message(msg)
                else:
                    print("use 465 / 587 as port value")
                    exit()
                print("successfully sent")
            except Exception as e:
                print(e)

            # try:
            #     s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            #     s.connect(('8.8.8.8', 1))
            #     local_ip_address = s.getsockname()[0]
            #
            #     emailId = "alerts@xbyte.io"
            #     emailpass = "xbyte123"
            #
            #     tdate = str(start_time).split()[0]
            #
            #
            #     send_to = [
            #         'tcai@migcap.com',
            #         'yjeon@migcap.com'
            #         # 'khyati.xbyte@gmail.com'
            #
            #     ]
            #     cc = [
            #         # 'foram.patel.xbyte@gmail.com',
            #         'hiral.trivedi.xbyte@gmail.com',
            #         'alpesh.khunt.xbyte@gmail.com',
            #         'xbyte.qa@gmail.com',
            #         'vishal.xbyte@gmail.com',
			# 		'kunals.xbyte@gmail.com',
            #         'khyati.xbyte@gmail.com'
            #     ]
            #
            #     # data_counts = df.count(axis=0).to_dict()
            #
            #     mail_content = list()
            #     mail_content.append("<html>")
            #     mail_content.append("<head>")
            #     mail_content.append("<style>")
            #     mail_content.append("table {border-collapse: collapse;width: 600px;}")
            #     mail_content.append("</style>")
            #     mail_content.append("</head>")
            #     mail_content.append("<body>")
            #     mail_content.append("<p>Hello Sir/Madam,<br><br> Here is the count of today's run. (Date : " + str(tdate) + ")<br>")
            #     mail_content.append("<table border='1'>")
            #     mail_content.append("<tr><td><b>File Name</b></td><td>microsoft_data_" + str(tdate) + "</td></tr>")
            #     mail_content.append("<tr><td><b>Table Name</b></td><td>MICROSOFT.data</td></tr>")
            #     mail_content.append("<tr><td><b>Count</b></td><td>" + str(totalsin) + "</td></tr>")
            #     mail_content.append("<tr><td><b>Previous Count</b></td><td>" + str(previou_asin) + "</td></tr>")
            #
            #     mail_content.append("<tr><td><b>Start Time</b></td><td>" + str(start_time) + "</td></tr>")
            #     mail_content.append("<tr><td><b>End Time</b></td><td>" + str(end_time) + "</td></tr>")
            #     mail_content.append("<tr><td><b>Time Taken</b></td><td>" + str(duration) + "</td></tr>")
            #     mail_content.append("<tr><td><b>Dropbox Link</b></td><td><a href='" + str(dropboxlink) + "'>microsoft.com" + str(tdate) + "</a></td></tr>")
            #
            #     mail_content.append("</table>")
            #     # Data count summary
            #
            #     # Data count comparision
            #     mail_content.append("<br><h3>Data Count Comparision For Microsoft_data</h3>")
            #     m_content = json2html.convert(json=count_df_html)
            #     m_content = m_content.replace("&lt;", "<")
            #     m_content = m_content.replace("&gt;", ">")
            #     m_content = m_content.replace("\n", "")
            #     m_content = m_content.replace('&quot;', '"')
            #     mail_content.append(m_content)
            #     mail_content.append("<br><br>Thank you,<br>")
            #     mail_content.append("<b>Team Xbyte.</b>")
            #     mail_content.append("</body>")
            #     mail_content.append("</html>")
            #     # mail_content.append("<br><h3>Data Count Summary</h3>")
            #     # mail_content.append(json2html.convert(json=data_counts))
            #
            #     body = "".join(mail_content)
            #     with open(f'mail_{tdate}.html', 'w') as o:
            #         o.write(body)
            #
            #     try:
            #         emailId = "emailapikey"
            #         emailpass = "wSsVR61/+hP5DKcszTH5Jbhpml9dVlL0HEV6iVSn7XSpTKzLoMdukkCdVlWjGPgfRDRpHDAWrLIhnBZShztYjdQszVtSDiiF9mqRe1U4J3x17qnvhDzPV2RdlhuAJYgIwwlqmWVoE88k+g=="
            #         SMTP_Host = 'smtp.zeptomail.com'
            #         # User = 'emailapikey'
            #         # Pass = 'Kx]]c6DX*[LO'
            #         # SSl = True
            #         # tls = True
            #         Port = 587
            #         msg = MIMEMultipart()
            #         msg['From'] = emailId
            #         msg['To'] = ",".join(send_to)
            #         msg['CC'] = ",".join(cc)
            #         msg['Subject'] = "microsoft.com Daily Delivery Report (Date : " + str(tdate) + ")"
            #         msg.attach(MIMEText(body, 'html'))
            #         s = smtplib.SMTP(SMTP_Host, Port)
            #         s.starttls()
            #         s.login(emailId, emailpass)
            #         text = msg.as_string()
            #         s.sendmail(emailId, send_to + cc, text)
            #         print("Mail Sent ...")
            #         s.quit()
            #     except Exception as e:
            #         print(e)
            # except Exception as e:
            #     print(e)
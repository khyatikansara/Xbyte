import datetime


class config():
    db_host = "bc5756vevd.database.windows.net"
    db_user = "xbyte"
    db_password = "X1b1y1t1e1"
    db_name = "XBYTE"
    db_port ="1433"
    driver_name = "mssql+pyodbc"
    DB_table_data1 = 'MICROSOFT.data'
    DB_table_summary = 'MICROSOFT.script_summary'


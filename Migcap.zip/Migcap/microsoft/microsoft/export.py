import pandas as pd
import pymysql
import sqlite3
from unidecode import unidecode

def export_data():
    try:
        db_con = pymysql.connect('192.168.1.252', 'root', 'xbyte', 'microsoft_migcap2')
        sql = f"Select * from microsoft_migcap2.data"
        df_all = pd.read_sql(sql, db_con)
        output_path = "D:\\khyati-H\\migcap\\microsoft\\microsoft.csv"
        df_all.drop(columns=['Hash_id'], inplace=True)
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', ' ') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        df_all.to_csv(output_path, index=True)
        print('CSV File generated', output_path)
    except Exception as e:
        print(e)

export_data()
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from itemadapter import ItemAdapter

from oriparts.items import OripartsItem, OripartsItem1, OripartsItem2, OripartsItem3, OripartsItem4


class OripartsPipeline:
    host = "localhost"
    passwd = "xbyte"
    uname = "root"
    db = "oriparts"
    insertcount = 0
    con1 = pymysql.connect(host, uname, passwd)

    def __init__(self):
        try:
            self.con1.cursor().execute("CREATE DATABASE IF NOT EXISTS " + self.db)
            con = pymysql.connect(self.host, self.uname, self.passwd, self.db)
            crsr = con.cursor()

            # CT = """drop table if exists clv_data_nov1 """
            # crsr.execute(CT)

            CT = """CREATE TABLE IF NOT EXISTS main(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                    id VARCHAR(100),
                                                    name longtext,
                                                    link longtext,
                                                    img_name VARCHAR(100),
                                                    url longtext,
                                                    status VARCHAR(50),
                                                    hash_id VARCHAR(100) UNIQUE,
                                                    html_path VARCHAR(700),
                                                    img_path VARCHAR(700),
                                                    img_stat VARCHAR(50),
                                                    PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                                        """

            crsr.execute(CT)

            CT1 = """CREATE TABLE IF NOT EXISTS child_1(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                        P1 VARCHAR(100),
                                                        id VARCHAR(100),
                                                        Name longtext,
                                                        Region longtext,
                                                        Product_Year VARCHAR(100),
                                                        Engine longtext,
                                                        Description longtext,
                                                        Chassis_Type longtext,
                                                        V_no longtext,
                                                        url longtext,
                                                        hash_id VARCHAR(100) UNIQUE,
                                                        html_path VARCHAR(700),
                                                        status VARCHAR(50),
                                                        PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                                                    """

            crsr.execute(CT1)

            CT2 = """CREATE TABLE IF NOT EXISTS child_2(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                        P1 VARCHAR(100),
                                                        P2 VARCHAR(100),
                                                        id VARCHAR(100),
                                                        Name longtext,
                                                        Details longtext,
                                                        image longtext,
                                                        url longtext,
                                                        html_path longtext,
                                                        hash_id VARCHAR(100) UNIQUE,
                                                        status VARCHAR(50),
                                                        img_path VARCHAR(700),
                                                        img_stat VARCHAR(50),
                                                        PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                                                                """

            crsr.execute(CT2)

            CT3 = """CREATE TABLE IF NOT EXISTS child_3(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                                    P1 VARCHAR(100),
                                                                    P2 VARCHAR(100),
                                                                    P3 VARCHAR(100),
                                                                    id VARCHAR(100),
                                                                    Details longtext,
                                                                    Name longtext,
                                                                    image longtext,
                                                                    url longtext,
                                                                    html_path longtext,
                                                                    hash_id VARCHAR(100) UNIQUE,
                                                                    status VARCHAR(50),
                                                                    img_path VARCHAR(700),
                                                                    img_stat VARCHAR(50),
                                                                    PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                                                                            """

            crsr.execute(CT3)

            CT4 = """CREATE TABLE IF NOT EXISTS child_4_pre(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                        P1 VARCHAR(100),
                                                        P2 VARCHAR(100),
                                                        P3 VARCHAR(100),
                                                        P4 VARCHAR(100),
                                                        Name longtext,
                                                        Image_name VARCHAR(100),
                                                        Image longtext,
                                                        Codinates longtext,
                                                        left_top longtext,
                                                        Fig_No VARCHAR(100),
                                                        Part_no VARCHAR(300),
                                                        Price VARCHAR(500),
                                                        status_code longtext,
                                                        Description longtext,
                                                        QTY VARCHAR(100),
                                                        Remarks longtext,
                                                        URL longtext,
                                                        pp_url longtext,
                                                        data_id VARCHAR(300),
                                                        status VARCHAR(50),
                                                        img_path longtext,
                                                        img_name longtext,
                                                        img_stat VARCHAR(50),
                                                        hash_id VARCHAR(100) UNIQUE,
                                                        html_path longtext,
                                                        PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                        """

            crsr.execute(CT4)

            CT5 = """CREATE TABLE IF NOT EXISTS child_4_new(sr_no INT UNSIGNED NOT NULL AUTO_INCREMENT,
                                                                    P1 VARCHAR(100),
                                                                    P2 VARCHAR(100),
                                                                    P3 VARCHAR(100),
                                                                    P4 VARCHAR(100),
                                                                    Name longtext,
                                                                    Image_name VARCHAR(100),
                                                                    Image longtext,
                                                                    Codinates longtext,
                                                                    left_top longtext,
                                                                    Fig_No VARCHAR(100),
                                                                    Part_no VARCHAR(300),
                                                                    Price VARCHAR(500),
                                                                    status_code longtext,
                                                                    Description longtext,
                                                                    QTY VARCHAR(100),
                                                                    Remarks longtext,
                                                                    URL longtext,
                                                                    pp_url longtext,
                                                                    # data_id VARCHAR(300),
                                                                    status VARCHAR(50),
                                                                    img_path longtext,
                                                                    img_name longtext,
                                                                    img_stat VARCHAR(50),
                                                                    hash_id VARCHAR(100) UNIQUE,
                                                                    html_path longtext,
                                                                    PRIMARY KEY(sr_no))DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;
                                                                    """

            crsr.execute(CT5)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, OripartsItem):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, 'oriparts')
                crsr = con.cursor()

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)

                values = "','".join(value_list)
                insert_db = "insert into main " + "( " + fields + " ) values ( '" + values + "' )"
                crsr.execute(insert_db)
                con.commit()
                print('data inserted in main....')
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, OripartsItem1):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, 'oriparts')
                crsr = con.cursor()

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)

                values = "','".join(value_list)
                insert_db = "insert into child_1 " + "( " + fields + " ) values ( '" + values + "' )"
                crsr.execute(insert_db)
                con.commit()
                print('data inserted in child_1....')
                if insert_db:
                    sql = (f"UPDATE oriparts.main SET status = 'done' WHERE  id = '{str(item['P1'])}';")
                    crsr.execute(sql)
                    con.commit()
                    print('status = Done....')
                con.commit()
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, OripartsItem2):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, 'oriparts')
                crsr = con.cursor()

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)

                values = "','".join(value_list)
                insert_db = "insert into child_2 " + "( " + fields + " ) values ( '" + values + "' )"
                crsr.execute(insert_db)
                con.commit()
                print('data inserted in child_1....')
                # if insert_db:
                #     sql = (f"UPDATE oriparts.main SET status = 'done' WHERE  id = '{str(item['P1'])}';")
                #     crsr.execute(sql)
                #     con.commit()
                #     print('status = Done....')
                # con.commit()
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, OripartsItem3):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, 'oriparts')
                crsr = con.cursor()

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)

                values = "','".join(value_list)
                insert_db = "insert into child_3 " + "( " + fields + " ) values ( '" + values + "' )"
                crsr.execute(insert_db)
                con.commit()
                print('data inserted in child_3....')
                # if insert_db:
                #     sql = (f"UPDATE oriparts.main SET status = 'done' WHERE  id = '{str(item['P1'])}';")
                #     crsr.execute(sql)
                #     con.commit()
                #     print('status = Done....')
                # con.commit()
            except Exception as e:
                print(str(e))
            return item

        if isinstance(item, OripartsItem4):
            try:
                con = pymysql.connect(self.host, self.uname, self.passwd, 'oriparts')
                crsr = con.cursor()

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)

                values = "','".join(value_list)
                # insert_db = "insert into child_4_pre " + "( " + fields + " ) values ( '" + values + "' )"
                insert_db = "insert into child_4_new " + "( " + fields + " ) values ( '" + values + "' )"
                crsr.execute(insert_db)
                con.commit()
                print('data inserted in child_4_new....')
                # if insert_db:
                #     sql = (f"UPDATE oriparts.main SET status = 'done' WHERE  id = '{str(item['P1'])}';")
                #     crsr.execute(sql)
                #     con.commit()
                #     print('status = Done....')
                # con.commit()
            except Exception as e:
                print(str(e))
            return item
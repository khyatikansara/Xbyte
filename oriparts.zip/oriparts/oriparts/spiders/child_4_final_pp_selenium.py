import hashlib
import json
import random
import re
import time
import pymysql
import scrapy
from requests.adapters import HTTPAdapter
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
import requests
from urllib3 import Retry
import http.client
from selenium import webdriver

proxy = [
    "alpesh.khunt.xbyte@gmail.com|xbyte123",
    # "lum-customer-xbyte-zone-zone_germany|germany@2018",
    # "lum-customer-xbyte-zone-zone_uk|bqa3iap0g4nr",
    # # "lum-customer-xbyte-zone-zone_france|france@2018",
    # # "lum-customer-xbyte-zone-zone_spain|k4vt6e2v53v9",
    # # "lum-customer-xbyte-zone-zone_italy|et2g17oqw1nm",
    # "lum-customer-xbyte-zone-zone_australia|rjbsuy1tzgco",
    # "lum-customer-xbyte-zone-zone_japan|5v9sl7ilbppn",
    # # "lum-customer-xbyte-zone-zone_taiwan|b2kqeq76cxi6",
    # # "lum-customer-xbyte-zone-zone_netherland|zvptczvd2ahq",
    # "lum-customer-xbyte-zone-zone_russia|plpsy85v8pu6",
    # "lum-customer-xbyte-zone-zone_india|w6zj0g4ikjy3",
    # "lum-customer-xbyte-zone-zone_israel|gtuythxi5oc3"
]

current_proxy = random.choice(proxy).split("|")
proxy_host = "108.59.14.200"
proxy_port = "13202"
proxy_auth = str(current_proxy[0]) + ":" + str(current_proxy[1])
proxies = {"https": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
           "http": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)}


class ChildFinalPPSpider(scrapy.Spider):
    name = 'child4_pp_final_selenium'
    # allowed_domains = ['www.example.com']
    # start_urls = ['https://oriparts.com/7']
    cnt = 0
    start = ''
    end = ''

    def start_requests(self):
        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(chrome_options=options)
        connection = pymysql.connect(host='192.168.1.252', database='oriparts_hundai', user='root', password='xbyte')

        # sql_select_Query = f"select * from child_3 where status='Pending' limit {self.start},{self.end}"
        # sql_select_Query = f"select * from child_3 where img_stat='done123' AND sr_no BETWEEN '{self.start}' AND '{self.end}'"
        sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' limit {self.start},{self.end}"
        # sql_select_Query = f"SELECT * FROM child_3 WHERE P3 = '830459'"
        # sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' AND sr_no BETWEEN {self.start} AND {self.end}"
        cursor = connection.cursor()
        cursor.execute(sql_select_Query)
        records = cursor.fetchall()

        for row in records:
            srno = row[0]
            # P1 = row[1]
            # P2 = row[2]
            # P3 = row[3]
            # id = row[4]
            # Details = row[5]
            # Name = row[6]
            pp_link = row[16]
            driver.get(pp_link)
            print()

if __name__ == '__main__':
    execute('scrapy crawl child4_pp_final_selenium -a start=0 -a end=500'.split())
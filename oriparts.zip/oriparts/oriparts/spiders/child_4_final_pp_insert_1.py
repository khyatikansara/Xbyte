import hashlib
import json
import random
import re
import pandas as pd
import time
import pymysql
import scrapy
from requests.adapters import HTTPAdapter
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
import requests
from urllib3 import Retry
import http.client
from selenium import webdriver

proxy = [
    "alpesh.khunt.xbyte@gmail.com|xbyte123",
                    # "lum-customer-xbyte-zone-zone_germany|germany@2018",
                    # "lum-customer-xbyte-zone-zone_uk|bqa3iap0g4nr",
                    # # "lum-customer-xbyte-zone-zone_france|france@2018",
                    # # "lum-customer-xbyte-zone-zone_spain|k4vt6e2v53v9",
                    # # "lum-customer-xbyte-zone-zone_italy|et2g17oqw1nm",
                    # "lum-customer-xbyte-zone-zone_australia|rjbsuy1tzgco",
                    # "lum-customer-xbyte-zone-zone_japan|5v9sl7ilbppn",
                    # # "lum-customer-xbyte-zone-zone_taiwan|b2kqeq76cxi6",
                    # # "lum-customer-xbyte-zone-zone_netherland|zvptczvd2ahq",
                    # "lum-customer-xbyte-zone-zone_russia|plpsy85v8pu6",
                    # "lum-customer-xbyte-zone-zone_india|w6zj0g4ikjy3",
                    # "lum-customer-xbyte-zone-zone_israel|gtuythxi5oc3"
]

current_proxy = random.choice(proxy).split("|")
proxy_host = "108.59.14.200"
proxy_port = "13202"
proxy_auth = str(current_proxy[0])+":"+str(current_proxy[1])
proxies = {"https": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
      "http": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)}


class ChildFinalPPSpider(scrapy.Spider):
    name = 'child4_pp_final_insert_1'
    # allowed_domains = ['www.example.com']
    # start_urls = ['https://oriparts.com/7']
    cnt = 0
    start = ''
    end = ''
    limit = ''

    def start_requests(self):
        list_252_1 = []
        connection = pymysql.connect(host='192.168.1.252', database='oriparts_hundai', user='root', password='xbyte')
        sql_select_Query1 = f"select * from `child4_hundai_final_252_1`"
        cursor = connection.cursor()
        cursor.execute(sql_select_Query1)
        records1 = cursor.fetchall()
        for row1 in records1:
            pp1 = row1[2]
            list_252_1.append(pp1)
        # sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' and sr_no>'{self.start}' and sr_no<'{self.end}'"
        # sql_select_Query = f"select * from child_3 where status='Pending' AND sr_no{self.start}' AND '{self.end}'"
        # sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' limit {self.start},{self.end}"
        # sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' AND pp_url LIKE '%/redirect%' AND sr_no>'{self.start}' and sr_no<'{self.end}' GROUP BY pp_url limit {self.limit},500"
        sql_select_Query = f"select * from `child4_hundai_final` where sr_no>'{self.start}' and sr_no<'{self.end}' and status_insert='pending'"
        # sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' AND sr_no BETWEEN {self.start} AND {self.end}"
        cursor = connection.cursor()
        cursor.execute(sql_select_Query)
        records = cursor.fetchall()
        # list = [['812301J010', 701.0, 'https://oriparts.com/redirect/product/820447'], ['81456-07000', 192.0, 'https://oriparts.com/redirect/product/820449'], ['817201J020', 645.0, 'https://oriparts.com/redirect/product/820450'], ['817501J0009R', 858.0, 'https://oriparts.com/redirect/product/820451'], ['817701J000', 611.0, 'https://oriparts.com/redirect/product/820452'], ['817701J010', 611.0, 'https://oriparts.com/redirect/product/820453'], ['817801J000', 611.0, 'https://oriparts.com/redirect/product/820454'], ['817801J010', 611.0, 'https://oriparts.com/redirect/product/820455']]
        for row in records:
            try:
                srno = row[0]
                print(srno)
                # P1 = row[1]
                # P2 = row[2]
                # P3 = row[3]
                # id = row[4]
                # Details = row[5]
                # Name = row[6]
                pp_link = row[16]
                if pp_link not in list_252_1:
                    # pp_link = 'https://oriparts.com/redirect/product/805094'
                    # url = row[7]
                    headers = {
                        # 'authority': 'postmates.com',
                        # 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                        # 'user-agent': str(get_useranget)
                        # # 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
                        # # 'Cookie': 'dId=fb51b87c-8b4f-4325-bd01-b12614d7421b; jwt-session=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MjQ4ODIwNDgsImV4cCI6MTYyNDk2ODQ0OH0.Paa7tiWv2799epvJcAFuna8Zwn6eVyfs9fpLMuKkqgE; marketing_vistor_id=02ca1e9f-189d-46a1-b7e3-c5d5bdd4a175; uev2.id.session=7f499306-db68-417b-b510-eaaeacf55233; uev2.id.xp=2371b57b-83b9-42ee-882a-f9143ed95ecf; uev2.loc=%7B%22address%22%3A%7B%22address1%22%3A%2210001%20Foster%20Ave%22%2C%22address2%22%3A%22Brooklyn%2C%20New%20York%22%2C%22aptOrSuite%22%3A%22%22%2C%22eaterFormattedAddress%22%3A%2210001%20Foster%20Ave%2C%20Brooklyn%2C%20NY%2011236%2C%20US%22%2C%22subtitle%22%3A%22Brooklyn%2C%20New%20York%22%2C%22title%22%3A%2210001%20Foster%20Ave%22%2C%22uuid%22%3A%22%22%7D%2C%22latitude%22%3A40.649890418494735%2C%22longitude%22%3A-73.90326227810849%2C%22reference%22%3A%2218d6c270-36f0-d6be-4125-dbbcd33adfd9%22%2C%22referenceType%22%3A%22uber_places%22%2C%22type%22%3A%22uber_places%22%2C%22source%22%3A%22rev_geo_reference%22%2C%22addressComponents%22%3A%7B%22countryCode%22%3A%22US%22%2C%22firstLevelSubdivisionCode%22%3A%22NY%22%2C%22city%22%3A%22Brooklyn%22%2C%22postalCode%22%3A%2211236%22%7D%2C%22originType%22%3A%22user_autocomplete%22%7D; uev2.ts.session=1624882048447'
                        'sec-ch-ua': '"Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                        'sec-ch-ua-mobile': '?0',
                        'Upgrade-Insecure-Requests': '1',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36'
                        # 'user-agent': str(get_useranget)
                    }

                    try:
                        while True:
                            res12 = requests.get(url=pp_link, headers=headers)
                            # session = requests.Session()
                            # retry = Retry(connect=3, backoff_factor=0.5)
                            # adapter = HTTPAdapter(max_retries=retry)
                            # session.mount('http://', adapter)
                            # session.mount('https://', adapter)
                            # res12 = session.get(pp_link, headers=headers)
                            if res12.status_code == 429:
                                time.sleep(int(res12.headers["Retry-After"]))
                            if res12.status_code != 429:
                                break
                    except Exception as e:
                        print(e)
                    # print(res12)
                    print(res12)
                    data_id = str(res12.url).split('-')[-1].replace('/', '')
                    url2 = f'https://boodmo.com/api/seller/offer/list/{data_id}'
                    url3 = f'https://boodmo.com/api/seller/offer/list/{data_id}'
                    if 'oriparts.comredirectproduct' in str(url2):
                        url2 = 'https://boodmo.com/api/seller/offer/list/' + str(url2).split('comredirectproduct')[-1]
                        data_id = str(url3).split('comredirectproduct')[-1]
                    else:
                        url2 = url2
                        data_id = data_id

                    # ----------- Price and part number --------------

                    pp_url1 = str(url2).split('https://boodmo.com')[-1]
                    conn = http.client.HTTPSConnection("boodmo.com")

                    headers = {
                        'accept': "application/json, text/plain, */*",
                        'referer': "https://boodmo.com/",
                        'user-agent': "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)",
                        'x-boo-sign': "6ec77c95f9e14c5a5466088c6b455713",
                        'x-build': "210719.10",
                        'x-date': "2021-07-26T12:03:24.717Z",
                        'x-version': "2.1.0",
                        'cache-control': "no-cache",
                    }

                    conn.request("GET", f"{pp_url1}", headers=headers)
                    res = conn.getresponse()
                    data = res.read()
                    resw = HtmlResponse(url=url2, body=data, encoding="utf-8")
                    # d1 = json.loads(resw.text)
                    try:
                        d1 = json.loads(resw.text)
                        while True:
                            if d1['items'] == []:
                                print(d1['items'])
                                pp_url1 = f"https://boodmo.com/api/catalog/part/{pp_url1.split('/')[-1]}"
                                conn.request("GET", f"{pp_url1}", headers=headers)
                                res = conn.getresponse()
                                data = res.read()
                                resw = HtmlResponse(url=url2, body=data, encoding="utf-8")
                                d11 = json.loads(resw.text)
                                if d11['number']:
                                    break
                            else:
                                break
                        # d1 = json.loads(resw.text)
                        try:
                            if d1['items'] != []:
                                price = int(d1['items'][0]['price']) / 100
                            else:
                                price = ''
                        except Exception as e:
                            price = 'price not found'
                        try:
                            if d1['items'] != []:
                                part_number = str(d1['items'][0]['part']['number'])
                            else:
                                part_number = d11['number']
                        except Exception as e:
                            part_number = 'part number not found'

                        # try:
                        #     price = int(d1['items'][0]['price']) / 100
                        # except Exception as e:
                        #     price = 'price not found'
                        # try:
                        #     part_number = str(d1['items'][0]['part']['number'])
                        # except Exception as e:
                        #     part_number = 'part number not found'

                        if 'LX ' in part_number:
                            print(part_number)

                        if ' ' in part_number:
                            if 'part number not found' not in part_number:
                                price = ''
                                part_number = ''
                            else:
                                price = price
                                part_number = part_number

                    except Exception as e:
                        price = ''
                        part_number = ''
                        print(e)

                    if part_number == '' and price == '':
                        print('issue')

                    if part_number:
                        # list.append([part_number,price,pp_link])
                        # print(list)
                        while True:
                            try:
                                insert = f"INSERT INTO `oriparts_hundai`.`child4_hundai_final_252_1` (`Part_no`,`Price`,`pp_url`) VALUES ('{part_number}','{price}','{pp_link}');"
                                cursor.execute(insert)
                                connection.commit()
                                print("khyati insert done for srno....", pp_link)
                                list_252_1.append(pp_link)
                                break
                            except Exception as e:
                                print(e)
            except Exception as e:
                print(e)
        # gh = pd.DataFrame(list, columns=['part_number', 'price', 'pp_link'])
        # gh.to_csv(f"oriparts_child4_0_50054.csv", index=False)
        # print(f"File generated")


if __name__ == '__main__':

    execute('scrapy crawl child4_pp_final_insert_1 -a start=352444 -a end=411106'.split())

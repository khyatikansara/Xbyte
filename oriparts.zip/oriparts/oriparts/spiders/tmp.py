import hashlib
import json
import random
import re
import pandas as pd
import time
import pymysql
import scrapy
from requests.adapters import HTTPAdapter
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
import requests
from urllib3 import Retry
import http.client
from selenium import webdriver


class TmpSpider(scrapy.Spider):
    name = 'tmp'
    # allowed_domains = ['www.example.com']
    # start_urls = ['https://oriparts.com/7']
    cnt = 0
    start = ''
    end = ''
    limit = 0

    def start_requests(self):
        df1 = pd.read_csv("0_50054.csv")
        df1 = df1.fillna('')
        df2 = pd.read_csv("50053_100148.csv")
        df2 = df2.fillna('')
        df3 = pd.read_csv("150204_200282.csv")
        df3 = df3.fillna('')
        df4 = pd.read_csv("200280_250350.csv")
        df4 = df4.fillna('')
        df5 = pd.read_csv("352444_411106.csv")
        df5 = df5.fillna('')
        df6 = pd.read_csv("411105_470793.csv")
        df6 = df6.fillna('')
        df7 = pd.read_csv("470792_526213.csv")
        df7 = df7.fillna('')
        connection = pymysql.connect(host='192.168.1.252', database='oriparts_hundai', user='root', password='xbyte')
        cursor = connection.cursor()
        # select_distinct = f"select distinct pp_url from `child4_hundai_final_252` where sr_no>'{self.start}' and sr_no<'{self.end}'"
        # cursor.execute(select_distinct)
        # records1 = cursor.fetchall()
        # for tmp_url in records1:
        #     sql = f"UPDATE oriparts_hundai.child4_hundai_final SET `status` = 'pp_done_final' WHERE  pp_url = '{tmp_url[0]}'"
        #     cursor.execute(sql)
        #     connection.commit()
        #     print("khyati update done for srno....", tmp_url[0])
        sql_select_Query = f"select * from `child4_hundai_final` where sr_no>'{self.start}' and sr_no<'{self.end}' and status_insert='pending' limit {self.limit},1000000"
        cursor.execute(sql_select_Query)
        records = cursor.fetchall()
        blank_list = []
        for row in records:
            try:
                sr_no = row[0]
                P1 = row[1]
                P2 = row[2]
                P3 = row[3]
                P4 = row[4]
                Name = row[5]
                Image_name = row[6]
                Image = row[7]
                left_top = row[8]
                Fig_No = row[9]
                Part_no = row[10]
                Price = row[11]
                Description = row[12]
                QTY = row[13]
                Remarks = row[14]
                URL = row[15]
                pp_url = row[16]
                img_path = row[17]
                img_name = row[18]
                hash_id = row[19]
                html_path = row[20]
                status = row[21]
                df_flag = False
                if Part_no == '':
                    df11 = df1[df1['pp_url'] == pp_url]
                    if df11.empty:
                        print("Df1 empty")
                        df22 = df2[df2['pp_url'] == pp_url]
                        if df22.empty:
                            print("Df2 empty")
                            df33 = df3[df3['pp_url'] == pp_url]
                            if df33.empty:
                                print("Df3 empty")
                                df44 = df4[df4['pp_url'] == pp_url]
                                if df44.empty:
                                    print("Df4 empty")
                                    df55 = df5[df5['pp_url'] == pp_url]
                                    if df55.empty:
                                        print("Df5 empty")
                                        df66 = df6[df6['pp_url'] == pp_url]
                                        if df66.empty:
                                            print("Df6 empty")
                                            df77 = df7[df7['pp_url'] == pp_url]
                                            if df77.empty:
                                                print("Df7 empty")
                                            else:
                                                df_flag = True
                                        else:
                                            df_flag = True
                                    else:
                                        df_flag = True
                                else:
                                    df_flag = True
                            else:
                                df_flag = True
                        else:
                            df_flag = True
                    else:
                        df_flag =True
                    if df_flag == True:
                        Part_no = df1['Part_no'].values[0]
                        Price = df1['Price'].values[0]
                        insert = f"INSERT INTO `oriparts_hundai`.`child4_hundai_final_final`(`sr_no`,`P1`,`P2`,`P3`,`P4`,`Name`,`Image_name`,`Image`,`left_top`,`Fig_No`,`Part_no`,`Price`,`Description`,`QTY`,`Remarks`,`URL`,`pp_url`,`img_path`,`img_name`,`hash_id`,`html_path`,`status`)VALUES('{sr_no}','{P1}','{P2}','{P3}','{P4}','{Name}','{Image_name}','{Image}','{left_top}','{Fig_No}','{Part_no}','{Price}','{Description}','{QTY}','{Remarks}','{URL}','{pp_url}','{img_path}','{img_name}','{hash_id}','{html_path}','pp_done_final')"
                        cursor.execute(insert)
                        connection.commit()
                        print("khyati insert done for srno....", sr_no)
                        sql = f"UPDATE `child4_hundai_final` SET `status_insert` = 'Done' WHERE sr_no = '{sr_no}'"
                        cursor.execute(sql)
                        connection.commit()
                        print("khyati update done for srno....", sr_no)
                else:
                    insert = f"INSERT INTO `oriparts_hundai`.`child4_hundai_final_final`(`sr_no`,`P1`,`P2`,`P3`,`P4`,`Name`,`Image_name`,`Image`,`left_top`,`Fig_No`,`Part_no`,`Price`,`Description`,`QTY`,`Remarks`,`URL`,`pp_url`,`img_path`,`img_name`,`hash_id`,`html_path`,`status`)VALUES('{sr_no}','{P1}','{P2}','{P3}','{P4}','{Name}','{Image_name}','{Image}','{left_top}','{Fig_No}','{Part_no}','{Price}','{Description}','{QTY}','{Remarks}','{URL}','{pp_url}','{img_path}','{img_name}','{hash_id}','{html_path}','{status}')"
                    cursor.execute(insert)
                    connection.commit()
                    print("khyati insert done for srno....", sr_no)
                    sql = f"UPDATE `child4_hundai_final` SET `status_insert` = 'Done' WHERE sr_no = '{sr_no}'"
                    cursor.execute(sql)
                    connection.commit()
                    print("khyati update done for srno....", sr_no)
                # print(blank_list)
            except Exception as e:
                print(e)
        print(blank_list)


if __name__ == '__main__':

    execute('scrapy crawl tmp -a start=470792 -a end=526213 -a limit=0'.split())

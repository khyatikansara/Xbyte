import pandas as pd
import pymysql
import scrapy
from scrapy.cmdline import execute


class Tmp3Spider(scrapy.Spider):
    name = 'tmp3'
    cnt = 0
    start = ''
    end = ''

    def start_requests(self):
        connection = pymysql.connect(host='192.168.1.252', database='oriparts_hundai', user='root', password='xbyte')
        sql_select_Query = f"select * from `child4_hundai_final` where `status`='pending' AND pp_url LIKE '%/redirect%' AND sr_no>'{self.start}' and sr_no<'{self.end}' GROUP BY pp_url"
        cursor = connection.cursor()
        cursor.execute(sql_select_Query)
        records = cursor.fetchall()
        df = pd.read_csv("352444_411106.csv")
        df = df.fillna('')
        for row in records:
            try:
                srno = row[0]
                pp_url = row[16]
                df1 = df[df['pp_url'] == pp_url]
                if df1.empty:
                    print("Df1 empty")
                else:
                    Part_no = df1['Part_no'].values[0]
                    Price = df1['Price'].values[0]
                    sql = f"UPDATE oriparts_hundai.child4_hundai_final SET `status` = 'pp_done_final' , Price = '{Price}' , Part_no = '{Part_no}'  WHERE  pp_url = '{pp_url}'"
                    cursor.execute(sql)
                    connection.commit()
                    print("khyati update done for srno....", srno)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute('scrapy crawl tmp3 -a start=352444 -a end=411106'.split())
import datetime
import MySQLdb as pymysql
import scrapy
import json
from scrapy.cmdline import execute

from epix_daily.items import EpixDailyLinkItem

class EpSpider(scrapy.Spider):
    name = 'epix_links'
    today = datetime.datetime.now().strftime("%d_%m_%Y")

    Movieisited = []
    SeriesVisited = []
    EpisodeVisited = []

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.con = pymysql.connect('localhost', 'root', 'xbyte', 'epix')
        self.crsr = self.con.cursor()

    def start_requests(self):

        self.crsr.execute("select char1 from a_z")
        result = self.crsr.fetchall()

        for row in result:
            url = f"https://api.epix.com/v2/search/b/page/{row[0]}/per_page/399?requested_types=movies,shows"
            header = {
                      'accept': 'application/json',
                      # 'accept-encoding': 'gzip, deflate, br',
                      'accept-language': 'en-US,en;q=0.9',
                      'content-type': 'application/json',
                      'origin': 'https://www.epix.com',
                      'referer': 'https://www.epix.com/',
                      'sec-fetch-dest': 'empty',
                      'sec-fetch-mode': 'cors',
                      'sec-fetch-site': 'same-site',
                      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
                      'x-session-token': 'eyJraWQiOiI5YjFjYjViZDYxZGNmMWU3ZmJkMWM2YjRmOGNhOTgzNmFkZmY5YjViNjYwMDQ5ZDIzMWZlZjBmMDllMTkwMmFmIiwiYWxnIjoiUlMyNTYifQ.eyJndWlkIjoiMjZiZGNhZmQtZWIxYy00MDUzLTgyOWItZGFhODUwZmM5NThmIiwidGVuYW50IjoiZXBpeCIsImV4cCI6MTYzMzE4MzM2MH0.X_5jSHnKRw3EW105pUf26rZbYWjHjOzdJRlX3GPV5hRpelqIEXhfv9NAwbACt1_QdcmQcMRu-ot_0miguYSOHr5UiE3jfu97Iy6drH-J3lAytAXEV4bN5ezXj1KjYCl6m3qT_9UMU0q9JixQ-sDfwC7s0l4IonLf7eTBePOrKHXGt_luNMMVoIxEevMSJYTlGcsYmupZCoZTe9nt_iFRLdNIDVhiVz13sqHTOrzMt4VnKRUAC-mibHOyOZq72-xzIvtObdNg2t9pzmph1rU65DCbaRl9KRvL7C606tMQ8XNZKIIPrqRnFm7hUUYyU4A6B855O2MsuYNhbl17TypNAA',
                      # 'Cookie': '__cfduid=d558906df847f6d028acde467f3f7778d1608867601'
                    }
            yield scrapy.Request(url=url,headers=header,callback=self.parse,meta={'ch':row[0]})

    def parse(self,response):

        item = EpixDailyLinkItem()

        data = json.loads(response.text)
        ch = response.meta['ch']
        try:
            for item_1 in data['data']['items']:
                try:
                    url = item_1['content']['deep_links']['universal']['navigate']
                    item['link'] = url
                    item['date'] = self.today
                    yield item
                except Exception as e:
                    print(e)
                try:
                    self.crsr.execute(f"update a_z set status='done' where char1 = '{ch}'")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    execute("scrapy crawl epix_links".split())
# -*- coding: utf-8 -*-
import datetime
import hashlib
import json
import re
import pymysql
import requests
import scrapy
import time

from scrapy.http import HtmlResponse

from epix_daily.items import EpixDailyDataItem

class EpixSpider(scrapy.Spider):
    name = 'epix_data_copy'
    allowed_domains = ['epix.com']
    today = datetime.datetime.now().strftime("%d_%m_%Y")
    Movieisited = 0
    SeriesVisited = 0
    EpisodeVisited = 0

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = start
        self.end = end
        self.con = pymysql.connect('localhost', 'root', 'xbyte', 'epix')
        self.cursor = self.con.cursor()


    def start_requests(self):
        try:
            select = f'select * from epix_master_link_refress '
            # select = f'SELECT * FROM epix_master_link WHERE link = "https://www.epix.com/series/nfl-the-grind"'
            self.cursor.execute(select)
            movie_links = self.cursor.fetchall()
            print(len(movie_links))
            for link in movie_links:
                Id = link[0]
                url = link[1]
                yield scrapy.Request(url=url, meta={'Id': Id})
        except Exception as e:
            print(e)

    def parse(self, response):
        item = EpixDailyDataItem()

        Id = response.meta['Id']
        Link = response.url
        session_link = 'https://api.epix.com/v2/sessions'

        session_headers = {
            "accept": "application/json",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US,en;q=0.9",
            "content-type": "application/json",
            "origin": "https://www.epix.com",
            "referer": str(response.url),
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }

        payload = {"device": {"guid": "25127853-479b-4e1d-aaae-983ae40f991a", "format": "console", "os": "web","app_version": "1.0.2", "model": "browser", "manufacturer": "google"},"apikey": "f07debfcdf0f442bab197b517a5126ec"}

        session_res = requests.post(url=session_link, headers=session_headers, data=json.dumps(payload))
        session_response = HtmlResponse(url=session_res.url, body=session_res.content)

        session_json_data = json.loads(session_response.text)

        session_token = session_json_data['device_session']['session_token']

        text = response.url.split('/')[-1].strip()
        filename = 'E:\\Vishal\\MinnoTV\\epix_daily\\epix_daily\\spiders\\pagesave\\'
        try:
            with open(filename + str(text) + '.html', 'wb') as f:
                f.write(response.body)
                f.close()
        except Exception as e:
            print(e)

        if 'series' in Link:

            link = 'https://api.epix.com/v2/series/' + str(text)

            headers = {
                "accept": "application/json",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/json",
                "origin": "https://www.epix.com",
                "referer": str(response.url),
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36",
                "x-session-token": str(session_token)
            }

            res = requests.get(url=link, headers=headers)
            response1 = HtmlResponse(url=res.url, body=res.content)

            json_data = json.loads(response1.text)

            try:Movie_Series_Title = json_data['series']['title']
            except:Movie_Series_Title = ''

            try:Movie_Series_Description = json_data['series']['description'].replace('\n','').strip()
            except:Movie_Series_Description = ''

            length = len(json_data['series']['items'][0]['content']['items'])
            for i in range(0, int(length) + 1):
                self.SeriesVisited += 1
                try:season_number = json_data['series']['items'][i]['content']['title'].replace('Season','').strip()
                except:season_number = ''

                try:Movie_Series_Year = json_data['series']['years']
                except:Movie_Series_Year = ''
                try:
                    length2 = len(json_data['series']['items'][i]['content']['items'])
                    for j in range(0, int(length2) + 1):
                        self.EpisodeVisited += 1
                        try:episode_title = json_data['series']['items'][i]['content']['items'][j]['content']['title']
                        except:episode_title = ''

                        try:episode_number = re.findall(r'E(\d+)', episode_title)[0]
                        except Exception as e:
                            print(e)
                            try:
                                episode_number = json_data['series']['items'][i]['content']['items'][j]['content']['number']
                            except Exception as e:
                                print(e)

                        try:episode_description = json_data['series']['items'][i]['content']['items'][j]['content']['synopsis'].replace('\n','').strip()
                        except:episode_description = ''
                        try:episode_link = json_data['series']['items'][i]['content']['items'][j]['content']['deep_links']['universal']['navigate']
                        except:episode_link = ''
                        try:episode_year = json_data['series']['items'][i]['content']['items'][j]['content']['release_year']
                        except:episode_year = ''

                        try:Movie_episode_time=int(json_data['series']['items'][i]['content']['items'][j]['content']['duration'])/60
                        except:Movie_episode_time=''
                        item["ID"] = Id
                        item["Source"] = 'Epix'
                        item["Type"] = 'EPISODE'
                        item["Movie_Series_Link"] = Link
                        item["Movie_Series_Title"] = Movie_Series_Title
                        item["Movie_Series_Description"] = Movie_Series_Description
                        item["Movie_Series_Year"] = (str(Movie_Series_Year).split('-'))[0].replace(' ','')
                        item["Movie_Series_IMDB"] = ''
                        item["Season_Number"] = season_number
                        item["Episode_Number"] = episode_number
                        item["Episode_Title"] = episode_title
                        item["Episode_Description"] = episode_description
                        item["Episode_Link"] = episode_link
                        try:
                            item["Episode_Date_Year"] = (str(episode_year).split('-'))[0].replace(' ','')
                        except:
                            item["Episode_Date_Year"] = (str(episode_year))
                        item["Episode_IMDB"] = ''
                        item["Android_DeepLink"] = episode_link
                        item["iOS_DeepLink"] = episode_link
                        item["foreign_id"] = int(hashlib.md5(bytes(str(item["Episode_Link"]), "utf8")).hexdigest(), 16) % (10 ** 30)
                        item["date"] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                        item['Movie_episode_time']= "{:.2f}".format(float(Movie_episode_time))
                        yield item
                except Exception as e:
                    print(e)

                    # try:
                    #     con = pymysql.connect('51.161.12.203', 'root', 'xbyte', 'minnow_tv_daily')
                    #     cursor = con.cursor()
                    #     cursor.execute(f"update movie_episodes_data_master set Episode_Number = '{episode_number}' where `Episode_Link` = '{episode_link}'")
                    #     con.commit()
                    # except Exception as e:
                    #     print(e)
        else:
            link = 'https://api.epix.com/v2/movies/' + str(text)

            headers = {
                "accept": "application/json",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/json",
                "origin": "https://www.epix.com",
                "referer": str(response.url),
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36",
                "x-session-token": str(session_token)
            }

            res = requests.get(url=link, headers=headers)
            response1 = HtmlResponse(url=res.url, body=res.content)

            json_data = json.loads(response1.text)

            try:Movie_Series_Title = json_data['movie']['title']
            except:Movie_Series_Title = ''

            try:Movie_Series_Description = json_data['movie']['synopsis'].replace('\n','').strip()
            except:Movie_Series_Description = ''
            try:Movie_episode_time=(int(json_data['movie']['duration'])/60)
            except:Movie_episode_time=''
            try:Movie_Series_Year = json_data['movie']['release_year']
            except:Movie_Series_Year = ''

            self.Movieisited += 1

            item["ID"] = Id
            item["Source"] = 'Epix'
            item["Type"] = 'MOVIE'
            item["Movie_Series_Link"] = Link
            item["Movie_Series_Title"] = Movie_Series_Title
            item["Movie_Series_Description"] = Movie_Series_Description
            item["Movie_Series_Year"] =(str(Movie_Series_Year).split('-'))[0].replace(' ','')
            item["Movie_Series_IMDB"] = ''
            item["Season_Number"] = ''
            item["Episode_Number"] = ''
            item["Episode_Title"] = ''
            item["Episode_Description"] = ''
            item["Episode_Link"] = ''
            item["Episode_Date_Year"] = ''
            item["Episode_IMDB"] = ''
            item["Android_DeepLink"] = Link
            item["iOS_DeepLink"] = Link
            item["foreign_id"] = int(hashlib.md5(bytes(item["Source"] + item["Movie_Series_Link"] + item["Movie_Series_Title"], "utf8")).hexdigest(),16) % (10 ** 30)
            item['Movie_episode_time'] = "{:.2f}".format(float(Movie_episode_time))
            item["date"] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
            yield item


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl epix_data_copy'.split())
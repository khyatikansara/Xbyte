# import datetime
# import pymysql
# import scrapy
# import json
# from scrapy.cmdline import execute
#
# from epix_daily.items import EpixDailyLinkItem
#
# class EpSpider(scrapy.Spider):
#     name = 'epix_links'
#     today = datetime.datetime.now().strftime("%d_%m_%Y")
#
#     Movieisited = []
#     SeriesVisited = []
#     EpisodeVisited = []
#
#     header =  {
#           'accept': ' application/json',
#           'accept-encoding': ' gzip, deflate, br',
#           'accept-language': ' en-US,en;q=0.9',
#           'content-type': ' application/json',
#           'origin': ' https://www.epix.com',
#           'referer': ' https://www.epix.com/',
#           'sec-fetch-dest': ' empty',
#           'sec-fetch-mode': ' cors',
#           'sec-fetch-site': ' same-site',
#           'user-agent': ' Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
#           'x-session-token': 'eyJraWQiOiI5YjFjYjViZDYxZGNmMWU3ZmJkMWM2YjRmOGNhOTgzNmFkZmY5YjViNjYwMDQ5ZDIzMWZlZjBmMDllMTkwMmFmIiwiYWxnIjoiUlMyNTYifQ.eyJndWlkIjoiYjQyMzkyNTktNGI2MC00MTFjLWJlMTctMzQ5ZjUxYTk1OTIyIiwidGVuYW50IjoiZXBpeCIsImV4cCI6MTYwOTMxMDU2Mn0.E5bqCtFZldLmD8NbqvQIqE1xBJs85NyCPyF5iX4j2okGFq6IiT-f8V-F-Dfzm7heesCGwWeBM_9P_UEK2h-d3oKBvoTs_AyH4P2D19SlRNi-MXsZ6RvNbVz81WbgksXk2aewHMyoufvecJxaZcTwdUcsprFLMTMkUnCLM3toc8TOzQafivubYadgeptdoC4B_kXeCYxrRiWmFfCpNWfRj9dcsfgnaFqqwyqFJkI_hmBcclVR0XN8M-myWgNF-Cj5nNvxRjSVqWWa1IGvXvP0wnoOZ0_m2MFZsMUN6rlooM7KSTK6bKG9uKYhKS-jWwrvY2f_bRaHQZqff0Plb2ZRzg',
#         }
#
#     def __init__(self, name=None, **kwargs):
#         super().__init__(name, **kwargs)
#         self.con = pymysql.connect('localhost', 'root', 'xbyte', 'epix')
#         self.crsr = self.con.cursor()
#
#     def start_requests(self):
#
#         for i in range(1,5):
#             url = f'https://api.epix.com/v2/search/page/{i}/per_page/100?requested_types=movies'
#             yield scrapy.Request(url=url,headers=self.header,callback=self.parse)
#
#         url = "https://api.epix.com/v2/collections/collections"
#         yield scrapy.Request(url=url,headers=self.header,callback=self.parse_2)
#
#     def parse(self, response):
#         item = EpixDailyLinkItem()
#         data = json.loads(response.text)
#
#         if "requested_types=movies" in response.url:
#             try:
#                 for item_1 in data['data']['items']:
#                     try:
#                         url = item_1['content']['deep_links']['universal']['navigate']
#                         item['link'] = url
#                         item['date'] = self.today
#                         yield item
#
#                         if url not in self.Movieisited and '/movie/' in url:
#                             self.Movieisited.append(url)
#                     except Exception as e:
#                         print(e)
#             except Exception as e:
#                 print(e)
#
#
#     def parse_2(self,response):
#
#         data = json.loads(response.text)
#
#         series_ls = ['epix-original-series','epix-original-docuseries','epix-comedy-specials']
#
#         try:
#             for item_1 in data['collection']['items']:
#                 try:
#                     shortname = item_1['content']['short_name']
#                     series_ls.append(shortname)
#                 except Exception as e:
#                     print(e)
#         except Exception as e:
#             print(e)
#
#         print(len(series_ls))
#
#         for ul in series_ls:
#
#             url = f"https://api.epix.com/v2/collections/{ul}/page/1/per_page/100"
#             yield scrapy.Request(url=url,headers=self.header,callback=self.parse_3)
#
#
#     def parse_3(self,response):
#         item = EpixDailyLinkItem()
#         data = json.loads(response.text)
#         try:
#             for item_1 in data['collection']['items']:
#                 try:
#                     url = item_1['content']['deep_links']['universal']['navigate']
#                     item['link'] = url
#                     item['date'] = self.today
#                     yield item
#
#                     if url not in self.SeriesVisited and '/series/' in url:
#                         self.SeriesVisited.append(url)
#
#                 except Exception as e:
#                     print(e)
#
#         except Exception as e:
#             print(e)
#
#     # def close(spider, reason):
#     #     print(len(spider.Movieisited),len(spider.SeriesVisited))
#
# # execute("scrapy crawl epix_links".split())
# # -*- coding: utf-8 -*-
# import datetime
# import json
#
# import scrapy
#
# from epix_daily.items import EpixDailyLinkItem
#
#
# class EpixLinksSpider(scrapy.Spider):
#     name = 'epix_links'
#     allowed_domains = ['epix.com']
#     today = datetime.datetime.now().strftime("%d_%m_%Y")
#     visited_count = 0
#     SeriesVisited = 0
#     EpisodeVisited = 0
#     Movieisited = 0
#
#
#     def start_requests(self):
#         headers = {
#             "accept": "application/json",
#             "accept-encoding": "gzip, deflate, br",
#             "accept-language": "en-US,en;q=0.9",
#             "content-type": "application/json",
#             "origin": "https://www.epix.com",
#             "referer": "https://www.epix.com/movies",
#             "sec-fetch-dest": "empty",
#             "sec-fetch-mode": "cors",
#             "sec-fetch-site": "same-site",
#             "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"
#         }
#         payload = {"device":{"guid":"25127853-479b-4e1d-aaae-983ae40f991a","format":"console","os":"web","app_version":"1.0.2","model":"browser","manufacturer":"google"},"apikey":"f07debfcdf0f442bab197b517a5126ec"}
#         yield scrapy.FormRequest(url='https://api.epix.com/v2/sessions', callback=self.parse_movies, headers=headers, body=json.dumps(payload), method='POST', dont_filter=True)
#
#         headers2 = {
#             "accept": "application/json",
#             "accept-encoding": "gzip, deflate, br",
#             "accept-language": "en-US,en;q=0.9",
#             "content-type": "application/json",
#             "origin": "https://www.epix.com",
#             "referer": "https://www.epix.com/originals/original-series_web_console",
#             "sec-fetch-dest": "empty",
#             "sec-fetch-mode": "cors",
#             "sec-fetch-site": "same-site",
#             "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"
#         }
#         payload2 = {"device": {"guid": "25127853-479b-4e1d-aaae-983ae40f991a", "format": "console", "os": "web","app_version": "1.0.2", "model": "browser", "manufacturer": "google"},"apikey": "f07debfcdf0f442bab197b517a5126ec"}
#         yield scrapy.FormRequest(url='https://api.epix.com/v2/sessions', callback=self.parse_series, headers=headers2, body=json.dumps(payload2), method='POST', dont_filter=True)
#
#     def parse_movies(self, response):
#         json_data = json.loads(response.text)
#
#         session_token = json_data['device_session']['session_token']
#
#         headers = {
#             "accept": "application/json",
#             "accept-encoding": "gzip, deflate, br",
#             "accept-language": "en-US,en;q=0.9",
#             "content-type": "application/json",
#             "origin": "https://www.epix.com",
#             "referer": "https://www.epix.com/movies",
#             "sec-fetch-dest": "empty",
#             "sec-fetch-mode": "cors",
#             "sec-fetch-site": "same-site",
#             "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
#             "x-session-token": str(session_token)
#         }
#
#         try:
#             for i in range(1, 100):
#                 link = 'https://api.epix.com/v2/search/page/'+str(i)+'/per_page/24?requested_types=movies'
#                 yield scrapy.Request(url=link, callback=self.parse2, headers=headers)
#         except Exception as e:
#             print(e)
#
#     def parse_series(self, response):
#         json_data = json.loads(response.text)
#
#         session_token = json_data['device_session']['session_token']
#
#         headers = {
#             "accept": "application/json",
#             "accept-encoding": "gzip, deflate, br",
#             "accept-language": "en-US,en;q=0.9",
#             "content-type": "application/json",
#             "origin": "https://www.epix.com",
#             "referer": "https://www.epix.com/originals/original-series_web_console",
#             "sec-fetch-dest": "empty",
#             "sec-fetch-mode": "cors",
#             "sec-fetch-site": "same-site",
#             "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
#             "x-session-token": str(session_token)
#         }
#
#         try:
#             for i in range(1, 100):
#                 link = 'https://api.epix.com/v2/collections/original-series_web_console/page/'+str(i)+'/per_page/50'
#                 yield scrapy.Request(url=link, callback=self.parse2, headers=headers)
#         except Exception as e:
#             print(e)
#
#     def parse2(self, response):
#
#         self.visited_count += 1
#         json_data = json.loads(response.text)
#         # filename = 'E:\\Kinjal\\MinnoTV\\epix_daily\\epix_daily\\spiders\\pagesave\\pages\\'
#         # with open(filename + str(self.visited_count) + '.html', 'wb') as f:
#         #     f.write(response.body)
#         #     f.close()
#         try:length = len(json_data['data']['items'])
#         except:length = len(json_data['collection']['items'])
#
#         for i in range(0, int(length)):
#
#             try:link = json_data['data']['items'][i]['content']['deep_links']['universal']['navigate']
#             except:link = json_data['collection']['items'][i]['content']['deep_links']['universal']['navigate']
#             if 'series' in link:
#                 self.SeriesVisited += 1
#             else:
#                 self.Movieisited += 1
#             try:
#                 item = EpixDailyLinkItem()
#                 item['link'] = link
#                 item['date'] = self.today
#                 yield item
#
#             except Exception as e:
#                 print(e)
#
#
# from scrapy.cmdline import execute
# execute('scrapy crawl epix_links'.split())
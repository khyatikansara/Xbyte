# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import datetime
import MySQLdb as pymysql
from epix_daily.items import EpixDailyLinkItem, EpixDailyDataItem

class EpixDailyPipeline:
    month = datetime.datetime.now().strftime("%m_%d_%Y")
    month_167 = datetime.datetime.now().strftime("%d-%m-%Y")
    counter = 0

    def __init__(self):
        try:
            self.con = pymysql.connect('localhost', 'root', 'xbyte')
            self.cursor = self.con.cursor()
            self.cursor.execute('CREATE DATABASE IF NOT EXISTS epix')
        except Exception as e:
            print(str(e))

        self.con = pymysql.connect('localhost', 'root', 'xbyte', 'epix')
        self.cursor = self.con.cursor()

        self.con_167 = pymysql.connect('localhost', 'root', 'xbyte', 'minnow_tv_daily')
        # self.con_167 = pymysql.connect('localhost', 'root', 'xbyte', 'epix')
        self.cursor_167 = self.con_167.cursor()

        try:
            create = f"""CREATE TABLE IF NOT EXISTS epix_master_link_refress (`ID` bigint(20) NOT NULL AUTO_INCREMENT,
                                                          `link` varchar(255),
                                                          `date` varchar(255),
                                                          `status` varchar(255) DEFAULT 'Pending',
                                                           PRIMARY KEY (`ID`),
                                                           unique key(`link`)) ENGINE=InnoDB AUTO_INCREMENT=2910 DEFAULT CHARSET=utf8"""
            self.cursor.execute(create)
        except Exception as e:
            print(e)

        try:
            self.data_table_167 = f'movie_episodes_data_master'
            # self.data_table_167 = f'movie_episodes_data_master_refress'
            create = f"""CREATE TABLE IF NOT EXISTS `{self.data_table_167}` (`ID` bigint(20) NOT NULL AUTO_INCREMENT,
                                                                      `Source` mediumtext,
                                                                      `Type` mediumtext,
                                                                      `Movie_Series Link` mediumtext,
                                                                      `Movie_Series Title` mediumtext,
                                                                      `Movie_Series Year` mediumtext,
                                                                      `Movie_Series Description` mediumtext,
                                                                      `Movie_Series IMDB` mediumtext,
                                                                      `Season_Number` mediumtext,
                                                                      `Episode_Number` mediumtext,
                                                                      `Episode_Title` mediumtext,
                                                                      `Episode_Description` mediumtext,
                                                                      `Episode_Link` mediumtext,
                                                                      `Episode_Date_Year` mediumtext,
                                                                      `Episode_IMDB` mediumtext,
                                                                      `Android_DeepLink` mediumtext,
                                                                      `iOS_DeepLink` mediumtext,
                                                                      `status` varchar(250) DEFAULT 'pending',
                                                                      `foreign_id` varchar(250) DEFAULT NULL unique,
                                                                      `date` varchar(250) DEFAULT NULL,
                                                                      `Cast` mediumtext,
                                                                      `Movie_Series_Poster` mediumtext,
                                                                      `Movie_episode_time` varchar(50) DEFAULT NULL,
                                                                       PRIMARY KEY (`ID`))"""
            self.cursor_167.execute(create)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, EpixDailyLinkItem):
            try:
                insert = f'insert into epix_master_link_refress(link, date) values (%s, %s)'
                # insert = f'insert into epix_master_link_refress(link, date) values (%s, %s)'
                self.cursor.execute(insert, (item["link"], item["date"]))
                self.con.commit()
                self.counter += 1
                print('Link Inserted...', self.counter)
            except Exception as e:
                print(e)

        if isinstance(item, EpixDailyDataItem):
            try:
                insert = f'insert into `movie_episodes_data_master`(`Source`, `Type`, `Movie_Series Link`, `Movie_Series Title`, `Movie_Series Year`, `Movie_Series Description`, `Movie_Series IMDB`, `Season_Number`, `Episode_Number`, `Episode_Title`, `Episode_Description`, `Episode_Link`, `Episode_Date_Year`, `Episode_IMDB`, `Android_DeepLink`, `iOS_DeepLink`, `foreign_id`, `date`, `Movie_episode_time`,`Cast`,`Movie_Series_Poster`) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
                self.cursor_167.execute(insert, (
                    item["Source"], item["Type"], item["Movie_Series_Link"], item["Movie_Series_Title"],
                    item["Movie_Series_Year"], item["Movie_Series_Description"], item["Movie_Series_IMDB"],
                    item["Season_Number"], item["Episode_Number"], item["Episode_Title"], item["Episode_Description"],
                    item["Episode_Link"], item["Episode_Date_Year"], item["Episode_IMDB"], item["Android_DeepLink"],
                    item["iOS_DeepLink"], item['foreign_id'], item['date'], item["Movie_episode_time"], item["Cast"], item['Movie_Series_Poster']))
                self.con_167.commit()
                self.counter += 1
                print('Data Inserted...', self.counter)
                update = 'update epix_master_link_refress set Status="Done" where Id=%s'
                self.cursor.execute(update, (item["ID"]))
                self.con.commit()
            except Exception as e:
                print(e)
        return item

    def close_spider(self, spider):
        try:
            if spider.name == 'epix_data':
                date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                select = f'select count(Id) from `{self.data_table_167}` where Source="Epix" and date="{date}"'
                self.cursor_167.execute(select)
                count = self.cursor_167.fetchone()[0]

                Movie_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Epix" and Type="MOVIE" and date="{date}"'
                self.cursor_167.execute(Movie_Count_select)
                Movie_Count = self.cursor_167.fetchone()[0]

                Series_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Epix" and Type="EPISODE" and date="{date}" group by `Movie_Series Link`'
                self.cursor_167.execute(Series_Count_select)
                Series_Count = len(self.cursor_167.fetchall())

                Episode_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Epix" and Type="EPISODE" and date="{date}"'
                self.cursor_167.execute(Episode_Count_select)
                Episode_Count = self.cursor_167.fetchone()[0]
                # previous_day = '2021-09-27'
                previous_day = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1), '%Y-%m-%d')
                total_count_query = f'select MovieTotalCount,SeriesTotalCount,EpisodeTotalCount from minnow_daily_status WHERE SiteName="Epix" and Date like "{previous_day}%"'
                self.cursor_167.execute(total_count_query)
                total_count = self.cursor_167.fetchone()

                MovieTotalCount = Movie_Count + int(total_count[0])
                SeriesTotalCount = Series_Count + int(total_count[1])
                EpisodeTotalCount = Episode_Count + int(total_count[2])

                # with open('visitedcount.txt', 'r') as f:
                #     totalvisitedcount = f.read()
                #     f.close()

                # c = str(totalvisitedcount).split(',')
                Movieisited = spider.Movieisited
                SeriesVisited = spider.SeriesVisited
                EpisodeVisited = spider.EpisodeVisited

                insert = 'insert into minnow_daily_status (SiteName,TodayCount,MovieVisted,Date,MovieCount,MovieTotalCount,SeriesVisited,SeriesCount,SeriesTotalCount,EpisodeVisited,EpisodeCount,EpisodeTotalCount) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
                self.cursor_167.execute(insert, ("Epix", str(count), Movieisited,
                                                 str(datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')),
                                                 str(Movie_Count), str(MovieTotalCount), str(SeriesVisited),
                                                 str(Series_Count), str(SeriesTotalCount), str(EpisodeVisited),
                                                 str(Episode_Count), str(EpisodeTotalCount)))
                self.con_167.commit()

            # elif spider.name == 'epix_links':
            #     print(f"{len(spider.Movieisited)},{len(spider.SeriesVisited)},{len(spider.EpisodeVisited)}")
            #     try:
            #         with open('visitedcount.txt', 'w') as f:
            #             f.write(f"{len(spider.Movieisited)},{len(spider.SeriesVisited)},{len(spider.EpisodeVisited)}")
            #             f.close()
            #     except Exception as e:
            #         print(e)
        except Exception as e:
            print(e)
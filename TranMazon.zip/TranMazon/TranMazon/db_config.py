host = "localhost"
usernm = "root"
passwd = "xbyte"
database = "TranMazon"

table5 = "history"

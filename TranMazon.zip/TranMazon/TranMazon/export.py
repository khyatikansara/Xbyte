from datetime import datetime
import pandas as pd
import re
import xlsxwriter
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline
from TranMazon.spiders.temp import Temp


def export_data():
    set = Temp()
    try:
        site_name = 'walmart'
        run_date = str(datetime.today()).split()[0].replace('-', '_')
        this_week_html_path = set.get_name("this_week_html_path",site_name)
        sql = f"Select * from {dbc.database}.walmart_data_2021_01_06"
        df_all = pd.read_sql(sql, set.db_con)
        output_path = f"{this_week_html_path}CSV\\{site_name}_{run_date}.xlsx"
        # df_all.drop(columns=['final_path'], inplace=True)
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', '_') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        # df_all.to_excel(output_path, index=True)

        writer = pd.ExcelWriter(rf'{output_path}', engine='xlsxwriter', options={'strings_to_urls': False})
        df_all.to_excel(writer, index=False)
        writer.close()
        print('Excel File generated', output_path)
    except Exception as e:
        print(e)

export_data()

def catgeory():
    final_list = []
    list_128 = []
    list_129 = []
    list_174 = []
    none_list = []

    df = pd.read_excel(f"D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_2021_01_05.xlsx")
    df = df.fillna('')
    df1 = pd.read_csv(f"D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_final_category.csv")
    df1 = df1.fillna('')

    for index1, row1 in df1.iterrows():
        Product_Link = row1[4]
        Category = row1[5]
        if Category == '128':
            list_128.append(Product_Link)
        elif Category == '129':
            list_129.append(Product_Link)
        elif Category == '174':
            list_174.append(Product_Link)
        else:
            none_list.append(Product_Link)

    for index, row in df.iterrows():
        Id = row[0]
        print(Id)
        Name = row[1]
        Description = row[2]
        Category = row[3]
        Status = row[4]
        MainImage = row[5]
        IsFeaturedProduct = row[6]
        FeaturedPosition = row[7]
        FeaturedImage = row[8]
        Price = row[9]
        Size = row[10]
        Country = row[11]
        ProductImage = row[12]
        URL = row[13]
        final_path = row[14]
        if Category == '':
            if URL in list_128:
                Category = '128'
            elif URL in list_129:
                Category = '129'
            elif URL in list_174:
                Category = '174'
            else:
                Category = 'None'
        else:
            Category = Category
        final_list.append([Id,Name,Description,Category,Status,MainImage,IsFeaturedProduct,FeaturedPosition,FeaturedImage,Price,Size,Country,ProductImage,URL,final_path])
    # try:
    #     writer = pd.ExcelWriter("D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_2021_01_05_66707.xlsx", engine='xlsxwriter', options={'strings_to_urls': False})
    #     df_all.to_excel(writer, index=False)
    #     writer.close()
    #     print('Excel File generated', output_path)
    # except Exception as e:
    #     print(e)

    try:
        gh = pd.DataFrame(final_list, columns=['id', 'Name', 'Description', 'Category', 'Status', 'MainImage', 'IsFeaturedProduct', 'FeaturedPosition', 'FeaturedImage', 'Price', 'Size', 'Country', 'ProductImage', 'URL', 'final_path'])
        gh.to_csv("D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_2021_01_05_66707_2.csv", index=False)
    except Exception as e:
        print(e)


# catgeory()

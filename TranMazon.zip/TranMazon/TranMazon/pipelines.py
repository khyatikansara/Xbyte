# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from itemadapter import ItemAdapter
from TranMazon import db_config as dbc
from TranMazon.items import TranmazonItem
from TranMazon.spiders.temp import Temp
from sqlalchemy import create_engine


class TranmazonPipeline(object):

    def open_spider(self,spider):
        self.count = 0
        self.engine = create_engine(f'mysql+pymysql://{str(dbc.usernm)}:{str(dbc.passwd)}@{str(dbc.host)}/{str(dbc.database)}')
        self.set = Temp()
        self.table1 = f"{spider.site_name}_{self.set.get_name('link_table',spider.site_name)}"
        self.table2 = f"{spider.site_name}_{self.set.get_name('this_week_table',spider.site_name)}"
        self.table3 = f"{spider.site_name}_{self.set.get_name('this_week_category',spider.site_name)}"

        try:
            create_table_1 = "CREATE TABLE IF NOT EXISTS " + self.table1 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                Category varchar(250) DEFAULT NULL,
                                                                                Category_Link varchar(250) DEFAULT NULL,
                                                                                Product_Link longtext DEFAULT NULL,
                                                                                path1 longtext DEFAULT NULL,
                                                                                path2 longtext DEFAULT NULL,
                                                                                Status varchar(50) DEFAULT 'pending',
                                                                                PRIMARY KEY (`Id`)) CHARACTER SET utf8 COLLATE utf8_general_ci"""
            self.set.cursor.execute(create_table_1)
        except Exception as e:
            print(e)

        try:
            create_table_2 = "CREATE TABLE IF NOT EXISTS " + self.table2 + """(ProductOrder INT NOT NULL AUTO_INCREMENT,
                                                                            Site varchar(250) DEFAULT NULL,
                                                                            Name longtext DEFAULT NULL,
                                                                            Description longtext DEFAULT NULL,
                                                                            Category longtext DEFAULT NULL,
                                                                            Status varchar(250) DEFAULT 'enabled',
                                                                            MainImage longtext DEFAULT NULL,
                                                                            IsFeaturedProduct INT DEFAULT '1',
                                                                            FeaturedPosition INT DEFAULT '1',
                                                                            FeaturedImage longtext DEFAULT NULL,
                                                                            Price longtext DEFAULT NULL,
                                                                            Size longtext DEFAULT NULL,
                                                                            Country INT DEFAULT '1',
                                                                            ProductImage longtext DEFAULT NULL,
                                                                            URL varchar(250) DEFAULT NULL,
                                                                            final_path longtext DEFAULT NULL,
                                                                            PRIMARY KEY (`ProductOrder`)) CHARACTER SET utf8 COLLATE utf8_general_ci"""
            self.set.cursor.execute(create_table_2)
        except Exception as e:
            print(e)

        try:
            create_table_3 = "CREATE TABLE IF NOT EXISTS " + self.table3 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                Category_source_link varchar(250) DEFAULT NULL,
                                                                                Category_Link varchar(250) DEFAULT NULL,
                                                                                Category_Name longtext DEFAULT NULL,
                                                                                Category_meta_name longtext DEFAULT NULL,
                                                                                Category_id longtext DEFAULT NULL,
                                                                                count longtext DEFAULT NULL,
                                                                                Category_path longtext DEFAULT NULL,
                                                                                Status varchar(50) DEFAULT 'pending',
                                                                                UNIQUE KEY (`Category_Link`),
                                                                                   PRIMARY KEY (`Id`)) CHARACTER SET utf8 COLLATE utf8_general_ci"""
            self.set.cursor.execute(create_table_3)
        except Exception as e:
            print(e)


    def process_item(self, item, spider):
        if isinstance(item, TranmazonItem):
            table = item['table']
            del item['table']
            self.insert_item(table, item)

    def insert_item(self, table, item):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.set.cursor.execute(insert_db)
            self.set.con.commit()
            print('\rdata inserted ')
            try:
                self.set.cursor.execute(f'''update {dbc.database}.walmart_link_2020_12_14 set status="Done12" where Product_Link="{item['URL']}"''')
                self.set.con.commit()
                print("update done")
            except Exception as e:
                print(e)
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))


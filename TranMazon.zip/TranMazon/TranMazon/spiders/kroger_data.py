# -*- coding: utf-8 -*-
import hashlib, json, re, pymysql, requests, scrapy,socket
import os
from datetime import datetime
from PIL import Image
import io
from lxml import html
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.http import HtmlResponse
from scrapy.spidermiddlewares.httperror import HttpError
from TranMazon.items import TranmazonItem
from scrapy.cmdline import execute
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon import db_config as dbc
from TranMazon.spiders.temp import Temp


class KrogerDataSpider(scrapy.Spider):
    name = 'kroger_data'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self, response):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path", self.site_name)
            table = f"{self.site_name}_{self.set.get_name('link_table', self.site_name)}"
            category_dict = {'Grocery':'174','Household':'128','health-wellness':'129'}
            self.set.cursor.execute(f'Select * from {dbc.database}.{table} where Id>{self.start} and Id<{self.end} and status="pending"')
            self.set.con.commit()
            product_results = self.set.cursor.fetchall()
            for row_p in product_results:
                try:
                    Id = row_p[0]
                    Category_Name = row_p[1]
                    Product_link = row_p[3]
                    if Product_link == 'https://www.kroger.com/p/kroger-cut-green-beans/0001111080235':
                        print("stop")
                    final_path = f"{self.this_week_html_path}Data\\{Product_link.split('/')[-1]}_{Id}.html"
                    if not os.path.exists(final_path):
                        headers_p = {
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                            'cookie': 'dtCookie=38$BB35AF6788B07A469AF6985A5752B369|81222ad3b2deb1ef|1; pid=a22a01fc-def4-4fbb-adb8-4aca6947535a; sid=2ec82bfc-5116-e6a7-c96a-66b6c9a279ca; akacd_RWASP-default-phased-release=3784855143~rv=79~id=02d422fa9f5953c4447f7ad56886e181; rxVisitor=160708749257445CR1MV7N880GTK4A8R1F7D6NOO3QEUT; AMCVS_371C27E253DB0F910A490D4E%40AdobeOrg=1; s_vi=[CS]v1|2FE781B78515F6B2-600008211FDD492B[CE]; s_ecid=MCMID%7C71545009456719684840477623698954371599; BVBRANDID=f1a30fa9-1a32-4fa2-b530-2a8c595f0cdb; BVImplmain_site=10876; s_cc=true; _gcl_au=1.1.575307936.1607402362; _pin_unauth=dWlkPVkyVTVNRGN5T1dNdFl6RXdaQzAwTTJWbUxXSTFZbVV0T1RGa01qUmtOakJtT0dSaA; origin=lvdc; x-active-modality={"postalCode":"30309","type":"SHIP","lat":33.79414367675781,"lng":-84.38739776611328}; _krgrtst=6c9e804b%3Bd7930f7f; abTest=tl_dyn-pos_B|mrrobot_12b59e_B; akaalb_KT_Digital_BannerSites=~op=KT_Digital_BannerSites_GCP_Search_Central1:gcpsearchcentral1|KT_Digital_BannerSites_KCVG_HDC_FailoverCDC:hdc|~rv=71~m=gcpsearchcentral1:0|hdc:0|~os=49d9e32c4b6129ccff2e66f9d0390271~id=bb6de6b653ea3563ce7e1e1a636cd89c; s_sq=%5B%5BB%5D%5D; bm_sz=B318E7379A65D3426F935B4E82D3DEC7~YAAQI0U5F7jybqR1AQAALXQfZgowoJQEU8MnbKpGIDbmPFJrfginE1ndTzIQOKK2tnOKgFs9wHVdK7Zm/NfrLJHVo+/5cKhUv5v7mGHN4aBjeslWf/79+i1q0d+AvbtIG0m1yxzgl5v3WbeLUDsp/oVpY9hrtN0wPwTl9h05oSblclo6QPR9VCGFIB2ZL2Ub; ak_bmsc=0110882A57C09511B0AD14853B3A03C017394523F96500008A9BD85FC37AA14D~plYt4cHFp0vzvGKiFw2cnm+1LpwNHi4js5NC7xoJedUZ7mUxclT3EshxqUyna7g7hX1n8hdvR/XkTZW3ILVpN27HQIPrB5v6kKZZRH2JRZnql7P4e5l894Lfw3myqGfBiTSFkXEF4+agOks0/2NQVUEwXwt+jRB3oZcxIX9Fb03/NeR/J/joVQZMN9rZfnGw4+/KwQSuKVULfKiRmDlcWCmWP+ZN+27IbsyXXRdz9TGDA9fJsY5fCsfqx5FQ8NYibU; AMCV_371C27E253DB0F910A490D4E%40AdobeOrg=-432600572%7CMCIDTS%7C18612%7CMCMID%7C71545009456719684840477623698954371599%7CMCAAMLH-1608635920%7C12%7CMCAAMB-1608635920%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1608038320s%7CNONE%7CMCAID%7C2FE781B78515F6B2-600008211FDD492B%7CvVersion%7C4.5.2; dtSa=-; __VCAP_ID__=048cc1d2-34df-41f6-4692-3391; AKA_A2=A; RT="z=1&dm=kroger.com&si=calzphpngkb&ss=kifhusmd&sl=0&tt=0"; _uetsid=d9a9c3303e9011eb884037b52d84e9ef; _uetvid=3de9a000363211eb833b95fc14ee71c8; s_ips=406; _derived_epik=dj0yJnU9aGpUSU50TkQzOGtXR2Y3VUV6eTJrS2ZZTFVzQ2dZX1Ymbj14eEhGMUtXcklmQjVFRVk5OUJOSTd3Jm09NyZ0PUFBQUFBRl9Zb29J; s_tslv=1608032899998; s_tp=3327; s_ppv=bn%253Aproducts%253Adetail%2C51%2C12%2C1701%2C1%2C3; bm_sv=07C662B334867E077CF900568D6F037F~BxCtqXOZOw/cfidxM4iqWE6LYIgBR7Cck3vUd72SZyRPtRJWq1WOpO2LDhzcox6AhWdYRlBQMLOW7gbUxIgkjSxggMUCQuMbpbcvwzCw+WZ0Plw9RqZzKTLEg/9xPOT2yHwjmbev5bA1wnhxbJSiVw7NkBn2WXrWU2oQnbbXZ8g=; dtLatC=4; dtPC=38$14036588_869h-vWOTIPSAASHUMUBRAMNPHSLVCHANJPFCC-0e0; rxvt=1608036503119|1608034703119; _abck=3E9C6DF21BE6577DC55B62A9EEC6DD6F~-1~YAAQKFstF0iD6GF2AQAASEtdZgUxQbPDRgrvtLA+I22s2zGwJd95n244nLhtB8lNzTC3J4ojynKYDd953xUyVm5SgsPap6UrarqDo8JivNAsg6L0n9yLrgjSjAlnv37UTORUZQaSzLZfofPpBE3B4AuH1MPWBHfvD5g2X/KllyzM7UtwKTpWfqH88cJ+zBXCPPEIyHSn0HBMyKDXa0hatFqcbNtx0T0Wz0WKc8eCkBmvNOv3fW3MRwbF8z6nsE5/5MS6YklYrVwBGAvwSerpJjdDznhDjyDysBZOllYPnEXF3LxLCqZOZXn6Y7CQzyWWaN0GCdrIcQDw3XbK0Q8nIIucSp8vV0tNplC9bz7AT163FQA=~-1~||-1||~-1; umid=5388ea13-2863-4698-9d3c-f0b899d86b75; pid=7b598bba-3867-4ffb-a519-c768fdb321fb; origin=lvdc; x-active-modality={"postalCode":"30309","type":"SHIP","lat":33.79414367675781,"lng":-84.38739776611328}; sid=2ec82bfc-5116-e6a7-c96a-66b6c9a279ca; dtCookie=37$3DA2E8C9482339FF4CE8F02774AD5F39; akaalb_KT_Digital_BannerSites=~op=KT_Digital_BannerSites_KCVG_HDC_FailoverCDC:hdc|~rv=88~m=hdc:0|~os=49d9e32c4b6129ccff2e66f9d0390271~id=771c03869b42415bd29706b8f79f5f71; ak_bmsc=76D5CB95CED253C1C2D57F9E11F6031617394523F9650000AA9BD85F1A046618~plTpiY4iTv1I31GTthLJ5u0uRYdzEpELPg+n1WqcGAoPVXriCNxcSq7+TkUlux5bhBX0Z4iLpA9bhEGLQl8JKYD1VNS/qW7l2OAXH5zNmjtGpZbSiVTFsePKSccXQPFwEfR8zQfJgtcNBaW51z1qm8Tn0O3KLpz4H0W/i3SU35s2CY0fTYkbRd3k3Mp9a1TtLOOINf1wk7opUm/5mAl6jSPsYpYuQ/ISlMPo15AYXquNg=; __VCAP_ID__=bc13c4d6-0924-4562-77b7-ac2b; bm_sv=07C662B334867E077CF900568D6F037F~BxCtqXOZOw/cfidxM4iqWE6LYIgBR7Cck3vUd72SZyRPtRJWq1WOpO2LDhzcox6AhWdYRlBQMLOW7gbUxIgkjSxggMUCQuMbpbcvwzCw+WYRP1tzNxNBG6eSVw4mpxPVv02fxvDpAITyTyh88cT+9BA4RdVXdfV1hFJQLIRFC60=; _abck=3E9C6DF21BE6577DC55B62A9EEC6DD6F~-1~YAAQKFstF/iG6GF2AQAAW/RdZgVcdv3s4JLlTsGijtAPfsqhSjrmJW9CkJHdSTwa1bQdF/BHRhOw5S0Np6VvoTROgyPxyz2h59/Rfl2oe1fcWo6tLwWaNgAmR2ikYOIR3cRilMmXYBlFl48W0FXh1QLBpYkna1+erI3wIHZsRzjUmcjTuwOFxG4OVZaDPDOk394X46r+b3FTHZbXQRDG6+zKXZMrsmKAx9PACZsB8Tn7JQWTRHlDc70uUreDtxkQlzRKengNGE7PmuQ/OOH+ousGU0uIRsTS2QPRdEpVo/LAGAJDxYlM31oaepi6bfci/YqZvdfx7h+M4GFt2KTGPe27HTJs6QWO4wtKDSRo7FcH1W8=~0~-1~-1',
                            'upgrade-insecure-requests': '1',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
                            }
                        count = 1
                        while True:
                            flag = True
                            res = requests.get(url=Product_link,headers=headers_p)
                            if count < 5:
                                if res.status_code == 200:
                                    response = HtmlResponse(url=res.url, body=res.content)
                                    if '{"address":{"postalCode":"30309"}' in response.text:
                                        # ------------ data page save
                                        if not response.xpath('//*[@class="ProductDetails-header"]/h1/text()'):
                                            print('Product not available on perticular zip.')
                                            count += 1
                                            flag = False
                                        if flag == True:
                                            self.set.page_save(final_path, response.text)
                                            print("page save done")
                                            count = 6
                                            break
                    file = self.set.page_read(final_path)
                    response = html.fromstring(file)
                    price_check = ''
                    # --------------------- data extraction
                    try:
                        Category = category_dict[Category_Name]
                    except Exception as e:
                        print(e)
                        Category = ''
                    if not response.xpath('//*[@class="ProductDetails-header"]/h1/text()'):
                        print('Product not available on perticular zip.')
                        Item_Name = Description = ProductImage = FeaturedImage = MainImage = Price = Size = ''
                    else:
                        try:
                            Item_Name = response.xpath('//*[@class="ProductDetails-header"]/h1/text()')[0].strip()
                        except Exception as e:
                            print(e)
                            Item_Name = ''
                        try:
                            Description_text = re.findall(r'"romanceDescription":"(.*?)","', file)[0]
                            response_p = html.fromstring(Description_text)
                            Description = '\n'.join(response_p.xpath('//text()'))
                        except Exception as e:
                            print(e)
                            Description = ''

                        try:
                            image_list = []
                            Rand_Images_Urls = '[{"url":' + re.findall(r'"images":\[{"url":(.*?)\],', file)[0] + "]"
                            image_data = json.loads(Rand_Images_Urls)
                            for i in image_data:
                                if i['size'] == 'xlarge':
                                    image_list.append(i['url'])
                            if image_list == []:
                                for i in image_data:
                                    if i['size'] == 'large':
                                        image_list.append(i['url'])
                            if image_list == []:
                                for i in image_data:
                                    if i['size'] == 'medium':
                                        image_list.append(i['url'])
                            if image_list == []:
                                for i in image_data:
                                    if i['size'] == 'small':
                                        image_list.append(i['url'])
                            Rand_Images_Url = '|'.join(image_list)
                            ProductImage = image_list[0]
                            FeaturedImage = Rand_Images_Url
                            MainImage = ProductImage
                        except Exception as e:
                            print(e)
                            ProductImage = FeaturedImage = MainImage = ''

                        try:
                            if price_check == '':
                                try:
                                    Price = re.findall(r'"priceNormal":"(.*?)",', file)[0]
                                except:
                                    Price = re.findall(r'"price":"(.*?)",', file)[0]
                            else:
                                Price = price_check
                        except Exception as e:
                            print(e)
                            Price = ''

                        try:
                            Size = re.findall(r'"customerFacingSize":"(.*?)",', file)[0]
                        except Exception as e:
                            print(e)
                            Size = ''

                    try:
                        self.item = TranmazonItem()
                        self.item['Site'] = self.site_name
                        self.item['Name'] = Item_Name
                        self.item['Description'] = Description
                        self.item['Category'] = Category
                        self.item['MainImage'] = MainImage
                        self.item['FeaturedImage'] = FeaturedImage
                        self.item['Price'] = Price
                        self.item['Size'] = Size
                        self.item['ProductImage'] = ProductImage
                        self.item['URL'] = Product_link
                        self.item['final_path'] = final_path.replace('\\', '\\\\')
                        self.item['table'] = f"{self.site_name}_{self.set.get_name('this_week_table',self.site_name)}"
                        yield self.item
                    except Exception as e:
                        print(e)

                    try:
                        self.set.cursor.execute(f'update {dbc.database}.{table} set status="Done" where Product_Link="{Product_link}" and Id="{Id}"')
                        self.set.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

# execute("scrapy crawl kroger_data -a start=0 -a end=3034 -a site_name=kroger".split())
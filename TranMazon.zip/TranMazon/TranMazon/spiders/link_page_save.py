# import os
# from random import choice
# import requests
# import scrapy
# from scrapy.cmdline import execute
# from scrapy.http import HtmlResponse
# from w3lib.http import basic_auth_header
# from scraper_api import ScraperAPIClient
# from TranMazon import db_config as dbc
# from TranMazon.spiders.temp import Temp
# from datetime import datetime
#
#
# class WalmartLinkPageSpider(scrapy.Spider):
#     name = 'walmart_link_page'
#     allowed_domains = []
#     start_urls = ['https://example.com']
#     start, end = '', ''
#
#     def __init__(self, name=None, site_name='', **kwargs):
#         super().__init__(name, **kwargs)
#         self.set = Temp()
#         self.ipaddress = "192.168.1.252"
#         self.site_name = site_name
#         self.run_date = str(datetime.today()).split()[0].replace('-', '_')
#         self.set.basic(self.run_date, self.ipaddress, self.site_name)
#
#     def parse(self, response):
#         self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name).replace("\\D\\","\\d\\")
#         self.set.cursor.execute(f'Select * from {dbc.database}.walmart_link_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and status="pending"')
#         self.set.con.commit()
#         product_results = self.set.cursor.fetchall()
#         for row_p in product_results:
#             try:
#                 Id = row_p[0]
#                 Product_Link = row_p[-3]
#                 productId_main = Product_Link.split('/')[-1]
#                 Category = row_p[-2]
#                 final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
#                 if not os.path.exists(final_path):
#                     payload = '{\"variables\":\"{\\\"casperSlots\\\":{\\\"fulfillmentType\\\":\\\"ACC\\\",\\\"reservationType\\\":\\\"SLOTS\\\"},\\\"postalAddress\\\":{\\\"addressType\\\":\\\"RESIDENTIAL\\\",\\\"countryCode\\\":\\\"USA\\\",\\\"postalCode\\\":\\\"55129\\\",\\\"stateOrProvinceCode\\\":\\\"MN\\\",\\\"zipLocated\\\":true},\\\"storeFrontIds\\\":[{\\\"distance\\\":3.35,\\\"inStore\\\":false,\\\"preferred\\\":true,\\\"storeId\\\":\\\"2643\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2643},{\\\"distance\\\":2.84,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"90133\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":90133},{\\\"distance\\\":6.24,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"2448\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2448},{\\\"distance\\\":8.91,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"1365\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":1365},{\\\"distance\\\":9.29,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"3364\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":3364}],\\\"productId\\\":\\\"' + f'{productId_main}' + '\\\",\\\"selected\\\":false}\"}'
#                     headers = {
#                         'WM_CONSUMER.ID': '8821a0c4-d3c0-11e7-9296-cec278b6b50a',
#                         'WM_SITE_MODE': '0',
#                         'itemId': str(productId_main),
#                         'User-Agent': 'Android v20.41.3',
#                         'did': '12c8586a-0335-4ba5-85f0-81f3783ea133',
#                         'X-PX-AUTHORIZATION': '3',
#                         'X-PX-ORIGINAL-TOKEN': '3:37af5453421b87a8e434012e5a0d9965b89'
#                                                'cfb0c28ef27072d7a2667ab93bd73:fZ1fIELALz+fXL6ns/6X+BTdJgJ8H641NZzXTAHwiC7aabl89piboXB0d6nhXy2bYvmsXVsOr/NUe/+i1CmcRQ==:1000:eZjnSImre2LoozJi/z0+CHU00C4v64Y5+soJiBpukw3ELxiGibSexbgVASmJd2ZClN5LCOKRX5jzBzRxG1ft0//N1/xHzIAfeTqZvGOXoAP45sDgbsz2WX8Yv6hslyUHldWLsqexV/cyJcC4W9TtrEJ0hRdH4cDFEtWp0yBNLac=',
#                         'Content-Type': 'application/json; charset=utf-8',
#                         'Content-Length': '907',
#                         'Cookie': 'WLM=1; hasACID=1; auth=MTAyOTYyMDE46OBEKZlDorF9XxhLfEcfCoFc9mWKD5zQW6XXScqwlnfLKcXjVFXbk6s9rCWJKfQ%2B%2Frk80vjTO7JstR79cnG32CdLuXpMJKYNLPb0mMniaMbUVW7CN5Slek5Z9TkzAhV1767wuZloTfhm7Wk2Kcjygp0i2CSRVbB3L7ys%2FtvUzQczv52bQ%2B4EkUZQhsMwQyjhg7KyGViTQjlqHkJLnHf%2FFUZTSxsKj1vnEodX4zkzEwBGyEMqGry%2B0lIRqFvmUM8k0S4ks2VlT7qwuWkKDx%2Bp%2BNDfOOAXU7Wbeglv9fAI1Hy5knd9GnrZjvaltpA1aHG4LNZuHxJXXbXek3ABOr0bLyVmFyUaR4c8EmE55nNX7BjSDqSsqzx%2Fz8FYPIj7peFD7Cu255NsR5qastUa0xdgRw%3D%3D; ACID=bc9a9ec3-16d6-45d0-89f2-702822034749; type=GUEST; speed=slow; spp=0.9562; vtc=ThthT6Fm77HjUIEsLgurG4; bstc=ThthT6Fm77HjUIEsLgurG4; mobileweb=1; xpa=76AYR; xpm=0%2B1604061863%2BThthT6Fm77HjUIEsLgurG4~%2B0; exp-ck=76AYR1; TS01b0be75=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c; TS013ed49a=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c'
#                     }
#                     try:
#                         client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')
#                         response = requests.request("POST", client.scrapyGet(url=Product_Link), headers=headers, data=payload, verify=False)
#                         print(response.text)
#                     except Exception as e:
#                         print(e)
#                     # proxy_o = self.get_proxy()
#                     # self.head = {
#                     #     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
#                     #     'cookie': 'vtc=cIvvCo1RBf5zuJseq6A5DA; TS013ed49a=01538efd7c68f27834f613e144c64f78f63e4f82d5bb7ca8c89603bdfcd2b9a76e2c29c2e6a5d7eb41225d78ed171718a1620bb467; TBV=7; cart-item-count=0; _pxvid=83e6c6b6-48f5-11eb-8449-0242ac120008; __gads=ID=365e7502c7267e32:T=1609150489:S=ALNI_MYgT0_8WVj_g5hTxOnmBw2bGea40w; _gcl_au=1.1.1958392586.1609150491; cid_csid=c39b6f57-7ddc-48fc-9e20-e17255884090; _fbp=fb.1.1609150499877.657637175; tb_sw_supported=true; _internal.verticalId=default; _internal.verticalTheme=default; bstc=bRr52Kv5djVwmAD5-IPRZc; mobileweb=0; xpa=; xpm=3%2B1609331760%2BcIvvCo1RBf5zuJseq6A5DA~%2B0; TS01b0be75=01538efd7ccc67d2b4b193fc43669c5da49c3ab0d538d71dc79ff2dfc9c24bc4ba697792bc99ec7f73fc934874bc47dd35694dca2c; athrvi=RVI~h2f2ccf2-hbcf7811-hfdb765-h1c82b13-h2ee286c4; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1609333008264@firstcreate:1609150484666"; akavpau_p8=1609333608~id=b0fb39c25231558f11eddb7274a489bf; s_sess_2=c32_v%3DS2H%2CPUT%2Cnull%3B%20prop32%3DS2H-V%2CPUT-V%2CPUT%2CS2H; _px3=f9ea3333dd5fda31f184d875391d232519d936d7ffe4f2953ca3d104684cff36:JHKjsZh7qk2WbbziaNlUw5ylDDoWNRr3KE1NzDE4fp6pFygnctpeeSTwkC/VMk2Z3UFwHYHg98TiVG+vg0y+3A==:1000:FAadZoKp04XE6E2WFS5Pi+ekjomeMNRjITivUi7v/Q6X7QiK6t5ez7e9sbUvwf8o+toHCLJlIOJyHOVzKCQhdpfhv0j6D35O3cgUuCoShxRDMMaGggJoxgaNRs3TAFrSE6f2vrvyrlJt2h6XSq+vSgnL6jctbzculuY3GisTh+0=; _uetsid=8a8cd9a048f511ebbde3e10f339cbdae; _uetvid=8a94779048f511eb9fff6b47f8693b93; _pxde=4906ed1066f844a8246fc835422c3ee5020f432f13f8a603ece699be33ec11ce:eyJ0aW1lc3RhbXAiOjE2MDkzMzMwNTY1NjYsImZfa2IiOjAsImlwY19pZCI6W119; next-day=1609351200|true|false|1609416000|1609333060; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1609333060296|30309',
#                     #     'upgrade-insecure-requests': '1',
#                     #     'Proxy-Authorization': basic_auth_header('alpesh.khunt.xbyte@gmail.com','xbyte123'),
#                     #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
#                     # }
#
#                     # proxy = {
#                     #     'Proxy-Authorization': basic_auth_header(proxy_o[0],proxy_o[1])
#                     # }
#                     # lkst = "http://api.scraperapi.com/?api_key=0f2e50f637e062a098bdf4d0a3e6e0d3&keep_headers=true&country_code=us&url=" + str(Product_Link)
#
#                     # response1 = requests.request("GET", url=lkst, headers=self.head)
#                     # if '<title>Verify your identity</title>' in response1.text or 'Request failed' in response1.text:
#                     #     print("blocked")
#                     # else:
#                     #     if '"productName"' in response1.text:
#                     #         final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
#                     #         self.set.page_save(final_path, response1.text)
#                     #         print(f"page save done ----- {Product_Link}")
#                     #
#                     #         try:
#                     #             self.set.cursor.execute(f'update {dbc.database}.walmart_link_2020_12_14 set status="Done" where Product_Link="{Product_Link}"')
#                     #             self.set.con.commit()
#                     #             print("update done")
#                     #         except Exception as e:
#                     #             print(e)
#                     # yield scrapy.Request(url=Product_Link, callback=self.get_data, dont_filter=True, headers=self.head, meta={'Catgeory': Category, 'source_url': Product_Link, 'Id': Id,'proxy':'108.59.14.200:13202'})
#                     # while True:
#                     #     res1 = requests.get(url=str(Product_Link), headers=self.head, proxies=proxy, verify=False)
#                     #     response1 = HtmlResponse(url=res1.url, body=res1.content)
#                     #     try:
#                     #         if '<title>Verify your identity</title>' in response1.text:
#                     #             print("blocked----")
#                     #             break
#                     #             # yield scrapy.Request(url=Product_Link, callback=self.get_data, dont_filter=True, headers=self.head,
#                     #             #                      meta={'Catgeory': Category, 'source_url': Product_Link, 'Id': Id})
#                     #         else:
#                     #             final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
#                     #             self.set.page_save(final_path, response1.text)
#                     #             print(f"page save done ----- {Product_Link}")
#                     #
#                     #             try:
#                     #                 self.set.cursor.execute(f'update {dbc.database}.walmart_link_2020_12_14 set status="Done" where Product_Link="{Product_Link}"')
#                     #                 self.set.con.commit()
#                     #                 print("update done")
#                     #             except Exception as e:
#                     #                 print(e)
#                     #             break
#                     #     except Exception as e:
#                     #         print(e)
#                     # yield scrapy.Request(url=str(Product_Link), callback=self.get_data, headers=self.head, dont_filter=True, meta={'Catgeory':Category,'source_url':Product_Link,'Id':Id})
#             except Exception as e:
#                 print(e)
#
#     def get_data(self, response):
#         try:
#             Catgeory = response.meta['Catgeory']
#             Product_Link = response.meta['source_url']
#             Id = response.meta['Id']
#             if '<title>Verify your identity</title>' in response.text:
#                 yield scrapy.Request(url=Product_Link, callback=self.get_data, dont_filter=True, headers=self.head,
#                                      meta={'Catgeory': Catgeory, 'source_url': Product_Link,'Id':Id})
#             else:
#                 final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
#                 self.set.page_save(final_path, response.text)
#                 print(f"page save done ----- {Product_Link}")
#
#                 try:
#                     self.set.cursor.execute(f'update {dbc.database}.walmart_link_2020_12_14 set status="Done" where Product_Link="{Product_Link}"')
#                     self.set.con.commit()
#                     print("update done")
#                 except Exception as e:
#                     print(e)
#         except Exception as e:
#             print(e)
#
#     def get_proxy(self):
#         proxy = [
#             "lum-customer-xbyte-zone-zone_us:0gi0pioy3oey",
#             "lum-customer-xbyte-zone-zone_uk:bqa3iap0g4nr",
#             "lum-customer-xbyte-zone-zone_spain:k4vt6e2v53v9",
#             "lum-customer-xbyte-zone-zone_italy:et2g17oqw1nm",
#             "lum-customer-xbyte-zone-zone_australia:rjbsuy1tzgco",
#             "lum-customer-xbyte-zone-zone_japan:5v9sl7ilbppn",
#             "lum-customer-xbyte-zone-zone_taiwan:b2kqeq76cxi6",
#             "lum-customer-xbyte-zone-zone_netherland:zvptczvd2ahq",
#             "lum-customer-xbyte-zone-zone_russia:plpsy85v8pu6",
#             "lum-customer-xbyte-zone-zone_india:w6zj0g4ikjy3",
#             "lum-customer-xbyte-zone-zone_israel:gtuythxi5oc3"
#         ]
#         proxy_auth_pass = str(choice(proxy))
#         proxy_auth = proxy_auth_pass.split(':')[0]
#         proxy_pass = proxy_auth_pass.split(':')[1]
#         return [proxy_auth,proxy_pass]
#
# # execute("scrapy crawl walmart_link_page -a site_name=walmart -a start=0 -a end=258108".split())
import os
import re
import pymysql
import scrapy
from unidecode import unidecode

from TranMazon.items import TranmazonItem
# from wallmart.items import WallmartItem
from scraper_api import ScraperAPIClient
from scrapy.cmdline import execute
import requests
from TranMazon.spiders.temp import Temp
from random import choice
import json

client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')

def get_proxy():

  proxy = [
    "lum-customer-xbyte-zone-zone_us:0gi0pioy3oey",
    "lum-customer-xbyte-zone-zone_uk:bqa3iap0g4nr",
    "lum-customer-xbyte-zone-zone_spain:k4vt6e2v53v9",
    "lum-customer-xbyte-zone-zone_italy:et2g17oqw1nm",
    "lum-customer-xbyte-zone-zone_australia:rjbsuy1tzgco",
    "lum-customer-xbyte-zone-zone_japan:5v9sl7ilbppn",
    "lum-customer-xbyte-zone-zone_taiwan:b2kqeq76cxi6",
    "lum-customer-xbyte-zone-zone_netherland:zvptczvd2ahq",
    "lum-customer-xbyte-zone-zone_russia:plpsy85v8pu6",
    "lum-customer-xbyte-zone-zone_india:w6zj0g4ikjy3",
    "lum-customer-xbyte-zone-zone_israel:gtuythxi5oc3"
  ]
  proxy_auth = str(choice(proxy))
  proxy_host = "zproxy.lum-superproxy.io"
  proxy_port = "22225"
  return {"https": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)}

class WallSpider(scrapy.Spider):

    name = 'wall'
    start_urls = ['https://www.amazon.in/']
    start = end = ""

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.con = pymysql.connect("localhost", "root", "xbyte", "tranmazon")
        self.crsr = self.con.cursor()
        self.crsr.execute(f"SELECT * FROM walmart_link_2020_12_14 where status='pending' limit {self.start},{self.end}")
        # self.crsr.execute(f"SELECT * FROM walmart_link_2020_12_14 where status='pending' and Id>'{self.start}' and Id<'{self.end}'")
        # self.crsr.execute(f"SELECT * FROM wallmart where id=1")
        self.allresult = self.crsr.fetchall()

    def parse(self,response):
        item = TranmazonItem()
        self.this_week_html_path = self.set.get_name("this_week_html_path", self.site_name).replace("\\D\\", "\\d\\")
        for row in self.allresult:
            Id = row[0]
            final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
            Product_Link = row[-3]
            Category = row[-2]
            product_id = row[-3].split('/')[-1]

            if not os.path.exists(final_path):
                url = "https://www.walmart.com/terra-firma/graphql?v=2&options=timing%2Cnonnull%2Cerrors%2Ccontext&id=FullProductRoute-android"
                payload =  '{\"variables\":\"{\\\"casperSlots\\\":{\\\"fulfillmentType\\\":\\\"ACC\\\",\\\"reservationType\\\":\\\"SLOTS\\\"},\\\"postalAddress\\\":{\\\"addressType\\\":\\\"RESIDENTIAL\\\",\\\"countryCode\\\":\\\"USA\\\",\\\"postalCode\\\":\\\"55129\\\",\\\"stateOrProvinceCode\\\":\\\"MN\\\",\\\"zipLocated\\\":true},\\\"storeFrontIds\\\":[{\\\"distance\\\":3.35,\\\"inStore\\\":false,\\\"preferred\\\":true,\\\"storeId\\\":\\\"2643\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2643},{\\\"distance\\\":2.84,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"90133\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":90133},{\\\"distance\\\":6.24,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"2448\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2448},{\\\"distance\\\":8.91,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"1365\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":1365},{\\\"distance\\\":9.29,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"3364\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":3364}],\\\"productId\\\":\\\"'+f'{product_id}'+'\\\",\\\"selected\\\":false}\"}'

                headers = {
                    'WM_CONSUMER.ID': '8821a0c4-d3c0-11e7-9296-cec278b6b50a',
                    'WM_SITE_MODE': '0',
                    'itemId': f'{product_id}',
                    'User-Agent': 'Android v20.41.3',
                    'did': '12c8586a-0335-4ba5-85f0-81f3783ea133',
                    'X-PX-AUTHORIZATION': '3',
                    'X-PX-ORIGINAL-TOKEN': '3:37af5453421b87a8e434012e5a0d9965b89'
                                           'cfb0c28ef27072d7a2667ab93bd73:fZ1fIELALz+fXL6ns/6X+BTdJgJ8H641NZzXTAHwiC7aabl89piboXB0d6nhXy2bYvmsXVsOr/NUe/+i1CmcRQ==:1000:eZjnSImre2LoozJi/z0+CHU00C4v64Y5+soJiBpukw3ELxiGibSexbgVASmJd2ZClN5LCOKRX5jzBzRxG1ft0//N1/xHzIAfeTqZvGOXoAP45sDgbsz2WX8Yv6hslyUHldWLsqexV/cyJcC4W9TtrEJ0hRdH4cDFEtWp0yBNLac=',
                    'Content-Type': 'application/json; charset=utf-8',
                    'Content-Length': '907',
                    'Cookie': 'WLM=1; hasACID=1; auth=MTAyOTYyMDE46OBEKZlDorF9XxhLfEcfCoFc9mWKD5zQW6XXScqwlnfLKcXjVFXbk6s9rCWJKfQ%2B%2Frk80vjTO7JstR79cnG32CdLuXpMJKYNLPb0mMniaMbUVW7CN5Slek5Z9TkzAhV1767wuZloTfhm7Wk2Kcjygp0i2CSRVbB3L7ys%2FtvUzQczv52bQ%2B4EkUZQhsMwQyjhg7KyGViTQjlqHkJLnHf%2FFUZTSxsKj1vnEodX4zkzEwBGyEMqGry%2B0lIRqFvmUM8k0S4ks2VlT7qwuWkKDx%2Bp%2BNDfOOAXU7Wbeglv9fAI1Hy5knd9GnrZjvaltpA1aHG4LNZuHxJXXbXek3ABOr0bLyVmFyUaR4c8EmE55nNX7BjSDqSsqzx%2Fz8FYPIj7peFD7Cu255NsR5qastUa0xdgRw%3D%3D; ACID=bc9a9ec3-16d6-45d0-89f2-702822034749; type=GUEST; speed=slow; spp=0.9562; vtc=ThthT6Fm77HjUIEsLgurG4; bstc=ThthT6Fm77HjUIEsLgurG4; mobileweb=1; xpa=76AYR; xpm=0%2B1604061863%2BThthT6Fm77HjUIEsLgurG4~%2B0; exp-ck=76AYR1; TS01b0be75=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c; TS013ed49a=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c'
                }

                try:
                    response = requests.request("POST", client.scrapyGet(url=url), headers=headers, data=payload, verify=False)
                except Exception as e:
                    print(e)

                res = response.text
                print(res)

                while response.text.startswith("<!DOCTYPE html>") or response.text.startswith("Request failed"):
                    try:
                        response = requests.request("POST", client.scrapyGet(url=url), headers=headers, data=payload, verify=False)
                    except Exception as e:
                        print(e)
                data = json.loads(response.text)
                self.set.page_save(final_path, response.text)
                print(f"page save done ----- {Id}")

            try:
                file = self.set.page_read(final_path)
                try:
                    Name = re.findall(r'"productName":"(.*?)","', file)[0].strip()
                except Exception as e:
                    print(e)
                    Name = ''
                if Name != '':
                    try:
                        Description = re.findall(r'"detailedDescription":"(.*?)","', file)[0].strip()
                        Description = re.sub('<[^<]+?>', '', str(Description))
                    except Exception as e:
                        print(e)
                        Description = ''
                    if Description == '':
                        Description = "We aim to show you accurate product information. Manufacturers, suppliers and others provide what you see here, and we have not verified it. See our disclaimer"

                    try:
                        Image_List = re.findall(r'"imageList":\[(.*?)\]', file)[0]
                        Images = re.findall(r'"default":"(.*?)"', Image_List)
                        ProductImage = Images[0]
                        FeaturedImage = '|'.join(Images[1:])
                    except Exception as e:
                        print(e)
                        ProductImage = FeaturedImage = ''

                    try:
                        Price = re.findall(r'\{"prices":\{"current":\{"price":(.*?),', file)[0]
                    except Exception as e:
                        print(e)
                        Price = ''

                    try:
                        var_cat = len(data['data']['productByProductId']['variantCategoryList'])
                    except:
                        var_cat = 0

                    try:
                        weight_measure = Name
                        Weight1 = str(weight_measure).lower()
                        print(Weight1)

                        if "oz" in Weight1:
                            Weight_unit_of_measurement = "Oz"
                            Weight = Weight1.split("oz")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "ounce" in Weight1:
                            Weight_unit_of_measurement = "Ounce"
                            Weight = Weight1.split("ounce")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "ounces" in Weight1:
                            Weight_unit_of_measurement = "Ounce"
                            Weight = Weight1.split("ounce")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "lb" in Weight1:
                            Weight_unit_of_measurement = "Lb"
                            Weight = Weight1.split("lb")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "lbs" in Weight1:
                            Weight_unit_of_measurement = "Lb"
                            Weight = Weight1.split("lbs")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "pound" in Weight1:
                            Weight_unit_of_measurement = "Pounds"
                            Weight = Weight1.split("pound")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "pounds" in Weight1:
                            Weight_unit_of_measurement = "Pounds"
                            Weight = Weight1.split("pounds")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "gram" in Weight1:
                            Weight_unit_of_measurement = "Grams"
                            Weight = Weight1.split("gram")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "grams" in Weight1:
                            Weight_unit_of_measurement = "Grams"
                            Weight = Weight1.split("grams")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif " ct" in Weight1:
                            Weight_unit_of_measurement = "Ct"
                            Weight = Weight1.split("ct")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        elif "gm" in Weight1:
                            Weight_unit_of_measurement = "Grams"
                            Weight = Weight1.split("gm")[0]
                            if "," in Weight:
                                Weight = Weight.split(",")[-1].strip()
                                if "-" in Weight:
                                    Weight = Weight.split("-")[-1].strip()
                                    Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                                else:
                                    Weight = Weight
                            elif "-" in Weight:
                                Weight = Weight.split("-")[-1]
                            elif "." in Weight:
                                Weight = re.findall(r'[0-9]\.[0-9]', Weight)[0]
                            elif "x" in Weight:
                                Weight = Weight.split("x")[-1].strip()
                            elif "(" in Weight:
                                Weight = Weight.split("(")[-1].strip()
                            elif " " in Weight:
                                Weight = re.findall(r'\d+', Weight)[0]
                            else:
                                Weight = Weight
                        else:
                            Weight_unit_of_measurement = ''
                            Weight = ''
                    except Exception:
                        Weight_unit_of_measurement = ''
                        Weight = ''

                try:
                    self.item = TranmazonItem()
                    self.item['Name'] = Name
                    self.item['Description'] = unidecode(Description)
                    self.item['Category'] = Category
                    self.item['MainImage'] = ProductImage
                    self.item['FeaturedImage'] = FeaturedImage
                    self.item['Price'] = Price
                    self.item['Size'] = Weight
                    self.item['ProductImage'] = ProductImage
                    self.item['URL'] = Product_Link
                    self.item['final_path'] = final_path.replace('\\', '\\\\')
                    self.item['table'] = 'walmart_data_2020_12_14'
                    yield self.item
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

# execute("scrapy crawl wall -a start=0 -a end=1000 -a site_name=walmart".split())
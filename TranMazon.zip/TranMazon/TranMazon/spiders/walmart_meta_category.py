import json
import os
import re

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class WalmartMetaCategorySpider(scrapy.Spider):
    name = 'walmart_meta_category'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self, response):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
            self.set.cursor.execute(f'Select * from {dbc.database}.walmart_category_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and link_status="Done"')
            self.set.con.commit()
            product_results = self.set.cursor.fetchall()
            for row_p in product_results:
                try:
                    Category_Main_Link = row_p[1]
                    Category_page = row_p[3]
                    Category_id = row_p[6]

                    file = self.set.page_read(Category_page)
                    response1 = html.fromstring(file)
                    data_json_text = response1.xpath('//script[@id="searchContent"]/text()')[0]
                    try:
                        data_json = json.loads(data_json_text)
                    except Exception as e:
                        print(e)
                    for data in data_json['searchContent']['preso']['facets']:
                        # items = data['searchContent']['preso']['facets']
                        # for item in items:
                        if data['name'] == 'Departments':
                            for data1 in data['values']:
                                try:Category_Link = f"https://www.walmart.com{data1['baseSeoURL']}"
                                except:Category_Link = f"https://www.walmart.com/search/?{data1['url']}"
                                Category_Name = data1['name']
                                try:
                                    self.item = TranmazonItem()
                                    self.item['Category_Main_Link'] = Category_Main_Link
                                    self.item['Category_Link'] = Category_Link
                                    # self.item['Category_page'] = final_path.replace('\\', '\\\\')
                                    # self.item['count'] = count
                                    self.item['Category_Name'] = Category_Name
                                    self.item['Category_id'] = Category_id
                                    self.item['table'] = "walmart_category_2020_12_14"
                                    yield self.item
                                except Exception as e:
                                    print(e)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


# execute("scrapy crawl walmart_meta_category -a site_name=walmart -a start=0 -a end=26347".split())
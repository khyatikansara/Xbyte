import json
import os
import re
from random import choice
import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from unidecode import unidecode
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class WalmartDataSpider(scrapy.Spider):
    name = 'walmart_data'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)
        self.links_not = []
        self.links_yes = []

    def parse(self, response):
        df = pd.read_csv("D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_2021_01_05_66707_3.csv")
        df = df.fillna('')
        final_list = []
        for index, row in df.iterrows():
            Id = row[0]
            print(Id)
            Name = row[1]
            Description = row[2]
            Category = row[3]
            Status = row[4]
            MainImage = row[5]
            IsFeaturedProduct = row[6]
            FeaturedPosition = row[7]
            FeaturedImage = row[8]
            Price = row[9]
            Size = row[10]
            Country = row[11]
            ProductImage = row[12]
            URL = row[13]
            final_path = row[14]
            if Description == '#NAME?':
                self.set.cursor.execute(f'Select Description from {dbc.database}.walmart_data_2020_12_14 where URL="{URL}"')
                self.set.con.commit()
                product_results = self.set.cursor.fetchall()
                print(product_results)
                try:
                    des = product_results[0][0]
                    Description = re.sub(r'^\-+','',des).strip()
                    print(Description)
                except Exception as e:
                    print(e)

            # if Price == '':
            #     print(final_path)
            #     file = self.set.page_read(final_path)
            #     response = html.fromstring(file)
            #     if not response.xpath('//h2[text()="Not available"]') or not response.xpath('//h2[text()="Item not available"]'):
            #         print("")
            final_list.append(
                [Id, Name, Description, Category, Status, MainImage, IsFeaturedProduct, FeaturedPosition,
                 FeaturedImage, Price, Size, Country, ProductImage, URL, final_path])
        #         if '"prices":{"current":' in file:
        #             try:
        #                 try:Price_text = re.findall(r'"prices":\{(.*?)"priceType"', file)[0]
        #                 except:Price_text = re.findall(r'"prices":\{(.*?),"', file)[0]
        #                 try:Price = re.findall(r'"price":(.*?),', Price_text)[0]
        #                 except:Price = re.findall(r'"price":(.*?)$', Price_text)[0]
        #                 if Price == '':
        #                     print("stop")
        #             except Exception as e:
        #                 print(e)
        #                 Price = ''
        #             if '$' not in Price:
        #                 Price = '$' + Price
        #     final_list.append([Id, Name, Description, Category, Status, MainImage, IsFeaturedProduct, FeaturedPosition, FeaturedImage,Price, Size, Country, ProductImage, URL, final_path])
        try:
            gh = pd.DataFrame(final_list, columns=['id', 'Name', 'Description', 'Category', 'Status', 'MainImage',
                                                   'IsFeaturedProduct', 'FeaturedPosition', 'FeaturedImage', 'Price',
                                                   'Size', 'Country', 'ProductImage', 'URL', 'final_path'])
            gh.to_excel("D:\\khyati-H\\TranMazon\\HTML\\Html_2020_12_09\\walmart\\CSV\\walmart_2021_01_06_66707.xlsx", index=False)
        except Exception as e:
            print(e)
        # links_missing = ['https://www.walmart.com/ip/Children-s-Motrin-Ibuprofen-Kids-Medicine-Berry-Flavored-4-fl-oz/10294152',
        #  'https://www.walmart.com/ip/Children-s-Tylenol-Pain-Fever-Relief-Cold-Medicine-Grape-4-fl-oz/10294184',
        #  'https://www.walmart.com/ip/Theraflu-Nighttime-Multi-Symptom-Severe-Cold-Hot-Liquid-Powder-Green-Tea-and-Citrus-Flavors-6-Count-Box/47300991',
        #  'https://www.walmart.com/ip/AZO-Complete-Feminine-Balance-Daily-Probiotic-for-Women-Supports-Vaginal-Health-30-ct/456487754',
        #  'https://www.walmart.com/ip/Mucinex-Sinus-Max-Maximum-Strength-Severe-Congestion-and-Pain-Liquid-6-fl-oz/39517587',
        #  'https://www.walmart.com/ip/6-pack-SEEDS-OF-CHANGE-Organic-Brown-Basmati-Rice-8-5oz/832690741',
        #  'https://www.walmart.com/ip/6-pack-Knorr-Rice-Side-Dish-For-Rich-Savoury-Flavor-Cheddar-Broccoli-No-Artificial-Preservatives-5-7-Oz/150889738',
        #  'https://www.walmart.com/ip/Sunbest-Natural-Jasmine-Rice-5lbs-Thai-Premium-Long-Grain-Jasmine-Rice/778028918',
        #  'https://www.walmart.com/ip/McCabe-Organic-Grain-3-Pound-2-Pack-White-Rice-and-Mixed-Rice/635128141',
        #  'https://www.walmart.com/ip/Organic-Basmati-White-Rice-1-Pound-Non-GMO-Kosher-Raw-Vegan-by-Food-to-Live/308999650',
        #  'https://www.walmart.com/ip/McCabe-Organic-Rice-Flour-1-Pound/718527743',
        #  'https://www.walmart.com/ip/McCabe-Organic-7030-Brown-Rice-Brown-Sweet-Rice-12-Pound/622164968',
        #  'https://www.walmart.com/ip/McCabe-Organic-Sweet-Rice-3-lb/392595310',
        #  'https://www.walmart.com/ip/McCabe-Organic-Brown-Rice-Flour-1lb-16-oz/398974871',
        #  'https://www.walmart.com/ip/TWING-Rustic-8-10-Picture-Frame-Distressed-Wood-Pattern-High-Definition-Plexiglass-Photos-Frame-for-Table-Top-and-Wall-Display-6-Pack-Grey/743325384',
        #  'https://www.walmart.com/ip/Icona-Bay-5x7-Pony-Gray-Picture-Frame-Rustic-Style-1-Pack-Barnwood-Collection/338299094',
        #  'https://www.walmart.com/ip/Rustic-Wooden-Picture-Frame-Shabby-Chic-Wall-Hanging-Frame-fits-5x7-Photo-EGP-HD-0180/111772210',
        #  'https://www.walmart.com/ip/Rustic-Three-Picture-Frame-Holds-three-3x3-Photos-Hand-Painted-Shabby-Chic-EGP-HD-0020/579964421',
        #  'https://www.walmart.com/ip/Rustic-Shabby-Chic-Turquoise-Blue-Picture-Frame-Holds-Two-5x7-Photos-Pack-of-2-EGP-HD-0103/457699818',
        #  'https://www.walmart.com/ip/Langdon-House-8x10-Gold-Picture-Frame-Glam-Style-3-Pack-Celebration-Collection/909825275',
        #  'https://www.walmart.com/ip/Decorative-Picture-Frame-5x7-Photo-Holder-Mirror-with-Sparkling-Crystal-Border-EGP-HD-0128/962296545',
        #  'https://www.walmart.com/ip/Decorative-Picture-Frame-8-x10-Blue-Bamboo-Reed-Textured-Pack-of-2-EGP-HD-0234/137434531']

        self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name).replace("\\D\\","\\d\\")
        # for i in links_missing:
        # query = f'Select * from {dbc.database}.walmart_data_2020_12_14 where URL="{i}"'
        self.set.cursor.execute(f'Select * from {dbc.database}.walmart_data_2020_12_14 where Price=""')
        # self.set.cursor.execute(f'Select * from {dbc.database}.walmart_link_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and status="Done" and price=""')
        self.set.con.commit()
        product_results = self.set.cursor.fetchall()
            # if product_results != ():
            #     self.links_yes.append(i)
            # else:
            #     self.links_not.append(i)
                # insert_db = f"insert into {dbc.database}.walmart_link_2020_12_14 (Product_Link) values ('{i}')"
                # self.set.cursor.execute(insert_db)
                # self.set.con.commit()
                # print('\rdata inserted ')
        # print("")
        for row_p in product_results:
            Id = row_p[0]
            final_path = row_p[-1]
            print(final_path)
            file = self.set.page_read(final_path)
            if '{"errors":[{"errorIdentifiers":' in file:
                try:
                    Price_text = re.findall(r'"prices":\{(.*?)"priceType"',file)[0]
                    Price = re.findall(r'"price":(.*?),',Price_text)[0]
                except Exception as e:
                    print(e)
                    Price = ''
            elif '"prices":' in file:
                try:
                    Price_text = re.findall(r'"prices":\{(.*?)"priceType"',file)[0]
                    Price = re.findall(r'"price":(.*?),',Price_text)[0]
                except Exception as e:
                    print(e)
                    Price = ''
                try:
                    self.set.cursor.execute(f'update {dbc.database}.walmart_data_2020_12_14 set Price="{Price}" where Id="{Id}"')
                    self.set.con.commit()
                    print(f"update done {Id}")
                except Exception as e:
                    print(e)

    #             Id = row_p[0]
    #             Product_Link = row_p[-3]
    #             Category = row_p[5]
    #             final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
    #             if os.path.exists(final_path):
    #                 file = self.set.page_read(final_path)
    #                 response1 = html.fromstring(file)
    #                 try:
    #                     Name = re.findall(r'"productName":"(.*?)","',file)[0]
    #                 except Exception as e:
    #                     print(e)
    #                     Name = ''
    #                 if Name != '':
    #                     try:
    #                         if response1.xpath('//*[contains(@class,"about-desc about-product-description")]//text()'):
    #                             Description = unidecode(''.join(response1.xpath('//*[contains(@class,"about-desc about-product-description")]//text()')).replace(" ",''))
    #                         else:
    #                             Description_1 = re.findall(r'"idmlShortDescription":"(.*?)","',file)[0]
    #                             Description_2 = re.findall(r'"idmlLongDescription":"(.*?)","',file)[0]
    #                             des = Description_1+Description_2
    #                             Description = re.sub('<[^<]+?>', '', str(des))
    #                         if Description == '':
    #                             Description = "We aim to show you accurate product information. Manufacturers, suppliers and others provide what you see here, and we have not verified it. See our disclaimer"
    #                     except Exception as e:
    #                         print(e)
    #
    #                     try:
    #                         try:ProductImage = response1.xpath('//*[@class="hover-zoom-hero-image"]/@src')[0]
    #                         except:ProductImage = response1.xpath('//*[@data-tl-id="ProductPage-primary-image"]/@src')[0]
    #                     except Exception as e:
    #                         print(e)
    #                     try:
    #                         FeaturedImage_text = re.findall(r'"images":\[\{(.*?)"variants":\[',file)[0]
    #                         FeaturedImage = '|'.join(re.findall(r'"url":"(.*?)","',FeaturedImage_text))
    #                     except Exception as e:
    #                         print(e)
    #                     try:
    #                         Price = ''
    #                         if response1.xpath('//*[@itemprop="price"]/@content'):
    #                             Price = response1.xpath('//*[@itemprop="price"]/@content')[0]
    #                         elif response1.xpath('//*[@itemprop="highPrice"]/@content'):
    #                             Price = response1.xpath('//*[@itemprop="highPrice"]/@content')[0]
    #                         elif response1.xpath('//span[@class="price "]/span[@class="visuallyhidden"]/text()'):
    #                             Price = response1.xpath('//span[@class="price "]/span[@class="visuallyhidden"]/text()')[0]
    #                         else:
    #                             Price = ''
    #                     except Exception as e:
    #                         print(e)
    #                     # try:
    #                     #     not_in = ['%','count','pack']
    #                     #     Size_list = []
    #                     #     Size = ''
    #                     #     size_digit = []
    #                     #     Name1 = Name.lower()
    #                     #     if ',' in Name1:
    #                     #         size_text = Name1
    #                     #         Size_list = size_text.split(',')
    #                     #     elif '-' in Name1:
    #                     #         size_text = Name1
    #                     #         Size_list = size_text.split('-')
    #                     #     elif Size_list == []:
    #                     #         measure = ['oz']
    #                     #         for i in Name1.split(' '):
    #                     #             if re.search('[0-9]', i) and '%' not in i:
    #                     #                 size_digit.append(i)
    #                     #             if i in measure:
    #                     #                 size_digit.append(i)
    #                     #     else:
    #                     #         Size_list = []
    #                     #     if Size_list != []:
    #                     #         for size_d in Size_list:
    #                     #             if re.search('[0-9]', size_d) and '%' not in size_d and 'count' not in size_d and 'pack' not in size_d:
    #                     #                 size_digit.append(size_d)
    #                     #         if ')' in Size_list[-1]:
    #                     #             size_digit.append(Size_list[-1])
    #                     #     Size = ''.join(size_digit).strip()
    #                     #     if Size == '':
    #                     #         print('')
    #                     # except Exception as e:
    #                     #     print(e)
    #
    #                     try:
    #                         weight_measure = Name
    #                         Weight1 = str(weight_measure).lower()
    #                         print(Weight1)
    #
    #                         if "oz" in Weight1:
    #                             Weight_unit_of_measurement = "Oz"
    #                             Weight = Weight1.split("oz")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "ounce" in Weight1:
    #                             Weight_unit_of_measurement = "Ounce"
    #                             Weight = Weight1.split("ounce")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "ounces" in Weight1:
    #                             Weight_unit_of_measurement = "Ounce"
    #                             Weight = Weight1.split("ounce")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "lb" in Weight1:
    #                             Weight_unit_of_measurement = "Lb"
    #                             Weight = Weight1.split("lb")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "lbs" in Weight1:
    #                             Weight_unit_of_measurement = "Lb"
    #                             Weight = Weight1.split("lbs")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "pound" in Weight1:
    #                             Weight_unit_of_measurement = "Pounds"
    #                             Weight = Weight1.split("pound")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "pounds" in Weight1:
    #                             Weight_unit_of_measurement = "Pounds"
    #                             Weight = Weight1.split("pounds")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "gram" in Weight1:
    #                             Weight_unit_of_measurement = "Grams"
    #                             Weight = Weight1.split("gram")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "grams" in Weight1:
    #                             Weight_unit_of_measurement = "Grams"
    #                             Weight = Weight1.split("grams")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif " ct" in Weight1:
    #                             Weight_unit_of_measurement = "Ct"
    #                             Weight = Weight1.split("ct")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         elif "gm" in Weight1:
    #                             Weight_unit_of_measurement = "Grams"
    #                             Weight = Weight1.split("gm")[0]
    #                             if "," in Weight:
    #                                 Weight = Weight.split(",")[-1].strip()
    #                                 if "-" in Weight:
    #                                     Weight = Weight.split("-")[-1].strip()
    #                                     Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                                 else:
    #                                     Weight = Weight
    #                             elif "-" in Weight:
    #                                 Weight = Weight.split("-")[-1]
    #                             elif "." in Weight:
    #                                 Weight = re.findall(r'[0-9]\.[0-9]',Weight)[0]
    #                             elif "x" in Weight:
    #                                 Weight = Weight.split("x")[-1].strip()
    #                             elif "(" in Weight:
    #                                 Weight = Weight.split("(")[-1].strip()
    #                             elif " " in Weight:
    #                                 Weight = re.findall(r'\d+',Weight)[0]
    #                             else:
    #                                 Weight = Weight
    #                         else:
    #                             Weight_unit_of_measurement = ''
    #                             Weight = ''
    #                     except Exception:
    #                         Weight_unit_of_measurement = ''
    #                         Weight = ''
    #
    #                     try:
    #                         self.item = TranmazonItem()
    #                         self.item['Name'] = Name
    #                         self.item['Description'] = Description
    #                         self.item['Category'] = Category
    #                         self.item['MainImage'] = ProductImage
    #                         self.item['FeaturedImage'] = FeaturedImage
    #                         if Price != '':
    #                             Price = '$' + Price
    #                         else:
    #                             Price = Price
    #                         self.item['Price'] = Price
    #                         self.item['Size'] = Weight
    #                         self.item['ProductImage'] = ProductImage
    #                         self.item['URL'] = Product_Link
    #                         self.item['final_path'] = final_path.replace('\\', '\\\\')
    #                         self.item['table'] = 'walmart_data_2020_12_14'
    #                         yield self.item
    #                     except Exception as e:
    #                         print(e)
    #             else:
    #                 self.head = {
    #                     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    #                     'cookie': 'vtc=ac4SkNq3rWtUZ5G7OizIR0; TBV=7; _pxvid=9a393384-41e4-11eb-b382-0242ac120019; cart-item-count=0; _gcl_au=1.1.332585788.1608373569; cid_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; _fbp=fb.1.1608373570153.1934083565; tb_sw_supported=true; __gads=ID=c5e47ced4e9b215e:T=1608373566:S=ALNI_Mafeft89rkavIzudSYWZOQFHHWMKg; TS013ed49a=01538efd7c942cd76d14a609e5158e1f36656a618f75750ab82a048a4760ec6b65662e58a65211a06e63af768138af98eaf1c75285; athrvi=RVI~h3831f771-h21a45114-h3abbacf5-h31871936-h153d5c5d-h2b489c5; cw_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; s_sess_2=ps%3D1; bstc=fVMbBPT0xiTdjibtYBcK64; mobileweb=0; xpa=; xpm=3%2B1608542579%2Bac4SkNq3rWtUZ5G7OizIR0~%2B0; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608543454108@firstcreate:1608373564012"; TS01b0be75=01538efd7c6521aafd8a065a36663000a6a37f97bbbd0863fee6799d800a84a2918a58bae9d7c8801b4ac49ea6443f408847d8ff41; _uetsid=a7ad2580434711eb9b017b4e60b19c2d; _uetvid=9c93218041e411eb9fab9dc80034c19e; _px3=54acf9b1493a956d9cb3ab7ca92d584bd65c24bfc52f2a2d606a3af5e6e65ba3:MxACGZYKs/DkNYaod+6dh4nSyV/AeWi2MGLe9x7WWpNXPZVtNcGe0u8xsWeKhPwfjRO4Y3Fo1XTLyd+iYd0Upg==:1000:ciEi4Oc6tMZE099o4IRcaXiFuDKlYwpBeMBweOQkM71w0D3oHj6wqfJ07xrdgjTIIVKWsVIZ6Orq/WCH05Qlco0TEwlRC1je08PNfG53l9L6Mqpjpm0pYYRLlftJ256SmIH5BaAi23JBTsH3+7SMibw3o14vYP54NvPYYMSrw2s=; akavpau_p8=1608544058~id=6ded017e934eb8aa17ee16413e048e3d; _pxde=c678fbb1e2ce300345d698065f50e2a2587da9b400dbb9b888a93067045eed90:eyJ0aW1lc3RhbXAiOjE2MDg1NDM0ODMwNjQsImZfa2IiOjAsImlwY19pZCI6W119; next-day=1608588000|true|false|1608638400|1608543491; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1608543491776|30309',
    #                     'upgrade-insecure-requests': '1',
    #                     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
    #                 }
    #                 while True:
    #                     res1 = requests.get(url=str(Product_Link), headers=self.head, proxies=self.get_proxy(), verify=False)
    #                     response1 = HtmlResponse(url=res1.url, body=res1.content)
    #                     try:
    #                         # Catgeory = response.meta['Catgeory']
    #                         # Product_Link = response.meta['source_url']
    #                         # Id = response.meta['Id']
    #                         if '<title>Verify your identity</title>' in response1.text:
    #                             continue
    #                             # yield scrapy.Request(url=Product_Link, callback=self.get_data, dont_filter=True, headers=self.head,
    #                             #                      meta={'Catgeory': Category, 'source_url': Product_Link, 'Id': Id})
    #                         else:
    #                             final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
    #                             self.set.page_save(final_path, response1.text)
    #                             print(f"page save done ----- {Product_Link}")
    #
    #                             try:
    #                                 self.set.cursor.execute(f'update {dbc.database}.walmart_link_2020_12_14 set status="Done" where Product_Link="{Product_Link}"')
    #                                 self.set.con.commit()
    #                                 print("update done")
    #                             except Exception as e:
    #                                 print(e)
    #                             break
    #                     except Exception as e:
    #                         print(e)
    #                 # yield scrapy.Request(url=str(Product_Link), callback=self.get_data, headers=self.head, dont_filter=True, meta={'Catgeory':Category,'source_url':Product_Link,'Id':Id})
    #         except Exception as e:
    #             print(e)
    #
    # def get_data(self, response):
    #     try:
    #         Catgeory = response.meta['Catgeory']
    #         Product_Link = response.meta['source_url']
    #         Id = response.meta['Id']
    #         if '<title>Verify your identity</title>' in response.text:
    #             yield scrapy.Request(url=Product_Link, callback=self.get_data, dont_filter=True, headers=self.head,
    #                                  meta={'Catgeory': Catgeory, 'source_url': Product_Link,'Id':Id})
    #         else:
    #             final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
    #             self.set.page_save(final_path, response.text)
    #             print(f"page save done ----- {Product_Link}")
    #
    #             try:
    #                 self.set.cursor.execute(f'update {dbc.database}.walmart_link_2020_12_14 set status="Done" where Product_Link="{Product_Link}"')
    #                 self.set.con.commit()
    #                 print("update done")
    #             except Exception as e:
    #                 print(e)
    #     except Exception as e:
    #         print(e)
    #
    # def get_proxy(self):
    #     proxy = [
    #         "lum-customer-xbyte-zone-zone_us:0gi0pioy3oey",
    #         "lum-customer-xbyte-zone-zone_uk:bqa3iap0g4nr",
    #         "lum-customer-xbyte-zone-zone_spain:k4vt6e2v53v9",
    #         "lum-customer-xbyte-zone-zone_italy:et2g17oqw1nm",
    #         "lum-customer-xbyte-zone-zone_australia:rjbsuy1tzgco",
    #         "lum-customer-xbyte-zone-zone_japan:5v9sl7ilbppn",
    #         "lum-customer-xbyte-zone-zone_taiwan:b2kqeq76cxi6",
    #         "lum-customer-xbyte-zone-zone_netherland:zvptczvd2ahq",
    #         "lum-customer-xbyte-zone-zone_russia:plpsy85v8pu6",
    #         "lum-customer-xbyte-zone-zone_india:w6zj0g4ikjy3",
    #         "lum-customer-xbyte-zone-zone_israel:gtuythxi5oc3"
    #     ]
    #     proxy_auth = str(choice(proxy))
    #     proxy_host = "zproxy.lum-superproxy.io"
    #     proxy_port = "22225"
    #     return {"https": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)}

execute("scrapy crawl walmart_data -a site_name=walmart".split())
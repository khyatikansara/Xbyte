import json
import os
import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class KrogerLinkSpider(scrapy.Spider):
    name = 'kroger_link'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self,response):
        self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
        table = f"{self.site_name}_{self.set.get_name('this_week_category',self.site_name)}"
        self.set.cursor.execute(f'Select * from {dbc.database}.{table} where Id>{self.start} and Id<{self.end} and status="pending"')
        self.set.con.commit()
        product_results = self.set.cursor.fetchall()
        for row_p in product_results:
            try:
                Id = row_p[0]
                Category_Link = row_p[2]
                Category_Name = row_p[3]
                Category_path = row_p[5]
                file = self.set.page_read(Category_path)
                response_c = html.fromstring(file)
                selectors = response_c.xpath('//*[@class="AutoGrid-cell min-w-0"]/div')
                for selector in selectors:
                    product = selector.xpath('.//h3/../@href')[0]
                    product_link = f"https://www.kroger.com{product}"
                    self.item = TranmazonItem()
                    self.item['Category'] = Category_Name
                    self.item['Category_Link'] = Category_Link
                    self.item['product_link'] = product_link
                    # self.item['path1'] = main_path.replace('\\','\\\\')
                    self.item['table'] = f"{self.site_name}_{self.set.get_name('link_table',self.site_name)}"
                    yield self.item
            except Exception as e:
                print(e)
            try:
                self.set.cursor.execute(f'update {dbc.database}.{table} set status="Done" where Category_Link="{Category_Link}"')
                self.set.con.commit()
                print("update done")
            except Exception as e:
                print(e)

# execute("scrapy crawl kroger_link -a site_name=kroger -a start=0 -a end=125".split())
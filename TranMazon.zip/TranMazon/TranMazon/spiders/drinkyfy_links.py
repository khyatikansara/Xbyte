import json
import os
import re

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class DrinkyfyLinkSpider(scrapy.Spider):
    name = 'drinkyfy_link'
    allowed_domains = []
    start_urls = ['https://drinkyfy.com/liquor/details?country=14']

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self,response):
        self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
        final_path = f"{self.this_week_html_path}Main\\country_14.html"
        # if not os.path.exists(final_path):
        self.set.page_save(final_path,response.text)
        print("page save Done")
        category_dict = {'BEER':'134','FOOD_AND_SNACKS':'136','LIQUEUR,_BRANDY_AND_COGNAC':'145','MIXERS_AND_SOFT_DRINKS':'135','RUM_AND_GIN':'145','TEQUILA_AND_MEZCAL':'145','VODKA':'145','WHISKEY_AND_SCOTCH':'145','WINE_AND_CHAMPAGNE':'134'}
        cats = response.xpath('//*[@class="restaurant-food-list"]')[1:]
        for cat in cats:
            try:
                Category = cat.xpath('./@id').extract_first()
                Category = category_dict[Category]
            except Exception as e:
                print(e)

            for inside in cat.xpath('.//*[@class="prodcont"]'):
                try:
                    Name = inside.xpath('./p/text()').extract_first()
                except Exception as e:
                    print(e)

                try:
                    ProductImage = inside.xpath('./../preceding-sibling::div[@class="food-img bg-img"]/div/@style').extract_first()
                    ProductImage = re.findall(r'url\((.*?)\);',ProductImage)[0]
                except Exception as e:
                    print(e)

                for catsel in inside.xpath('./../select[@class="catsel"]/option'):
                    try:
                        Size = catsel.xpath('./text()').extract_first()
                    except Exception as e:
                        print(e)

                    try:
                        Price = '$'+catsel.xpath('./@value').extract_first().split('-')[1]
                    except Exception as e:
                        print(e)

                    try:
                        self.item = TranmazonItem()
                        self.item['Site'] = self.site_name
                        self.item['Name'] = Name
                        self.item['Description'] = ''
                        self.item['Category'] = Category
                        self.item['MainImage'] = ProductImage
                        self.item['FeaturedImage'] = ''
                        self.item['Price'] = Price
                        self.item['Size'] = Size
                        self.item['ProductImage'] = ProductImage
                        self.item['URL'] = "https://drinkyfy.com/liquor/details?country=14"
                        self.item['final_path'] = final_path.replace('\\','\\\\')
                        self.item['table'] = 'drinkyfy_data_2020_11_30'
                        yield self.item
                    except Exception as e:
                        print(e)

# execute("scrapy crawl drinkyfy_link -a site_name=drinkyfy".split())
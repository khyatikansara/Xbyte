import json
import os
import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class KrogerCategorySpider(scrapy.Spider):
    name = 'kroger_category'
    allowed_domains = []
    start_urls = ['https://example.com']

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self,response):
        self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
        category_link = {
                            'Grocery':['https://www.kroger.com/search?fulfillment=all&page=1&query=Food&searchType=default_search','42'],
                            'Household':['https://www.kroger.com/search?fulfillment=all&page=1&query=Household%20&searchType=default_search','42'],
                            'health-wellness':['https://www.kroger.com/search?fulfillment=all&page=1&query=Health%20and%20Wellness&searchType=default_search','42']
                        }

        for cat_name,cat_link in category_link.items():
            try:
                page = 1
                total = cat_link[1]
                while page<int(total):
                    main_path = f"{self.this_week_html_path}Main\\{cat_name}_{page}.html"
                    url = cat_link[0].replace(f'page=1', f'page={page}')
                    if not os.path.exists(main_path):
                        while True:
                            headers = {
                                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                                'upgrade-insecure-requests': '1',
                                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                                'Cookie': 'pid=7b598bba-3867-4ffb-a519-c768fdb321fb; abTest=tl_dyn-pos_A|mrrobot_12b59e_A; origin=lvdc; x-active-modality={"postalCode":"30309","type":"SHIP","lat":33.79414367675781,"lng":-84.38739776611328}; sid=2ec82bfc-5116-e6a7-c96a-66b6c9a279ca; dtCookie=37$3DA2E8C9482339FF4CE8F02774AD5F39; AKA_A2=A; ak_bmsc=F407FB8391C64DDBD821490415D180C87B3FFAAC99250000965AD85F94F3A41C~plA+p/VxvU1tDedHolHWnNbMcOn38n9+cIMHdD0uf/8v62wCuU4VBNqWXr8VOg4KlM7D1ZfSBLtLgXZCCnuk5lFlXqYVAFcoj4slXn/sFjKREYsNVc2l4VJdPdq/IoGS4ulroGs6fdSBokymv3615WGE5coPsgTERaTcjZEo2wLiqoX9u8R45OGtFFe3SSH4ReZtJB8KVTGVQ9oo3AC52r4ITmf2+gOxdIUXdwrbSokIs=; akaalb_KT_Digital_BannerSites=~op=KT_Digital_BannerSites_KCVG_HDC_FailoverCDC:hdc|~rv=88~m=hdc:0|~os=49d9e32c4b6129ccff2e66f9d0390271~id=771c03869b42415bd29706b8f79f5f71; bm_sz=3944C82E4A637E85C885CC7849450AD4~YAAQrPo/e/7rw1x2AQAAwtshZQq2WyZdHt+GkZydH/7x3obxdW9wTvEV/IJkQ3ef9FRre0NktVlfHbci09j7sDsBfPElwBhaU2DLRzoYKLQ4SbaHCWwSoVaqvD0Nlim5l4fxZJgVyuMzfRgH67+VsfdSsMYWSvdwmTQisxzFjPJ3vpwC9U32NgOHws4Nj4ss; bm_mi=47B4C5D39D239935B51366867F9A069A~Sf2AEeNLKzdjTLxlst/40DPD025je1j9IBDx6BmgRJNbOdeUCFjl9vma3Il+IWSyNSBz9E8Yp8Oqyh+wIb1E2ZtKweWG2w/SUCf8sSN0qmV5WlTXyJznPAyrGxBBSJbWdciPxiH6gnwJWWDgse0UCEnJl+Jvwp80kq1QKpjzKYqkDinr1MrpkMmCVtJVEh2qaEe5Pk2rjBUOHKnlKRHg5GYUeLq6xlafdEjQLC7GIAQ=; _abck=3E9C6DF21BE6577DC55B62A9EEC6DD6F~-1~YAAQrPo/ezv5w1x2AQAA25IrZQV+QF03sPXnqArppGGR+SaPvGtK6twSJkimn2jK3PtXy2LPYknq9X/U/9xnOqtqWFKPPu6aIE/Y86ppj7BebMM8shtnQ+G9+XNtdBcdF+pIkGcYEYx1204IR/xgAeb71q387ZWPFR09SxJnp9yo3qT8vCfJoR6GA4rXdaiBMlxjEwI7O0xLEKh0BWV9B2LaB2rIVgat+iitVOVEO7/t//wGfRnotke00tDbXIUl7N/P/Z8yuuy7aYfS0prW8tlobBy4U0GQwTz4z+1m1a7Uvt9Ug/NLAhpc2G//sUQC9hEJzUCbAXECIX17vtucniqh6lfnosy9bt/VhAqkmUONP3c=~0~-1~-1; __VCAP_ID__=909b16dc-d3fa-4dcc-77fa-e51d; bm_sv=1EBE1147EE518496CB3D241706007601~3juioWHWvG7CEJ8lsuZgayJgabOJPBpMWUaP8RA3w8zPPTTDz5OWvE9f/ECna9GwiDGqkgleI2G8WT4cciq/VY0Tv36Mrcb1EgYoYvMGiDPpBLADoLA4ncin9DX0OWaW1fasR5v5koGdmIWGgDd5z4knyMWJVftRmrUlvOtynEc='
                                }
                            res = requests.get(url=url, headers=headers)
                            if res.status_code == 200:
                                response = HtmlResponse(url=res.url, body=res.content)
                                if '{"postalCode":"30309"}' in response.text:
                                    self.set.page_save(main_path,response.text)
                                    print("category page save done")
                                    break
                    file = self.set.page_read(main_path)
                    response = html.fromstring(file)
                    try:count = response.xpath('//*[@class="SearchGridHeader "]/h1/text()')[1]
                    except:count='0'
                    self.item = TranmazonItem()
                    self.item['Category_source_link'] = cat_link[0]
                    self.item['Category_Link'] = url
                    self.item['Category_Name'] = cat_name
                    self.item['count'] = count
                    self.item['Category_path'] = main_path.replace('\\', '\\\\')
                    self.item['table'] = f"{self.site_name}_{self.set.get_name('this_week_category',self.site_name)}"
                    yield self.item
                    page+=1
            except Exception as e:
                print(e)

# execute("scrapy crawl kroger_category -a site_name=kroger".split())
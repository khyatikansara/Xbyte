import re
import pymysql
import scrapy
# from items import WallmartItem
# from wallmart.items import WallmartItem
from scraper_api import ScraperAPIClient
from scrapy.cmdline import execute
import requests
from TranMazon.spiders.temp import Temp
from random import choice
from datetime import datetime
from TranMazon import db_config as dbc
from TranMazon.items import TranmazonItem
import json
# from TranMazon import db_config as dbc
# from TranMazon.spiders.temp import Temp

client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')

def get_proxy():

  proxy = [
    "lum-customer-xbyte-zone-zone_us:0gi0pioy3oey",
    "lum-customer-xbyte-zone-zone_uk:bqa3iap0g4nr",
    "lum-customer-xbyte-zone-zone_spain:k4vt6e2v53v9",
    "lum-customer-xbyte-zone-zone_italy:et2g17oqw1nm",
    "lum-customer-xbyte-zone-zone_australia:rjbsuy1tzgco",
    "lum-customer-xbyte-zone-zone_japan:5v9sl7ilbppn",
    "lum-customer-xbyte-zone-zone_taiwan:b2kqeq76cxi6",
    "lum-customer-xbyte-zone-zone_netherland:zvptczvd2ahq",
    "lum-customer-xbyte-zone-zone_russia:plpsy85v8pu6",
    "lum-customer-xbyte-zone-zone_india:w6zj0g4ikjy3",
    "lum-customer-xbyte-zone-zone_israel:gtuythxi5oc3"
  ]
  proxy_auth = str(choice(proxy))
  proxy_host = "zproxy.lum-superproxy.io"
  proxy_port = "22225"
  return {"https": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)}

class WallSpider(scrapy.Spider):

    name = 'wall1'
    start_urls = ['https://www.amazon.in/']

    def __init__(self, name=None, start="", end="",site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.start = start
        self.end = end
        # self.con = pymysql.connect("localhost", "root", "xbyte", "tranmazon")
        # self.crsr = self.con.cursor()
        # self.crsr.execute(f"SELECT * FROM walmart_link_2020_12_14 where status='pending' limit {start},{end}")
        # self.allresult = self.crsr.fetchall()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self,response):
        self.this_week_html_path = self.set.get_name("this_week_html_path", self.site_name).replace("\\D\\", "\\d\\")
        # item = WallmartItem()
        self.set.cursor.execute(f'Select * from {dbc.database}.walmart_link_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and status="pending"')
        self.set.con.commit()
        product_results = self.set.cursor.fetchall()
        for row in product_results:
            Id = row[0]
            final_path = f"{self.this_week_html_path}Data\\walmart_{Id}.html"
            Product_Link = row[-3]
            Category = row[-2]
            product_id = row[-3].split('/')[-1]
            row=['',"","",'',product_id]

            url = "https://www.walmart.com/terra-firma/graphql?v=2&options=timing%2Cnonnull%2Cerrors%2Ccontext&id=FullProductRoute-android"
            payload =  '{\"variables\":\"{\\\"casperSlots\\\":{\\\"fulfillmentType\\\":\\\"ACC\\\",\\\"reservationType\\\":\\\"SLOTS\\\"},\\\"postalAddress\\\":{\\\"addressType\\\":\\\"RESIDENTIAL\\\",\\\"countryCode\\\":\\\"USA\\\",\\\"postalCode\\\":\\\"55129\\\",\\\"stateOrProvinceCode\\\":\\\"MN\\\",\\\"zipLocated\\\":true},\\\"storeFrontIds\\\":[{\\\"distance\\\":3.35,\\\"inStore\\\":false,\\\"preferred\\\":true,\\\"storeId\\\":\\\"2643\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2643},{\\\"distance\\\":2.84,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"90133\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":90133},{\\\"distance\\\":6.24,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"2448\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":2448},{\\\"distance\\\":8.91,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"1365\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":1365},{\\\"distance\\\":9.29,\\\"inStore\\\":false,\\\"preferred\\\":false,\\\"storeId\\\":\\\"3364\\\",\\\"storeUUID\\\":null,\\\"usStoreId\\\":3364}],\\\"productId\\\":\\\"'+f'{product_id}'+'\\\",\\\"selected\\\":false}\"}'

            headers = {
                'WM_CONSUMER.ID': '8821a0c4-d3c0-11e7-9296-cec278b6b50a',
                'WM_SITE_MODE': '0',
                'itemId': f'{product_id}',
                'User-Agent': 'Android v20.41.3',
                'did': '12c8586a-0335-4ba5-85f0-81f3783ea133',
                'X-PX-AUTHORIZATION': '3',
                'X-PX-ORIGINAL-TOKEN': '3:37af5453421b87a8e434012e5a0d9965b89'
                                       'cfb0c28ef27072d7a2667ab93bd73:fZ1fIELALz+fXL6ns/6X+BTdJgJ8H641NZzXTAHwiC7aabl89piboXB0d6nhXy2bYvmsXVsOr/NUe/+i1CmcRQ==:1000:eZjnSImre2LoozJi/z0+CHU00C4v64Y5+soJiBpukw3ELxiGibSexbgVASmJd2ZClN5LCOKRX5jzBzRxG1ft0//N1/xHzIAfeTqZvGOXoAP45sDgbsz2WX8Yv6hslyUHldWLsqexV/cyJcC4W9TtrEJ0hRdH4cDFEtWp0yBNLac=',
                'Content-Type': 'application/json; charset=utf-8',
                'Content-Length': '907',
                'Cookie': 'WLM=1; hasACID=1; auth=MTAyOTYyMDE46OBEKZlDorF9XxhLfEcfCoFc9mWKD5zQW6XXScqwlnfLKcXjVFXbk6s9rCWJKfQ%2B%2Frk80vjTO7JstR79cnG32CdLuXpMJKYNLPb0mMniaMbUVW7CN5Slek5Z9TkzAhV1767wuZloTfhm7Wk2Kcjygp0i2CSRVbB3L7ys%2FtvUzQczv52bQ%2B4EkUZQhsMwQyjhg7KyGViTQjlqHkJLnHf%2FFUZTSxsKj1vnEodX4zkzEwBGyEMqGry%2B0lIRqFvmUM8k0S4ks2VlT7qwuWkKDx%2Bp%2BNDfOOAXU7Wbeglv9fAI1Hy5knd9GnrZjvaltpA1aHG4LNZuHxJXXbXek3ABOr0bLyVmFyUaR4c8EmE55nNX7BjSDqSsqzx%2Fz8FYPIj7peFD7Cu255NsR5qastUa0xdgRw%3D%3D; ACID=bc9a9ec3-16d6-45d0-89f2-702822034749; type=GUEST; speed=slow; spp=0.9562; vtc=ThthT6Fm77HjUIEsLgurG4; bstc=ThthT6Fm77HjUIEsLgurG4; mobileweb=1; xpa=76AYR; xpm=0%2B1604061863%2BThthT6Fm77HjUIEsLgurG4~%2B0; exp-ck=76AYR1; TS01b0be75=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c; TS013ed49a=01538efd7c7ceff6ab4dca06300d1bd83b9d33b8f502bb97d15f143495f56037adf246073c737ef020ead4d4b1324ef5dd7df2d88c'
            }

            try:
                response = requests.request("POST", client.scrapyGet(url=url), headers=headers, data=payload, verify=False)
                self.set.page_save(final_path, response.text)
                print(f"page save done ----- {Product_Link}")
            except Exception as e:
                print(e)
            file = self.set.page_read(final_path)
            try:
                Name = re.findall(r'"productName":"(.*?)",',file)[0].strip()
            except Exception as e:
                print(e)
                Name = ''
            if Name != '':
                try:
                    Description = re.findall(r'"detailedDescription":"(.*?)",',file)[0].strip()
                    Description = re.sub('<[^<]+?>', '', str(Description))
                except Exception as e:
                    print(e)
                    Description = ''
                if Description == '':
                    Description = "We aim to show you accurate product information. Manufacturers, suppliers and others provide what you see here, and we have not verified it. See our disclaimer"

                try:
                    Image_List = re.findall(r'"imageList":\[(.*?)\]',file)[0]
                    Images = re.findall(r'"default":"(.*?)"',Image_List)
                    ProductImage = Images[0]
                    FeaturedImage = '|'.join(Images[1:])
                except Exception as e:
                    print(e)
                    ProductImage = FeaturedImage = ''

                try:
                    Price = ''
                except Exception as e:
                    print(e)
                    Price = ''


            try:
                self.item = TranmazonItem()
                self.item['Name'] = Name
                self.item['Description'] = Description
                self.item['Category'] = Category
                self.item['MainImage'] = ProductImage
                self.item['FeaturedImage'] = FeaturedImage
                if Price != '':
                    Price = '$' + Price
                else:
                    Price = Price
                self.item['Price'] = Price
                self.item['Size'] = Weight
                self.item['ProductImage'] = ProductImage
                self.item['URL'] = Product_Link
                self.item['final_path'] = final_path.replace('\\', '\\\\')
                self.item['table'] = 'walmart_data_2020_12_14'
                yield self.item
            except Exception as e:
                print(e)




# execute("scrapy crawl wall -a start=0 -a end=258108 -a site_name=walmart".split())
import json
import os
import re

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class WalmartCategorySpider(scrapy.Spider):
    name = 'walmart_category'
    allowed_domains = []
    # start_urls = ['https://example.com']

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def start_requests(self):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
            category_link = {
                                'Grocery':['https://www.walmart.com/browse/food/976759','174'],
                                'Household Good':['https://www.walmart.com/search/?query=household%20essentials&typeahead=Household','128'],
                                'health-wellness':['https://www.walmart.com/search/?query=health%20and%20wellness%20catalogue%20items&cat_id=976760&typeahead=Health%20and','129']
                            }
            self.head = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'upgrade-insecure-requests': ' 1',
                # 'user-agent': ' Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                'Cookie': 'vtc=Rks1wYh6WqQfrXxu6kMxaA; TBV=7; cart-item-count=0; _pxvid=23ddb618-3a40-11eb-acb3-0242ac120018; __gads=ID=46100f13aa4d110f:T=1607533275:S=ALNI_Maa0Oueo2pduvxJwT6IaqIxiRo73g; tb_sw_supported=true; _gcl_au=1.1.140647066.1607533281; _fbp=fb.1.1607533289475.226425468; GCRT=393daaff-1d73-4741-914f-98c614302973; hasGCRT=1; ACID=3d7ea160-3ab6-11eb-bbca-3d65dee28722; hasACID=1; s_vi=[CS]v1|2FE8E47E0515FAD1-400006A9450496CC[CE]; s_pers_2=+s_fid%3D1A27E7CC7F89011C-2CEEB5975D905E61%7C1670656254637%3B+s_v%3DY%7C1607586054641%3B+s_cmpstack%3D%255B%255B%2527wmt%2527%252C%25271607584254666%2527%255D%255D%7C1765350654666%3B+gpv_p11%3DLocationOverlay%2520%257C%2520use%2520pickup%7C1607586054669%3B+gpv_p44%3Dno%2520value%7C1607586054674%3B+s_vs%3D1%7C1607586054681%3BuseVTC%3DN%7C1670699455; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1607584312100|30309; cid_csid=8adc91cd-44a4-44c1-b3be-e44d60f85ce4; _ga=GA1.2.439359351.1608026552; mp_1c2a194c4a1f5485ee14e14b459058fd_mixpanel=%7B%22distinct_id%22%3A%20%2217665da096998a-07ce3188ba6e89-c791039-1fa400-17665da096aa29%22%2C%22%24device_id%22%3A%20%2217665da096998a-07ce3188ba6e89-c791039-1fa400-17665da096aa29%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; wm_mystore=Fe26.2**f89d80b802587b8aa4a6c1573a9bc12456473c6a1330fffe4d98dc76cac31baf*8CvmBTJn2iKvLHXlOgJRuA*UKhAfSphlZUhUAlUffJC02Vu8u487kTmVqT6otqrEiZivVthZvdjPjubyX3CG7KsNYjW5OLufDjSwcPH0KA2RDUMuaiV1vF9Gjp0-YfzdL-I7v-sxA15VdgayYdPdH9bGiOLdhD7LCiPdy87RvQxZg**bd28ea1181ff06ab64dd6f820cce7a872775c1cc44644a22e3fa06434f6e76f3*w7NzmhvBv5aAKiotC6vTAYcgvJFh1O7EFlXnXUfg4mw; x-csrf-jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0eXBlIjoiY29va2llIiwidXVpZCI6ImM4ZjQxZTEwLTNmNzQtMTFlYi1hYjljLWZkYWFhYjg1ZGM3NiIsImlhdCI6MTYwODEwNTYzOCwiZXhwIjoxNjA5MTg1NjM4fQ.vlIPAooPTRzpNXkEqMUxihMTjiHUl3tGtxcQxIKNH8w; s_pers=%20s_cmpstack%3D%255B%255B%2527wmt%2527%252C%25271607584254666%2527%255D%255D%7C1765350654666%3B%20s_fid%3D1A27E7CC7F89011C-2CEEB5975D905E61%7C1671177639544%3B%20s_v%3DY%7C1608107439552%3B%20gpv_p11%3DProduct%2520page%7C1608107439587%3B%20gpv_p44%3Dno%2520value%7C1608107439596%3B%20s_vs%3D1%7C1608107439606%3B; s_sess=%20ent%3DoundSuperSliders-16782120%3B%20s_cc%3Dtrue%3B%20chan%3Dorg%3B%20v59%3D%3B%20v54%3DProduct%2520page%3B%20cps%3D0%3B%20s_sq%3D%3B; TS01bae75b=01538efd7c00de6cd8fc88168cca273f460e79de3800b6b8fbc46d36069f8dbbee1903ab0f2916983806902dbb84729e5a86db9d78; TS01af768b=01538efd7c00de6cd8fc88168cca273f460e79de3800b6b8fbc46d36069f8dbbee1903ab0f2916983806902dbb84729e5a86db9d78; TS012c809b=01538efd7c00de6cd8fc88168cca273f460e79de3800b6b8fbc46d36069f8dbbee1903ab0f2916983806902dbb84729e5a86db9d78; akavpau_p14=1608106249~id=54ce777d4be779cea541c976a2aa173f; athrvi=RVI~h9d56f2-h2d2e4ba-h2641c15a-h2c43959-h23348bb-h1027c39-he2e4ac-h97aa116-ha79c9e-h75c232b; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; bstc=V8LZ2fh49TFOiC2cjhR5zU; mobileweb=0; xpa=; xpm=3%2B1608268059%2BRks1wYh6WqQfrXxu6kMxaA~%2B0; s_sess_2=ps%3D1; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608269636451@firstcreate:1607940381537"; _uetsid=450126903dc811ebb65cb39f9fdf4fb7; _uetvid=2d7912d03a4011ebb66e5b6856fe183d; TS013ed49a=01538efd7cdea9faec52b27ac80d2503794afe19e20f1c87a2a9a8aac4228d5fbefc751b1e95f13fa3629657078214bcdb876e9361; TS01b0be75=01538efd7c99349989304ed432f6ecd9dab4283c8eab4885e4b6281158491401e7e203e3a36b32716dd42bf9d7c5163c44b5bc4fa0; akavpau_p8=1608270785~id=209630d9ad67afa97d9226c997650560; _pxff_rf=1; _pxff_fp=1; _px3=dda1e5e2df2dccf5836ccf3a23e4bd9b0b12ca24e78a8a544bc3fd895564a1ca:f9uyFkc3bmGCwu/E4gpK20cmT90uXpsfLMi0Hj8ufuXdq9ddtVczB1IgrY+HxcYEyIwk8SYG1FmIZ27L7+SYIg==:1000:ACNNyFMkdvfYoPKwiMyuhsKOS0G+f7fsml1964B1PAsJpxTAEQmjhEuj7hifFalLxtk+NWRUSpQEKTOHvZODNaHt2Wg3Unxr6IGcb/YrC3JNy7tAD/NgwylF+jyrAoZgnfz3EiJ7hhRN3b5kgdpRbb19fjcPuPskTdjqpAJ+bnQ=; _pxde=ae88ef534ce7c257a03eb9ee2aa587b139cd88c94e4d82fbba1e505158df673a:eyJ0aW1lc3RhbXAiOjE2MDgyNzAxOTAwOTgsImZfa2IiOjAsImlwY19pZCI6W119'
                # 'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us','0gi0pioy3oey')
            }

            for cat_name,cat_link in category_link.items():
                yield scrapy.Request(url=cat_link[0], callback=self.parse, dont_filter=True, headers=self.head,
                                     meta={'next_url':cat_link[0],'Category_Name':cat_name,'Category_id':cat_link[1],'Category_Main_Link':cat_link[0]})#,"proxy": "zproxy.lum-superproxy.io:22225"})
        except Exception as e:
            print(e)

    def parse(self, response):
        if response.status != 200 or '<title>Verify your identity</title>' in response.text:
            yield scrapy.Request(url=response.meta['redirect_urls'][0], callback=self.parse, dont_filter=True, headers=self.head,
                                 meta={'Category_id':response.meta['Category_id'],
                                        'Category_Name':response.meta['Category_Name'],'Category_Main_Link':response.meta['Category_Main_Link']})
        else:
            if 'page=' in response.url:
                page = re.findall('page=(.*?)&',response.url)[0]
                final_path = f"{self.this_week_html_path}Link\\{response.meta['Category_Name']}_{page}.html"
            else:
                final_path = f"{self.this_week_html_path}Link\\{response.meta['Category_Name']}_1.html"
            if 'zipcode=30309' in response.text:
                if not os.path.exists(final_path):
                    self.set.page_save(final_path, response.text)
                    print('page save done')
                file = self.set.page_read(final_path)
                response1 = html.fromstring(file)
                try:
                    count = ''.join(response1.xpath('//*[@class="result-summary-container"]//text()'))
                except Exception as e:
                    print(e)
                    count = ''

                try:
                    self.item = TranmazonItem()
                    self.item['Category_Main_Link'] = response.meta['Category_Main_Link']
                    self.item['Category_Link'] = response.url
                    self.item['Category_page'] = final_path.replace('\\','\\\\')
                    self.item['count'] = count
                    self.item['Category_Name'] = response.meta['Category_Name']
                    self.item['Category_id'] = response.meta['Category_id']
                    self.item['table'] = "walmart_category_2020_12_14"
                    yield self.item
                except Exception as e:
                    print(e)

                final_next_page = re.findall(r'"next":\{"url":"(.*?)"},"pages":', response.text)
                while True:
                    if final_next_page != []:
                        next_url = f"https://www.walmart.com/search//?{final_next_page[0]}"
                        if 'page=' in next_url:
                            page = re.findall('page=(.*?)&', next_url)[0]
                            final_path = f"{self.this_week_html_path}Link\\{response.meta['Category_Name']}_{page}.html"
                        else:
                            final_path = f"{self.this_week_html_path}Link\\{response.meta['Category_Name']}_1.html"
                        if not os.path.exists(final_path):
                            yield scrapy.Request(url=next_url, callback=self.parse, dont_filter=True, headers=self.head,meta={'next_url':next_url,'Category_id':response.meta['Category_id'],
                                                'Category_Name':response.meta['Category_Name'],'Category_Main_Link':response.meta['Category_Main_Link']})#,"proxy": "zproxy.lum-superproxy.io:22225"})
                            break
                        else:
                            file = self.set.page_read(final_path)
                            final_next_page = re.findall(r'"next":\{"url":"(.*?)"},"pages":', file)
                    else:
                        break

# execute("scrapy crawl walmart_category -a site_name=walmart".split())
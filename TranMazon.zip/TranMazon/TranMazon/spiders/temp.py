from datetime import datetime
import os, dateparser, re
from decimal import *
import pandas as pd
import platform
import pymysql
from sqlalchemy import create_engine
from TranMazon import db_config as dbc


class Temp:
    try:
        try:
            db_con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd)
            db_cursor = db_con.cursor()
            db_cursor.execute(f'CREATE DATABASE IF NOT EXISTS {dbc.database} CHARACTER SET UTF8MB4 COLLATE utf8mb4_general_ci')
        except Exception as e:print(e)
        con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd, dbc.database)
        cursor = con.cursor()
        engine = create_engine(f'mysql+pymysql://{str(dbc.usernm)}:{str(dbc.passwd)}@{str(dbc.host)}/{str(dbc.database)}')
        temp_list = run_date = ''
        this_week_table = this_week_csv = this_week_csv_path = this_week_html_path = last_week_table = last_week_csv = last_week_csv_path = last_week_html_path =''
    except Exception as e:
        print(e)

    def page_save(self, path, response):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(response)
            f.close()

    def page_read(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            file_open = file.read()
            file.close()
            return file_open

    def basic(self,run_date,ipaddress,site_name):

        try:
            create_table_5 = "CREATE TABLE IF NOT EXISTS " + dbc.table5 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                date varchar(40),
                                                                                site_name varchar(255) DEFAULT NULL,
                                                                                this_week_finallink longtext DEFAULT NULL,
                                                                                this_week_category longtext DEFAULT NULL,
                                                                                this_week_table longtext DEFAULT NULL,
                                                                                this_week_csv longtext DEFAULT NULL,
                                                                                this_week_csv_path longtext DEFAULT NULL,
                                                                                this_week_html_path longtext DEFAULT NULL,
                                                                                last_week_table longtext DEFAULT NULL,
                                                                                last_week_csv longtext DEFAULT NULL,
                                                                                last_week_csv_path longtext DEFAULT NULL,
                                                                                last_week_html_path longtext DEFAULT NULL,
                                                                                link_table longtext DEFAULT NULL,
                                                                                UNIQUE KEY (`date`,`site_name`),
                                                                                   PRIMARY KEY (`Id`))"""
            self.cursor.execute(create_table_5)
        except Exception as e:
            print(e)

        try:
            tempq = f'select * from {dbc.database}.{dbc.table5} where site_name="{site_name}" order by Id DESC LIMIT 1'
            gh = pd.read_sql(tempq, con=self.engine)
            if gh.empty==False:
                run_date_prev = dateparser.parse(gh['date'][0])

                run_date_format = dateparser.parse(run_date)
                if (run_date_format - run_date_prev).days > 30:
                    run_date = run_date
                else:
                    run_date = gh['date'][0]
            else:
                run_date=run_date
        except Exception as e:
            print(e)
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            tmp = str(current_dir).split('TranMazon\\TranMazon\\spiders')[0]
            Current_Directory = f"\\\\{ipaddress}\\{tmp}".replace(':','')
            # check permissions
            if os.access(Current_Directory, os.X_OK | os.W_OK) !=True:
                print("# --------------------------------------------------------------------------------------------------------- #")
                print(f"Allow permissions to write in folder ... {Current_Directory}")
                print("# --------------------------------------------------------------------------------------------------------- #")

            CSV = Current_Directory + f'HTML\\Html_{run_date}\\{site_name}\\CSV\\'
            HTML_Path_Data = Current_Directory + f'HTML\\Html_{run_date}\\{site_name}\\Data\\'
            HTML_Path_Link = Current_Directory + f'HTML\\Html_{run_date}\\{site_name}\\Link\\'
            HTML_Path_Main = Current_Directory + f'HTML\\Html_{run_date}\\{site_name}\\Main\\'

            self.cursor.execute(f'SELECT * from {dbc.database}.{dbc.table5} where date="{str(run_date)}" and site_name="{site_name}"')
            date_details = self.cursor.fetchall()
            if date_details==():
                if not os.path.exists(CSV):
                    os.makedirs(CSV)
                if not os.path.exists(HTML_Path_Data):
                    os.makedirs(HTML_Path_Data)
                if not os.path.exists(HTML_Path_Link):
                    os.makedirs(HTML_Path_Link)
                if not os.path.exists(HTML_Path_Main):
                    os.makedirs(HTML_Path_Main)
                try:
                    this_week_finallink = f'finallink_{str(run_date)}'
                    this_week_category = f'category_{str(run_date)}'
                    this_week_table = f'data_{str(run_date)}'
                    this_week_csv = f"{site_name}_{datetime.strftime(datetime.today(),'%d-%m-%y')}.xlsx"
                    this_week_csv_path = f"{CSV}{this_week_csv}"
                    this_week_html_path = Current_Directory + f'HTML\\Html_{run_date}\\{site_name}\\'
                    try:
                        last_week_sql = f'select site_name,this_week_finallink,this_week_category,this_week_table,this_week_csv,this_week_csv_path,this_week_html_path from {dbc.database}.{dbc.table5} where site_name="{site_name}" order by Id DESC LIMIT 1'
                        gh = pd.read_sql(last_week_sql,con=Temp.engine)
                        last_week_table = gh['this_week_table'][0]
                        last_week_csv = gh['this_week_csv'][0]
                        last_week_csv_path = gh['this_week_csv_path'][0]
                        last_week_html_path = gh['this_week_html_path'][0]
                    except Exception as e:
                        last_week_table = last_week_csv = last_week_csv_path = last_week_html_path = ''
                        print("no last week table available")
                    temp_list = [[str(run_date),site_name,this_week_finallink,this_week_category,this_week_table,this_week_csv,this_week_csv_path,this_week_html_path,last_week_table, last_week_csv, last_week_csv_path, last_week_html_path,f'link_{run_date}']]
                    df = pd.DataFrame(temp_list,columns=['date','site_name','this_week_finallink','this_week_category','this_week_table','this_week_csv','this_week_csv_path','this_week_html_path','last_week_table','last_week_csv','last_week_csv_path','last_week_html_path','link_table'])
                    df.to_sql('history', con=Temp.engine, if_exists='append', index=False)
                except Exception as e:
                    print(e)

        except Exception as e:
            print(e)

    def get_name(self,field_name,site_name):
        try:
            sql = f"select * from {dbc.database}.{dbc.table5} where site_name='{site_name}' order by Id DESC LIMIT 1"
            df = pd.read_sql(sql,con=self.engine)
            return df[field_name][0]
        except Exception as e:
            print(e)

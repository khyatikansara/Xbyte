import json
import os
import re

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class WalmartMetaPagesaveSpider(scrapy.Spider):
    name = 'walmart_meta_page_save'
    allowed_domains = []
    # start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def start_requests(self):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
            self.set.cursor.execute(f'Select * from {dbc.database}.walmart_category_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and link_status="pending"')
            self.set.con.commit()
            product_results = self.set.cursor.fetchall()
            self.head = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'cookie': 'vtc=ac4SkNq3rWtUZ5G7OizIR0; TBV=7; _pxvid=9a393384-41e4-11eb-b382-0242ac120019; cart-item-count=0; _gcl_au=1.1.332585788.1608373569; cid_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; _fbp=fb.1.1608373570153.1934083565; tb_sw_supported=true; __gads=ID=c5e47ced4e9b215e:T=1608373566:S=ALNI_Mafeft89rkavIzudSYWZOQFHHWMKg; cw_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1608543491776|30309; s_vi=[CS]v1|2FF03D878515C7D2-6000099934C1E6C2[CE]; s_pers_2=+s_v%3DY%7C1608548912037%3B+gpv_p11%3DCards%2520%2526%2520Invitations%253A%2520Christmas%2520%2526%2520Holiday%2520Cards%7C1608548912052%3B+gpv_p44%3DWalmart%2520Photo%253A%2520LiveLink%7C1608548912055%3B+s_vs%3D1%7C1608548912060%3BuseVTC%3DN%7C1671662463; s_sess=%20ent%3Dns%253AChristmas%2526HolidayCards%3B%20cp%3DY%3B%20s_cc%3Dtrue%3B%20chan%3Dorg%3B%20v59%3DWalmart%2520Photo%253A%2520LiveLink%3B%20v54%3DCards%2520%2526%2520Invitations%253A%2520Christmas%2520%2526%2520Holiday%2520Cards%3B%20cps%3D0%3B%20s_sq%3D%3B; _pk_id.3.32c3=91caa309077afb0b.1608708311.; _rdt_uuid=1608708314342.34485f9f-8af7-4f83-b3f5-60b24cc2ee85; radar-publishableKey=prj_live_pk_0067e32a02d402dc523f976947ae1e016de23857; _scid=6fb81990-6c3d-46c3-b972-56cd91ecdac7; __adroll_fpc=d3e889f3487619d6b21805f54d273fcb-1608708315903; __qca=P0-195998108-1608708315886; _sctr=1|1608661800000; crl8.fpcuid=eb9add84-9617-44bc-ac49-43fc1c7a5b81; _pk_id.24.32c3=b6353ace0358003a.1608708526.; __utmc=1; __utmz=1.1608708528.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); ajs_anonymous_id=%22449bd163-d1e0-43e9-ab3f-77c9302d9054%22; _pk_id.1.32c3=ddca2825c225cc14.1608708529.; __ar_v4=MUTCFQ3O7ND2DHFLLBUYOC%3A20210022%3A3%7CZLFNJ455ZRHE7MN4INTB2Y%3A20210022%3A3%7CEX5IBFJPEBDTJIFC6YANFD%3A20210022%3A1; _ga_G6WEM4YCRE=GS1.1.1608708312.1.1.1608708625.60; _ga=GA1.1.1809308902.1608708312; __utma=1.1809308902.1608708312.1608708528.1608708604.2; cbp=48088535-1608801946884|54320956-1608802030046; athrvi=RVI~h9d1388-h33cdf3c-h2ddc5d7-h21293d8-h8fe650a-h31a1da35-h142a08d6-h25afd93-h2d1c17f-h9d13a8; TS013ed49a=01538efd7c2045689fba15efbfc17de255e3177d57e8fcd2f583278668f3c4d86e0e2ed40743af3a3f15d56fbd661906298462ff46; next-day=1609020000|true|false|1609070400|1608809461; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; bstc=f6xWc7O-L4tndOEYlFboPs; mobileweb=0; xpa=; xpm=3%2B1608809461%2Bac4SkNq3rWtUZ5G7OizIR0~%2B0; TS01b0be75=01538efd7c5ad76874aedd35f6f6c6e1bf9df2c22fa2ee2211f32e7e2d2364c8b68b6f0966cb4eb6288e28beee962514abf8b006ae; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608809727253@firstcreate:1608708595052"; s_sess_2=ps%3D1; _uetsid=acac7d1045c711eb8007f7049690c036; _uetvid=9c93218041e411eb9fab9dc80034c19e; akavpau_p8=1608810333~id=0e6fc33d65c0667f2beaae5cb4e102ad; _px3=6bb7960714702aed98dd762ce2d7718dce77a989c280e177b5c49549d5ecceac:Xey46PRNst0ql78dryOIE9Wx5QrHlmVQyeLJydDdoNPCJ6i22GysVMxMpk/mwB5Rypq+u2Ht8ht/swqulZuTSA==:1000:xIxicCNAkSNqMHL9ruSqWP6US6Cs+2fG+lLd8SgvtyQepXhkf9KQ71ULCoYSQ75q9BWYAicAr2+H/vXG3IhMiQ+jNYEVZxZdg+FLIxL5jqEEIJ5kf5FPU8K7sYtJKFkp/18c3CYk22HUoiK8gZn9hv42lqmTNKZ0TSHokmag3i0=; _pxde=9dab2b1d9155a46a31daacde0128be90576ec6d2c9be0941e1f895ab5d59f3b2:eyJ0aW1lc3RhbXAiOjE2MDg4MDk3Mzc3NjYsImZfa2IiOjAsImlwY19pZCI6W119; DL=30309%2C%2C%2Cip%2C30309%2C%2C; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608809839450@firstcreate:1607574377246"; vtc=ac4SkNq3rWtUZ5G7OizIR0; bstc=f6xWc7O-L4tndOEYlFboPs; mobileweb=0; xpa=; xpm=7%2B1608809461%2Bac4SkNq3rWtUZ5G7OizIR0~%2B0; TS01b0be75=01538efd7c592114cd9e1cfdb0c36918ae4460951d59414ea394843e428df4822657e296206fd4e90aa357ebbb9e177cbfe6739d38; TS013ed49a=01538efd7c2045689fba15efbfc17de255e3177d57e8fcd2f583278668f3c4d86e0e2ed40743af3a3f15d56fbd661906298462ff46; akavpau_p8=1608810440~id=a59006f8933d503c515b3d1d5326155f',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
                }
            for row_p in product_results:
                Id = row_p[0]
                Category_Link = row_p[2]
                final_path = f"{self.this_week_html_path}Link\\{Id}.html"
                yield scrapy.Request(url=Category_Link, callback=self.parse, dont_filter=True, headers=self.head, meta={'final_path':final_path,'Category_Link':Category_Link})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            final_path = response.meta['final_path']
            Category_Link = response.meta['Category_Link']
            if response.status != 200 or '<title>Verify your identity</title>' in response.text:
                yield scrapy.Request(url=Category_Link, callback=self.parse, dont_filter=True, headers=self.head, meta={'final_path':final_path,'Category_Link':Category_Link})
            else:
                if 'zipcode=30309' in response.text:
                    if not os.path.exists(final_path):
                        self.set.page_save(final_path, response.text)
                        print('page save done')
                    file = self.set.page_read(final_path)
                    response1 = html.fromstring(file)
                    try:
                        count = ''.join(response1.xpath('//*[@class="result-summary-container"]//text()'))
                    except Exception as e:
                        print(e)
                        count = ''

                    try:
                        Category_page = final_path.replace('\\','\\\\')
                        self.set.cursor.execute(f'update {dbc.database}.walmart_category_2020_12_14 set link_status="Done",Category_page="{Category_page}",count="{count}" where Category_Link="{Category_Link}"')
                        self.set.con.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)

# execute("scrapy crawl walmart_meta_page_save -a site_name=walmart -a start=8880 -a end=26347".split())
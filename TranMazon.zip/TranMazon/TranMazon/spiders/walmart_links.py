import json
import os
import re
import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from TranMazon.items import TranmazonItem
from TranMazon import db_config as dbc
from TranMazon.pipelines import TranmazonPipeline as pipe
from TranMazon.spiders.temp import Temp
from datetime import datetime


class WalmartLinkSpider(scrapy.Spider):
    name = 'walmart_link'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, site_name='', **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.ipaddress = "192.168.1.252"
        self.site_name = site_name
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress, self.site_name)

    def parse(self, response):
        self.this_week_html_path = self.set.get_name("this_week_html_path",self.site_name)
        self.set.cursor.execute(f'Select * from {dbc.database}.walmart_category_2020_12_14 where Id>"{self.start}" and Id<"{self.end}" and link_status="Done"')
        self.set.con.commit()
        product_results = self.set.cursor.fetchall()
        self.head = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'cookie': 'vtc=ac4SkNq3rWtUZ5G7OizIR0; TBV=7; _pxvid=9a393384-41e4-11eb-b382-0242ac120019; cart-item-count=0; _gcl_au=1.1.332585788.1608373569; cid_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; _fbp=fb.1.1608373570153.1934083565; tb_sw_supported=true; __gads=ID=c5e47ced4e9b215e:T=1608373566:S=ALNI_Mafeft89rkavIzudSYWZOQFHHWMKg; TS013ed49a=01538efd7c942cd76d14a609e5158e1f36656a618f75750ab82a048a4760ec6b65662e58a65211a06e63af768138af98eaf1c75285; athrvi=RVI~h3831f771-h21a45114-h3abbacf5-h31871936-h153d5c5d-h2b489c5; cw_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; s_sess_2=ps%3D1; bstc=fVMbBPT0xiTdjibtYBcK64; mobileweb=0; xpa=; xpm=3%2B1608542579%2Bac4SkNq3rWtUZ5G7OizIR0~%2B0; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608543454108@firstcreate:1608373564012"; TS01b0be75=01538efd7c6521aafd8a065a36663000a6a37f97bbbd0863fee6799d800a84a2918a58bae9d7c8801b4ac49ea6443f408847d8ff41; _uetsid=a7ad2580434711eb9b017b4e60b19c2d; _uetvid=9c93218041e411eb9fab9dc80034c19e; _px3=54acf9b1493a956d9cb3ab7ca92d584bd65c24bfc52f2a2d606a3af5e6e65ba3:MxACGZYKs/DkNYaod+6dh4nSyV/AeWi2MGLe9x7WWpNXPZVtNcGe0u8xsWeKhPwfjRO4Y3Fo1XTLyd+iYd0Upg==:1000:ciEi4Oc6tMZE099o4IRcaXiFuDKlYwpBeMBweOQkM71w0D3oHj6wqfJ07xrdgjTIIVKWsVIZ6Orq/WCH05Qlco0TEwlRC1je08PNfG53l9L6Mqpjpm0pYYRLlftJ256SmIH5BaAi23JBTsH3+7SMibw3o14vYP54NvPYYMSrw2s=; akavpau_p8=1608544058~id=6ded017e934eb8aa17ee16413e048e3d; _pxde=c678fbb1e2ce300345d698065f50e2a2587da9b400dbb9b888a93067045eed90:eyJ0aW1lc3RhbXAiOjE2MDg1NDM0ODMwNjQsImZfa2IiOjAsImlwY19pZCI6W119; next-day=1608588000|true|false|1608638400|1608543491; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1608543491776|30309',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
        }
        for row_p in product_results:
            try:
                Category_Link = row_p[2]
                Category_page = row_p[3]
                Category_Name = row_p[5]
                Category = row_p[6]
                file = self.set.page_read(Category_page)
                response1 = html.fromstring(file)
                data_json_text = response1.xpath('//script[@id="searchContent"]/text()')[0]
                try:data_json = json.loads(data_json_text)
                except Exception as e:
                    print(e)
                for data in data_json['searchContent']['preso']['items']:
                    product_link = f"https://www.walmart.com{data['productPageUrl']}"
                    if '/col/' in product_link or '/co/' in product_link:
                        yield scrapy.Request(url=product_link, callback=self.parse_link, dont_filter=True, headers=self.head,
                                             meta={'Category_Link': Category_Link, 'Category_page': Category_page, 'Category_Name': Category_Name, 'Category': Category, 'source_url': product_link})
                    else:
                        try:
                            self.item = TranmazonItem()
                            self.item['Site'] = self.site_name
                            self.item['Category_Link'] = Category_Link
                            self.item['Category_Name'] = Category_Name
                            self.item['Product_Link'] = product_link
                            self.item['Category'] = Category
                            self.item['table'] = 'walmart_link_2020_12_14'
                            yield self.item
                        except Exception as e:
                            print(e)
                try:
                    self.set.cursor.execute(f'update {dbc.database}.walmart_category_2020_12_14 set link_status="Done1" where Category_Link="{Category_Link}"')
                    self.set.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

    def parse_link(self, response):
        try:
            Category_Link = response.meta['Category_Link']
            Category_page = response.meta['Category_page']
            Category_Name = response.meta['Category_Name']
            Category = response.meta['Category']
            product_link = response.meta['source_url']
            if '<title>Verify your identity</title>' in response.text:
                self.heade_col = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'cookie': 'vtc=ac4SkNq3rWtUZ5G7OizIR0; TBV=7; _pxvid=9a393384-41e4-11eb-b382-0242ac120019; cart-item-count=0; _gcl_au=1.1.332585788.1608373569; cid_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; _fbp=fb.1.1608373570153.1934083565; tb_sw_supported=true; __gads=ID=c5e47ced4e9b215e:T=1608373566:S=ALNI_Mafeft89rkavIzudSYWZOQFHHWMKg; TS013ed49a=01538efd7c942cd76d14a609e5158e1f36656a618f75750ab82a048a4760ec6b65662e58a65211a06e63af768138af98eaf1c75285; athrvi=RVI~h3831f771-h21a45114-h3abbacf5-h31871936-h153d5c5d-h2b489c5; cw_csid=4c718c21-d0fd-47a7-aaea-339ac2792fd7; s_sess_2=ps%3D1; bstc=fVMbBPT0xiTdjibtYBcK64; mobileweb=0; xpa=; xpm=3%2B1608542579%2Bac4SkNq3rWtUZ5G7OizIR0~%2B0; com.wm.reflector="reflectorid:0000000000000000000000@lastupd:1608543454108@firstcreate:1608373564012"; TS01b0be75=01538efd7c6521aafd8a065a36663000a6a37f97bbbd0863fee6799d800a84a2918a58bae9d7c8801b4ac49ea6443f408847d8ff41; _uetsid=a7ad2580434711eb9b017b4e60b19c2d; _uetvid=9c93218041e411eb9fab9dc80034c19e; _px3=54acf9b1493a956d9cb3ab7ca92d584bd65c24bfc52f2a2d606a3af5e6e65ba3:MxACGZYKs/DkNYaod+6dh4nSyV/AeWi2MGLe9x7WWpNXPZVtNcGe0u8xsWeKhPwfjRO4Y3Fo1XTLyd+iYd0Upg==:1000:ciEi4Oc6tMZE099o4IRcaXiFuDKlYwpBeMBweOQkM71w0D3oHj6wqfJ07xrdgjTIIVKWsVIZ6Orq/WCH05Qlco0TEwlRC1je08PNfG53l9L6Mqpjpm0pYYRLlftJ256SmIH5BaAi23JBTsH3+7SMibw3o14vYP54NvPYYMSrw2s=; akavpau_p8=1608544058~id=6ded017e934eb8aa17ee16413e048e3d; _pxde=c678fbb1e2ce300345d698065f50e2a2587da9b400dbb9b888a93067045eed90:eyJ0aW1lc3RhbXAiOjE2MDg1NDM0ODMwNjQsImZfa2IiOjAsImlwY19pZCI6W119; next-day=1608588000|true|false|1608638400|1608543491; location-data=30309%3AAtlanta%3AGA%3A%3A8%3A1|2wv%3B%3B1.84%2C2bk%3B%3B3.43%2C2em%3B%3B5.27%2C2v1%3B%3B6.64%2C2v2%3B%3B7%2C2sl%3B%3B7.46%2C5ee%3B%3B8.46%2C2vx%3B%3B8.73%2C1tk%3B%3B9.79%2Cwt%3B%3B9.96||7|1|1yjz%3B16%3B0%3B0.46%2C1yot%3B16%3B1%3B1.05%2C1y78%3B16%3B3%3B2.08%2C1yjy%3B16%3B4%3B2.24%2C1yqr%3B16%3B5%3B2.4; DL=30309%2C%2C%2Cip%2C30309%2C%2C; t-loc-zip=1608543491776|30309',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
                }
                yield scrapy.Request(url=product_link, callback=self.parse_link, dont_filter=True, headers=self.heade_col,
                                     meta={'Category_Link': Category_Link, 'Category_page': Category_page,
                                           'Category_Name': Category_Name, 'Category': Category,
                                           'source_url': product_link})
            else:
                data_json_text = response.xpath('//script[@id="collection"]/text()').extract()[0]
                try:
                    data_json = json.loads(data_json_text)
                except Exception as e:
                    print(e)
                for data in data_json['collection']['product']['componentItems']:
                    product_link = f"https://www.walmart.com{data['productUrl']}"
                    try:
                        self.item = TranmazonItem()
                        self.item['Site'] = self.site_name
                        self.item['Category_Link'] = Category_Link
                        self.item['Category_Name'] = Category_Name
                        self.item['Product_Link'] = product_link
                        self.item['Category'] = Category
                        self.item['table'] = 'walmart_link_2020_12_14'
                        yield self.item
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


# execute("scrapy crawl walmart_link -a site_name=walmart -a start=0 -a end=26347".split())
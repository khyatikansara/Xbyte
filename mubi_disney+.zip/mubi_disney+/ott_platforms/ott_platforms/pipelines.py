# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from datetime import datetime
import pymongo
from ott_platforms.items import OTTPlatformsMoviesItem, OTTPlatformsAvailabilitiesItem, OTTPlatformsShowsItem, \
    OTTPlatformsSeasonsItem, OTTPlatformsEpisodesItem, OTTPlatformsLinksItem
from ott_platforms.items_models import ProviderMovie, ProviderShow, ProviderSeason, ProviderEpisode, Availability, \
    OfferLink, IMDbId


class OttPlatformsPipeline:
    date = datetime.now().strftime('%d_%m_%Y')
    # date = '21_01_2021'

    def open_spider(self, spider):
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': spider.OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']


        con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = con[f'OTT_{Source}_{Country}']

        self.movies_master = self.db[f'OTT_{Source}_{Country}_Movies_Master']
        self.shows_master = self.db[f'OTT_{Source}_{Country}_Shows_Master']
        self.seasons_master = self.db[f'OTT_{Source}_{Country}_Seasons_Master']
        self.episodes_master = self.db[f'OTT_{Source}_{Country}_Episodes_Master']
        self.link_master = self.db[f'OTT_{Source}_{Country}_Links_Master']

        self.movies_daily = self.db[f'OTT_{Source}_{Country}_Movies_{self.date}']
        self.shows_daily = self.db[f'OTT_{Source}_{Country}_Shows_{self.date}']
        self.seasons_daily = self.db[f'OTT_{Source}_{Country}_Seasons_{self.date}']
        self.episodes_daily = self.db[f'OTT_{Source}_{Country}_Episodes_{self.date}']
        self.availabilities_daily = self.db[f'OTT_{Source}_{Country}_Availabilities_data_{self.date}']

    def process_item(self, item, spider):

        # For Movie
        if isinstance(item, OTTPlatformsMoviesItem):
            is_valid = True
            Movie = ProviderMovie()
            item = dict(item)
            Movie.Title = item['Title']
            Movie.Actors = item['Actors']
            Movie.Directors = item['Directors']
            Movie.Crew = item['Crew']
            Movie.Year = item['Year']
            Movie.Source = item['Source']
            Movie.PosterUrl = item['PosterUrl']
            Movie.Description = item['Description']
            Movie.ProviderUniqueId = item['ProviderUniqueId']
            Movie.IMDBId = item['IMDBId']
            Movie.Url = item['Url']
            Movie.Country = item['Country']
            Movie.TMDBId = item['TMDBId']
            Movie.Modifier = item['Modifier']
            Movie.Modified = item['Modified']
            try:
                Movie.validate()
            except Exception as e:
                print(e)
                is_valid = False

            if is_valid:
                try:
                    print('Movie Validated...')
                    item['status'] = 'pending'
                    try:
                        self.movies_master.insert(item)
                    except Exception as e:
                        print(e)

                    try:
                        self.movies_daily.insert(item)
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
            else:
                print('Movie Data Not Valid. Droping item. Please check...')

        # For Show
        if isinstance(item, OTTPlatformsShowsItem):
            is_valid = True
            Show = ProviderShow()
            item = dict(item)
            Show.Title = item['Title']
            Show.Actors = item['Actors']
            Show.Directors = item['Directors']
            Show.Crew = item['Crew']
            Show.Year = item['Year']
            Show.Source = item['Source']
            Show.PosterUrl = item['PosterUrl']
            Show.Description = item['Description']
            Show.ProviderUniqueId = item['ProviderUniqueId']
            Show.IMDBId = item['IMDBId']
            Show.Url = item['Url']
            Show.Country = item['Country']
            Show.TMDBId = item['TMDBId']
            Show.Modifier = item['Modifier']
            Show.Modified = item['Modified']
            try:
                Show.validate()
            except Exception as e:
                print(e)
                is_valid = False

            if is_valid:
                print('Show Validated...')
                item['status'] = 'pending'
                try:
                    self.shows_master.insert(item)
                except Exception as e:
                    print(e)

                try:
                    self.shows_daily.insert(item)
                except Exception as e:
                    print(e)
            else:
                print('Show Data Not Valid. Droping item. Please check...')

        # For Season
        if isinstance(item, OTTPlatformsSeasonsItem):
            is_valid = True
            Season = ProviderSeason()
            item = dict(item)
            Season.Title = item['Title']
            Season.SeasonNumber = item['SeasonNumber']
            Season.Actors = item['Actors']
            Season.Directors = item['Directors']
            Season.Crew = item['Crew']
            Season.Year = item['Year']
            Season.Source = item['Source']
            Season.PosterUrl = item['PosterUrl']
            Season.Description = item['Description']
            Season.ProviderUniqueShowId = item['ProviderUniqueId']
            Season.ProviderUniqueId = item['ProviderUniqueSeasonId']
            Season.IMDBId = item['IMDBId']
            Season.Url = item['Url']
            Season.Country = item['Country']
            Season.TMDBId = item['TMDBId']
            Season.Modifier = item['Modifier']
            Season.Modified = item['Modified']
            try:
                Season.validate()
            except Exception as e:
                print(e)
                is_valid = False

            if is_valid:
                print('Season Validated...')
                item['status'] = 'pending'
                try:
                    self.seasons_master.insert(item)
                except Exception as e:
                    print(e)

                try:
                    self.seasons_daily.insert(item)
                except Exception as e:
                    print(e)
            else:
                print('Season Data Not Valid. Droping item. Please check...')

        # For Episode
        if isinstance(item, OTTPlatformsEpisodesItem):
            is_valid = True
            Episode = ProviderEpisode()
            item = dict(item)
            Episode.Title = item['Title']
            Episode.EpisodeNumber = item['EpisodeNumber']
            Episode.Actors = item['Actors']
            Episode.Directors = item['Directors']
            Episode.Crew = item['Crew']
            Episode.Year = item['Year']
            Episode.Source = item['Source']
            Episode.ImageUrl = item['ImageUrl']
            Episode.Description = item['Description']
            Episode.ProviderUniqueId = item['ProviderUniqueEpisodeId']
            Episode.IMDBId = item['IMDBId']
            Episode.Url = item['Url']
            Episode.Country = item['Country']
            Episode.TMDBId = item['TMDBId']
            Episode.Modifier = item['Modifier']
            Episode.Modified = item['Modified']
            try:
                Episode.validate()
            except Exception as e:
                print(e)
                is_valid = False

            if is_valid:
                print('Episode Validated...')
                item['status'] = 'pending'
                try:
                    self.episodes_master.insert(item)
                except Exception as e:
                    print(e)

                try:
                    self.episodes_daily.insert(item)
                except Exception as e:
                    print(e)
            else:
                print('Episode Data Not Valid. Droping item. Please check...')

        # For Availabilities
        if isinstance(item, OTTPlatformsAvailabilitiesItem):
            is_valid = True
            Availabilities = Availability()
            item = dict(item)
            Availabilities.Provider = item['Provider']
            Availabilities.OfferType = item['OfferType']
            Availabilities.DeliveryMethod = item['DeliveryMethod']
            Availabilities.Price = item['Price']
            Availabilities.Currency = item['Currency']
            Availabilities.PreSale = item['PreSale']
            Availabilities.Quality = item['Quality']
            Availabilities.Links = item['Links']
            Availabilities.Country = item['Country']
            Availabilities.ExpirationDate = item['ExpirationDate']
            Availabilities.Modifier = item['Modifier']
            Availabilities.Modified = item['Modified']
            try:
                Availabilities.validate()
            except Exception as e:
                print(e)
                is_valid = False

            if is_valid:
                print('Availability Validated...')
                try:
                    self.availabilities_daily.insert(item)
                except Exception as e:
                    print(e)
            else:
                print('Availabilities Data Not Valid. Droping item. Please check...')

        # For Links
        if isinstance(item, OTTPlatformsLinksItem):
            try:
                item = dict(item)
                item['Status'] = 'Pending'
                self.link_master.insert(item)
            except Exception as e:
                print(e)

        return item


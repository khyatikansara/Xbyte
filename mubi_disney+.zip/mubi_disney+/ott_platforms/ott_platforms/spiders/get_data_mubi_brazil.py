import datetime
import hashlib
import json
import pymongo
import scrapy
from ott_platforms.items import OTTPlatformsMoviesItem, OTTPlatformsAvailabilitiesItem, OTTPlatformsShowsItem, \
    OTTPlatformsSeasonsItem, OTTPlatformsEpisodesItem
from scrapy.cmdline import execute


class GetDataMubiBrazilSpider(scrapy.Spider):
    name = 'get_data_mubi_br'
    allowed_domains = []

    handle_httpstatus_list = [503, 502, 501, 500]

    OTT_Platform_Number = 'mubi_br'

    def __init__(self, start='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': self.OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']

        con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = con[f'OTT_{Source}_{Country}']
        self.link_master = self.db[f'OTT_{Source}_{Country}_Links_Master']

    def start_requests(self):
        try:
            links = self.link_master.find({'Status': "Pending"}, no_cursor_timeout=True)#.limit(100).skip(self.start)
            print(self.link_master.find({'Status': "Pending"}).count())
            for link in links:
                _id = link['_id']
                url = link['link']
                header = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
                }
                yield scrapy.Request(url=url, headers=header, meta={'Id': _id, 'url': url})
        except Exception as e:
            print(e)


    def parse(self, response):
        try:
            Id = response.meta['Id']
            url = response.meta["url"]
            header = {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "accept-language": "en-US,en;q=0.9",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": "1",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
            }
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(url=url, headers=header, meta={'Id': Id, 'url': url}, dont_filter=True)
            else:
                if 'Enter the characters you see below' in response.text:
                    yield scrapy.Request(url=url, headers=header, meta={'Id': Id, 'url': url}, dont_filter=True)
                else:
                    try:
                        json_text = response.xpath('//script[@id="__NEXT_DATA__"]/text()').get()
                        data = json.loads(json_text)
                        if data['props']['initialProps']['pageProps'] != {}:
                            main_asin = data['props']['initialProps']['pageProps']['film']['id']
                            page_name =  f'D:\khyati-H\Project FP\Mubi_BR\\{main_asin}.html'
                            with open(page_name, 'wb') as f:
                                f.write(response.body)
                                f.close()

                            # For Movie data
                            Title = data['props']['initialProps']['pageProps']['film']['title']
                            Actors = []
                            Directors = []
                            Director_list = data['props']['initialProps']['pageProps']['film']['cast']
                            for direct in Director_list:
                                print(direct)
                                if 'Director' in direct['credits']:
                                    Directors.append(direct['name'])

                            Crew = None
                            Year = data['props']['initialProps']['pageProps']['film']['year']
                            if Year:
                                Year = int(Year)
                            try:
                                PosterUrl = data['props']['initialProps']['pageProps']['film']['still_url']
                            except Exception as e:
                                print(e)
                                PosterUrl = None
                            Description = data['props']['initialProps']['pageProps']['film']['short_synopsis']
                            Url = response.url
                            Country = 'BR'
                            IMDBId = ''
                            found_asin = data['props']['initialProps']['pageProps']['film']['id']
                            ProviderUniqueId = found_asin

                            movie = OTTPlatformsMoviesItem()

                            # make sure to take unique value for this if found for specific movie. do not generate using any hash function
                            movie["_id"] = found_asin
                            movie["Title"] = Title
                            movie["Actors"] = Actors
                            movie["Directors"] = Directors
                            movie["Crew"] = Crew
                            movie["Year"] = Year
                            movie["Source"] = 'Mubi'
                            movie["PosterUrl"] = PosterUrl
                            movie["Description"] = Description
                            movie["ProviderUniqueId"] = ProviderUniqueId
                            movie["IMDBId"] = IMDBId
                            movie["Url"] = Url
                            movie["Country"] = Country
                            movie["TMDBId"] = None
                            movie["Modifier"] = None
                            movie["Modified"] = datetime.datetime.utcnow()
                            movie["Scrap_datetime"] = datetime.datetime.now()
                            movie["SlotNumber"] = 1
                            yield movie

                            # Movie Availabilities
                            availabilities = OTTPlatformsAvailabilitiesItem()

                            availabilities["ProviderUniqueId"] = ProviderUniqueId
                            availabilities["PreSale"] = None
                            availabilities["Modifier"] = None
                            availabilities["StartDate"] = None
                            availabilities["Country"] = 'BR'
                            availabilities["DeliveryMethod"] = 'OnDemand'
                            availabilities["Modified"] = datetime.datetime.utcnow()

                            Links = list()
                            Links.append({'Url': movie["Url"], 'Platform': 'Web'})
                            Links.append({
                                'Url': f'{movie["Url"].replace("https", "intent")}#Intent;package=com.mubi.mediaclient;scheme=https;end',
                                'Platform': 'Android'})
                            Links.append({'Url': f'{movie["Url"].replace("https", "mubi")}', 'Platform': 'IOS'})

                            availabilities["Links"] = Links
                            availabilities["Price"] = '0'
                            availabilities["Currency"] = 'EUR'
                            availabilities["ExpirationDate"] = None
                            availabilities["Provider"] = 'Mubi'
                            availabilities["OfferType"] = 'Subscription'
                            availabilities["Quality"] = None

                            unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                availabilities["Price"]) + str(availabilities["Provider"]) + str(
                                availabilities["OfferType"]) + str(availabilities["Quality"])
                            availabilities["_id"] = int(hashlib.md5(bytes(unique_key, encoding='utf8')).hexdigest(),
                                                        16) % (10 ** 8)

                            yield availabilities

                            try:
                                self.link_master.update({'_id': Id}, {'$set': {'Status': 'Done'}}, upsert=False)
                            except Exception as e:
                                print(e)
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


# execute('scrapy crawl get_data_mubi_br -a start=0'.split())
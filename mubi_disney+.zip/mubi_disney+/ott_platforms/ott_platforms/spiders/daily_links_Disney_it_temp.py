# -*- coding: utf-8 -*-
import datetime
import hashlib
import json
from os import listdir
from os.path import isfile, join

from scrapy.cmdline import execute
import scrapy
from ott_platforms.items import OTTPlatformsLinksItem


class DailyLinksDisneyITTempSpider(scrapy.Spider):
    name = 'daily_links_disney_it_temp'
    allowed_domains = ['www.disneyplus.com']
    start_urls = ['https://www.disneyplus.com/en-it']
    today = datetime.datetime.now().strftime("%d_%m_%Y")
    handle_httpstatus_list = [503, 502, 501, 500]
    OTT_Platform_Number = 'disney_it'
    Source = 'Disney+'
    flag = True
    page = 2

    def parse(self,response):
        try:
            mypath = "D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney IT\link\\"
            onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
            for files in onlyfiles:
                print(files)
                if 'Movie' in files:
                    file = open(mypath+files,encoding='utf-8')
                    file_r = file.read()
                    data_json = json.loads(file_r)
                    if data_json['data']['CuratedSet']['items'] != []:
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'IT':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedFamilyId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedFamilyId = j['family']['encodedFamilyId']
                                if content != '' and encodedFamilyId != '':
                                    link = f"https://www.disneyplus.com/movies/{content}/{encodedFamilyId}"
                                    if 'None' in link:
                                        print("encodedFamilyId None")
                                    else:
                                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                        item['link'] = link
                                        yield item
                else:
                    file = open(mypath + files, encoding='utf-8')
                    file_r = file.read()
                    data_json = json.loads(file_r)
                    if data_json['data']['CuratedSet']['items'] != []:
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'IT':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedSeriesId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedSeriesId = j['encodedSeriesId']
                                if content != '' and encodedSeriesId != '':
                                    link = f"https://www.disneyplus.com/series/{content}/{encodedSeriesId}"
                                    if 'None' in link:
                                        print("encodedSeriesId None")
                                    else:
                                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                        item['link'] = link
                                        yield item
        except Exception as e:
            print(e)

# execute('scrapy crawl daily_links_disney_it_temp'.split())
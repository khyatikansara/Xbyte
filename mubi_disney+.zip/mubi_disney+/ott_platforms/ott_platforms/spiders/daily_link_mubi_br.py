# -*- coding: utf-8 -*-
import datetime
import hashlib
from scrapy.cmdline import execute
import scrapy
from ott_platforms.items import OTTPlatformsLinksItem


class DailyLinksMubiBRSpider(scrapy.Spider):
    name = 'daily_links_mubi_br'
    allowed_domains = []

    handle_httpstatus_list = [503, 502, 501, 500]

    OTT_Platform_Number = 'mubi_br'
    Source = 'Mubi'

    def start_requests(self):
        try:
            url = 'https://mubi.com/films?country=Brazil&sort=title'
            yield scrapy.Request(url=url)
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            header = {
                'accept-language': 'en-US,en;q=0.9',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
                          'application/signed-exchange;v=b3;q=0.9',
                'cache-control': 'max-age=0',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                "user-agent": 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
            }
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(
                    url=response.url,
                    headers=header,
                    meta=response.meta,
                    dont_filter=True,
                    callback=self.parse
                )
            else:
                if 'Enter the characters you see below' in response.text:
                    yield scrapy.Request(
                        url=response.url,
                        headers=header,
                        meta=response.meta,
                        dont_filter=True,
                        callback=self.parse
                    )
                else:
                    item = OTTPlatformsLinksItem()
                    links = response.xpath('//a[@class="film-link"]/@href').getall()
                    for link in links:
                        link = f'https://mubi.com{link}'
                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                        item['link'] = link
                        yield item
                    try:
                        next_page_tmp = response.xpath('//a[@rel="next"]/@href').get()
                        if next_page_tmp:
                            next_page = 'https://mubi.com' + next_page_tmp
                            yield scrapy.Request(
                                url=next_page,
                                headers=header,
                                meta=response.meta,
                                dont_filter=True,
                                callback=self.parse
                            )
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)

# execute('scrapy crawl daily_links_mubi_br'.split())
import datetime
import hashlib
import json
import re
import pymongo
import requests
import scrapy
from scrapy.http import HtmlResponse

from ott_platforms.items import OTTPlatformsMoviesItem, OTTPlatformsAvailabilitiesItem, OTTPlatformsShowsItem, OTTPlatformsSeasonsItem, OTTPlatformsEpisodesItem
from scrapy.cmdline import execute
from scraper_api import ScraperAPIClient
client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')


class GetDataDisneyBRSpider(scrapy.Spider):
    name = 'get_data_disney_br'
    allowed_domains = ['www.disneyplus.com']
    handle_httpstatus_list = [503, 502, 501, 500]
    OTT_Platform_Number = 'disney_br'

    def __init__(self, start='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': self.OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']

        con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = con[f'OTT_{Source}_{Country}']
        self.link_master = self.db[f'OTT_{Source}_{Country}_Links_Master']

    def start_requests(self):
        try:
            links = self.link_master.find({'Status': "pending"}, no_cursor_timeout=True)#.limit(1).skip(self.start)
            print(self.link_master.find({'Status': "pending"}).count())
            for link in links:
                _id = link['_id']
                url = link['link']
                self.headers = {
                    'accept': 'application/json',
                    'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ3NDg1NzgsInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wM1QwNToxNjoxOC44ODErMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IkJSIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6Ii0wMzowMCIsIm5hbWUiOiJBbWVyaWNhXC9TYW9fUGF1bG8ifSwicmF0aW5nX3N5c3RlbXMiOlsiZGpjdHEiXX0sImV4cGlyZXNfb24iOiIyMDIxLTAzLTAzVDA5OjE2OjE4Ljg4MSswMDAwIiwiZXhwZXJpbWVudHMiOnsiMWIyZTBmNTkmJkNXX2RldGFpbHNfcGFnZV9BQSI6eyJ2YXJpYW50X2lkIjoiZW5oYW5jZWRfZGVzaWduIiwidmVyc2lvbiI6MX0sIjQzNTYwZTQxJiZhYXRlc3RKYW4yNyI6eyJ2YXJpYW50X2lkIjoiY29udHJvbCIsInZlcnNpb24iOjF9LCJlMmZjMGQzMSYmQ1dfZGV0YWlsc19wYWdlX3Rlc3QiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfSwiMzlhYjZjNDUmJlN0YW5kYWxvbmVfVGVzdF9KYW4yMSI6eyJ2YXJpYW50X2lkIjoiY29udHJvbCIsInZlcnNpb24iOjF9fSwicHJvZmlsZXMiOlt7Imdyb3VwX3dhdGNoIjp7ImVuYWJsZWQiOnRydWV9LCJraWRzX21vZGVfZW5hYmxlZCI6ZmFsc2UsInBsYXliYWNrX3NldHRpbmdzIjp7InByZWZlcl8xMzMiOmZhbHNlfSwicGFyZW50YWxfY29udHJvbHMiOnsicGluX2VudHJ5X2V4cGlyZXNfYXQiOiIiLCJtYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6Ik1QQUFBbmRUVlBHIiwiY29udGVudF9tYXR1cml0eV9yYXRpbmciOiJUVi0xNCIsImltcGxpZWRfbWF0dXJpdHlfcmF0aW5nIjowfSwiaXNfYWdlMjFfdmVyaWZpZWQiOmZhbHNlLCJpc19waW5fcHJvdGVjdGVkIjpmYWxzZSwiZW5hYmxlZCI6dHJ1ZX0sImFjdGl2ZSI6dHJ1ZSwiaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJhdmF0YXIiOnsiaWQiOiI0NDJhZjdkYi04NWY3LTVlMWQtOTZmMC1iMmM1MTdiZTQwODUifSwidHlwZSI6InVybjpiYW10ZWNoOnByb2ZpbGUiLCJsYW5ndWFnZV9wcmVmZXJlbmNlcyI6eyJhcHBfbGFuZ3VhZ2UiOiJlbiIsInBsYXliYWNrX2xhbmd1YWdlIjoiZW4iLCJzdWJ0aXRsZV9sYW5ndWFnZSI6ImVuIn19XSwiaXBfYWRkcmVzcyI6IjE3MC44MC42NS40MyIsInR5cGUiOiJSRUdJU1RFUkVEIiwidmVyc2lvbiI6IlYyLjAuMCIsImJsYWNrb3V0cyI6eyJlbnRpdGxlbWVudHMiOltdLCJkYXRhIjp7fSwicnVsZXMiOnsidmlvbGF0ZWQiOltdfX0sInBhcnRuZXIiOnsibmFtZSI6ImRpc25leSJ9LCJsb2NhdGlvbiI6eyJjb3VudHJ5X2NvZGUiOiJCUiIsImNpdHlfbmFtZSI6ImxhZ29hIHNhbnRhIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6Im1pbmFzIGdlcmFpcyIsImRtYSI6MCwicmVnaW9uX25hbWUiOiJzb3V0aGVhc3QiLCJ0eXBlIjoiWklQX0NPREUiLCJhc24iOjI2NDIyOCwiemlwX2NvZGUiOiIzMzQwMC0wMDAifSwiZ2VuZXJhdGVkX29uIjoiMjAyMS0wMy0wM1QwNToxNjoxOC44ODErMDAwMCIsImhvbWVfbG9jYXRpb24iOnsiY291bnRyeV9jb2RlIjoiVVMiLCJjaXR5X25hbWUiOiIiLCJjb25uZWN0aW9uX3R5cGUiOiIiLCJzdGF0ZV9uYW1lIjoiIiwiZG1hIjowLCJyZWdpb25fbmFtZSI6IiIsInR5cGUiOiJDT1VOVFJZX0NPREUiLCJhc24iOjAsInppcF9jb2RlIjoiIn0sImlkIjoiOTVmNjFjZjAtN2JkZi0xMWViLTlmOTctMDI0MmFjMTEwMDA2IiwibWVkaWFfcGVybWlzc2lvbnMiOnsiZW50aXRsZW1lbnRzIjpbIkRJU05FWV9QTFVTIiwiRVNQTl9QTFVTIiwiRElTTkVZX1BMVVMiLCJESVNORVlfSFVMVV9BRFMiXSwiZGF0YSI6e30sInJ1bGVzIjp7InBhc3NlZCI6W119fSwiZGV2aWNlIjp7ImFwcF9ydW50aW1lIjoiY2hyb21lIiwicHJvZmlsZSI6IndpbmRvd3MiLCJtb2RlbCI6IiIsImlkIjoiNDk2NTE0OTUtMDY0Ny00NzcxLWFlMGMtOGU5ODExZTIyY2I4IiwidHlwZSI6InVybjpkc3M6ZGV2aWNlOmludGVybmFsIiwiZmFtaWx5IjoiYnJvd3NlciIsInBsYXRmb3JtIjoiYnJvd3NlciJ9LCJhY2NvdW50Ijp7ImRhdGEiOnt9LCJsb2NhdGlvbnMiOnsicHVyY2hhc2UiOnsiY291bnRyeSI6IlVTIn0sInJlZ2lzdHJhdGlvbiI6eyJjb3VudHJ5IjoiVVMifX0sImlkIjoiZjY5MzRhYWMtYmU2Ny00NjFjLTg2MjItYjRhNzZhZmUzZDA4IiwidHlwZSI6InVybjpiYW10ZWNoOmFjY291bnQifSwicHJlZmVycmVkX21hdHVyaXR5X3JhdGluZyI6eyJyYXRpbmdfc3lzdGVtIjoiREpDVFEiLCJwcm9maWxlX2hhc19tYXR1cml0eV9yYXRpbmciOnRydWUsImltcGxpZWRfbWF0dXJpdHlfcmF0aW5nIjoxNDk5fSwic3VwcG9ydGVkIjp0cnVlfSwiZW52IjoicHJvZCIsImV4cCI6MTYxNDc2Mjk3OCwiaWF0IjoxNjE0NzQ4NTc4LCJqdGkiOiI4NTg2MzRhNy1mYjQ2LTRlYjAtYTUwZi1kMzMwZGUyMTMzZTUifQ.1tvb18xgZgmsx7uzZ431G28JvCJnRbWYhOF6KpynGQ-oNBCvILfueKVQLwUpYfk4Tkb316lxgOSDGriFSGCYAA',
                    'Referer': 'https://www.disneyplus.com/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                    'x-application-version': '1.1.2',
                    'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                    'x-bamsdk-platform': 'windows',
                    'x-bamsdk-version': '4.19'
                }
                if '/movies/' in url:
                    encodedFamilyId = url.split('/')[-1]
                    json_url = f"https://content.global.edge.bamgrid.com/svc/content/DmcVideoBundle/version/3.3/region/BR/audience/false/maturity/1499/language/en/encodedFamilyId/{encodedFamilyId}"
                elif '/series/' in url:
                    encodedSeriesId = url.split('/')[-1]
                    json_url = f"https://content.global.edge.bamgrid.com/svc/content/DmcSeriesBundle/version/3.3/region/BR/audience/false/maturity/1499/language/en/encodedSeriesId/{encodedSeriesId}"
                else:
                    json_url = ''
                if json_url != '':
                    yield scrapy.Request(url=json_url, headers=self.headers, meta={'Id': _id, 'url': url})
                # break
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            Id = response.meta['Id']
            if response.status != 200:
                Link = response.meta['url']
                yield scrapy.Request(url=response.url, meta={'Id': Id, 'Link': Link}, dont_filter=True)
            else:
                try:
                    with open(f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney BR\Data\\{Id}.json', 'wb') as f:
                        f.write(response.body)
                        f.close()
                except Exception as e:
                    print(e)

                Url = response.meta['url']
                found_asin = Url.split('/')[-1]
                ProviderUniqueId = found_asin
                json_data = json.loads(response.text)
                if '/movies/' in Url:
                    for i_movie in json_data['data']['DmcVideoBundle']['video']['texts']:
                        if i_movie['field'] == 'title' and i_movie['type'] == 'full':
                            Title = i_movie['content']
                        if i_movie['field'] == 'description' and i_movie['type'] == 'full':
                            Description = i_movie['content']
                    try:
                        Year = json_data['data']['DmcVideoBundle']['video']['releases'][0]['releaseYear']
                    except Exception as e:
                        print(e)
                        year = None
                    Actors = []
                    Directors = []
                    Crew = []
                    try:
                        for p_movie in json_data['data']['DmcVideoBundle']['video']['participants']:
                            if p_movie['role'] == 'Actor':
                                Actors.append(p_movie['displayName'])
                            if p_movie['role'] == 'Director':
                                Directors.append(p_movie['displayName'])
                            if p_movie['role'] == 'Producer':
                                Crew.append(p_movie['displayName'])
                    except Exception as e:
                        print(e)

                    for img in json_data['data']['DmcVideoBundle']['video']['images']:
                        if 'background' in img.values():
                            if img['purpose'] == 'background':
                                PosterUrl = img['url']
                                break
                        else:
                            if img['purpose'] == 'background_details':
                                PosterUrl = img['url']
                                break


                    movie = OTTPlatformsMoviesItem()

                    # make sure to take unique value for this if found for specific movie. do not generate using any hash function
                    movie["_id"] = found_asin
                    movie["Title"] = Title
                    movie["Actors"] = Actors
                    movie["Directors"] = Directors
                    movie["Crew"] = Crew
                    movie["Year"] = int(Year)
                    movie["Source"] = 'Disney+'
                    movie["PosterUrl"] = PosterUrl
                    movie["Description"] = Description
                    movie["ProviderUniqueId"] = ProviderUniqueId
                    movie["IMDBId"] = None
                    movie["Url"] = Url
                    movie["Country"] = 'BR'
                    movie["TMDBId"] = None
                    movie["Modifier"] = None
                    movie["Modified"] = datetime.datetime.utcnow()
                    movie["Scrap_datetime"] = datetime.datetime.now()
                    movie["SlotNumber"] = 1
                    yield movie

                    # Movie Availabilities
                    availabilities = OTTPlatformsAvailabilitiesItem()
                    availabilities["ProviderUniqueId"] = ProviderUniqueId
                    availabilities["PreSale"] = None
                    availabilities["Modifier"] = None
                    availabilities["StartDate"] = None
                    availabilities["Country"] = 'BR'
                    availabilities["DeliveryMethod"] = 'OnDemand'
                    availabilities["Modified"] = datetime.datetime.utcnow()
                    Links = list()
                    Links.append({'Url': movie["Url"], 'Platform': 'Web'})
                    Links.append({'Url': f'{movie["Url"].replace("https://www.", "intent://")}#Intent;package=com.disney.disneyplus;scheme=disneyplus;end', 'Platform': 'Android'})
                    Links.append({'Url': f'{movie["Url"].replace("https://www.", "disneyplus://")}', 'Platform': 'IOS'})
                    availabilities["Links"] = Links
                    availabilities["Price"] = 0
                    availabilities["Currency"] = 'BRL'
                    availabilities["ExpirationDate"] = None
                    availabilities["Provider"] = 'Disney+'
                    availabilities["OfferType"] = 'Subscription'
                    availabilities["Quality"] = None
                    unique_key = str(availabilities["ProviderUniqueId"]) + str(availabilities["Price"]) + str(availabilities["Provider"]) + str(availabilities["OfferType"]) + str(availabilities["Quality"])
                    availabilities["_id"] = int(hashlib.md5(bytes(unique_key + 'Movie', encoding='utf8')).hexdigest(),16) % (10 ** 8)
                    yield availabilities

                else:
                    for i_show in json_data['data']['DmcSeriesBundle']['series']['texts']:
                        if i_show['field'] == 'title' and i_show['type'] == 'full':
                            Title = i_show['content']
                        if i_show['field'] == 'description' and i_show['type'] == 'full':
                            Description = i_show['content']
                    try:
                        Year = json_data['data']['DmcSeriesBundle']['series']['releases'][0]['releaseYear']
                    except Exception as e:
                        print(e)
                        year = None
                    Actors = []
                    Directors = []
                    Crew = []
                    try:
                        for p_show in json_data['data']['DmcSeriesBundle']['series']['participants']:
                            if p_show['role'] == 'Actor':
                                Actors.append(p_show['displayName'])
                            if p_show['role'] == 'Director':
                                Directors.append(p_show['displayName'])
                            if p_show['role'] == 'Producer':
                                Crew.append(p_show['displayName'])
                    except Exception as e:
                        print(e)

                    for img_show in json_data['data']['DmcSeriesBundle']['series']['images']:
                        if 'background' in img_show.values():
                            if img_show['purpose'] == 'background':
                                PosterUrl = img_show['url']
                                break
                        else:
                            if img_show['purpose'] == 'background_details':
                                PosterUrl = img_show['url']
                                break

                    # For show Data
                    show = OTTPlatformsShowsItem()
                    show["_id"] = found_asin
                    show["Title"] = Title
                    show["Actors"] = Actors
                    show["Directors"] = Directors
                    show["Crew"] = Crew
                    show["Year"] = int(Year)
                    show["Source"] = 'Disney+'
                    show["PosterUrl"] = PosterUrl
                    show["Description"] = Description
                    show["ProviderUniqueId"] = ProviderUniqueId
                    show["IMDBId"] = None
                    show["Url"] = Url
                    show["Country"] = 'BR'
                    show["TMDBId"] = None
                    show["Modifier"] = None
                    show["Modified"] = datetime.datetime.utcnow()
                    show["Scrap_datetime"] = datetime.datetime.now()
                    show["SlotNumber"] = 1
                    yield show

                    # Show Availabilities
                    availabilities = OTTPlatformsAvailabilitiesItem()
                    availabilities["ProviderUniqueId"] = ProviderUniqueId
                    availabilities["PreSale"] = None
                    availabilities["Modifier"] = None
                    availabilities["StartDate"] = None
                    availabilities["Country"] = 'BR'
                    availabilities["DeliveryMethod"] = 'OnDemand'
                    availabilities["Modified"] = datetime.datetime.utcnow()
                    Links = list()
                    Links.append({'Url': show["Url"], 'Platform': 'Web'})
                    Links.append({'Url': f'{show["Url"].replace("https://www.", "intent://")}#Intent;package=com.disney.disneyplus;scheme=disneyplus;end','Platform': 'Android'})
                    Links.append({'Url': f'{show["Url"].replace("https://www.", "disneyplus://")}', 'Platform': 'IOS'})
                    availabilities["Links"] = Links
                    availabilities["Price"] = 0
                    availabilities["Currency"] = 'BRL'
                    availabilities["ExpirationDate"] = None
                    availabilities["Provider"] = 'Disney+'
                    availabilities["OfferType"] = 'Subscription'
                    availabilities["Quality"] = None
                    unique_key = str(availabilities["ProviderUniqueId"]) + str(availabilities["Price"]) + str(availabilities["Provider"]) + str(availabilities["OfferType"]) + str(availabilities["Quality"])
                    availabilities["_id"] = int(hashlib.md5(bytes(unique_key + 'Show', encoding='utf8')).hexdigest(), 16) % (10 ** 8)
                    yield availabilities

                    total_Season = json_data['data']['DmcSeriesBundle']['seasons']['seasons']
                    if total_Season != []:
                        for season_i in total_Season:
                            page = 1
                            seasonId = season_i['seasonId']
                            Season_num = season_i['seasonSequenceNumber']
                            season_Year = season_i['releases'][0]['releaseYear']

                            # For Season Data
                            season = OTTPlatformsSeasonsItem()
                            season["SeasonNumber"] = Season_num
                            season["_id"] = seasonId
                            season["Modified"] = datetime.datetime.utcnow()
                            season["Modifier"] = None
                            season["Description"] = Description
                            season["Country"] = 'BR'
                            season["Title"] = Title
                            season["Url"] = Url
                            season["IMDBId"] = None
                            season["PosterUrl"] = PosterUrl
                            season["Crew"] = Crew
                            season["Source"] = 'Disney+'
                            season["Directors"] = Directors
                            season["Actors"] = Actors
                            season["TMDBId"] = None
                            season["Year"] = season_Year
                            season["Scrap_datetime"] = datetime.datetime.now()
                            season["SlotNumber"] = 1
                            season["ProviderUniqueId"] = show["ProviderUniqueId"]
                            season["ProviderUniqueSeasonId"] = seasonId
                            yield season

                            # Season Availabilities
                            availabilities_season = OTTPlatformsAvailabilitiesItem()
                            availabilities_season["PreSale"] = None
                            availabilities_season["Modifier"] = None
                            availabilities_season["StartDate"] = None
                            availabilities_season["Country"] = 'BR'
                            availabilities_season["DeliveryMethod"] = 'OnDemand'
                            availabilities_season["Modified"] = datetime.datetime.utcnow()
                            Links = list()
                            Links.append({'Url': season["Url"], 'Platform': 'Web'})
                            Links.append({'Url': f'{season["Url"].replace("https://www.", "intent://")}#Intent;package=com.disney.disneyplus;scheme=disneyplus;end', 'Platform': 'Android'})
                            Links.append({'Url': f'{season["Url"].replace("https://www.", "disneyplus://")}', 'Platform': 'IOS'})
                            availabilities_season["Links"] = Links
                            availabilities_season["ProviderUniqueSeasonId"] = seasonId
                            availabilities_season["Price"] = 0
                            availabilities_season["Currency"] = 'BRL'
                            availabilities_season["ExpirationDate"] = None
                            availabilities_season["Provider"] = 'Disney+'
                            availabilities_season["OfferType"] = 'Subscription'
                            availabilities_season["Quality"] = None
                            unique_key = str(availabilities_season["ProviderUniqueSeasonId"]) + str(availabilities_season["Price"]) + str(availabilities_season["Provider"]) + str(availabilities_season["OfferType"]) + str(availabilities_season["Quality"])
                            availabilities_season["_id"] = int(hashlib.md5(bytes(unique_key + 'Season', encoding='utf8')).hexdigest(), 16) % (10 ** 8)
                            yield availabilities_season

                            while True:
                                season_json_url = f"https://content.global.edge.bamgrid.com/svc/content/DmcEpisodes/version/3.3/region/BR/audience/false/maturity/1499/language/en/seasonId/{seasonId}/pageSize/15/page/{str(page)}"
                                res_season = requests.get(url=season_json_url, headers=self.headers)
                                response_season = HtmlResponse(url=res_season.url, body= res_season.content)
                                season_json_data = json.loads(response_season.text)
                                if season_json_data['data']['DmcEpisodes']['videos'] == []:
                                    break
                                else:
                                    page+=1
                                    total_Episode = season_json_data['data']['DmcEpisodes']['videos']
                                    if total_Episode != []:
                                        for Episode in total_Episode:
                                            Episode_Id = Episode['programId']
                                            Episode_No = Episode['episodeSequenceNumber']
                                            contentId = Episode['contentId']
                                            for i_episode in Episode['texts']:
                                                if i_episode['field'] == 'title' and i_episode['type'] == 'full' and i_episode['sourceEntity'] == 'program':
                                                    Episode_Title = i_episode['content']
                                                if i_episode['field'] == 'description' and i_episode['type'] == 'brief' and i_episode['sourceEntity'] == 'program':
                                                    Episode_Description = i_episode['content']
                                            for img_episode in Episode['images']:
                                                if img_episode['purpose'] == 'thumbnail' and img_episode['sourceEntity'] == 'program':
                                                    Episode_ImageUrl = img_episode['url']
                                                    break
                                            Episode_Year = Episode['releases'][0]['releaseYear']

                                            # For Episode Data
                                            episode = OTTPlatformsEpisodesItem()
                                            episode['_id'] = Episode_Id
                                            episode['Modified'] = datetime.datetime.utcnow()
                                            episode['Modifier'] = None
                                            episode['EpisodeNumber'] = Episode_No
                                            episode['Description'] = Episode_Description
                                            episode['Country'] = 'BR'
                                            episode['Title'] = Episode_Title
                                            episode['Url'] = f'https://www.disneyplus.com/video/{contentId}'
                                            episode['IMDBId'] = None
                                            episode['ImageUrl'] = Episode_ImageUrl
                                            episode['Crew'] = None
                                            episode['Source'] = 'Disney+'
                                            episode['Directors'] = Directors
                                            episode['Actors'] = Actors
                                            episode['TMDBId'] = None
                                            episode['Year'] = Episode_Year
                                            episode['Scrap_datetime'] = datetime.datetime.now()
                                            episode['SlotNumber'] = 1
                                            episode['ProviderUniqueId'] = show["ProviderUniqueId"]
                                            episode['ProviderUniqueSeasonId'] = season["ProviderUniqueSeasonId"]
                                            episode['ProviderUniqueEpisodeId'] = Episode_Id
                                            yield episode

                                            # Episode Availabilities
                                            availabilities_episode = OTTPlatformsAvailabilitiesItem()
                                            availabilities_episode["ProviderUniqueEpisodeId"] = Episode_Id
                                            availabilities_episode["PreSale"] = None
                                            availabilities_episode["Modifier"] = None
                                            availabilities_episode["StartDate"] = None
                                            availabilities_episode["Country"] = 'BR'
                                            availabilities_episode["DeliveryMethod"] = 'OnDemand'
                                            availabilities_episode["Modified"] = datetime.datetime.utcnow()
                                            Links = list()
                                            Links.append({'Url': episode["Url"], 'Platform': 'Web'})
                                            Links.append({'Url': f'{episode["Url"].replace("https://www.", "intent://")}#Intent;package=com.disney.disneyplus;scheme=disneyplus;end', 'Platform': 'Android'})
                                            Links.append({'Url': f'{episode["Url"].replace("https://www.", "disneyplus://")}','Platform': 'IOS'})
                                            availabilities_episode["Links"] = Links
                                            availabilities_episode["Price"] = 0
                                            availabilities_episode["Currency"] = 'BRL'
                                            availabilities_episode["ExpirationDate"] = None
                                            availabilities_episode["Provider"] = 'Disney+'
                                            availabilities_episode["OfferType"] = 'Subscription'
                                            availabilities_episode["Quality"] = None
                                            unique_key = str(availabilities_episode["ProviderUniqueEpisodeId"]) + str(availabilities_episode["Price"]) + str(availabilities_episode["Provider"]) + str(availabilities_episode["OfferType"]) + str(availabilities_episode["Quality"])
                                            availabilities_episode["_id"] = int(hashlib.md5(bytes(unique_key + 'Episode', encoding='utf8')).hexdigest(),16) % (10 ** 8)
                                            yield availabilities_episode

                try:
                    self.link_master.update({'_id': Id}, {'$set': {'Status': 'Done1'}}, upsert=False)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


# execute('scrapy crawl get_data_disney_br -a start=0'.split())
# -*- coding: utf-8 -*-
import datetime
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from ott_platforms.items import OTTPlatformsLinksItem


class DailyLinksDisneyBRSpider(scrapy.Spider):
    name = 'daily_links_disney_br'
    allowed_domains = ['https://disney.com.br/']
    today = datetime.datetime.now().strftime("%d_%m_%Y")
    handle_httpstatus_list = [503, 502, 501, 500]
    OTT_Platform_Number = 'disney_br'
    Source = 'Disney+'
    flag = True
    page = 2

    def start_requests(self):
        try:
            self.headre_movie = {
                'accept': 'application/json',
                'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ2MDI4MjMsInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wMVQxMjo0NzowMy43NzcrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IkJSIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6Ii0wMzowMCIsIm5hbWUiOiJBbWVyaWNhXC9TYW9fUGF1bG8ifSwicmF0aW5nX3N5c3RlbXMiOlsiZGpjdHEiXX0sImV4cGlyZXNfb24iOiIyMDIxLTAzLTAxVDE2OjQ3OjAzLjc3NyswMDAwIiwiZXhwZXJpbWVudHMiOnsiNDM1NjBlNDEmJmFhdGVzdEphbjI3Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIxODkuNi4xNi42MSIsInR5cGUiOiJSRUdJU1RFUkVEIiwidmVyc2lvbiI6IlYyLjAuMCIsImJsYWNrb3V0cyI6eyJlbnRpdGxlbWVudHMiOltdLCJkYXRhIjp7fSwicnVsZXMiOnsidmlvbGF0ZWQiOltdfX0sInBhcnRuZXIiOnsibmFtZSI6ImRpc25leSJ9LCJsb2NhdGlvbiI6eyJjb3VudHJ5X2NvZGUiOiJCUiIsImNpdHlfbmFtZSI6ImJyYXNpbGlhIiwiY29ubmVjdGlvbl90eXBlIjoiY2FibGUiLCJzdGF0ZV9uYW1lIjoiZGlzdHJpdG8gZmVkZXJhbCIsImRtYSI6MCwicmVnaW9uX25hbWUiOiJjZW50cmUtd2VzdCIsInR5cGUiOiJaSVBfQ09ERSIsImFzbiI6Mjg1NzMsInppcF9jb2RlIjoiNzAwNDAtMDEwIn0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDFUMTI6NDc6MDMuNzc3KzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6IjM5MjVmMGQwLTdhOGMtMTFlYi04ODA2LTAyNDJhYzExMDAwYSIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6IjQ5NjUxNDk1LTA2NDctNDc3MS1hZTBjLThlOTgxMWUyMmNiOCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRKQ1RRIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ2MTcyMjMsImlhdCI6MTYxNDYwMjgyMywianRpIjoiN2RlMTg3N2UtNTAyMi00MDk2LWI5ZDctMTNmMjBkNzQ3YjgwIn0.VWvztUqIIKr_BGubCg0rkkpiw9B5g8YTgkXxRv3hXJMH5FXfp513e3x8QhIzNm7IzJDczyuSrZ9hycG20Xr4Cg',
                'Referer': 'https://www.disneyplus.com/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                'x-application-version': '1.1.2',
                'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                'x-bamsdk-platform': 'windows',
                'x-bamsdk-version': '4.19'
            }
            self.headre_series = {
                'accept': 'application/json',
                'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ2NjIyMjksInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wMlQwNToxNzowOS40NjQrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IkJSIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6Ii0wMzowMCIsIm5hbWUiOiJBbWVyaWNhXC9TYW9fUGF1bG8ifSwicmF0aW5nX3N5c3RlbXMiOlsiZGpjdHEiXX0sImV4cGlyZXNfb24iOiIyMDIxLTAzLTAyVDA5OjE3OjA5LjQ2NCswMDAwIiwiZXhwZXJpbWVudHMiOnsiNDM1NjBlNDEmJmFhdGVzdEphbjI3Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIxODYuMTkzLjE4My4xMTMiLCJ0eXBlIjoiUkVHSVNURVJFRCIsInZlcnNpb24iOiJWMi4wLjAiLCJibGFja291dHMiOnsiZW50aXRsZW1lbnRzIjpbXSwiZGF0YSI6e30sInJ1bGVzIjp7InZpb2xhdGVkIjpbXX19LCJwYXJ0bmVyIjp7Im5hbWUiOiJkaXNuZXkifSwibG9jYXRpb24iOnsiY291bnRyeV9jb2RlIjoiQlIiLCJjaXR5X25hbWUiOiJpbXBlcmF0cml6IiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6Im1hcmFuaGFvIiwiZG1hIjowLCJyZWdpb25fbmFtZSI6Im5vcnRoZWFzdCIsInR5cGUiOiJaSVBfQ09ERSIsImFzbiI6MjgxOTEsInppcF9jb2RlIjoiNjU5MDAtMDEwIn0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDJUMDU6MTc6MDkuNDY0KzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6Ijg5YjJiNzYwLTdiMTYtMTFlYi1iZTk1LTAyNDJhYzExMDAwYyIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6ImIxNzI2ZjM4LTMzNTEtNGE0My04NTA2LTZkODEwMWYwZmI4MCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRKQ1RRIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ2NzY2MjksImlhdCI6MTYxNDY2MjIyOSwianRpIjoiOTYxZWUwMDAtM2Q0ZS00MzRjLWI5ODctNTBkYmI1NmNkOTg0In0.8US6RE1Z8UuoyN3PlIWRmKhT1bOhqP4DWVAtOx8jdGXwYx2NFwbnFVqA5uo785dV5UNBkrBy7MSYlK2Gw7bJAA',
                'Referer': 'https://www.disneyplus.com/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36',
                'x-application-version': '1.1.2',
                'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                'x-bamsdk-platform': 'windows',
                'x-bamsdk-version': '4.19'
            }
            url = {
                'Movie': 'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/BR/audience/false/maturity/1499/language/en/setId/9f7c38e5-41c3-47b4-b99e-b5b3d2eb95d4/pageSize/30/page/1',
                'Series': 'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/BR/audience/false/maturity/1499/language/en/setId/53adf843-491b-40ae-9b46-bccbceed863b/pageSize/30/page/1'
            }
            for type in url:
                if type == 'Movie':
                    yield scrapy.Request(url=url[type], meta={'type':type}, headers=self.headre_movie)
                else:
                    yield scrapy.Request(url=url[type], meta={'type':type}, headers=self.headre_series, callback=self.parse_series)
        except Exception as e:
            print(e)

    def parse(self, response):
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta,  dont_filter=True, callback=self.parse)
        else:
            if 'Enter the characters you see below' in response.text:
                yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True, callback=self.parse)
            else:
                try:
                    with open(f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney BR\link\\{response.meta["type"]}_{response.url.split("/")[-1]}.json','wb') as f:
                        f.write(response.body)
                        f.close()
                    data_json = json.loads(response.text)
                    if data_json['data']['CuratedSet']['items'] != []:
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'BR':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedFamilyId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedFamilyId = j['family']['encodedFamilyId']
                                if content !='' and encodedFamilyId!='':
                                    link = f"https://www.disneyplus.com/movies/{content}/{encodedFamilyId}"
                                    item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                    item['link'] = link
                                    yield item
                        else:
                            print("other country")
                    else:
                        self.flag = False
                    if self.flag:
                        next_url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/BR/audience/false/maturity/1499/language/en/setId/9f7c38e5-41c3-47b4-b99e-b5b3d2eb95d4/pageSize/30/page/{self.page}'
                        self.page += 1
                        yield scrapy.Request(url=next_url, headers=self.headre_movie, meta={'type': response.meta['type']}, callback=self.parse, dont_filter=True)
                except Exception as e:
                    print(e)

    def parse_series(self, response):
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True,
                                 callback=self.parse)
        else:
            if 'Enter the characters you see below' in response.text:
                yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True,
                                     callback=self.parse)
            else:
                try:
                    with open(f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney BR\link\\{response.meta["type"]}_{response.url.split("/")[-1]}.json', 'wb') as f:
                        f.write(response.body)
                        f.close()
                    data_json = json.loads(response.text)
                    if data_json['data']['CuratedSet']['items'] != []:
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'BR':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedSeriesId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedSeriesId = j['encodedSeriesId']
                                if content != '' and encodedSeriesId != '':
                                    link = f"https://www.disneyplus.com/series/{content}/{encodedSeriesId}"
                                    item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                    item['link'] = link
                                    yield item
                        else:
                            print("other country")
                    else:
                        self.flag = False
                    if self.flag:
                        next_url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/BR/audience/false/maturity/1499/language/en/setId/53adf843-491b-40ae-9b46-bccbceed863b/pageSize/30/page/{self.page}'
                        self.page += 1
                        yield scrapy.Request(url=next_url, headers=self.headre_series, meta={'type': response.meta['type']}, callback=self.parse_series, dont_filter=True)
                except Exception as e:
                    print(e)

# execute('scrapy crawl daily_links_disney_br'.split())
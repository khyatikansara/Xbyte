import pandas as pd


def jsontoexcel():
    try:
        json_file = "D:\khyati-H\CRM\Projects AP\Minnow TV\json Files\Disney BR\data_05_03_2021.json"
        excel_File = "D:\khyati-H\CRM\Projects AP\Minnow TV\json Files\Disney BR\data_05_03_2021.xlsx"
        data = pd.read_json(json_file, lines=True)
        data.to_excel(excel_File, index=False)
        print("JSON TO EXCEL CONVERT DONE")
    except Exception as e:
        print(f"JSON TO EXCEL CONVERT ERROR : {str(e)}")

# jsontoexcel()
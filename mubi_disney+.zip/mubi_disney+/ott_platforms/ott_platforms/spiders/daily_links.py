# -*- coding: utf-8 -*-
import datetime
import hashlib
from scrapy.cmdline import execute
import scrapy
from ott_platforms.items import OTTPlatformsLinksItem


class DailyLinksSpider(scrapy.Spider):
    name = 'daily_links'
    allowed_domains = []
    
    handle_httpstatus_list = [503, 502, 501, 500]

    OTT_Platform_Number = 32229790
    Source = 'Amazon Prime'

    def start_requests(self):
        try:
            urls = [
                'https://www.amazon.com/gp/video/storefront/ref=atv_tc_m?filterId=OFFER_FILTER%3DALL&node=2858905011',
                'https://www.amazon.com/gp/video/storefront/ref=atv_tc_tv?filterId=OFFER_FILTER%3DALL&node=2864549011']
            for url in urls:
                yield scrapy.Request(
                    url=url
                )
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            header = {
                'accept-language': 'en-US,en;q=0.9',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
                          'application/signed-exchange;v=b3;q=0.9',
                'cache-control': 'max-age=0',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                "user-agent": 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
                # "Proxy-Authorization": basic_auth_header(proxy[0], proxy[1])
            }
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(
                    url=response.url,
                    headers=header,
                    meta=response.meta,
                    dont_filter=True,
                    callback=self.parse
                )
            else:
                if 'Enter the characters you see below' in response.text:
                    yield scrapy.Request(
                        url=response.url,
                        headers=header,
                        meta=response.meta,
                        dont_filter=True,
                        callback=self.parse
                    )
                else:
                    item = OTTPlatformsLinksItem()
                    # page_name = f'E:\Maulik\\amazpn_prime_pages\\{self.today}.html'
                    # with open(page_name, 'ab') as f:
                    #     f.write(response.body)
                    #     f.close()
                    # links = response.xpath('//*[@alt="Prime"]/../../../../..//*[@class="ctTZXu _2Q1eQS tst-packshot tst-packshot-link"]/a/@href').getall()
                    # if not links:
                    links = response.xpath('//a[contains(@href, "gp/video/detail")]/@href').getall()
                    for link in links:
                        
                        if '/gp/video/detail' in link:
                            link = 'https://www.amazon.com' + link.split('/ref')[0]
                            item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                            item['link'] = link
                            yield item

                    other_genere = response.xpath('//*[contains(text(), "See more")]/@href').getall()
                    for gener in other_genere:
                        # 
                        if '/gp/video/' in gener:
                            gener = 'https://www.amazon.com' + gener
                            yield scrapy.Request(
                                url=gener
                            )
                    #
                    # see_more = response.xpath('//*[contains(@href, "/gp/video/storefront")]/button/../@href').get()
                    # if see_more:
                    #     # 
                    #     if '/gp/video/' in see_more:
                    #         see_more = 'https://www.amazon.com' + see_more
                    #         yield scrapy.Request(
                    #             url=see_more
                    #         )

                    try:
                        urls = [
                            'https://www.amazon.com/s/ref=atv_cat_new?node=13431540011&field-ways_to_watch=12007867011&field-is_prime_benefit=0&field-entity_type=14069184011&bbn=13431540011&search-alias=instant-video']
                        header = {
                            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                            "accept-language": "en-US,en;q=0.9",
                            "cache-control": "max-age=0",
                            "downlink": "6.3",
                            "ect": "4g",
                            "rtt": "100",
                            "sec-fetch-dest": "document",
                            "sec-fetch-mode": "navigate",
                            "sec-fetch-site": "none",
                            "sec-fetch-user": "?1",
                            "upgrade-insecure-requests": "1",
                            "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36"
                        }
                        for url in urls:
                            
                            yield scrapy.Request(
                                url=url,
                                # url='https://www.amazon.com/gp/video/search/ref=atv_tv_hom_1_c_innhq1_2_smr?queryToken=eyJ0eXBlIjoicXVlcnkiLCJuYXYiOnRydWUsInBpIjoiZGVmYXVsdCIsInNlYyI6ImNlbnRlciIsInN0eXBlIjoic2VhcmNoIiwicXJ5IjoiZmllbGQtd2F5c190b193YXRjaD0xMjAwNzg2NTAxMSZwX25fZW50aXR5X3R5cGU9MTQwNjkxODUwMTEmYWR1bHQtcHJvZHVjdD0wJmJxPShhbmQgKGFuZCAoYW5kIGZpZWxkLWlzX3ByaW1lX2JlbmVmaXQ6JzEnIChub3QgKG9yIGdlbnJlOidhdl9nZW5yZV9lcm90aWMnIGF2X3ByaW1hcnlfZ2VucmU6J2F2X2dlbnJlX2Vyb3RpYycpKSAobm90IChvciBnZW5yZTonYXZfZ2VucmVfa2lkcycgYXZfcHJpbWFyeV9nZW5yZTonYXZfZ2VucmVfa2lkcycpKSkgKGFuZCAob3IgZ2VucmU6J2F2X2dlbnJlX3N1c3BlbnNlJyBhdl9wcmltYXJ5X2dlbnJlOidhdl9nZW5yZV9zdXNwZW5zZScpIGVudGl0eV90eXBlOidUViBTaG93JykpIChub3QgYXZfa2lkX2luX3RlcnJpdG9yeTonVVMnKSkmZmllbGQtaXNfcHJpbWVfYmVuZWZpdD0xJnNlYXJjaC1hbGlhcz1pbnN0YW50LXZpZGVvJnFzLWF2X3JlcXVlc3RfdHlwZT00JnFzLWlzLXByaW1lLWN1c3RvbWVyPTAiLCJydCI6ImlOTmhxMXNtciIsInR4dCI6Ik15c3RlcnkgYW5kIHRocmlsbGVyIFRWIiwib2Zmc2V0IjowLCJucHNpIjowLCJvcmVxIjoiYmE4YWIwZjUtMjM2NC00ZmMxLWEyYWUtYmUzM2Y4NDBmNGE2OjE2MDc0MDQzODEwMDAiLCJzdHJpZCI6IjE6MTFHWEhRV0dLQUU2VDEjI01aUVdHWkxVTVZTRUdZTFNONTJYR1pMTSIsIm9yZXFrIjoiTGk2K28vZ3NoMGhHQ2NUZ2FUZ0tMem1iQXp0em5nb3NvZUkwNnphaGZkST0iLCJvcmVxa3YiOjF9&pageId=default&queryPageType=browse&ie=UTF8',
                                callback=self.new_realese,
                                headers=header
                            )
                    except Exception as e:
                        print(e)

        except Exception as e:
            print(e)

    def new_realese(self, response):
        header = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "accept-language": "en-US,en;q=0.9",
            "cache-control": "max-age=0",
            "downlink": "6.3",
            "ect": "4g",
            "rtt": "100",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36"
        }
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(
                url=response.url,
                headers=header,
                meta=response.meta,
                dont_filter=True,
                callback=self.new_realese
            )
        else:
            if 'Enter the characters you see below' in response.text:
                yield scrapy.Request(
                    url=response.url,
                    headers=header,
                    meta=response.meta,
                    dont_filter=True,
                    callback=self.new_realese
                )
            else:

                item = OTTPlatformsLinksItem()
                links = response.xpath('//a[contains(text(), "  Prime Video")]/@href').extract()

                for link in links:
                    
                    link = 'https://www.amazon.com' + link.split('/ref')[0]
                    item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                    item['link'] = link
                    yield item

                next_page = response.xpath('//*[@class="a-last"]/a/@href').get()
                if next_page:
                    # 
                    next_page = 'https://www.amazon.com' + next_page
                    yield scrapy.Request(
                        url=next_page,
                        callback=self.new_realese,
                        headers=header
                    )


# execute('scrapy crawl daily_links'.split())
import datetime
import hashlib
import json
import pymongo
import scrapy
from ott_platforms.items import OTTPlatformsMoviesItem, OTTPlatformsAvailabilitiesItem, OTTPlatformsShowsItem, \
    OTTPlatformsSeasonsItem, OTTPlatformsEpisodesItem
from scrapy.cmdline import execute


class GetDataAmazonInstantUSSpider(scrapy.Spider):
    name = 'get_data_amazoninstant_us'
    allowed_domains = []

    handle_httpstatus_list = [503, 502, 501, 500]

    OTT_Platform_Number = "amazoninstant_us"

    def __init__(self, start='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': self.OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']

        con = pymongo.MongoClient('mongodb://localhost:27017/')
        # self.db = con[f'OTT_{Source}_{Country}']
        self.db = con[f'OTT_AmazonPrime_US']
        self.link_master = self.db[f'OTT_AmazonPrime_US_Links_Master']

    def start_requests(self):
        try:
            links = self.link_master.find({'Status': "Pending"}, no_cursor_timeout=True).limit(100).skip(self.start)
            print(self.link_master.find({'Status': "Pending"}).count())
            for link in links:
                _id = link['_id']
                url = link['link']
                if '/ref=' in url:
                    url = url.split('/ref=')[0]
                asin = url.strip('/').split('/')[-1]
                header = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
                }
                yield scrapy.Request(
                    url=url,
                    headers=header,
                    meta={
                        'Id': _id,
                        'asin': asin,
                        'url': url
                    }
                )
        except Exception as e:
            print(e)


    def parse(self, response):
        try:
            Id = response.meta['Id']
            main_asin = response.meta["asin"]
            if '?' in main_asin:
                main_asin = main_asin.split('?')[0]
            url = response.meta["url"]
            header = {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "accept-language": "en-US,en;q=0.9",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": "1",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
            }
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(
                    url=url,
                    headers=header,
                    meta={
                        'Id': Id,
                        'asin': main_asin,
                        'url': url
                    },
                    dont_filter=True
                )
            else:
                if 'Enter the characters you see below' in response.text:
                    yield scrapy.Request(
                        url=url,
                        headers=header,
                        meta={
                            'Id': Id,
                            'asin': main_asin,
                            'url': url
                        },
                        dont_filter=True
                    )
                else:
                    # For ShowData
                    if not 'Watch for $0.00 with Prime' in response.text:
                        page_name = f'F:\Maulik\page_save\streaming_ivr\\amazon_prime\\{main_asin}_instant.html'
                        with open(page_name, 'wb') as f:
                            f.write(response.body)
                            f.close()

                        Source = 'AmazonInstantVideo'

                        Title = response.xpath('//h1[@data-automation-id="title"]/text()').get()
                        if not Title:
                            Title = response.xpath('//*[@class="PTbhtZ"]/@alt').get()
                        Actors = response.xpath('//span[contains(text(), "Starring")]/../../dd/a//text()').getall()
                        Directors = response.xpath('//span[contains(text(), "Directors")]/../../dd/a//text()').getall()
                        Crew = None
                        Year = response.xpath('//*[@data-automation-id="release-year-badge"]/text()').get(None)
                        if Year:
                            Year = int(Year)
                        try:
                            PosterUrl = response.xpath('//img/@srcset').get().split(',')[-1].split()[0].strip()
                        except Exception as e:
                            print(e)
                            PosterUrl = None
                        Description = response.xpath('//*[@for="atfSynopsisExpander"]/../div/text()').get(None)
                        if not Description:
                            Description = response.xpath('//*[@class="_3qsVvm _1wxob_"]/div/text()').get(None)

                        Url = response.url
                        Country = 'US'
                        IMDBId = None
                        Season = response.xpath(
                            '//*[@class="_1TO3hV _3ra7oO"]/span[1]/text()|//*[@class="XqYSS8 _2c06dW"]/span/text()').get(
                            None)
                        price_data = response.xpath('''//*[contains(text(), '{"props":{"state":{"features":{"isElcano"')]/text()''').get()
                        price_json = json.loads(price_data)
                        found_asin = price_json["props"]["state"]["pageTitleId"]
                        ProviderUniqueId = found_asin
                        if Season:
                            show = OTTPlatformsShowsItem()
                            show["_id"] = found_asin
                            show["Title"] = Title
                            show["Actors"] = Actors
                            show["Directors"] = Directors
                            show["Crew"] = Crew
                            show["Year"] = Year
                            show["Source"] = Source
                            show["PosterUrl"] = PosterUrl
                            show["Description"] = Description
                            show["ProviderUniqueId"] = ProviderUniqueId
                            show["IMDBId"] = IMDBId
                            show["Url"] = Url
                            show["Country"] = Country
                            show["TMDBId"] = None
                            show["Modifier"] = None
                            show["Modified"] = datetime.datetime.utcnow()
                            show["Scrap_datetime"] = datetime.datetime.now()
                            show["SlotNumber"] = 1
                            yield show


                            availabilities = OTTPlatformsAvailabilitiesItem()
                            availabilities_season = OTTPlatformsAvailabilitiesItem()
                            availabilities["PreSale"] = None
                            availabilities["Modifier"] = None
                            availabilities["StartDate"] = None
                            availabilities["Country"] = 'US'
                            availabilities["DeliveryMethod"] = 'OnDemand'
                            availabilities["Modified"] = datetime.datetime.utcnow()

                            Links = list()
                            Links.append({'Url': Url, 'Platform': 'Web'})
                            availabilities["Links"] = Links

                            availabilities_season["PreSale"] = None
                            availabilities_season["Modifier"] = None
                            availabilities_season["StartDate"] = None
                            availabilities_season["Country"] = 'US'
                            availabilities_season["DeliveryMethod"] = 'OnDemand'
                            availabilities_season["Modified"] = datetime.datetime.utcnow()

                            Links = list()
                            Links.append({'Url': Url, 'Platform': 'Web'})
                            availabilities_season["Links"] = Links

                            is_price = False
                            price_detail = dict()
                            if 'moreWaysToWatch' in price_json["props"]["state"]["action"]["atf"][found_asin][
                                "acquisitionActions"]:
                                rent_buy_list = \
                                    price_json["props"]["state"]["action"]["atf"][found_asin]["acquisitionActions"][
                                        "moreWaysToWatch"]["children"]

                                if len(rent_buy_list) == 2:
                                    if 'sType' in rent_buy_list[0]["children"][0].keys():
                                        try:
                                            movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                            if 'Rent {conditionalLineBreak}{bold}HD{end}' in movie_rental_HD_data:
                                                price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rental_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rental_HD"] = ''

                                        try:
                                            movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                            if 'Buy' in movie_buy_HD_data:
                                                price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_HD"] = ''

                                        try:
                                            movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                            if 'Rent' in movie_rent_SD_data and 'SD' in movie_rent_SD_data:
                                                price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rent_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rent_SD"] = ''

                                        try:
                                            movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                            if 'Buy' in movie_buy_SD_data and 'SD' in movie_buy_SD_data:
                                                price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_SD"] = ''

                                    else:
                                        try:
                                            movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                            if 'Rent' in movie_rental_HD_data and 'HD' in movie_rental_HD_data:
                                                price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rental_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rental_HD"] = ''

                                        try:
                                            movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                            if 'Buy' in movie_buy_HD_data:
                                                price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_HD"] = ''

                                        try:
                                            movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                            if 'Rent' in movie_rent_SD_data and 'SD' in movie_rent_SD_data:
                                                price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rent_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rent_SD"] = ''

                                        try:
                                            movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                            if 'Buy' in movie_buy_SD_data and 'SD' in movie_buy_SD_data:
                                                price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_SD"] = ''

                                else:
                                    try:
                                        movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                        if 'Rent' in movie_rental_HD_data and 'HD' in movie_rental_HD_data:
                                            price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                -1].strip()
                                        else:
                                            price_detail["movie_rental_HD"] = ''
                                    except Exception as e:
                                        price_detail["movie_rental_HD"] = ''

                                    try:
                                        movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                        if 'Buy' in movie_buy_HD_data:
                                            price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_buy_HD"] = ''
                                    except Exception as e:
                                        movie_buy_HD = ''

                                    try:
                                        movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                        if 'Rent' in movie_rent_SD_data and 'SD' in movie_rent_SD_data:
                                            price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_rent_SD"] = ''
                                    except Exception as e:
                                        price_detail["movie_rent_SD"] = ''

                                    try:
                                        movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                        if 'Buy' in movie_buy_SD_data and 'SD' in movie_buy_SD_data:
                                            price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_buy_SD"] = ''
                                    except Exception as e:
                                        price_detail["movie_buy_SD"] = ''

                                for price in price_detail:
                                    if price_detail[price]:
                                        is_price = True
                                        break

                                if is_price:
                                    for price in price_detail:
                                        if price_detail[price]:
                                            if 'buy' in price:
                                                Buy_Type = 'Buy'
                                            else:
                                                Buy_Type = 'Rent'

                                            if 'HD' in price:
                                                Format = 'HD'
                                            else:
                                                Format = 'SD'

                                            Price = price_detail[price].replace("$", "")
                                            availabilities["ProviderUniqueId"] = found_asin
                                            # availabilities["ProviderUniqueSeasonId"] = found_asin
                                            availabilities["Price"] = Price
                                            availabilities["Currency"] = 'USD'
                                            availabilities["ExpirationDate"] = None
                                            availabilities["Provider"] = Source
                                            availabilities["OfferType"] = Buy_Type
                                            availabilities["Quality"] = Format
                                            unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                                availabilities["Price"]) + str(availabilities["Provider"]) + str(
                                                availabilities["OfferType"]) + str(availabilities["Quality"])
                                            availabilities["_id"] = int(
                                                hashlib.md5(bytes(unique_key + 'Show', encoding='utf8')).hexdigest(), 16) % (
                                                                            10 ** 8)
                                            yield availabilities

                                            # availabilities_season["ProviderUniqueId"] = found_asin
                                            availabilities_season["ProviderUniqueSeasonId"] = found_asin
                                            availabilities_season["Price"] = Price
                                            availabilities_season["Currency"] = 'USD'
                                            availabilities_season["ExpirationDate"] = None
                                            availabilities_season["Provider"] = Source
                                            availabilities_season["OfferType"] = Buy_Type
                                            availabilities_season["Quality"] = Format
                                            unique_key = str(availabilities_season["ProviderUniqueSeasonId"]) + str(
                                                availabilities_season["Price"]) + \
                                                         str(availabilities_season["Provider"]) + str(
                                                availabilities_season["OfferType"]) + \
                                                         str(availabilities_season["Quality"])
                                            availabilities_season["_id"] = int(
                                                hashlib.md5(bytes(unique_key + 'Season', encoding='utf8')).hexdigest(), 16) % (
                                                                                   10 ** 8)
                                            yield availabilities_season

                            # For Season Data
                            Season = int(Season.replace('Season', '').strip())
                            season = OTTPlatformsSeasonsItem()
                            season["_id"] = found_asin
                            season["Modified"] = datetime.datetime.utcnow()
                            season["Modifier"] = None
                            season["SeasonNumber"] = Season
                            season["Description"] = Description
                            season["Country"] = Country
                            season["Title"] = Title
                            season["Url"] = Url
                            season["IMDBId"] = IMDBId
                            season["PosterUrl"] = PosterUrl
                            season["Crew"] = Crew
                            season["Source"] = Source
                            season["Directors"] = Directors
                            season["Actors"] = Actors
                            season["TMDBId"] = None
                            season["Year"] = Year
                            season["Scrap_datetime"] = datetime.datetime.now()
                            season["SlotNumber"] = 1
                            season["ProviderUniqueId"] = show["ProviderUniqueId"]
                            season["ProviderUniqueSeasonId"] = found_asin
                            yield season

                            # For Episode Data
                            data = response.xpath("""//*[contains(text(), '{"props":{"state":{"features":{"useFaq":true,"us')]/text()""").get()
                            if not data:
                                data = response.xpath("""//*[contains(text(), '{"props":{"state":{"features":{"enableSPAGiftCard":false')]/text()""").get()
                            json_data = json.loads(data)
                            episode_data = json_data["props"]["state"]["detail"]["detail"]
                            for asin in episode_data:
                                Episode_link = f'https://www.amazon.com/gp/video/detail/{asin}'
                                if 'episodeNumber' in json_data["props"]["state"]["detail"]["detail"][asin].keys():
                                    episode = OTTPlatformsEpisodesItem()
                                    Episode_No = json_data["props"]["state"]["detail"]["detail"][asin]["episodeNumber"]
                                    Episode_Title = json_data["props"]["state"]["detail"]["detail"][asin]["title"]
                                    Episode_Description = json_data["props"]["state"]["detail"]["detail"][asin][
                                        "synopsis"] if 'synopsis' in json_data["props"]["state"]["detail"]["detail"][
                                        asin].keys() else ''
                                    ImageUrl = json_data["props"]["state"]["detail"]["detail"][asin]["images"]["packshot"]
                                    try:
                                        Year = int(json_data["props"]["state"]["detail"]["detail"][asin]["releaseYear"])
                                    except:
                                        Year = None

                                    try:
                                        Directors = []
                                        Directors_data = \
                                            json_data["props"]["state"]["detail"]["detail"][asin]["contributors"][
                                                "directors"]
                                        for director in Directors_data:
                                            Directors.append(director['name'])
                                    except Exception as e:
                                        Directors = None

                                    try:
                                        Actors = []
                                        Actors_data = json_data["props"]["state"]["detail"]["detail"][asin]["contributors"][
                                            "starringActors"]
                                        for actor in Actors_data:
                                            Actors.append(actor['name'])
                                    except Exception as e:
                                        Actors = None

                                    episodeimdb = None

                                    episode['_id'] = asin
                                    episode['Modified'] = datetime.datetime.utcnow()
                                    episode['Modifier'] = None
                                    episode['EpisodeNumber'] = Episode_No
                                    episode['Description'] = Episode_Description
                                    episode['Country'] = 'US'
                                    episode['Title'] = Episode_Title
                                    episode['Url'] = Episode_link
                                    episode['IMDBId'] = episodeimdb
                                    episode['ImageUrl'] = ImageUrl
                                    episode['Crew'] = None
                                    episode['Source'] = Source
                                    episode['Directors'] = Directors
                                    episode['Actors'] = Actors
                                    episode['TMDBId'] = None
                                    episode['Year'] = Year
                                    episode['Scrap_datetime'] = datetime.datetime.now()
                                    episode['SlotNumber'] = 1
                                    episode['ProviderUniqueId'] = show["ProviderUniqueId"]
                                    episode['ProviderUniqueSeasonId'] = season["ProviderUniqueSeasonId"]
                                    episode['ProviderUniqueEpisodeId'] = asin
                                    yield episode

                                    # Episode Availabilities

                                    availabilities = OTTPlatformsAvailabilitiesItem()

                                    # availabilities["ProviderUniqueSeasonId"] = found_asin
                                    availabilities["ProviderUniqueEpisodeId"] = asin
                                    availabilities["PreSale"] = None
                                    availabilities["Modifier"] = None
                                    availabilities["StartDate"] = None
                                    availabilities["Country"] = 'US'
                                    availabilities["DeliveryMethod"] = 'OnDemand'
                                    availabilities["Modified"] = datetime.datetime.utcnow()

                                    Links = list()
                                    Links.append({'Url': Episode_link, 'Platform': 'Web'})
                                    availabilities["Links"] = Links

                                    price_detail = dict()
                                    is_price = False
                                    if 'moreWaysToWatch' in price_json["props"]["state"]["action"]["atf"][found_asin][
                                        "acquisitionActions"].keys():
                                        rent_buy_list = \
                                            price_json["props"]["state"]["action"]["atf"][found_asin][
                                                "acquisitionActions"][
                                                "moreWaysToWatch"]["children"]
                                        if len(rent_buy_list) == 2:
                                            if 'sType' in rent_buy_list[0]["children"][0].keys():
                                                try:
                                                    episode_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                                    if 'Episode' in episode_buy_HD_data:
                                                        price_detail["episode_buy_HD"] = episode_buy_HD_data.split(' ')[
                                                            -1]
                                                except:
                                                    price_detail["episode_buy_HD"] = ''

                                                try:
                                                    episode_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                                    if 'Episode' in episode_buy_SD_data:
                                                        price_detail["episode_buy_SD"] = episode_buy_SD_data.split(' ')[
                                                            -1]
                                                except:
                                                    price_detail["episode_buy_SD"] = ''

                                            else:
                                                try:
                                                    episode_buy_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                                    if 'Episode' in episode_buy_HD_data:
                                                        price_detail["episode_buy_HD"] = episode_buy_HD_data.split(' ')[
                                                            -1]
                                                except:
                                                    price_detail["episode_buy_HD"] = ''

                                                try:
                                                    episode_buy_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                                    if 'Episode' in episode_buy_SD_data:
                                                        price_detail["episode_buy_SD"] = episode_buy_SD_data.split(' ')[
                                                            -1]
                                                except:
                                                    price_detail["episode_buy_SD"] = ''


                                        else:
                                            try:
                                                episode_buy_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                                if 'Episode' in episode_buy_HD_data:
                                                    price_detail["episode_buy_HD"] = episode_buy_HD_data.split(' ')[-1]
                                            except:
                                                price_detail["episode_buy_HD"] = ''

                                            try:
                                                episode_buy_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                                if 'Episode' in episode_buy_SD_data:
                                                    price_detail["episode_buy_SD"] = episode_buy_SD_data.split(' ')[-1]
                                            except:
                                                price_detail["episode_buy_SD"] = ''


                                    else:
                                        button = ''.join(response.xpath(
                                            '//*[@class="abwJ5F tFxybk _2LF_6p"]//*[@class="_2Kmlqa _15Ikr8 _20uSE4 _2X_Irl tvod-button av-button"]//text()').getall())
                                        if button:
                                            if 'Episode' in button:
                                                if 'SD' in button:
                                                    price_detail["episode_buy_SD"] = button.split(' ')[-1]
                                                else:
                                                    price_detail["episode_buy_HD"] = button.split(' ')[-1]

                                            else:
                                                if 'SD' in button:
                                                    price_detail["season_buy_SD"] = button.split(' ')[-1]
                                                else:
                                                    price_detail["season_buy_HD"] = button.split(' ')[-1]
                                        else:
                                            price_detail["episode_buy_HD"] = ''
                                            price_detail["episode_buy_SD"] = ''

                                    for price in price_detail:
                                        if price_detail[price]:
                                            is_price = True
                                            break

                                    if is_price:
                                        for price in price_detail:
                                            if price_detail[price]:
                                                if 'buy' in price:
                                                    Buy_Type = 'Buy'
                                                else:
                                                    Buy_Type = 'Rent'

                                                if 'HD' in price:
                                                    Format = 'HD'
                                                else:
                                                    Format = 'SD'

                                                Price = price_detail[price].replace("$", "")
                                                availabilities["Price"] = Price
                                                availabilities["Currency"] = 'USD'
                                                availabilities["ExpirationDate"] = None
                                                availabilities["Provider"] = Source
                                                availabilities["OfferType"] = Buy_Type
                                                availabilities["Quality"] = Format
                                                unique_key = str(availabilities["ProviderUniqueEpisodeId"]) + str(
                                                    availabilities["Price"]) + str(availabilities["Provider"]) + str(
                                                    availabilities["OfferType"]) + str(availabilities["Quality"])
                                                availabilities["_id"] = int(
                                                    hashlib.md5(bytes(unique_key + 'Episode', encoding='utf8')).hexdigest(),
                                                    16) % (10 ** 8)
                                                yield availabilities

                        else:
                            movie = OTTPlatformsMoviesItem()

                            # make sure to take unique value for this if found for specific movie. do not generate using any hash function
                            movie["_id"] = found_asin
                            movie["Title"] = Title
                            movie["Actors"] = Actors
                            movie["Directors"] = Directors
                            movie["Crew"] = Crew
                            movie["Year"] = Year
                            movie["Source"] = Source
                            movie["PosterUrl"] = PosterUrl
                            movie["Description"] = Description
                            movie["ProviderUniqueId"] = ProviderUniqueId
                            movie["IMDBId"] = IMDBId
                            movie["Url"] = Url
                            movie["Country"] = Country
                            movie["TMDBId"] = None
                            movie["Modifier"] = None
                            movie["Modified"] = datetime.datetime.utcnow()
                            movie["Scrap_datetime"] = datetime.datetime.now()
                            movie["SlotNumber"] = 1
                            yield movie

                            # Movie Availabilities
                            availabilities = OTTPlatformsAvailabilitiesItem()
                            availabilities["ProviderUniqueId"] = found_asin
                            availabilities["PreSale"] = None
                            availabilities["Modifier"] = None
                            availabilities["StartDate"] = None
                            availabilities["Country"] = 'US'
                            availabilities["DeliveryMethod"] = 'OnDemand'
                            availabilities["Modified"] = datetime.datetime.utcnow()

                            Links = list()
                            Links.append({'Url': Url, 'Platform': 'Web'})
                            availabilities["Links"] = Links

                            price_data = response.xpath(
                                '''//*[contains(text(), '{"props":{"state":{"features":{"isElcano"')]/text()''').get()
                            price_json = json.loads(price_data)
                            found_asin = price_json["props"]["state"]["pageTitleId"]
                            is_price = False
                            price_detail = dict()
                            if 'moreWaysToWatch' in price_json["props"]["state"]["action"]["atf"][found_asin][
                                "acquisitionActions"]:
                                rent_buy_list = \
                                    price_json["props"]["state"]["action"]["atf"][found_asin]["acquisitionActions"][
                                        "moreWaysToWatch"]["children"]

                                if len(rent_buy_list) == 2:
                                    if 'sType' in rent_buy_list[0]["children"][0].keys():
                                        try:
                                            movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                            if 'Rent {conditionalLineBreak}{bold}HD{end}' in movie_rental_HD_data:
                                                price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rental_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rental_HD"] = ''

                                        try:
                                            movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                            if 'Buy' in movie_buy_HD_data:
                                                price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_HD"] = ''

                                        try:
                                            movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                            if 'Rent {conditionalLineBreak}{bold}SD{end}' in movie_rent_SD_data:
                                                price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rent_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rent_SD"] = ''

                                        try:
                                            movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                            if 'Buy {conditionalLineBreak}{bold}SD{end}' in movie_buy_SD_data:
                                                price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_SD"] = ''

                                    else:
                                        try:
                                            movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                            if 'Rent {conditionalLineBreak}{bold}HD{end}' in movie_rental_HD_data:
                                                price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rental_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rental_HD"] = ''

                                        try:
                                            movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                            if 'Buy' in movie_buy_HD_data:
                                                price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_HD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_HD"] = ''

                                        try:
                                            movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                            if 'Rent {conditionalLineBreak}{bold}SD{end}' in movie_rent_SD_data:
                                                price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[
                                                    -1].strip()
                                            else:
                                                price_detail["movie_rent_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_rent_SD"] = ''

                                        try:
                                            movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                            if 'Buy {conditionalLineBreak}{bold}SD{end}' in movie_buy_SD_data:
                                                price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                            else:
                                                price_detail["movie_buy_SD"] = ''
                                        except Exception as e:
                                            price_detail["movie_buy_SD"] = ''

                                else:
                                    try:
                                        movie_rental_HD_data = rent_buy_list[-2]["children"][0]["label"]
                                        if 'Rent {conditionalLineBreak}{bold}HD{end}' in movie_rental_HD_data:
                                            price_detail["movie_rental_HD"] = movie_rental_HD_data.split(' ')[
                                                -1].strip()
                                        else:
                                            price_detail["movie_rental_HD"] = ''
                                    except Exception as e:
                                        price_detail["movie_rental_HD"] = ''

                                    try:
                                        movie_buy_HD_data = rent_buy_list[-1]["children"][0]["label"]
                                        if 'Buy' in movie_buy_HD_data:
                                            price_detail["movie_buy_HD"] = movie_buy_HD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_buy_HD"] = ''
                                    except Exception as e:
                                        movie_buy_HD = ''

                                    try:
                                        movie_rent_SD_data = rent_buy_list[-2]["children"][1]["label"]
                                        if 'Rent {conditionalLineBreak}{bold}SD{end}' in movie_rent_SD_data:
                                            price_detail["movie_rent_SD"] = movie_rent_SD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_rent_SD"] = ''
                                    except Exception as e:
                                        price_detail["movie_rent_SD"] = ''

                                    try:
                                        movie_buy_SD_data = rent_buy_list[-1]["children"][1]["label"]
                                        if 'Buy {conditionalLineBreak}{bold}SD{end}' in movie_buy_SD_data:
                                            price_detail["movie_buy_SD"] = movie_buy_SD_data.split(' ')[-1].strip()
                                        else:
                                            price_detail["movie_buy_SD"] = ''
                                    except Exception as e:
                                        price_detail["movie_buy_SD"] = ''

                                for price in price_detail:
                                    if price_detail[price]:
                                        is_price = True
                                        break

                                if is_price:
                                    for price in price_detail:
                                        if price_detail[price]:
                                            if 'buy' in price:
                                                Buy_Type = 'Buy'
                                            else:
                                                Buy_Type = 'Rent'

                                            if 'HD' in price:
                                                Format = 'HD'
                                            else:
                                                Format = 'SD'

                                            Price = price_detail[price].replace("$", "")
                                            availabilities["Price"] = Price
                                            availabilities["Currency"] = 'USD'
                                            availabilities["ExpirationDate"] = None
                                            availabilities["Provider"] = Source
                                            availabilities["OfferType"] = Buy_Type
                                            availabilities["Quality"] = Format
                                            unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                                availabilities["Price"]) + str(availabilities["Provider"]) + str(
                                                availabilities["OfferType"]) + str(availabilities["Quality"])
                                            availabilities["_id"] = int(
                                                hashlib.md5(bytes(unique_key + 'Movie', encoding='utf8')).hexdigest(), 16) % (
                                                                            10 ** 8)
                                            yield availabilities


                            else:
                                buttons = response.xpath('//*[@class="_2cx-XY _3tJ38a"]//button')
                                if buttons:
                                    for button in buttons:
                                        button_text = ''.join(button.xpath('.//text()').getall())
                                        if 'Buy' in button_text:
                                            if 'SD' in button_text:
                                                price_detail["movie_buy_SD"] = button_text.split(' ')[-1]
                                            else:
                                                price_detail["movie_buy_HD"] = button_text.split(' ')[-1]

                                        else:
                                            if 'SD' in button_text:
                                                price_detail["movie_rent_SD"] = button_text.split(' ')[-1]
                                            else:
                                                price_detail["movie_rental_HD"] = button_text.split(' ')[-1]
                                else:
                                    price_detail["movie_buy_SD"] = ''
                                    price_detail["movie_buy_HD"] = ''
                                    price_detail["movie_rent_SD"] = ''
                                    price_detail["movie_rental_HD"] = ''

                                if is_price:
                                    for price in price_detail:
                                        if price_detail[price]:
                                            if 'buy' in price:
                                                Buy_Type = 'Buy'
                                            else:
                                                Buy_Type = 'Rent'

                                            if 'HD' in price:
                                                Format = 'HD'
                                            else:
                                                Format = 'SD'

                                            Price = price_detail[price].replace("$", "")
                                            availabilities["Price"] = Price
                                            availabilities["Currency"] = 'USD'
                                            availabilities["ExpirationDate"] = None
                                            availabilities["Provider"] = Source
                                            availabilities["OfferType"] = Buy_Type
                                            availabilities["Quality"] = Format
                                            unique_key = str(availabilities["ProviderUniqueId"]) + str(
                                                availabilities["Price"]) + str(availabilities["Provider"]) + str(
                                                availabilities["OfferType"]) + str(availabilities["Quality"])
                                            availabilities["_id"] = int(
                                                hashlib.md5(bytes(unique_key + 'Movie', encoding='utf8')).hexdigest(), 16) % (
                                                                            10 ** 8)
                                            yield availabilities

                        try:
                            self.link_master.update({'_id': Id}, {'$set': {'Status': 'Done'}}, upsert=False)
                        except Exception as e:
                            print(e)


        except Exception as e:
            print(e)


# execute('scrapy crawl get_data_amazoninstant_us -a start=0'.split())
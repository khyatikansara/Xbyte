import json
from datetime import datetime
import pymongo
import pandas as pd


# date = datetime.now().strftime('%d_%m_%Y')
date = '16_03_2021'


def export_data_json(OTT_Platform_Number):
    try:
        master_con = pymongo.MongoClient('mongodb://maulik.k:Maulik$123@51.161.13.140:27017/?authSource=admin')
        master_data = master_con["streaming_platform"].master_data.find({'OTT_Platform_Number': OTT_Platform_Number})
        Source = master_data[0]['Source'].replace(' ', '').replace('+', '')
        Country = master_data[0]['Country']
        Location = master_data[0]['Location']

        con = pymongo.MongoClient('mongodb://localhost:27017/')
        db = con[f'OTT_{Source}_{Country}']
        movies_daily = db[f'OTT_{Source}_{Country}_Movies_{date}']
        seasons_daily = db[f'OTT_{Source}_{Country}_Seasons_{date}']
        episodes_daily = db[f'OTT_{Source}_{Country}_Episodes_{date}']


        data_list = list()
        counter = 1
        for movie in movies_daily.find():
            data_dict = dict()
            data_dict["ID"] = counter
            data_dict["Source"] = Source+'+'
            data_dict["TYPE"] = 'MOVIE'
            data_dict["Movie_Series Link"] = movie["Url"]
            data_dict["Movie_Series Title"] = movie["Title"]
            data_dict["Movie_Series Year"] = movie["Year"]
            data_dict["Movie_Series Description"] = movie["Description"]
            data_dict["Movie_Series IMDB"] = movie["IMDBId"]
            data_dict["Season_Number"] = ""
            data_dict["Episode_Number"] = ""
            data_dict["Episode_Title"] = ""
            data_dict["Episode_Description"] = ""
            data_dict["Episode_Link"] = ""
            data_dict["Episode_Date_Year"] = ""
            data_dict["Episode_IMDB"] = ""
            data_dict["Android_DeepLink"] = movie["Url"]
            data_dict["iOS_DeepLink"] = movie["Url"]
            data_dict["Country Code"] = Country
            data_dict["Location"] = Location
            data_list.append(data_dict.copy())
            counter += 1

        for season in seasons_daily.find():
            data_dict = dict()
            data_dict["ID"] = counter
            data_dict["Source"] = Source+'+'
            data_dict["TYPE"] = 'EPISODE'
            data_dict["Movie_Series Link"] = season["Url"]
            data_dict["Movie_Series Title"] = season["Title"]
            data_dict["Movie_Series Year"] = season["Year"]
            data_dict["Movie_Series Description"] = season["Description"]
            data_dict["Movie_Series IMDB"] = season["IMDBId"]
            data_dict["Season_Number"] = season["SeasonNumber"]
            for episodes in episodes_daily.find({'ProviderUniqueSeasonId': season['ProviderUniqueSeasonId']}):
                data_dict["Episode_Number"] = episodes['EpisodeNumber']
                data_dict["Episode_Title"] = episodes['Title']
                data_dict["Episode_Description"] = episodes['Description']
                data_dict["Episode_Link"] = episodes['Url']
                data_dict["Episode_Date_Year"] = episodes['Year']
                data_dict["Episode_IMDB"] = episodes['IMDBId']
                data_dict["Android_DeepLink"] = episodes['Url']
                data_dict["iOS_DeepLink"] = episodes['Url']
                data_dict["Country Code"] = Country
                data_dict["Location"] = Location
                data_list.append(data_dict.copy())
                counter += 1

        filename = f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\json Files\Disney IT\data_{datetime.strftime(datetime.now(), "%d_%m_%Y")}'
        df1 = pd.DataFrame(data_list)
        df1.to_excel(f'{filename}.xlsx')

    except Exception as e:
        print(e)


if __name__ == '__main__':
    export_data_json('disney_it')
# -*- coding: utf-8 -*-
import datetime
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from ott_platforms.items import OTTPlatformsLinksItem


class DailyLinksDisneyITSpider(scrapy.Spider):
    name = 'daily_links_disney_it'
    allowed_domains = ['www.disneyplus.com']
    today = datetime.datetime.now().strftime("%d_%m_%Y")
    handle_httpstatus_list = [503, 502, 501, 500]
    OTT_Platform_Number = 'disney_it'
    Source = 'Disney+'
    flag = True
    page = 2

    def start_requests(self):
        try:
            Movie_headers = {
                'accept': 'application/json',
                'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ5NDcxNTksInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wNVQxMjoyNTo1OS4wNTUrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IklUIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6IiswMTowMCIsIm5hbWUiOiJFdXJvcGVcL1JvbWUifSwicmF0aW5nX3N5c3RlbXMiOlsiY3VzdG9tOmRpc25leXBsdXM6a2lqa3dpanplciJdfSwiZXhwaXJlc19vbiI6IjIwMjEtMDMtMDVUMTY6MjU6NTkuMDU1KzAwMDAiLCJleHBlcmltZW50cyI6eyI0MzU2MGU0MSYmYWF0ZXN0SmFuMjciOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfSwiZTJmYzBkMzEmJkNXX2RldGFpbHNfcGFnZV90ZXN0Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIxNTEuMzEuNjcuMTcwIiwidHlwZSI6IlJFR0lTVEVSRUQiLCJ2ZXJzaW9uIjoiVjIuMC4wIiwiYmxhY2tvdXRzIjp7ImVudGl0bGVtZW50cyI6W10sImRhdGEiOnt9LCJydWxlcyI6eyJ2aW9sYXRlZCI6W119fSwicGFydG5lciI6eyJuYW1lIjoiZGlzbmV5In0sImxvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IklUIiwiY2l0eV9uYW1lIjoidHVzY2FuaWEiLCJjb25uZWN0aW9uX3R5cGUiOiJ0eCIsInN0YXRlX25hbWUiOiJ2aXRlcmJvIiwiZG1hIjowLCJyZWdpb25fbmFtZSI6ImxhemlvIiwidHlwZSI6IlpJUF9DT0RFIiwiYXNuIjoxMjY3LCJ6aXBfY29kZSI6IjAxMDE3In0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDVUMTI6MjU6NTkuMDU1KzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6ImYwZjdmYmQwLTdkYWQtMTFlYi04Nzk2LTAyNDJhYzExMDAwYyIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6ImRmYjA3NDc5LWNiNzctNDYyOS1iYmM5LTRhZmZiMTA0MGMxOCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRpc25leVBsdXNFTUVBIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ5NjE1NTksImlhdCI6MTYxNDk0NzE1OSwianRpIjoiMGVjNTc1MTMtMTQxMS00OWZlLTgxN2QtMmFjMjZkNWI2MzMzIn0.TrQwo54-gKI7qdOg6eiXdbPEHcS6_EIN9SPE7ZOMpN97S61Bf5GQP8_8TGCWtQmnWvhNStzhSUw8G7lMrmT1Cw',
                'Referer': 'https://www.disneyplus.com/',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                'x-application-version': '1.1.2',
                'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                'x-bamsdk-platform': 'windows',
                'x-bamsdk-version': '4.19'
            }
            Series_headers = {
                'accept': 'application/json',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ5NDg2NDksInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wNVQxMjo1MDo0OS4xNDIrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IklUIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6IiswMTowMCIsIm5hbWUiOiJFdXJvcGVcL1JvbWUifSwicmF0aW5nX3N5c3RlbXMiOlsiY3VzdG9tOmRpc25leXBsdXM6a2lqa3dpanplciJdfSwiZXhwaXJlc19vbiI6IjIwMjEtMDMtMDVUMTY6NTA6NDkuMTQyKzAwMDAiLCJleHBlcmltZW50cyI6eyI0MzU2MGU0MSYmYWF0ZXN0SmFuMjciOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfSwiZTJmYzBkMzEmJkNXX2RldGFpbHNfcGFnZV90ZXN0Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIyLjIzMy4xMTcuMjE4IiwidHlwZSI6IlJFR0lTVEVSRUQiLCJ2ZXJzaW9uIjoiVjIuMC4wIiwiYmxhY2tvdXRzIjp7ImVudGl0bGVtZW50cyI6W10sImRhdGEiOnt9LCJydWxlcyI6eyJ2aW9sYXRlZCI6W119fSwicGFydG5lciI6eyJuYW1lIjoiZGlzbmV5In0sImxvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IklUIiwiY2l0eV9uYW1lIjoibWlsYW5vIiwiY29ubmVjdGlvbl90eXBlIjoiZHNsIiwic3RhdGVfbmFtZSI6Im1pbGFubyIsImRtYSI6MCwicmVnaW9uX25hbWUiOiJsb21iYXJkaWEiLCJ0eXBlIjoiWklQX0NPREUiLCJhc24iOjEyODc0LCJ6aXBfY29kZSI6IjIwMTIxIn0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDVUMTI6NTA6NDkuMTQyKzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6IjY5MjExMDMwLTdkYjEtMTFlYi1hMDJlLTAyNDJhYzExMDAwNSIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6ImIxNzI2ZjM4LTMzNTEtNGE0My04NTA2LTZkODEwMWYwZmI4MCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRpc25leVBsdXNFTUVBIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ5NjMwNDksImlhdCI6MTYxNDk0ODY0OSwianRpIjoiMGU3MThkMTMtYjU2NC00MjcxLTliZWYtNDEzY2I5MGI0MjJjIn0.qhEHlYULNDZB36MQbnHA0xreft57MW_nDRNCHaHsYTF2Lmc2MTt9WVt8wO0K5AX2WFzeYK6bAk-DiSy3TD5rBw',
                'origin': 'https://www.disneyplus.com',
                'referer': 'https://www.disneyplus.com/',
                'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Safari/537.36',
                'x-application-version': '1.1.2',
                'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                'x-bamsdk-platform': 'windows',
                'x-bamsdk-version': '4.19'
            }
            main_url = {
                'Movie':"https://content.global.edge.bamgrid.com/svc/content/StandardCollection/version/3.3/region/IT/audience/false/maturity/1499/language/en/contentClass/contentType/slug/movies",
                # 'Series':"https://content.global.edge.bamgrid.com/svc/content/StandardCollection/version/3.3/region/IT/audience/false/maturity/1499/language/en/contentClass/contentType/slug/series"
            }
            for main_type in main_url:
                if main_type == 'Movie':
                    yield scrapy.Request(url=main_url[main_type], headers=Movie_headers, dont_filter=True,meta={'type':main_type})
                else:
                    yield scrapy.Request(url=main_url[main_type], headers=Series_headers, callback=self.parse1, dont_filter=True, meta={'type':main_type})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            data_json_key = json.loads(response.text)
            for setId1 in data_json_key['data']['StandardCollection']['containers']:
                setId = setId1['set']['refId']
                self.headre_movie = {
                    'accept': 'application/json',
                    'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ5NDg2NDksInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wNVQxMjo1MDo0OS4xNDIrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IklUIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6IiswMTowMCIsIm5hbWUiOiJFdXJvcGVcL1JvbWUifSwicmF0aW5nX3N5c3RlbXMiOlsiY3VzdG9tOmRpc25leXBsdXM6a2lqa3dpanplciJdfSwiZXhwaXJlc19vbiI6IjIwMjEtMDMtMDVUMTY6NTA6NDkuMTQyKzAwMDAiLCJleHBlcmltZW50cyI6eyI0MzU2MGU0MSYmYWF0ZXN0SmFuMjciOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfSwiZTJmYzBkMzEmJkNXX2RldGFpbHNfcGFnZV90ZXN0Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIyLjIzMy4xMTcuMjE4IiwidHlwZSI6IlJFR0lTVEVSRUQiLCJ2ZXJzaW9uIjoiVjIuMC4wIiwiYmxhY2tvdXRzIjp7ImVudGl0bGVtZW50cyI6W10sImRhdGEiOnt9LCJydWxlcyI6eyJ2aW9sYXRlZCI6W119fSwicGFydG5lciI6eyJuYW1lIjoiZGlzbmV5In0sImxvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IklUIiwiY2l0eV9uYW1lIjoibWlsYW5vIiwiY29ubmVjdGlvbl90eXBlIjoiZHNsIiwic3RhdGVfbmFtZSI6Im1pbGFubyIsImRtYSI6MCwicmVnaW9uX25hbWUiOiJsb21iYXJkaWEiLCJ0eXBlIjoiWklQX0NPREUiLCJhc24iOjEyODc0LCJ6aXBfY29kZSI6IjIwMTIxIn0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDVUMTI6NTA6NDkuMTQyKzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6IjY5MjExMDMwLTdkYjEtMTFlYi1hMDJlLTAyNDJhYzExMDAwNSIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6ImIxNzI2ZjM4LTMzNTEtNGE0My04NTA2LTZkODEwMWYwZmI4MCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRpc25leVBsdXNFTUVBIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ5NjMwNDksImlhdCI6MTYxNDk0ODY0OSwianRpIjoiMGU3MThkMTMtYjU2NC00MjcxLTliZWYtNDEzY2I5MGI0MjJjIn0.qhEHlYULNDZB36MQbnHA0xreft57MW_nDRNCHaHsYTF2Lmc2MTt9WVt8wO0K5AX2WFzeYK6bAk-DiSy3TD5rBw',
                    'Referer': 'https://www.disneyplus.com/',
                    'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
                    'sec-ch-ua-mobile': '?0',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Safari/537.36',
                    'x-application-version': '1.1.2',
                    'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                    'x-bamsdk-platform': 'windows',
                    'x-bamsdk-version': '4.19'
                }
                url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/IT/audience/false/maturity/1499/language/en/setId/{setId}/pageSize/30/page/1'
                yield scrapy.Request(url=url, meta={'type':type}, headers=self.headre_movie, callback=self.parse_movie, dont_filter=True)
        except Exception as e:
            print(e)

    def parse1(self, response):
        try:
            data_json_key = json.loads(response.text)
            for setId1 in data_json_key['data']['StandardCollection']['containers']:
                setId = setId1['set']['refId']
                self.headre_series = {
                    'accept': 'application/json',
                    'authorization': 'Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiJmNjkzNGFhYy1iZTY3LTQ2MWMtODYyMi1iNGE3NmFmZTNkMDgiLCJuYmYiOjE2MTQ5NDcxNTksInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiIwZTA0NDZkNC05ZjU3LTRiNjQtYTFjYi05OGJlMTMxMWIxZDUiLCJ1cGRhdGVkX29uIjoiMjAyMS0wMy0wNVQxMjoyNTo1OS4wNTUrMDAwMCIsInN1YnNjcmlwdGlvbnMiOlt7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTExVDIwOjQwOjI0LjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOmFlNTVjMTllLTI1ZTMtNGZiZC04NTlkLTFiODA1ZDQ4MjJmYl8xOTk5MTk5OTk5OTk5OTEwMTUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJJTklUSUFMIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0xMlQyMDo0MDoyNC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczphZTU1YzE5ZS0yNWUzLTRmYmQtODU5ZC0xYjgwNWQ0ODIyZmJfMTk5OTE5OTk5OTk5OTkxMDE1MTk5OTAwMF9kaXNuZXkifSx7ImVudGl0bGVtZW50cyI6WyJFU1BOX1BMVVMiLCJESVNORVlfUExVUyIsIkRJU05FWV9IVUxVX0FEUyJdLCJyZW5ld3Nfb24iOiIyMDIxLTAzLTI0VDE3OjM1OjIwLjAwMFoiLCJjYW5vbmljYWxTb3VyY2UiOnsicmVmIjoidXJuOmRzczpkaXNuZXk6b3JkZXJzOjFjODcyZmJjLTFmNmMtNDM2YS04MTdkLTk5ZmRkZDg3YTA2M18xOTk5MTk5OTk5OTk5OTE3MDUxOTk5MDAwX2Rpc25leSIsInByb3ZpZGVyIjoiQkFNVEVDSCIsInN1YlR5cGUiOiJQQUlEIiwidHlwZSI6IkQyQyJ9LCJleHBpcmVzX29uIjoiMjAyMS0wMy0yNVQxNzozNToyMC4wMDBaIiwiaWQiOiJ1cm46YmFtdGVjaG1lZGlhOnN1YnNjcmlwdGlvbi1hcGk6c3Vic2NyaXB0aW9uOkQyQzpCQU1URUNIOnVybjpkc3M6ZGlzbmV5Om9yZGVyczoxYzg3MmZiYy0xZjZjLTQzNmEtODE3ZC05OWZkZGQ4N2EwNjNfMTk5OTE5OTk5OTk5OTkxNzA1MTk5OTAwMF9kaXNuZXkifV0sImNvdW50cnlfc2V0dGluZ3MiOnsiY29kZSI6IklUIiwidGltZXpvbmUiOnsidXRjX29mZnNldCI6IiswMTowMCIsIm5hbWUiOiJFdXJvcGVcL1JvbWUifSwicmF0aW5nX3N5c3RlbXMiOlsiY3VzdG9tOmRpc25leXBsdXM6a2lqa3dpanplciJdfSwiZXhwaXJlc19vbiI6IjIwMjEtMDMtMDVUMTY6MjU6NTkuMDU1KzAwMDAiLCJleHBlcmltZW50cyI6eyI0MzU2MGU0MSYmYWF0ZXN0SmFuMjciOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfSwiZTJmYzBkMzEmJkNXX2RldGFpbHNfcGFnZV90ZXN0Ijp7InZhcmlhbnRfaWQiOiJjb250cm9sIiwidmVyc2lvbiI6MX0sIjM5YWI2YzQ1JiZTdGFuZGFsb25lX1Rlc3RfSmFuMjEiOnsidmFyaWFudF9pZCI6ImNvbnRyb2wiLCJ2ZXJzaW9uIjoxfX0sInByb2ZpbGVzIjpbeyJncm91cF93YXRjaCI6eyJlbmFibGVkIjp0cnVlfSwia2lkc19tb2RlX2VuYWJsZWQiOmZhbHNlLCJwbGF5YmFja19zZXR0aW5ncyI6eyJwcmVmZXJfMTMzIjpmYWxzZX0sInBhcmVudGFsX2NvbnRyb2xzIjp7InBpbl9lbnRyeV9leHBpcmVzX2F0IjoiIiwibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiVFYtMTQiLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MH0sImlzX2FnZTIxX3ZlcmlmaWVkIjpmYWxzZSwiaXNfcGluX3Byb3RlY3RlZCI6ZmFsc2UsImVuYWJsZWQiOnRydWV9LCJhY3RpdmUiOnRydWUsImlkIjoiMGUwNDQ2ZDQtOWY1Ny00YjY0LWExY2ItOThiZTEzMTFiMWQ1IiwiYXZhdGFyIjp7ImlkIjoiNDQyYWY3ZGItODVmNy01ZTFkLTk2ZjAtYjJjNTE3YmU0MDg1In0sInR5cGUiOiJ1cm46YmFtdGVjaDpwcm9maWxlIiwibGFuZ3VhZ2VfcHJlZmVyZW5jZXMiOnsiYXBwX2xhbmd1YWdlIjoiZW4iLCJwbGF5YmFja19sYW5ndWFnZSI6ImVuIiwic3VidGl0bGVfbGFuZ3VhZ2UiOiJlbiJ9fV0sImlwX2FkZHJlc3MiOiIxNTEuMzEuNjcuMTcwIiwidHlwZSI6IlJFR0lTVEVSRUQiLCJ2ZXJzaW9uIjoiVjIuMC4wIiwiYmxhY2tvdXRzIjp7ImVudGl0bGVtZW50cyI6W10sImRhdGEiOnt9LCJydWxlcyI6eyJ2aW9sYXRlZCI6W119fSwicGFydG5lciI6eyJuYW1lIjoiZGlzbmV5In0sImxvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IklUIiwiY2l0eV9uYW1lIjoidHVzY2FuaWEiLCJjb25uZWN0aW9uX3R5cGUiOiJ0eCIsInN0YXRlX25hbWUiOiJ2aXRlcmJvIiwiZG1hIjowLCJyZWdpb25fbmFtZSI6ImxhemlvIiwidHlwZSI6IlpJUF9DT0RFIiwiYXNuIjoxMjY3LCJ6aXBfY29kZSI6IjAxMDE3In0sImdlbmVyYXRlZF9vbiI6IjIwMjEtMDMtMDVUMTI6MjU6NTkuMDU1KzAwMDAiLCJob21lX2xvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IlVTIiwiY2l0eV9uYW1lIjoiIiwiY29ubmVjdGlvbl90eXBlIjoiIiwic3RhdGVfbmFtZSI6IiIsImRtYSI6MCwicmVnaW9uX25hbWUiOiIiLCJ0eXBlIjoiQ09VTlRSWV9DT0RFIiwiYXNuIjowLCJ6aXBfY29kZSI6IiJ9LCJpZCI6ImYwZjdmYmQwLTdkYWQtMTFlYi04Nzk2LTAyNDJhYzExMDAwYyIsIm1lZGlhX3Blcm1pc3Npb25zIjp7ImVudGl0bGVtZW50cyI6WyJESVNORVlfUExVUyIsIkVTUE5fUExVUyIsIkRJU05FWV9QTFVTIiwiRElTTkVZX0hVTFVfQURTIl0sImRhdGEiOnt9LCJydWxlcyI6eyJwYXNzZWQiOltdfX0sImRldmljZSI6eyJhcHBfcnVudGltZSI6ImNocm9tZSIsInByb2ZpbGUiOiJ3aW5kb3dzIiwibW9kZWwiOiIiLCJpZCI6ImRmYjA3NDc5LWNiNzctNDYyOS1iYmM5LTRhZmZiMTA0MGMxOCIsInR5cGUiOiJ1cm46ZHNzOmRldmljZTppbnRlcm5hbCIsImZhbWlseSI6ImJyb3dzZXIiLCJwbGF0Zm9ybSI6ImJyb3dzZXIifSwiYWNjb3VudCI6eyJkYXRhIjp7fSwibG9jYXRpb25zIjp7InB1cmNoYXNlIjp7ImNvdW50cnkiOiJVUyJ9LCJyZWdpc3RyYXRpb24iOnsiY291bnRyeSI6IlVTIn19LCJpZCI6ImY2OTM0YWFjLWJlNjctNDYxYy04NjIyLWI0YTc2YWZlM2QwOCIsInR5cGUiOiJ1cm46YmFtdGVjaDphY2NvdW50In0sInByZWZlcnJlZF9tYXR1cml0eV9yYXRpbmciOnsicmF0aW5nX3N5c3RlbSI6IkRpc25leVBsdXNFTUVBIiwicHJvZmlsZV9oYXNfbWF0dXJpdHlfcmF0aW5nIjp0cnVlLCJpbXBsaWVkX21hdHVyaXR5X3JhdGluZyI6MTQ5OX0sInN1cHBvcnRlZCI6dHJ1ZX0sImVudiI6InByb2QiLCJleHAiOjE2MTQ5NjE1NTksImlhdCI6MTYxNDk0NzE1OSwianRpIjoiMGVjNTc1MTMtMTQxMS00OWZlLTgxN2QtMmFjMjZkNWI2MzMzIn0.TrQwo54-gKI7qdOg6eiXdbPEHcS6_EIN9SPE7ZOMpN97S61Bf5GQP8_8TGCWtQmnWvhNStzhSUw8G7lMrmT1Cw',
                    'Referer': 'https://www.disneyplus.com/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                    'x-application-version': '1.1.2',
                    'x-bamsdk-client-id': 'disney-svod-3d9324fc',
                    'x-bamsdk-platform': 'windows',
                    'x-bamsdk-version': '4.19'
                }
                url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/IT/audience/false/maturity/1499/language/en/setId/{setId}/pageSize/30/page/1'
                yield scrapy.Request(url=url, meta={'type':type}, headers=self.headre_series, callback=self.parse_series, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_movie(self, response):
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta,  dont_filter=True, callback=self.parse)
        else:
            if 'Enter the characters you see below' in response.text:
                yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True, callback=self.parse)
            else:
                try:
                    data_json = json.loads(response.text)
                    if data_json['data']['CuratedSet']['items'] != []:
                        with open(f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney IT\link\\Movie_{response.url.split("/")[-1]}.json','wb') as f:
                            f.write(response.body)
                            f.close()
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'IT':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedFamilyId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedFamilyId = j['family']['encodedFamilyId']
                                if content !='' and encodedFamilyId!='':
                                    link = f"https://www.disneyplus.com/movies/{content}/{encodedFamilyId}"
                                    if 'None' in link:
                                        print("encodedFamilyId None")
                                    else:
                                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                        item['link'] = link
                                        yield item
                        else:
                            print("other country")
                    else:
                        self.flag = False
                    if self.flag:
                        setId_next_movie = data_json['data']['CuratedSet']['setId']
                        next_url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/IT/audience/false/maturity/1499/language/en/setId/{setId_next_movie}/pageSize/30/page/{self.page}'
                        self.page += 1
                        yield scrapy.Request(url=next_url, headers=self.headre_movie, meta={'type': response.meta['type']}, callback=self.parse_movie, dont_filter=True)
                except Exception as e:
                    print(e)

    def parse_series(self, response):
        if response.status in self.handle_httpstatus_list:
            yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True,
                                 callback=self.parse)
        else:
            if 'Enter the characters you see below' in response.text:
                yield scrapy.Request(url=response.url, headers=self.headre_movie, meta=response.meta, dont_filter=True,
                                     callback=self.parse)
            else:
                try:
                    data_json = json.loads(response.text)
                    if data_json['data']['CuratedSet']['items'] != []:
                        with open(f'D:\khyati-H\CRM\Projects AP\Minnow TV Project\HTML\Disney IT\link\\Series_{response.url.split("/")[-1]}.json','wb') as f:
                            f.write(response.body)
                            f.close()
                        if data_json['data']['CuratedSet']['items'][0]['currentAvailability']['region'] == 'IT':
                            item = OTTPlatformsLinksItem()
                            for j in data_json['data']['CuratedSet']['items']:
                                content, encodedSeriesId = '', ''
                                for t in j['texts']:
                                    if t['type'] == 'slug':
                                        content = t['content']
                                        break
                                encodedSeriesId = j['encodedSeriesId']
                                if content != '' and encodedSeriesId != '':
                                    link = f"https://www.disneyplus.com/series/{content}/{encodedSeriesId}"
                                    if 'None' in link:
                                        print("encodedSeriesId None")
                                    else:
                                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                                        item['link'] = link
                                        yield item
                        else:
                            print("other country")
                    else:
                        self.flag = False
                    if self.flag:
                        setId_next_series = data_json['data']['CuratedSet']['setId']
                        next_url = f'https://content.global.edge.bamgrid.com/svc/content/CuratedSet/version/3.3/region/IT/audience/false/maturity/1499/language/en/setId/{setId_next_series}/pageSize/30/page/{self.page}'
                        self.page += 1
                        yield scrapy.Request(url=next_url, headers=self.headre_series, meta={'type': response.meta['type']}, callback=self.parse_series, dont_filter=True)
                except Exception as e:
                    print(e)

# execute('scrapy crawl daily_links_disney_it'.split())
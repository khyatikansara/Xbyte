# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class OTTPlatformsMoviesItem(scrapy.Item):
    _id = scrapy.Field()
    Title = scrapy.Field()
    Actors = scrapy.Field()
    Directors = scrapy.Field()
    Crew = scrapy.Field()
    Year = scrapy.Field()
    Source = scrapy.Field()
    PosterUrl = scrapy.Field()
    Description = scrapy.Field()
    ProviderUniqueId = scrapy.Field()
    IMDBId = scrapy.Field()
    Url = scrapy.Field()
    Country = scrapy.Field()
    TMDBId = scrapy.Field()
    Modifier = scrapy.Field()
    Modified = scrapy.Field()
    Scrap_datetime = scrapy.Field()
    SlotNumber = scrapy.Field()

class OTTPlatformsShowsItem(scrapy.Item):
    _id = scrapy.Field()
    Title = scrapy.Field()
    Actors = scrapy.Field()
    Directors = scrapy.Field()
    Crew = scrapy.Field()
    Year = scrapy.Field()
    Source = scrapy.Field()
    PosterUrl = scrapy.Field()
    Description = scrapy.Field()
    ProviderUniqueId = scrapy.Field()
    IMDBId = scrapy.Field()
    Url = scrapy.Field()
    Country = scrapy.Field()
    TMDBId = scrapy.Field()
    Modifier = scrapy.Field()
    Modified = scrapy.Field()
    Scrap_datetime = scrapy.Field()
    SlotNumber = scrapy.Field()


class OTTPlatformsSeasonsItem(scrapy.Item):
    _id = scrapy.Field()
    Modified = scrapy.Field()
    Modifier = scrapy.Field()
    SeasonNumber = scrapy.Field()
    Description = scrapy.Field()
    Country = scrapy.Field()
    Title = scrapy.Field()
    Url = scrapy.Field()
    IMDBId = scrapy.Field()
    PosterUrl = scrapy.Field()
    Crew = scrapy.Field()
    Source = scrapy.Field()
    Directors = scrapy.Field()
    Actors = scrapy.Field()
    TMDBId = scrapy.Field()
    Year = scrapy.Field()
    Scrap_datetime = scrapy.Field()
    SlotNumber = scrapy.Field()
    ProviderUniqueId = scrapy.Field()
    ProviderUniqueSeasonId = scrapy.Field()


class OTTPlatformsEpisodesItem(scrapy.Item):
    _id = scrapy.Field()
    Modified = scrapy.Field()
    Modifier = scrapy.Field()
    EpisodeNumber = scrapy.Field()
    Description = scrapy.Field()
    Country = scrapy.Field()
    Title = scrapy.Field()
    Url = scrapy.Field()
    IMDBId = scrapy.Field()
    ImageUrl = scrapy.Field()
    Crew = scrapy.Field()
    Source = scrapy.Field()
    Directors = scrapy.Field()
    Actors = scrapy.Field()
    TMDBId = scrapy.Field()
    Year = scrapy.Field()
    Scrap_datetime = scrapy.Field()
    SlotNumber = scrapy.Field()
    ProviderUniqueId = scrapy.Field()
    ProviderUniqueSeasonId = scrapy.Field()
    ProviderUniqueEpisodeId = scrapy.Field()


class OTTPlatformsAvailabilitiesItem(scrapy.Item):
    _id = scrapy.Field()
    ProviderUniqueId = scrapy.Field()
    ProviderUniqueSeasonId = scrapy.Field()
    ProviderUniqueEpisodeId = scrapy.Field()
    PreSale = scrapy.Field()
    Modifier = scrapy.Field()
    StartDate = scrapy.Field()
    Country = scrapy.Field()
    Price = scrapy.Field()
    DeliveryMethod = scrapy.Field()
    Modified = scrapy.Field()
    Currency = scrapy.Field()
    ExpirationDate = scrapy.Field()
    Provider = scrapy.Field()
    OfferType = scrapy.Field()
    Quality = scrapy.Field()
    Links = scrapy.Field()


class OTTPlatformsLinksItem(scrapy.Item):
    _id = scrapy.Field()
    link = scrapy.Field()
# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals
from random import choice
from scrapy import signals
from w3lib.http import basic_auth_header

# useful for handling different item types with a single interface
from itemadapter import is_item, ItemAdapter

proxy_list = [
    "73477|qX8wYee4|50.2.25.58:3128", "73477|qX8wYee4|104.140.73.198:3128", "73477|qX8wYee4|23.19.97.104:3128",
    "73477|qX8wYee4|192.161.162.55:3128", "73477|qX8wYee4|192.126.161.56:3128", "73477|qX8wYee4|173.232.7.87:3128",
    "73477|qX8wYee4|50.2.15.109:3128", "73477|qX8wYee4|192.126.161.153:3128", "73477|qX8wYee4|50.2.25.40:3128",
    "73477|qX8wYee4|173.232.7.185:3128", "73477|qX8wYee4|50.2.15.119:3128", "73477|qX8wYee4|50.2.25.234:3128",
    "73477|qX8wYee4|23.19.97.67:3128", "73477|qX8wYee4|104.140.183.141:3128", "73477|qX8wYee4|23.19.97.151:3128",
    "73477|qX8wYee4|50.2.25.238:3128", "73477|qX8wYee4|192.161.162.126:3128", "73477|qX8wYee4|23.19.97.38:3128",
    "73477|qX8wYee4|50.2.25.198:3128", "73477|qX8wYee4|104.140.73.158:3128", "73477|qX8wYee4|104.140.183.224:3128",
    "73477|qX8wYee4|50.2.25.51:3128", "73477|qX8wYee4|104.140.215.42:3128", "73477|qX8wYee4|173.234.232.146:3128",
    "73477|qX8wYee4|173.234.232.192:3128", "73477|qX8wYee4|173.232.7.130:3128", "73477|qX8wYee4|104.140.73.75:3128",
    "73477|qX8wYee4|104.140.183.48:3128", "73477|qX8wYee4|192.161.162.2:3128", "73477|qX8wYee4|104.140.215.216:3128",
    "73477|qX8wYee4|23.19.97.216:3128", "73477|qX8wYee4|104.140.183.8:3128", "73477|qX8wYee4|104.140.73.175:3128",
    "73477|qX8wYee4|173.234.232.194:3128", "73477|qX8wYee4|173.234.232.27:3128", "73477|qX8wYee4|104.140.183.239:3128",
    "73477|qX8wYee4|192.161.162.155:3128", "73477|qX8wYee4|192.161.162.21:3128", "73477|qX8wYee4|173.232.7.62:3128",
    "73477|qX8wYee4|173.232.7.53:3128", "73477|qX8wYee4|192.126.161.47:3128", "73477|qX8wYee4|104.140.183.10:3128",
    "73477|qX8wYee4|104.140.73.251:3128", "73477|qX8wYee4|104.140.215.126:3128", "73477|qX8wYee4|50.2.15.76:3128",
    "73477|qX8wYee4|104.140.215.149:3128", "73477|qX8wYee4|50.2.25.135:3128", "73477|qX8wYee4|23.19.97.205:3128",
    "73477|qX8wYee4|192.126.161.173:3128", "73477|qX8wYee4|104.140.73.32:3128", "73477|qX8wYee4|50.2.15.246:3128",
    "73477|qX8wYee4|50.2.15.194:3128", "73477|qX8wYee4|50.2.25.75:3128", "73477|qX8wYee4|23.19.97.165:3128",
    "73477|qX8wYee4|104.140.215.51:3128", "73477|qX8wYee4|173.232.7.85:3128", "73477|qX8wYee4|104.140.73.235:3128",
    "73477|qX8wYee4|192.126.161.227:3128", "73477|qX8wYee4|50.2.25.231:3128", "73477|qX8wYee4|173.234.232.173:3128",
    "73477|qX8wYee4|104.140.73.82:3128", "73477|qX8wYee4|173.234.232.103:3128", "73477|qX8wYee4|192.161.162.125:3128",
    "73477|qX8wYee4|192.161.162.6:3128", "73477|qX8wYee4|104.140.183.195:3128", "73477|qX8wYee4|173.232.7.211:3128",
    "73477|qX8wYee4|104.140.183.59:3128", "73477|qX8wYee4|173.232.7.126:3128", "73477|qX8wYee4|104.140.73.147:3128",
    "73477|qX8wYee4|104.140.215.112:3128", "73477|qX8wYee4|173.234.232.214:3128", "73477|qX8wYee4|192.126.161.115:3128",
    "73477|qX8wYee4|192.161.162.44:3128", "73477|qX8wYee4|50.2.15.96:3128", "73477|qX8wYee4|173.232.7.27:3128",
    "73477|qX8wYee4|192.126.161.132:3128", "73477|qX8wYee4|192.126.161.53:3128", "73477|qX8wYee4|50.2.15.74:3128",
    "73477|qX8wYee4|23.19.97.239:3128", "73477|qX8wYee4|50.2.15.22:3128", "73477|qX8wYee4|173.232.7.175:3128",
    "73477|qX8wYee4|104.140.73.234:3128", "73477|qX8wYee4|173.234.232.239:3128", "73477|qX8wYee4|192.126.161.215:3128",
    "73477|qX8wYee4|23.19.97.71:3128", "73477|qX8wYee4|50.2.15.30:3128", "73477|qX8wYee4|104.140.215.70:3128",
    "73477|qX8wYee4|192.161.162.215:3128", "73477|qX8wYee4|173.234.232.233:3128", "73477|qX8wYee4|104.140.215.89:3128",
    "73477|qX8wYee4|50.2.25.205:3128", "73477|qX8wYee4|104.140.183.246:3128", "73477|qX8wYee4|104.140.215.36:3128",
    "73477|qX8wYee4|192.126.161.122:3128", "73477|qX8wYee4|104.140.183.231:3128", "73477|qX8wYee4|173.234.232.44:3128",
    "73477|qX8wYee4|23.19.97.72:3128", "73477|qX8wYee4|50.2.15.35:3128", "73477|qX8wYee4|104.140.215.122:3128",
    "73477|qX8wYee4|192.161.162.121:3128",
    "lum-customer-xbyte-zone-zone_us-country-us|0gi0pioy3oey|zproxy.lum-superproxy.io:22225"
]


class OttPlatformsSpiderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, or item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request or item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class OttPlatformsDownloaderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # Called for each request that goes through the downloader
        # middleware.
        proxy = choice(proxy_list).split('|')
        request.meta['proxy'] = f'https://{proxy[2]}'
        request.headers['Proxy-Authorization'] = basic_auth_header(proxy[0], proxy[1])

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)

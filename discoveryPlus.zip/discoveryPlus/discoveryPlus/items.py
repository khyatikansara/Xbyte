# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DiscoveryLinkItem(scrapy.Item):
    link = scrapy.Field()
    date = scrapy.Field()

class DiscoveryDataItem(scrapy.Item):
    ID = scrapy.Field()
    Source = scrapy.Field()
    Type = scrapy.Field()
    Movie_Series_Link = scrapy.Field()
    Movie_Series_Title = scrapy.Field()
    Movie_Series_Year = scrapy.Field()
    Movie_Series_Description = scrapy.Field()
    Movie_Series_IMDB = scrapy.Field()
    Season_Number = scrapy.Field()
    Episode_Number = scrapy.Field()
    Episode_Title = scrapy.Field()
    Episode_Description = scrapy.Field()
    Episode_Link = scrapy.Field()
    Episode_Date_Year = scrapy.Field()
    Episode_IMDB = scrapy.Field()
    Android_DeepLink = scrapy.Field()
    iOS_DeepLink = scrapy.Field()
    foreign_id = scrapy.Field()
    date = scrapy.Field()
    Movie_episode_time = scrapy.Field()
    Cast = scrapy.Field()
    Movie_Series_Poster = scrapy.Field()

import datetime
import time

import pymysql
import requests
import scrapy
import json
from discoveryPlus.items import DiscoveryLinkItem
from scrapy.cmdline import execute
from discoveryPlus import pipelines
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from scraper_api import ScraperAPIClient
from w3lib.http import basic_auth_header
# client = ScraperAPIClient('3b634b2d9dccdc93c6b18a3f0372c60d')
# client = ScraperAPIClient('370fd24c59d43efdcbafwefja0j8j8e')
# client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')
# client = ScraperAPIClient('23292b2ff2324af3bcb7acab7c639654')
# client = ScraperAPIClient('300a3210851d44098e18bf60655a8f2e')
# client = ScraperAPIClient('30aa984ae6a94b0d8898f8e9393413c1')
# client = ScraperAPIClient('847641580f8a287fcf415713f838796b')
# client = ScraperAPIClient('626f05bb44bb46b592c7c91c6cdad05e')
# client_ScraperAPIClient_list = [ScraperAPIClient('3b634b2d9dccdc93c6b18a3f0372c60d'),ScraperAPIClient('626f05bb44bb46b592c7c91c6cdad05e'),ScraperAPIClient('847641580f8a287fcf415713f838796b'),ScraperAPIClient('30aa984ae6a94b0d8898f8e9393413c1'),ScraperAPIClient('370fd24c59d43efdcbafwefja0j8j8e'),ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3'), ScraperAPIClient('23292b2ff2324af3bcb7acab7c639654'), ScraperAPIClient('300a3210851d44098e18bf60655a8f2e')]


class LinksSpider(scrapy.Spider):
    name = 'links_new'
    start_urls = ['http://www.example.com/']
    today = datetime.datetime.now().strftime("%d_%m_%Y")

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = start
        self.end = end
        self.flag = False
        self.crawlera_key = '66b18fe5e75149d8b42fa081d35da7da'
        self.pipe = pipelines.DiscoveryplusPipeline()


    def parse(self, response):
        self.pipe.cursor.execute(f'SELECT * FROM a_z limit {self.start},1000')
        links = self.pipe.cursor.fetchall()
        for row in links:
            char1 = row[1]
            url = f'https://us1-prod-direct.discoveryplus.com/cms/routes/search/result?include=default&decorators=viewingHistory,isFavorite,playbackAllowed&contentFilter[query]={char1}'
            print(url)
            headers = {
                'authority': "us1-prod-direct.discoveryplus.com",
                'accept': "*/*",
                # 'accept-encoding': "gzip, deflate, br",
                # 'accept-language': "en-US,en;q=0.9",
                'cookie': "_gcl_au=1.1.1455022448.1633013139; _rdt_uuid=1633013140197.7ff84f14-a7d5-44f5-b6f1-e763514778d8; _scid=9e266db1-dff8-4744-93d4-27d47a5011a8; _fbp=fb.1.1633013141235.1897454920; _pin_unauth=dWlkPVlUaG1ZV0k0WVRFdFptTmtZeTAwTWpoa0xXSTBaak10T1RobE9XSm1aV1E0WVRFeA; aam_uuid=83831556636164924051938384169903218976; _ga=GA1.2.1282495738.1634111601; aam_fw=aam%3D9354365%3Baam%3D331659%3Baam%3D251502%3Baam%3D807135%3Baam%3D251453%3Baam%3D311690%3Baam%3D318096%3Baam%3D279231%3Baam%3D807134%3Baam%3D251505%3Baam%3D1790877%3Baam%3D592474%3Baam%3D1322178%3Baam%3D592419%3BAAM%3D3484046%3Baam%3D4327697%3Baam%3D3998706%3Baam%3D6641686%3Baam%3D9040990%3Baam%3D9565614%3Baam%3D10532552%3Baam%3D10469396%3Baam%3D3975512; _sctr=1|1634149800000; st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6Z286NjNhNGIyYTktZjRiMC00MDlhLTg0YTAtMGE0OWYzNjIyYzc0IiwianRpIjoidG9rZW4tMDdiZTJjNDgtYTUzNS00OTg5LWE5NjQtNDMxMzI5MDA1MmEyIiwiYW5vbnltb3VzIjpmYWxzZSwiaWF0IjoxNjM0NjUwNDk5fQ.T8Ps9etvcS7SjP7zASWcS84yQMxfcE4MINC7_ZlBu2A; gi_ls=1; ass=de8cfb1e-9b53-4a03-86de-e5bf8432bf70.1634652313.1634650467; _uetsid=64f503c02fe311ecad9cad0f08f49a8e; _uetvid=14f4bc3021fd11ec8c83f137f84e83bd; AMCV_BC501253513148ED0A490D45%40AdobeOrg=-1124106680%7CMCMID%7C83668731813156433391922315060155749790%7CMCAAMLH-1635148269%7C7%7CMCAAMB-1634727122%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1634550669s%7CNONE%7CvVersion%7C5.2.0%7CMCIDTS%7C18921",
                # 'if-none-match': "W/\"4236107528\"",
                # 'origin': "https://www.discoveryplus.com",
                'referer': "https://www.discoveryplus.com/",
                'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                'sec-ch-ua-mobile': "?0",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'sec-fetch-site': "same-site",
                'x-disco-client': "WEB:UNKNOWN:dplus_us:1.18.2",
                'x-disco-params': "realm=go,siteLookupKey=dplus_us,bid=dplus,hn=www.discoveryplus.com,features=ar"
                # 'cache-control': "no-cache",
                # 'Proxy-Authorization': basic_auth_header("alpesh.khunt.xbyte@gmail.com", "xbyte123"),
                # 'postman-token': "20eaf253-2182-7bd4-a7ba-1e8fd4225642",
                # 'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36",

            }
            response = requests.request("GET", url, headers=headers)
            print(response)

            self.flag = True
            item = DiscoveryLinkItem()
            data = json.loads(response.text)
            try:
                for include in data['included']:
                    try:
                        url = include['attributes']['url']
                        item['link'] = "https://www.discoveryplus.com" + url
                        item["date"] =self.today
                        if "/show/" in url:
                            yield item
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute("scrapy crawl links_new -a start=0".split())
import datetime
import hashlib
import json
from scrapy.cmdline import execute
import MySQLdb as pymysql
import scrapy
import time
import requests
from w3lib.http import basic_auth_header
from discoveryPlus.items import DiscoveryDataItem


class DiscoveryPlusDataSpider(scrapy.Spider):
    name = 'data'
    start_urls = ['http://www.discoveryplus.com/']
    today = datetime.datetime.now().strftime("%d_%m_%Y")
    Movieisited = 0
    SeriesVisited = 0
    SeriesVisited_list = []
    EpisodeVisited = 0
    EpisodeVisited_list = []

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = start
        self.end = end
        self.con = pymysql.connect('localhost', 'root', 'xbyte', 'discoveryplusdaily')
        self.cursor = self.con.cursor()

    def start_requests(self):
        self.headers = {
            'authority': "us1-prod-direct.discoveryplus.com",
            'accept': "*/*",
            'cookie': "_gcl_au=1.1.1455022448.1633013139; _rdt_uuid=1633013140197.7ff84f14-a7d5-44f5-b6f1-e763514778d8; _scid=9e266db1-dff8-4744-93d4-27d47a5011a8; _fbp=fb.1.1633013141235.1897454920; _pin_unauth=dWlkPVlUaG1ZV0k0WVRFdFptTmtZeTAwTWpoa0xXSTBaak10T1RobE9XSm1aV1E0WVRFeA; aam_uuid=83831556636164924051938384169903218976; _ga=GA1.2.1282495738.1634111601; aam_fw=aam%3D9354365%3Baam%3D331659%3Baam%3D251502%3Baam%3D807135%3Baam%3D251453%3Baam%3D311690%3Baam%3D318096%3Baam%3D279231%3Baam%3D807134%3Baam%3D251505%3Baam%3D1790877%3Baam%3D592474%3Baam%3D1322178%3Baam%3D592419%3BAAM%3D3484046%3Baam%3D4327697%3Baam%3D3998706%3Baam%3D6641686%3Baam%3D9040990%3Baam%3D9565614%3Baam%3D10532552%3Baam%3D10469396%3Baam%3D3975512; _sctr=1|1634149800000; st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6Z286NjNhNGIyYTktZjRiMC00MDlhLTg0YTAtMGE0OWYzNjIyYzc0IiwianRpIjoidG9rZW4tMDdiZTJjNDgtYTUzNS00OTg5LWE5NjQtNDMxMzI5MDA1MmEyIiwiYW5vbnltb3VzIjpmYWxzZSwiaWF0IjoxNjM0NjUwNDk5fQ.T8Ps9etvcS7SjP7zASWcS84yQMxfcE4MINC7_ZlBu2A; gi_ls=1; ass=de8cfb1e-9b53-4a03-86de-e5bf8432bf70.1634652313.1634650467; _uetsid=64f503c02fe311ecad9cad0f08f49a8e; _uetvid=14f4bc3021fd11ec8c83f137f84e83bd; AMCVS_BC501253513148ED0A490D45%40AdobeOrg=1; AMCV_BC501253513148ED0A490D45%40AdobeOrg=-1124106680%7CMCMID%7C83668731813156433391922315060155749790%7CMCAAMLH-1635331924%7C7%7CMCAAMB-1635331924%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1634734324s%7CNONE%7CvVersion%7C5.2.0%7CMCIDTS%7C18921",
            'referer': "https://www.discoveryplus.com/",
            'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            'sec-ch-ua-mobile': "?0",
            'sec-fetch-dest': "empty",
            'sec-fetch-mode': "cors",
            'sec-fetch-site': "same-site",
            'x-disco-client': "WEB:UNKNOWN:dplus_us:1.18.2",
            'x-disco-params': "realm=go,siteLookupKey=dplus_us,bid=dplus,hn=www.discoveryplus.com,features=ar"
        }
        try:
            select = f'select * from links limit {self.start},500'
            # select = f'select * from links'
            self.cursor.execute(select)
            movie_links = self.cursor.fetchall()
            print(len(movie_links))
            for link in movie_links:
                Id = link[0]
                attr = str(link[1]).split("/")[-1]
                url = f"https://us1-prod-direct.discoveryplus.com/cms/routes/show/{attr}"
                if str(link[1]) not in self.SeriesVisited_list:
                    self.SeriesVisited_list.append(link[1])

                querystring = {"include": "default"}
                try:
                    res = requests.get(url, headers=self.headers, params=querystring)
                    print(res.status_code)
                except Exception as e:
                    print(e)
                    time.sleep(int(res.headers["Retry-After"]))
                yield scrapy.Request(url='https://www.discoveryplus.com',dont_filter=True,headers=self.headers, meta={'Id': Id,'attr':attr,'response_text':res.text})
        except Exception as e:
            print(e)

    def parse(self, response):
        total_season = 0
        response_text = response.meta['response_text']
        item = DiscoveryDataItem()
        Id = response.meta['Id']
        attr = str(response.meta['attr'])
        try:
            with open(f"E:\\Khyati\\MinnowTV\\discovery_html\\{attr}.json",'w') as f:
                f.write(response_text)
                f.close()
        except Exception as e:
            print(e)

        data = json.loads(response_text)
        item['Source'] = "Discovery Plus"
        try:
            for index,include in enumerate(data['included']):
                try:
                    if include['attributes']['alternateId'] == attr:
                        try:
                            if include['type'] == 'show':
                                item['Movie_Series_Link'] = "https://www.discoveryplus.com/show/" + str(attr)
                                item['Movie_Series_Description'] = include['attributes']["longDescription"]
                                item['Movie_Series_Title'] = include['attributes']["name"]
                                item['Type'] = 'EPISODE'
                                total_season = len(include['relationships']['seasons']['data'])
                                image_id = include['relationships']['images']['data'][0]['id']
                                # episode_count = include['attributes']['episodeCount']
                                include_count_list = []
                                for i in range(len(data['included'])):
                                    try:
                                        key_list = list(data['included'][i]['attributes'].keys())
                                        if 'path' in key_list:
                                            if attr in data['included'][i]['attributes']['path']:
                                                include_count_list.append(i)
                                    except Exception as e:
                                        print(e)

                                # leng = len(data['included'])
                                # episodes = leng - episode_count
                                # print(episodes)
                        except Exception as e:
                            print(e)
                except Exception as e:
                    print(e)
            # a = data['included']
            if include_count_list != []:
                try:
                    for number in include_count_list:
                        try:
                            # item['ID'] = Id
                            try:item['Episode_Number'] = data['included'][number]['attributes']['episodeNumber']
                            except:item['Episode_Number'] = ""
                            try:item['Season_Number'] = data['included'][number]['attributes']['seasonNumber']
                            except:item['Season_Number'] = ''
                            try:item['Episode_Title'] = data['included'][number]['attributes']['name']
                            except:item['Episode_Title'] = ''
                            try:item['Episode_Description'] = data['included'][number]['attributes']['description']
                            except:item['Episode_Description'] = ''
                            try:item['Episode_Link'] = "https://www.discoveryplus.com/video/"+str(data['included'][number]['attributes']['path'])
                            except:item['Episode_Link'] = ''
                            try:item['Episode_Date_Year'] = str(data['included'][number]['attributes']['airDate']).split('-')[0]
                            except:item['Episode_Date_Year'] = ''
                            item['Movie_Series_Year'] = ''
                            try:item['Android_DeepLink'] = item['Episode_Link']
                            except:item['Android_DeepLink'] = ''
                            try:item['iOS_DeepLink'] = item['Episode_Link']
                            except:item['iOS_DeepLink'] = ''
                            item['foreign_id'] = int(hashlib.md5(bytes(str(item['Movie_Series_Link'])+str(item["Episode_Link"]), "utf8")).hexdigest(),16) % (10 ** 30)
                            item['date'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                            duration = int(data['included'][number]['attributes']['videoDuration'])
                            try:item['Movie_episode_time'] = duration
                            except:item['Movie_episode_time'] = ''
                            item['Movie_Series_IMDB'] = ''
                            item['Episode_IMDB'] = ''
                            item['Cast'] = ''
                            Movie_Series_Poster = ''
                            for index,image_index in enumerate(data['included']):
                                if image_index['id'] == image_id:
                                    Movie_Series_Poster = image_index['attributes']['src']
                                    break
                            try:item["Movie_Series_Poster"] = Movie_Series_Poster
                            except:item["Movie_Series_Poster"] = ''
                            yield item
                            if item['Episode_Link'] not in self.EpisodeVisited_list:
                                self.EpisodeVisited_list.append(item['Episode_Link'])
                        except Exception as e:
                            print(e)
                except:pass
        except Exception as e:
            print(e)
        if total_season > 1:
            try:
                for include in data['included']:
                    try:
                        if include['attributes']['alias'] == 'generic-show-episodes':
                            showid = include['attributes']['component']['mandatoryParams']
                            for option in include['attributes']['component']['filters'][0]['options']:
                                season_parameter = option['parameter']
                                link = f"https://us1-prod-direct.discoveryplus.com/cms/collections/89438300356657080631189351362572714453?include=default&decorators=viewingHistory,isFavorite&{season_parameter}&{showid}"
                                response1 = requests.request("GET", link, headers=self.headers)
                                yield scrapy.Request(url='https://www.discoveryplus.com',dont_filter=True, headers=self.headers,callback=self.parse, meta={'Id': Id,'attr':attr,'response_text':response1.text})
                            break
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    # execute("scrapy crawl data -a start=0 -a end=4435543".split())
    execute("scrapy crawl data".split())
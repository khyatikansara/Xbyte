import time
import scrapy
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


class SeleniumCookieSpider(scrapy.Spider):
    name = 'selenium_cookie'
    start_urls = ['http://www.example.com/']

    def parse(self, response):
        chrome_options = Options()
        chrome_driver = "chromedriver.exe"
        driver = webdriver.Chrome(chrome_options = chrome_options, executable_path = chrome_driver)
        driver.get("https://www.discoveryplus.com/")
        time.sleep(10)
        driver.find_element_by_xpath('//a[@aria-label="Sign in"]').click()
        time.sleep(10)
        email = driver.find_element_by_id("email")
        email.send_keys("hello@minnowtv.com")
        password = driver.find_element_by_id("password")
        password.send_keys("getMinnow1@")
        time.sleep(3)
        driver.find_element_by_xpath('//button[@type="submit"]').click()
        time.sleep(10)
        print()


if __name__ == '__main__':

    execute("scrapy crawl selenium_cookie".split())
import datetime
import pymysql
import scrapy
import json
from discoveryPlus.items import DiscoveryLinkItem
from scrapy.cmdline import execute

class LinksSpider(scrapy.Spider):
    name = 'links'
    start_urls = ['http://www.discoveryplus.com/']
    today = datetime.datetime.now().strftime("%d_%m_%Y")

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = start
        self.end = end
        self.crawlera_key = '66b18fe5e75149d8b42fa081d35da7da'
        # self.crawlera_key = '91cde569d403483fab622483b9f6ffae'
        # self.crawlera_key = '5c57a79ae7b54a1a8cb5552464ca3a10'
        # self.con = pymysql.connect('localhost', 'root', 'xbyte', 'discoveryplusdaily')
        # self.cursor = self.con.cursor()

    def start_requests(self):

        for i in range(0,1000):
            url = f"https://us1-prod-direct.discoveryplus.com/cms/collections/158493674439610656811844478092097438971?include=default&decorators=viewingHistory,isFavorite,playbackAllowed&page[items.number]={i}&page[items.size]=100"
            # headers = {
            #     'authority': 'us1-prod-direct.discoveryplus.com',
            #     'accept': "*/*",
            #     'cookie': '_fbp=fb.1.1628590724331.1354000919; _gcl_au=1.1.18592415.1628590758; _rdt_uuid=1628590759137.0af7cf21-2cf4-4b91-8563-a62226fb2e7a; _pin_unauth=dWlkPU5qWXhObVE0TlRVdFltRTNNQzAwWXpVd0xUaGxNamN0TkRBelltWXhNemt3TjJFMw; _scid=0d5f6730-2168-4854-aa5b-8ae7edfc5219; AMCVS_BC501253513148ED0A490D45%40AdobeOrg=1; AMCV_BC501253513148ED0A490D45%40AdobeOrg=-1124106680%7CMCIDTS%7C18850%7CMCMID%7C20232464406614328641511540920951665252%7CMCAAMLH-1629195560%7C7%7CMCAAMB-1629195560%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1628597960s%7CNONE%7CvVersion%7C5.2.0; _sctr=1|1628533800000; st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6Z286NjNhNGIyYTktZjRiMC00MDlhLTg0YTAtMGE0OWYzNjIyYzc0IiwianRpIjoidG9rZW4tZTU5ZGVlZGItOTMwMS00YjM5LTg1MzQtMTY1OGI3NTc3NjY5IiwiYW5vbnltb3VzIjpmYWxzZSwiaWF0IjoxNjI4NTkwNzkzfQ.8GhKNm_9PjRB-00ABHDp3G-RYGsxQAyUEqqKTG0qkbM; gi_ls=1; aam_fw=aam%3D9354365%3Baam%3D331659%3Baam%3D251502%3Baam%3D807135%3Baam%3D251453%3Baam%3D311690%3Baam%3D318098%3Baam%3D318096%3Baam%3D279231%3Baam%3D250543%3Baam%3D807141%3Baam%3D807134%3Baam%3D251505%3Baam%3D592474%3Baam%3D1322178%3Baam%3D592419%3BAAM%3D3484046%3Baam%3D4327697%3Baam%3D3998706%3Baam%3D6641686%3Baam%3D9040990%3Baam%3D9565614%3Baam%3D10469396; aam_uuid=20446106864042185261491248966223759066; _uetsid=2c12b6f0f9c011ebbd5c857b043ee3ec; _uetvid=2c130380f9c011eb994e91142483f096; ass=7ae83b69-5e93-4b35-a33f-8e19e8aac672.1628593254.1628590629',
            #     # 'origin': 'https://www.discoveryplus.com',
            #     'Referer': 'https://www.discoveryplus.com',
            #     # 'sec-fetch-mode': 'cors',
            #     # 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
            #     'x-disco-client': 'WEB:UNKNOWN:dplus_us:prod',
            #     'x-disco-params': 'realm=go,siteLookupKey=dplus_us'
            # }

            headers = {
                'authority': "us1-prod-direct.discoveryplus.com",
                'accept': "*/*",
                # 'accept-encoding': "gzip, deflate, br",
                # 'accept-language': "en-US,en;q=0.9",
                'cookie': "AMCVS_BC501253513148ED0A490D45%40AdobeOrg=1; s_cc=true; s_sq=%5B%5BB%5D%5D; _gcl_au=1.1.1455022448.1633013139; _rdt_uuid=1633013140197.7ff84f14-a7d5-44f5-b6f1-e763514778d8; _scid=9e266db1-dff8-4744-93d4-27d47a5011a8; AMCV_BC501253513148ED0A490D45%40AdobeOrg=-1124106680%7CMCMID%7C83668731813156433391922315060155749790%7CMCAAMLH-1633617941%7C7%7CMCAAMB-1633617941%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1633020341s%7CNONE%7CvVersion%7C5.2.0%7CMCIDTS%7C18901; _fbp=fb.1.1633013141235.1897454920; _sctr=1|1632940200000; st=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJVU0VSSUQ6Z286NjNhNGIyYTktZjRiMC00MDlhLTg0YTAtMGE0OWYzNjIyYzc0IiwianRpIjoidG9rZW4tNzZjOTRkMGItZDg1OS00MGQ0LTkxOGItNGExYmMwYTkwYTc2IiwiYW5vbnltb3VzIjpmYWxzZSwiaWF0IjoxNjMzMDEzMTkxfQ.LsuYXoyOnJgzKs0JdRen8wEQ21Te9CJjfVHxljDxtkM; gi_ls=1; _pin_unauth=dWlkPVlUaG1ZV0k0WVRFdFptTmtZeTAwTWpoa0xXSTBaak10T1RobE9XSm1aV1E0WVRFeA; aam_fw=aam%3D9354365%3Baam%3D331659%3Baam%3D251502%3Baam%3D807135%3Baam%3D251453%3Baam%3D311690%3Baam%3D318096%3Baam%3D279231%3Baam%3D807134%3Baam%3D251505%3Baam%3D592474%3Baam%3D1322178%3Baam%3D592419%3BAAM%3D3484046%3Baam%3D4327697%3Baam%3D3998706%3Baam%3D6641686%3Baam%3D9040990%3Baam%3D9565614%3Baam%3D10469396%3Baam%3D3975512%3Baam%3D1215067%3Baam%3D549979; aam_uuid=83831556636164924051938384169903218976; ass=e80fec42-250f-4e06-9067-8c4df78b06c3.1633015018.1633013141; _uetsid=14f4472021fd11ecae131b04d501837e; _uetvid=14f4bc3021fd11ec8c83f137f84e83bd",
                # 'if-none-match': "W/\"4236107528\"",
                # 'origin': "https://www.discoveryplus.com",
                'referer': "https://www.discoveryplus.com/",
                'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                'sec-ch-ua-mobile': "?0",
                'sec-fetch-dest': "empty",
                'sec-fetch-mode': "cors",
                'sec-fetch-site': "same-site",
                'x-disco-client': "WEB:UNKNOWN:dplus_us:1.18.2",
                'x-disco-params': "realm=go,siteLookupKey=dplus_us,bid=dplus,hn=www.discoveryplus.com,features=ar"
                # 'cache-control': "no-cache",
                # 'Proxy-Authorization': basic_auth_header("alpesh.khunt.xbyte@gmail.com", "xbyte123"),
                # 'postman-token': "20eaf253-2182-7bd4-a7ba-1e8fd4225642",
                # 'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36",

            }
            # yield scrapy.Request(url=url, headers=headers, callback=self.parse, dont_filter=True,
            #                      meta={"proxy": f"https://{self.crawlera_key}:@proxy.crawlera.com:8011/"})
            yield scrapy.Request(url=url,headers=headers,callback=self.parse, meta={"proxy": f"https://{self.crawlera_key}:@proxy.crawlera.com:8011/"})

    def parse(self, response):
        print(response.text)
        item = DiscoveryLinkItem()
        data = json.loads(response.text)
        # print(data)
        try:
            for include in data['included']:
                try:
                    url = include['attributes']['url']
                    item['link'] = "https://www.discoveryplus.com" + url
                    item["date"] =self.today
                    yield item
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    execute("scrapy crawl links".split())
import datetime
import MySQLdb as pymysql
from discoveryPlus.items import DiscoveryLinkItem,DiscoveryDataItem


class DiscoveryplusPipeline:
    month = datetime.datetime.now().strftime("%m_%d_%Y")

    def __init__(self):
        try:
            self.con = pymysql.connect('localhost', 'root', 'xbyte')
            self.cursor = self.con.cursor()
            self.cursor.execute('CREATE DATABASE IF NOT EXISTS DiscoveryPlusDaily')
        except Exception as e:
            print(str(e))
        self.con = pymysql.connect('localhost', 'root', 'xbyte', 'DiscoveryPlusDaily')
        self.cursor = self.con.cursor()

        self.con_167 = pymysql.connect('localhost', 'root', 'xbyte', 'minnow_tv_daily')
        self.cursor_167 = self.con_167.cursor()

        try:
            create = f"""CREATE TABLE IF NOT EXISTS links (`ID` bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                                          `link` varchar(255) unique,
                                                          `date` varchar(255),
                                                          `status` varchar(255) DEFAULT 'pending')"""
            self.cursor.execute(create)
        except Exception as e:
            print(e)

        try:
            self.data_table_167 = f'movie_episodes_data_master'
            create = f"""CREATE TABLE IF NOT EXISTS`{self.data_table_167}` (`ID` bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                                                                      `Source` mediumtext,
                                                                      `Type` mediumtext ,
                                                                      `Movie_Series Link` mediumtext ,
                                                                      `Movie_Series Title` mediumtext ,
                                                                      `Movie_Series Year` mediumtext ,
                                                                      `Movie_Series Description` mediumtext ,
                                                                      `Movie_Series IMDB` mediumtext ,
                                                                      `Season_Number` mediumtext ,
                                                                      `Episode_Number` mediumtext ,
                                                                      `Episode_Title` mediumtext ,
                                                                      `Episode_Description` mediumtext ,
                                                                      `Episode_Link` mediumtext ,
                                                                      `Episode_Date_Year` mediumtext ,
                                                                      `Episode_IMDB` mediumtext ,
                                                                      `Android_DeepLink` mediumtext ,
                                                                      `iOS_DeepLink` mediumtext ,
                                                                      `Cast` mediumtext,
                                                                      `Movie_Series_Poster` mediumtext,
                                                                      `status` varchar(250) DEFAULT 'pending' ,
                                                                      `Location` varchar(25) DEFAULT 'United States',
                                                                      `Country Code` varchar(25) DEFAULT 'US',
                                                                      `foreign_id` varchar(250) unique,
                                                                      `Movie_episode_time` varchar(250),
                                                                      `date` varchar(250))"""
            self.cursor_167.execute(create)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, DiscoveryLinkItem):
            try:
                insert = f'insert into links (link, date) values (%s, %s)'
                self.cursor.execute(insert, (item["link"], item["date"]))
                self.con.commit()
                print('Link Inserted...')
            except Exception as e:
                print(e)
            return item

        if isinstance(item, DiscoveryDataItem):
            try:
                insert = f'insert into `movie_episodes_data_master`(`Source`, `Type`, `Movie_Series Link`, `Movie_Series Title`, `Movie_Series Year`, `Movie_Series Description`, `Movie_Series IMDB`, `Season_Number`, `Episode_Number`, `Episode_Title`, `Episode_Description`, `Episode_Link`, `Episode_Date_Year`, `Episode_IMDB`, `Android_DeepLink`, `iOS_DeepLink`, `foreign_id`, `date`, `Movie_episode_time`,`Cast`,`Movie_Series_Poster`) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
                self.cursor_167.execute(insert, (
                    item["Source"], item["Type"], item["Movie_Series_Link"], item["Movie_Series_Title"],
                    item["Movie_Series_Year"], item["Movie_Series_Description"], item["Movie_Series_IMDB"],
                    item["Season_Number"], item["Episode_Number"], item["Episode_Title"],
                    item["Episode_Description"],
                    item["Episode_Link"], item["Episode_Date_Year"], item["Episode_IMDB"], item["Android_DeepLink"],
                    item["iOS_DeepLink"], item['foreign_id'], item['date'], item["Movie_episode_time"],item["Cast"], item['Movie_Series_Poster']))
                self.con_167.commit()
                print('Data Inserted...')

                update = 'update links set Status="Done" where Id=%s'
                self.cursor.execute(update, (item["ID"]))
                self.con.commit()
            except Exception as e:
                print(e)

        return item

    def close_spider(self, spider):
        try:
            if spider.name == 'data':
                date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
                select = f'select count(Id) from `{self.data_table_167}` where Source="Discovery Plus" and date="{date}"'
                self.cursor_167.execute(select)
                count = self.cursor_167.fetchone()[0]

                Movie_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Discovery Plus" and Type="MOVIE" and date="{date}"'
                self.cursor_167.execute(Movie_Count_select)
                Movie_Count = self.cursor_167.fetchone()[0]

                Series_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Discovery Plus" and Type="EPISODE" and date="{date}" group by `Movie_Series Link`'
                self.cursor_167.execute(Series_Count_select)
                Series_Count = len(self.cursor_167.fetchall())

                Episode_Count_select = f'select count(Id) from `{self.data_table_167}` where Source="Discovery Plus" and Type="EPISODE" and date="{date}"'
                self.cursor_167.execute(Episode_Count_select)
                Episode_Count = self.cursor_167.fetchone()[0]

                previous_day = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1),
                                                          '%Y-%m-%d')
                total_count_query = f'select MovieTotalCount,SeriesTotalCount,EpisodeTotalCount from minnow_daily_status WHERE SiteName="Discovery Plus" and Date like "{previous_day}%"'
                self.cursor_167.execute(total_count_query)
                total_count = self.cursor_167.fetchone()

                MovieTotalCount = int(Movie_Count) + int(total_count[0])
                SeriesTotalCount = int(Series_Count) + int(total_count[1])
                EpisodeTotalCount = int(Episode_Count) + int(total_count[2])

                Movievisited = 0
                SeriesVisited = len(spider.SeriesVisited_list)
                EpisodeVisited = len(spider.EpisodeVisited_list)

                insert = 'insert into minnow_daily_status (SiteName,TodayCount,MovieVisted,Date,MovieCount,MovieTotalCount,SeriesVisited,SeriesCount,SeriesTotalCount,EpisodeVisited,EpisodeCount,EpisodeTotalCount) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
                self.cursor_167.execute(insert, ("Discovery Plus", str(count), Movievisited,
                                                 str(datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')),
                                                 str(Movie_Count), str(MovieTotalCount), str(SeriesVisited),
                                                 str(Series_Count), str(SeriesTotalCount), str(EpisodeVisited),
                                                 str(Episode_Count), str(EpisodeTotalCount)))
                self.con_167.commit()
        except Exception as e:
            print(e)



# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from myvipon.db_config import config
import pymysql

from myvipon.items import MyviponLinkItem, MyviponItem


class MyviponPipeline:

    def __init__(self):
        self.con = pymysql.connect(host=config.db_host, user=config.db_user, password=config.db_password, database=config.db_name)
        self.crsr = self.con.cursor()
        try:
            self.con.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {config.db_name}")
        except Exception as e:
            print(e)
        try:
            CT = f"""CREATE TABLE IF NOT EXISTS {config.daily_link}(
                                                                Id int auto_increment not null primary key,
                                                                Link varchar(255) unique,
                                                                Status varchar(50) DEFAULT 'pending'
                                                                )
                                                                DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci"""
            self.crsr.execute(CT)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):

        if isinstance(item, MyviponLinkItem):
            try:
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {config.daily_link}" + "( " + fields + " ) values ( '" + values + "' )"
                self.crsr.execute(insert_db)
                self.con.commit()
                print('data inserted')
            except Exception as e:
                print(str(e))

        if isinstance(item, MyviponItem):
            try:
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = f"insert into {config.data_table}" + "( " + fields + " ) values ( '" + values + "' )"
                self.crsr.execute(insert_db)
                self.con.commit()
                print('data inserted')

                update = f"""update {config.daily_link} set Status="done1" where Link='{item["review_url"]}'"""
                self.crsr.execute(update)
                self.con.commit()
                print('Data updated')
            except Exception as e:
                update = f"""update {config.daily_link} set Status="done" where Link='{item["review_url"]}'"""
                self.crsr.execute(update)
                self.con.commit()
                print('Data updated')
                print(str(e))

            return item

        return item

cd /media/xbyte/data/"Projects Training"/myvipon/myvipon/spiders

gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=0 -a end=50
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=50 -a end=100
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=100 -a end=150
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=150 -a end=200
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=200 -a end=250
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=250 -a end=300
gnome-terminal -- python3 -m scrapy crawl UKDataSpider -a start=300 -a end=400

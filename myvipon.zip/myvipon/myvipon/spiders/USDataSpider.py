import boto3
import pymysql
import scrapy
import json
import re
from scrapy.cmdline import execute
from scrapy_splash import SplashRequest
from myvipon import db_config as dbc
from selenium.webdriver.firefox.options import Options
from myvipon.items import MyviponItem
from selenium import webdriver
from datetime import datetime
import os
import hashlib


class USDataSpider(scrapy.Spider):

    name = 'USDataSpider'

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        self.end = int(end)
        # options = Options()
        # options.add_argument('--headless')
        # self.driver = webdriver.Firefox(options=options,executable_path="geckodriver.exe")
        self.con = pymysql.connect(host="192.168.1.252", user="root", password="xbyte", database="bungeetech_daily_sites")
        self.crsr = self.con.cursor()
        # self.options = webdriver.ChromeOptions()
        # self.options.add_argument('--headless')
        # self.driver = webdriver.Chrome(chrome_options=self.options, executable_path="chromedriver.exe")


    def start_requests(self):
        query = f'select * from myvipon_link_20210927 where status="done"'
        self.crsr.execute(query)
        all_url = self.crsr.fetchall()
        for surl in all_url[self.start:self.end]:
            Id = surl[0]
            url = surl[1]
            link = f"http://192.168.1.106:8050/render.html?wait=5&url={url}&proxy=http://lum-customer-xbyte-zone-zone_us-country-us:0gi0pioy3oey@zproxy.lum-superproxy.io:22225"

            # link = f'http://0.0.0.0:8050/render.html?wait=5&url={url}&proxy=http://lum-customer-xbyte-zone-zone_us-country-us:0gi0pioy3oey@zproxy.lum-superproxy.io:22225'
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'cache-control': 'max-age=0',
                'referer': 'https://www.myvipon.com/promotion',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
            }
            yield scrapy.Request(url=link, callback=self.parse, headers=headers, meta={'url': url,'Id':Id})

    def parse(self, response, **kwargs):
        item_id = response.meta['Id']
        HTML_Path = f"F:\khyati\Project_FP\\bungetech\\USmyvipon\\2021-09-29\\HTML"
        HTML_File_Name = HTML_Path + '//' + str(item_id) + '.html'
        with open(HTML_File_Name, 'wb') as f:
            f.write(response.body)
            f.close()
        sql_update_Query = f"update `bungeetech_daily_sites`.`myvipon_link_20210927` set status='page_done' where Id='{item_id}'"
        self.crsr.execute(sql_update_Query)
        self.con.commit()
        print("SQL Data updated....")

        # url = response.meta['url']
        # try:
        #     Title = response.xpath('//p[@class="product-title"]/text()').extract_first().encode('ascii','ignore').decode('utf8').strip()
        #     if Title == '':
        #         Title = response.xpath('//meta[@property="og:title"]/@content').extract_first().encode('ascii', 'ignore').decode('utf8').strip()
        # except Exception as e:
        #     print(e)
        #     Title = ''
        #
        # try:
        #     amazon_link = ''
        #     amazon_link = response.xpath('//p[@class="go-to-amazon"]/a/@href').extract_first()
        #     if '/gp/product/' in amazon_link:
        #         amazon_link = amazon_link.replace('/gp/product/', '/dp/')
        # except Exception as e:
        #     print(e)
        #     amazon_link = ''
        #
        # try:
        #     domain_promo_price = response.xpath('//p[@class="product-price"]/span/text()').extract_first().replace('$','')
        # except Exception as e:
        #     print(e)
        #     domain_promo_price = ''
        #
        # try:
        #     domain_price = response.xpath('//p[@class="product-price"]/s/text()').extract_first().replace('$', '')
        # except Exception as e:
        #     print(e)
        #     domain_price = ''
        #
        # HTML_Path = f"F:\khyati\Project_FP\\bungetech\\USmyvipon\\2021-09-29\\HTML"
        # Screenshot_Path = f"F:\khyati\Project_FP\\bungetech\\USmyvipon\\2021-09-29\\Screenshot"
        # # HTML_Path = '/media/xbyte/data/Projects Training' + '//Html//' + 'UKMyVipon' + f'//{datetime.now().date()}/HTML'
        # # Screenshot_Path = '/media/xbyte/data/Projects Training' + '//Html//' + 'UKMyVipon' + f'//{datetime.now().date()}/Screenshot'
        #
        # if not os.path.exists(HTML_Path):
        #     os.makedirs(HTML_Path)
        # if not os.path.exists(Screenshot_Path):
        #     os.makedirs(Screenshot_Path)
        #
        # x = datetime.now()
        # crawl_date_time = str(x).replace(' ', 'T').split('.')[0].replace('2021-09-30','2021-09-29')
        # date = '2021-09-29'#str(x).split(' ')[0]
        # Hash_Id = int(hashlib.md5(bytes(str(url) + str({date}), "utf8")).hexdigest(), 16) % (10 ** 20)
        # s3_url = ''
        # try:
        #     item_id = response.meta['Id']
        #     # item_id = item_id.split('-')[0]
        #     HTML_File_Name = HTML_Path + '//' + str(item_id) + '.html'
        #     with open(HTML_File_Name, 'wb') as f:
        #         f.write(response.body)
        #         f.close()
        #
        #     ss_url = f'file://{HTML_File_Name}'
        #     self.driver.get(ss_url)
        #     img_full_path = Screenshot_Path + f'/{item_id}.jpg'
        #     # S = lambda X: self.driver.execute_script('return document.body.parentNode.scroll' + X)
        #     # self.driver.set_window_size(S('Width'), S('Height'))
        #     self.driver.find_element_by_tag_name('body').screenshot(img_full_path)
        #     # self.driver.save_screenshot(img_full_path)
        #
        #     ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
        #     SECRET_KEY = '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'
        #     # dt = datetime.strftime(datetime.now(), "%d-%m-%Y")
        #     dt = "29-09-2021"
        #     month = datetime.strftime(datetime.now(), "%B")
        #     s3FolderName = "myvipon_US"
        #
        #     try:
        #         fileName = f'{item_id}.jpg'
        #         bucket = "bungee.internal.data"
        #         s3_folder = f"{month}'21/{dt}/{s3FolderName}/screenshots/domain/"
        #         FileToS3 = s3_folder + fileName
        #         s = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        #         # s.upload_file(FileFromMachine, bucket, FileToS3)
        #         s.upload_file(img_full_path, bucket, FileToS3, ExtraArgs={'ContentType': "image/png"})
        #         # s3_url = f"https://xbyte.s3.amazonaws.com/{s3_folder}{s3_file}"
        #         # print(f'Screenshot Uploaded to S3: {s3_url}')
        #         s3_url = s.generate_presigned_url('get_object',
        #                                           Params={'Bucket': bucket, 'Key': FileToS3},
        #                                           ExpiresIn=600000)
        #         # print(s3_url)
        #     except:
        #         pass
        # except Exception as e:
        #     print(e)
        #     print('Page not saved')
        #
        # item = MyviponItem()
        # item['HashID'] = Hash_Id
        # item['Date'] = date
        # item['Title'] = Title
        # item['crawl_date_time'] = crawl_date_time
        # item['site_name'] = 'myvipon'
        # item['review_url'] = url
        # item['country'] = 'United States'
        # item['amazon_url'] = amazon_link
        # item['asin'] = ''
        # item['sold_by'] = ''
        # item['seller_id'] = ''
        # item['screenshotamazonpage'] = ''
        # item['screenshotproductpage'] = s3_url
        # item['domain_promo_price'] = domain_promo_price
        # item['domain_price'] = domain_price
        # item['amazon_price'] = ''
        # yield item

    def close(self, reason):
        self.driver.close()


if __name__ == '__main__':
    execute('scrapy crawl USDataSpider -a start=0 -a end=1000000'.split())

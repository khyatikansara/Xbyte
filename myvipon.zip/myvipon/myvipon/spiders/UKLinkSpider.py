import scrapy
import json
import re
from scrapy.cmdline import execute
from scrapy_splash import SplashRequest

from myvipon.items import MyviponLinkItem


class UKLinkSpider(scrapy.Spider):

    name = 'UKLinkSpider'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def start_requests(self):
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            # 'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            # 'cookie': 'v_uid=25ee222eecdea2a741c4fcd0fbcfe1350f502951555ba9ce6604750bad7a2a81a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22v_uid%22%3Bi%3A1%3Bs%3A32%3A%22b486d036f13fad5113cd1c1a7c744ef6%22%3B%7D; _fbp=fb.1.1631961080435.348321364; __gads=ID=0b5addce55e612eb-22ef336538c9009d:T=1631961080:RT=1631961080:S=ALNI_Mab6LicKMOj_Tsv4bEffzpuPddyOw; d2018=www.amazon.co.uk; _gid=GA1.2.74642319.1632392828; _ga=GA1.1.2004448580.1631961080;',
            # 'cache-control': 'max-age=0',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
        }
        vipon_url = 'https://www.myvipon.com/promotion/guide%3Fdomain=www.amazon.co.uk%26page=1%26limit=500000'

        url = f'http://0.0.0.0:8050/render.html?wait=5&proxy=http://lum-customer-xbyte-zone-zone_us-country-us:0gi0pioy3oey@zproxy.lum-superproxy.io:22225&url={vipon_url}'

        # url = 'https://www.myvipon.com/promotion/guide?domain=www.amazon.co.uk&page=1&fba=&n=8&limit=500000'

        yield scrapy.Request(url=url, callback=self.parse, headers=headers)

    def parse(self, response, **kwargs):

        # json_value = json.loads(response.text)
        #
        # full_text = json_value['html']

        all_links = re.findall('getDetail\(\'(.*?)\',',response.text)

        for single in all_links:
            item = MyviponLinkItem()
            try:
                item['Link'] = f'https://www.myvipon.com{single}'
                yield item
            except Exception as e:
                print(e)


if __name__ == '__main__':
    execute('scrapy crawl UKLinkSpider'.split())

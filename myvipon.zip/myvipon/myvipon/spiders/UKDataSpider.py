import hashlib
import os

import scrapy
import json
import re
from scrapy.cmdline import execute
import pymysql
from myvipon.db_config import config
from scrapy.utils.response import open_in_browser
from datetime import datetime
from selenium.webdriver.firefox.options import Options
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from myvipon.items import MyviponItem
import boto3


class UKDataSpider(scrapy.Spider):

    name = 'UKDataSpider'

    def __init__(self, start='', end='', **kwargs):
        super().__init__(**kwargs)
        self.start = int(start)
        self.end = int(end)
        options = Options()
        options.add_argument('--headless')
        self.driver = webdriver.Firefox(options=options)

    def start_requests(self):
        con = pymysql.connect(host=config.db_host, user=config.db_user, password=config.db_password,
                              database=config.db_name)
        crsr = con.cursor()

        query = f'select * from {config.daily_link} where Status = "pending"'
        crsr.execute(query)

        all_url = crsr.fetchall()

        for surl in all_url[self.start:self.end]:
            url = surl[1]
            link = f'http://0.0.0.0:8050/render.html?wait=5&url={url}&proxy=http://lum-customer-xbyte-zone-zone_us-country-us:0gi0pioy3oey@zproxy.lum-superproxy.io:22225'
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'cache-control': 'max-age=0',
                'referer': 'https://www.myvipon.com/promotion',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
            }
            yield scrapy.Request(url=link, callback=self.parse, headers=headers, meta={'url': url})
            # break

    def parse(self, response, **kwargs):

        url = response.meta['url']
        try:
            Title = response.xpath('//p[@class="product-title"]/text()').get('').strip()
            if Title == '':
                Title = response.xpath('//meta[@property="og:title"]/@content').get('').strip()
        except Exception as e:
            print(e)
            Title = ''

        try:
            amazon_link = response.xpath('//p[@class="go-to-amazon"]/a/@href').get('')
            if '/gp/product/' in amazon_link:
                amazon_link = amazon_link.replace('/gp/product/', '/dp/')
        except Exception as e:
            print(e)
            amazon_link = ''

        try:
            domain_promo_price = response.xpath('//p[@class="product-price"]/span/text()').get('').replace('£', '')
        except Exception as e:
            print(e)
            domain_promo_price = ''

        try:
            domain_price = response.xpath('//p[@class="product-price"]/s/text()').get('').replace('£', '')
        except Exception as e:
            print(e)
            domain_price = ''

        HTML_Path = '/media/xbyte/data/Projects Training' + '//Html//' + 'UKMyVipon' + f'//{datetime.now().date()}/HTML'
        Screenshot_Path = '/media/xbyte/data/Projects Training' + '//Html//' + 'UKMyVipon' + f'//{datetime.now().date()}/Screenshot'

        if not os.path.exists(HTML_Path):
            os.makedirs(HTML_Path)
        if not os.path.exists(Screenshot_Path):
            os.makedirs(Screenshot_Path)

        x = datetime.now()
        crawl_date_time = str(x).replace(' ', 'T').split('.')[0]
        date = str(x).split(' ')[0]
        Hash_Id = int(hashlib.md5(bytes(str(url) + str({date}), "utf8")).hexdigest(), 16) % (10 ** 20)
        s3_url = ''
        try:
            item_id = url.split('product/')[1]
            item_id = item_id.split('-')[0]
            HTML_File_Name = HTML_Path + '//' + str(item_id) + '.html'
            with open(HTML_File_Name, 'wb') as f:
                f.write(response.body)
                f.close()

            ss_url = f'file://{HTML_File_Name}'
            self.driver.get(ss_url)
            img_full_path = Screenshot_Path + f'/{item_id}.jpg'
            self.driver.find_element_by_tag_name('body').screenshot(img_full_path)
            # self.driver.save_screenshot(img_full_path)

            ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
            SECRET_KEY = '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'
            dt = datetime.strftime(datetime.now(), "%d-%m-%Y")
            # dt = "17-09-2021"
            month = datetime.strftime(datetime.now(), "%B")
            s3FolderName = "myvipon_UK"

            try:
                fileName = f'{item_id}.jpg'
                bucket = "bungee.internal.data"
                s3_folder = f"{month}'21/{dt}/{s3FolderName}/screenshots/domain/"
                FileToS3 = s3_folder + fileName
                s = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
                # s.upload_file(FileFromMachine, bucket, FileToS3)
                s.upload_file(img_full_path, bucket, FileToS3, ExtraArgs={'ContentType': "image/png"})
                # s3_url = f"https://xbyte.s3.amazonaws.com/{s3_folder}{s3_file}"
                # print(f'Screenshot Uploaded to S3: {s3_url}')
                s3_url = s.generate_presigned_url('get_object',
                                                  Params={'Bucket': bucket, 'Key': FileToS3},
                                                  ExpiresIn=600000)
                # print(s3_url)
            except:
               pass
        except Exception as e:
            print(e)
            print('Page not saved')

        item = MyviponItem()
        item['HashID'] = Hash_Id
        item['Date'] = date
        item['Title'] = Title
        item['crawl_date_time'] = crawl_date_time
        item['site_name'] = 'myvipon'
        item['review_url'] = url
        item['country'] = 'United Kingdom'
        item['amazon_url'] = amazon_link
        item['asin'] = ''
        item['sold_by'] = ''
        item['seller_id'] = ''
        item['screenshotamazonpage'] = ''
        item['screenshotproductpage'] = s3_url
        item['domain_promo_price'] = domain_promo_price
        item['domain_price'] = domain_price
        item['amazon_price'] = ''
        yield item

    def close(self, reason):
        self.driver.close()


if __name__ == '__main__':
    execute('scrapy crawl UKDataSpider -a start=0 -a end=10000'.split())



import pymysql
import datetime


class config():
    db_host = "192.168.1.252"
    db_user = "root"
    db_password = "xbyte"
    db_name = "bungeetech_daily_sites"
    daily_link = "myvipon_link_20210927"
    # daily_link = f"myvipon_Link_{datetime.datetime.now().date()}".replace('-', '')
    data_table = f'myvipon_finaldata'



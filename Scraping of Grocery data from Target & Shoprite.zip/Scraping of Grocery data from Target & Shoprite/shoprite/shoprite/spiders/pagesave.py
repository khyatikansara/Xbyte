# -*- coding: utf-8 -*-
from datetime import datetime
import os
import socket
import time
import scrapy
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from shoprite.items import ShopriteFinalItem
from selenium.webdriver.common.by import By
from shoprite.pipelines import ShopritePipeline
from shoprite import db_config as dbc
from shoprite.spiders.temp import Temp


class pagesaveSpider(scrapy.Spider):
    name = 'link_pagesave'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.pipe = ShopritePipeline()
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress)

    def parse(self,response):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path")
            options = webdriver.ChromeOptions()
            driver = webdriver.Chrome(chrome_options=options)  # Optional argument, if not specified will search path.
            driver.maximize_window()
            time.sleep(5)
            driver.get("https://shop.shoprite.com/store/c977694")
            # time.sleep(10)
            delay = 10
            myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, 'Email')))
            print("Page is ready!")
            email = driver.find_element_by_id("Email")
            email.send_keys("stopthatsquirrel15@protonmail.com")
            password = driver.find_element_by_id("Password")
            password.send_keys("Xbyte1234.")
            time.sleep(3)
            driver.find_element_by_id("SignIn").click()
            print("Login Done")
            self.set.cursor.execute(f'Select * from {str(dbc.database)}.{self.pipe.table2} where status="pending" and Id>{self.start} and Id<{self.end}')
            self.set.con.commit()
            item_link_results = self.set.cursor.fetchall()
            view_all = ""
            for row in item_link_results:
                status = ""
                Id = row[0]
                url = row[1]
                category = row[2]
                status = row[4]
                item_file_name = f'{self.this_week_html_path}Link\\{Id}_{category.split("/")[0]}.html'
                final_file_name = item_file_name.replace('\\', '\\\\')
                if os.path.isfile(item_file_name):
                    print(f"already exist {Id}")
                    if status == 'pending':
                        self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table2} set status="Done",html_path="{final_file_name}" where Link="{url}"''')
                        self.set.con.commit()
                        print("data url updated")
                else:
                    driver.get(url)
                    time.sleep(10)
                    try:
                        if driver.find_element_by_xpath('//*[contains(text(),"Sorry, no products were found.")]'):
                            print(" Sorry, no products were found. ")
                            view_item_page = driver.page_source
                            self.set.page_save(item_file_name,view_item_page)
                            print(f"Item page save {Id}")
                            self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table2} set status="Sorry, no products were found.",html_path="{final_file_name}" where Link="{url}"''')
                            self.set.con.commit()
                            print("data url updated")
                            status = "Sorry, no products were found."
                    except Exception as e:
                        print(" ")
                    if status != "Sorry, no products were found.":
                        try:
                            if driver.find_element_by_xpath('//*[@class="pagingControls__viewAll"]'):
                                view_all = "found"
                                total_count = driver.find_element_by_xpath('//*[@class="productListing__counter"]').text.replace('(','').replace(')','')
                        except Exception as e:
                            view_all = "not found"
                            # total_count = driver.find_element_by_xpath('//*[@class="productListing__counter"]').text.replace('(', '').replace(')', '')
                        if view_all == "found":
                            flag = True
                            try:
                                if driver.find_element_by_xpath('//iframe[@class="hero-launcher-push"]'):
                                    flag = True
                                    # driver.find_element_by_tag_name('body').send_keys(Keys.HOME)
                                    # element = driver.find_element_by_xpath('//*[@class="pagingControls__viewAll"]')
                                    # coordinates = element.location_once_scrolled_into_view
                                    # driver.execute_script('window.scrollTo({}, {});'.format(coordinates['x'], coordinates['y']))
                                    # actions = ActionChains(driver)
                                    # actions.move_to_element(element).perform()
                                    # driver.execute_script("arguments[0].scrollIntoView();", element)
                                    # close_button = driver.find_element_by_xpath('//iframe[@class="hero-launcher-push"]//button').click()
                                    print("")
                            except Exception as e:
                                print(e)
                            if flag:
                                next_click = driver.find_element_by_xpath('//*[@class="pagingControls__viewAll"]').click()
                                time.sleep(10)
                                if driver.current_url == url:
                                    next_click = driver.find_element_by_xpath('//*[@class="pagingControls__viewAll"]').click()
                                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                                    time.sleep(10)
                                else:
                                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                                    time.sleep(10)
                                item_links = driver.find_elements_by_xpath('//*[@class="product__detailsLink"]')
                                while int(total_count) <= len(item_links):
                                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                                    item_links = driver.find_elements_by_xpath('//*[@class="product__detailsLink"]')
                                    if int(total_count) <= len(item_links):
                                        break
                                    else:
                                        continue
                                view_item_page = driver.page_source
                                self.set.page_save(item_file_name, view_item_page)
                                print(f"Item page save {Id}")
                                    # for item_link in item_links:
                                    #     final_link = item_link.get_attribute('href')
                                    #     item_name = item_link.text
                                    #     item_path = f"F:\\khyati\\Ajay sir SHOPRITE\\HTML\\shoprite_selenium\\data\\{final_link.split('/')[-1]}.html"
                                    #     if os.path.isfile(item_path):
                                    #         print("already exist")
                                    #     else:
                                    #         driver.find_element_by_tag_name('body').send_keys(Keys.CONTROL + Keys.TAB)
                                    #         driver.get(final_link)
                                    #         item_page = driver.page_source
                                    #         dbc.page_save(item_path, item_page)
                                    #         print("final Item page save")
                                    #         driver.back()
                                    #         item = ShopriteFinalItem()
                                    #         item['MainLink'] = url
                                    #         item['Category'] = category
                                    #         item['final_link'] = final_link
                                    #         item['name'] = item_name
                                    #         item['html_path'] = item_path.replace('\\','\\\\')
                                    #         yield item
                                self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table2} set status="Done",html_path="{final_file_name}" where Link="{url}"''')
                                self.set.con.commit()
                                print("data url updated")
                        else:
                            view_item_page = driver.page_source
                            self.set.page_save(item_file_name, view_item_page)
                            print(f"Item page save {Id}")
                            self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table2} set status="Done",html_path="{final_file_name}" where Link="{url}"''')
                            self.set.con.commit()
                            print("data url updated")
            driver.quit()
        except Exception as e:
            print(e)

from scrapy.cmdline import execute
# execute("scrapy crawl link_pagesave -a start=0 -a end=983".split())
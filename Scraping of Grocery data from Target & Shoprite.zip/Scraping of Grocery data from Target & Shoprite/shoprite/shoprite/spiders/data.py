# -*- coding: utf-8 -*-
import io
import json
from os import listdir
from os.path import isfile, join
import html2text
import requests, socket
import re
import pymysql
import scrapy
from lxml import html
from datetime import datetime
from scrapy.http import HtmlResponse
from w3lib.http import basic_auth_header
from unidecode import unidecode
from shoprite import db_config as dbc
from shoprite.items import ShopriteDataItem
from shoprite.pipelines import ShopritePipeline
from scrapy.cmdline import execute
from shoprite.spiders.temp import Temp


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.pipe = ShopritePipeline()
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress)

    def parse(self, response):
        try:
            # mypath = "D:\\khyati-H\\Ajay sir SHOPRITE\\HTML\\shoprite_selenium\\notfound\\"
            # onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
            # for files in onlyfiles:
            #     print(files)
            #     files1 = files.replace('.html','')
            #     final_links = f"https://shop.shoprite.com/store/c977694/product/{files1}"
            #     try:
            #         pipe.db_cursor.execute(f"update {dbc.database}.{dbc.table4} set Status='Done' where final_link='{final_links}'")
            #         pipe.db_con.commit()
            #         print("link updated")
            #     except Exception as e:
            #         print(e)
            # pipe.db_cursor.execute(f'Select * from {str(dbc.database)}.{dbc.table5} where availability="found" and online_price=""')
            self.set.cursor.execute(f'Select * from {str(dbc.database)}.link_2020_10_01 where Status="Done1" and Id>{self.start} and Id<{self.end}')
            # self.set.cursor.execute(f'Select * from {str(dbc.database)}.{self.pipe.table1} where Status="Done"')
            self.set.con.commit()
            link_results = self.set.cursor.fetchall()
            for row in link_results:
                try:
                    Id = row[0]
                    URL = row[3]
                    category = row[2]
                    # sub_category = row[6]
                    category_ranking = "" #row[5]
                    HTML_path = row[5]
                    # HTML_path = 'D:\\khyati-H\\Ajay sir SHOPRITE\\HTML\\shoprite_selenium\\notfound\\' + URL.split("/")[-1]+'.html'
                    file_open = self.set.page_read(HTML_path)
                    response1 = html.fromstring(file_open)
                    text = html2text.HTML2Text()
                    text.ignore_images = True
                    text.ignore_links = True
                    text.ignore_emphasis = True
                    text.body_width = 0
                    text.ignore_tables = True
                    sku_number = URL.split('/')[-1]
                    try:
                        download = str(datetime.now()).replace('-', '/').strip()
                        download_date = datetime.strptime(download.split()[0], '%Y/%m/%d').strftime('%m/%d/%Y')
                        download_time = f"{download_date} {download.split()[-1]}"
                    except Exception as e:
                        print(e)
                    if response1.xpath('//*[@class="basicInfo__brandName"]/text()'):
                        ava = "found"
                        try:
                            product_image = response1.xpath('//img[@class="product__image"]/@src')[0]
                        except Exception as e:
                            print(e)
                            product_image = ''
                        try:
                            Item_Name = response1.xpath('//*[@class="basicInfo__brandName"]/text()')[0]
                        except Exception as e:
                            print(e)
                        try:
                            product_description = response1.xpath('//h2[contains(text(),"Description")]/../*[@class="productLabel__value"]/text()')[0]
                        except Exception as e:
                            print(e)
                            product_description = ''
                        try:
                            online_price, online_price_currency = '', ''
                            if response1.xpath('//*[@class="productPriceInfo__regularPrice"]'):
                                reg_price = response1.xpath('//*[@class="productPriceInfo__regularPrice"]/span/text()')
                                if reg_price:
                                    reg_price = reg_price[0]
                                    if '/' in reg_price:
                                        R_PRICE = reg_price.strip().split('/')[0]
                                        r_p = R_PRICE.split(' ')[0]
                                        online_price = r_p
                                    else:
                                        online_price = reg_price.strip().split(' ')[0]
                                else:
                                    reg_price = response1.xpath('//*[@class="productPriceInfo__regularPrice"]/text()')
                                    if reg_price:
                                        reg_price = reg_price[0]
                                        if re.findall(r'\n', reg_price) and \
                                                response1.xpath('//*[@class="productPriceInfo__saleInfo"]/text()')[0] != 'On Sale!':
                                            reg_price = response1.xpath('//*[@class="productPriceInfo__salePrice"]/text()')
                                            if '/' in reg_price:
                                                reg_price = reg_price[0]
                                                R_PRICE = reg_price.strip().split('/')[0]
                                                r_p = R_PRICE.split(' ')[0]
                                                online_price = r_p
                                            else:
                                                reg_price = reg_price[0]
                                                online_price = reg_price.strip().split(' ')[0]
                                        else:
                                            online_price = ''
                            elif response1.xpath('//*[contains(text(),"Price: ")]'):
                                reg_price = response1.xpath('//*[contains(text(),"Price: ")]/following-sibling::text()')
                                if reg_price:
                                    reg_price = reg_price[0]
                                    if '/' in reg_price:
                                        R_PRICE = reg_price.strip().split('/')[0]
                                        r_p = R_PRICE.split(' ')[0]
                                        online_price = r_p
                                    else:
                                        online_price = reg_price.strip().split(' ')[0]
                                else:
                                    online_price = ''
                        except Exception as e:
                            print(e)
                            online_price = ''
                        # try:
                        #     pipe.db_cursor.execute(
                        #         f"update {dbc.database}.{dbc.table4} set Status='Done' where final_link='{URL}'")
                        #     pipe.db_con.commit()
                        #     print("link updated")
                        # except Exception as e:
                        #     print(e)
                        # try:
                        #     pipe.db_cursor.execute(
                        #         f"update {dbc.database}.{dbc.table5} set online_price='{online_price}' where url='{URL}'")
                        #     pipe.db_con.commit()
                        #     print("link updated")
                        # except Exception as e:
                        #     print(e)
                        if '$' in reg_price:
                            online_price_currency = '$'
                        try:
                            try:
                                brand = response1.xpath('//*[@class="product__imageLink"]/@data-brandname')
                                if brand:
                                    brand = brand[0]
                                else:
                                    brand = ''
                            except:
                                brand = response1.xpath('//*[@class="productPage__detail"]//@data-brand')
                                if brand:
                                    brand = brand[0]
                                else:
                                    brand = ''
                        except:
                            brand = ''

                        ingredients_list = {}
                        # --------Ingredients
                        try:
                            if response1.xpath('//*[@class="productLabel__title"][contains(text(),"Ingredients")]'):
                                title = response1.xpath('//*[@class="productLabel__title"][contains(text(),"Ingredients")]/text()')[0].strip()
                                ingredients_value_tmp = response1.xpath('//*[contains(text(),"Ingredients")]/../div[@class="productLabel__value"]/text()')[0].strip()
                                ingredients_value = text.handle(ingredients_value_tmp)
                                try:
                                    d = re.sub(r'\n{4, 50}', '\n', ingredients_value)
                                    d = re.sub(r'\n{3}', '\n', d)
                                    des = re.sub(r'(\n\s*)+\n+', '\n\n', d).replace('#', '').strip()
                                    des = re.sub('<[^<]+?>', '', str(des))  # Remove HTML tags
                                    des = re.sub(r'\\', "", des)
                                    des = re.sub(r'\"', "'", des)
                                    ingredients_value = des.encode('ascii', 'ignore').decode('utf8').strip()
                                except Exception as e:
                                    print('Problem in Beautifier :', e)
                                if '"' in ingredients_value:
                                    ingredients_value = ingredients_value.replace('"', "'")
                                ingredients_list[title] = ingredients_value
                            if ingredients_list == {}:
                                ingredients_list = ""
                        except Exception as e:
                            print(e)

                        # --------Warnings / Cautions
                        warnings = {}
                        try:
                            if response1.xpath('//*[@class="productLabel__title"][contains(text(),"Warnings / Cautions")]'):
                                title = response1.xpath('//*[@class="productLabel__title"][contains(text(),"Warnings / Cautions")]/text()')[0].strip()
                                Warnings_Cautions_value_tmp = response1.xpath('//*[contains(text(),"Warnings / Cautions")]/../div[@class="productLabel__value"]/text()')[0].strip()
                                Warnings_Cautions_value = text.handle(Warnings_Cautions_value_tmp)
                                try:
                                    d = re.sub(r'\n{4, 50}', '\n', Warnings_Cautions_value)
                                    d = re.sub(r'\n{3}', '\n', d)
                                    des = re.sub(r'(\n\s*)+\n+', '\n\n', d).replace('#', '').strip()
                                    des = re.sub('<[^<]+?>', '', str(des))  # Remove HTML tags
                                    des = re.sub(r'\\', "", des)
                                    des = re.sub(r'\"', "'", des)
                                    Warnings_Cautions_value = des.encode('ascii', 'ignore').decode('utf8').strip()
                                except Exception as e:
                                    print('Problem in Beautifier :', e)
                                warnings[title] = Warnings_Cautions_value
                            if warnings == {}:
                                warnings = ""
                        except Exception as e:
                            print(e)

                        try:
                            size = response1.xpath('//*[@class="basicInfo__size"]/text()')
                            if size:
                                size = size[0]
                                if '/' in size:
                                    size = dbc.convert(size)
                            else:
                                size = ''
                        except:
                            size = ''

                        # --------Nutrition_Info
                        try:
                            serving_size, number_of_servings_in_package, calories_per_serving = '', '', ''
                            calories_from_fat_per_serving, total_fat_per_serving, total_fat_per_serving_uom = '', '', ''
                            saturated_fat_per_serving, saturated_fat_per_serving_uom, trans_fat_per_serving = '', '', ''
                            trans_fat_per_serving_uom, cholesterol_per_serving, cholesterol_per_serving_uom = '', '', ''
                            sodium_per_serving, sodium_per_serving_uom, total_carb_per_serving = '', '', ''
                            total_carb_per_serving_uom, dietary_fibre_per_serving, dietary_fibre_per_serving_uom = '', '', ''
                            total_sugars_per_serving, total_sugars_per_serving_uom, protein_per_serving = '', '', ''
                            protein_per_serving_uom, vitamin_a_per_serving, vitamin_a_per_serving_uom = '', '', ''
                            vitamin_c_per_serving, vitamin_c_per_serving_uom, calcium_per_serving = '', '', ''
                            calcium_per_serving_uom, iron_per_serving, iron_per_serving_uom = '', '', ''
                            if response1.xpath('//*[@id="nutrionFacts"]'):
                                Nutrition_Info = []
                                Nutrition_Facts = {}
                                names = []
                                values = []
                                data = response1.xpath('//*[@class="normalText"]/label/text()')
                                for d in data:
                                    if d.strip() == 'Servings Per Container':
                                        servingsPercontainer = d.strip()
                                        names.append(servingsPercontainer)
                                        servingsPercontainer_value = response1.xpath('//*[contains(text(),"' + d.strip() + '")]/../span/text()')
                                        if servingsPercontainer_value:
                                            servingsPercontainer_value = servingsPercontainer_value[0]
                                            if '"' in servingsPercontainer_value:
                                                servingsPercontainer_value = servingsPercontainer_value.replace('"', "'")
                                        else:
                                            servingsPercontainer_value = ''
                                        number_of_servings_in_package = servingsPercontainer_value
                                        values.append(servingsPercontainer_value.strip())
                                    else:
                                        servingSize = d.strip()
                                        names.append(servingSize)
                                        servingSize_value = response1.xpath('//*[contains(text(),"' + d.strip() + '")]/../span/text()')
                                        if servingSize_value:
                                            servingSize_value = servingSize_value[0]
                                            if '"' in servingSize_value:
                                                servingSize_value = servingSize_value.replace('"', "'")
                                        else:
                                            servingSize_value = ''
                                        serving_size = servingSize_value
                                        values.append(servingSize_value.strip())

                                calories = response1.xpath('//*[@class="medBorder"]//label/text()')
                                for c in calories:
                                    if c.strip() == 'Calories':
                                        calaries = c.strip()
                                        names.append(calaries)
                                        calaries_value = response1.xpath('//*[contains(text(),"' + c.strip() + '")]/../span/text()')
                                        if calaries_value:
                                            calaries_value = calaries_value[0]
                                            if '"' in calaries_value:
                                                calaries_value = calaries_value.replace('"', "'")
                                        else:
                                            calaries_value = ''
                                        calories_per_serving = calaries_value
                                        calories_from_fat_per_serving = ""
                                        values.append(calaries_value.strip())
                                    else:
                                        calaries_fat = c.strip()
                                        names.append(calaries_fat)
                                        calaries_fat_value = response1.xpath('//*[contains(text(),"' + c.strip() + '")]/../span/text()')
                                        if calaries_fat_value:
                                            calaries_fat_value = calaries_fat_value[0]
                                            if '"' in calaries_fat_value:
                                                calaries_fat_value = calaries_fat_value.replace('"', "'")
                                        else:
                                            calaries_fat_value = ''
                                        calories_from_fat_per_serving = calaries_fat_value
                                        values.append(calaries_fat_value.strip())
                                for index, name in enumerate(names):
                                    Nutrition_Facts[name] = values[index]
                                macronutrients = []
                                macronutrients_data = response1.xpath('//*[@class="smBorder"]/label/text()')
                                for md in macronutrients_data:
                                    macro = {}
                                    title = response1.xpath('//*[@class="smBorder"]/label[contains(text(),"' + md.strip() + '")]/text()')
                                    if title:
                                        title = title[0]
                                    amount_unit = response1.xpath('//*[contains(text(),"' + md.strip() + '")]/../span[@class="ntrVal"]/text()')
                                    if amount_unit:
                                        amount_unit = amount_unit[0]
                                    if amount_unit != None and len(amount_unit) != 0:
                                        amount_digit = amount_unit#re.findall(r'\d+', amount_unit)
                                        unitOfMeasure = ''.join(re.findall(r'[a-z]|[A-Z]', amount_unit))
                                        if unitOfMeasure:
                                            unitOfMeasure = unitOfMeasure
                                            amount_digit = amount_digit.replace(unitOfMeasure,'')
                                        else:
                                            unitOfMeasure = ''
                                    else:
                                        amount_digit = ''
                                        unitOfMeasure = ''
                                    if response1.xpath('//*[contains(text(),"' + md.strip() + '")]/../span[@class="ntrDvp Bold"]'):
                                        dailyValue = response1.xpath('//*[contains(text(),"' + md.strip() + '")]/../span[@class="ntrDvp Bold"]/text()')
                                        if dailyValue:
                                            dailyValue = dailyValue[0]
                                    else:
                                        dailyValue = response1.xpath('//*[contains(text(),"' + md.strip() + '")]/../span[@class="ntrDvp"]/text()')
                                        if dailyValue:
                                            dailyValue = dailyValue[0]
                                    if title != None:
                                        macro['title'] = title
                                    else:
                                        macro['title'] = ''
                                    if amount_digit != None:
                                        macro['amount_digit'] = amount_digit
                                    else:
                                        macro['amount_digit'] = ''
                                    if unitOfMeasure != None:
                                        macro['unitOfMeasure'] = unitOfMeasure
                                    else:
                                        macro['unitOfMeasure'] = ''
                                    if dailyValue != None:
                                        macro['dailyValue'] = dailyValue
                                    else:
                                        macro['dailyValue'] = ''
                                    macronutrients.append(macro)
                                total_sugars_per_serving=total_sugars_per_serving_uom=''
                                for nd in macronutrients:
                                    if nd['title'] == "Total Fat":
                                        total_fat_per_serving = nd['amount_digit']
                                        total_fat_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Saturated Fat ":
                                        saturated_fat_per_serving = nd['amount_digit']
                                        saturated_fat_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Trans Fat ":
                                        trans_fat_per_serving = nd['amount_digit']
                                        trans_fat_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Cholesterol":
                                        cholesterol_per_serving = nd['amount_digit']
                                        cholesterol_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Sodium":
                                        sodium_per_serving = nd['amount_digit']
                                        sodium_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Total Carbohydrate":
                                        total_carb_per_serving = nd['amount_digit']
                                        total_carb_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Dietary Fiber ":
                                        dietary_fibre_per_serving = nd['amount_digit']
                                        dietary_fibre_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Sugars ":
                                        total_sugars_per_serving = nd['amount_digit']
                                        total_sugars_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Protein":
                                        protein_per_serving = nd['amount_digit']
                                        protein_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Vitamin A":
                                        vitamin_a_per_serving = nd['amount_digit']
                                        vitamin_a_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Vitamin C":
                                        vitamin_c_per_serving = nd['amount_digit']
                                        vitamin_c_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Calcium":
                                        calcium_per_serving = nd['amount_digit']
                                        calcium_per_serving_uom = nd['unitOfMeasure']
                                    if nd['title'] == "Iron":
                                        iron_per_serving = nd['amount_digit']
                                        iron_per_serving_uom = nd['unitOfMeasure']

                                # Nutrition_Facts['macronutrients'] = macronutrients
                                # raw_data['Nutrition_Facts'] = Nutrition_Facts
                                # Nutrition_Info.append(raw_data)
                                # tmp = {}
                                # table_key = []
                                # table_value = []
                                # table_child = []
                                # if response2.xpath('//*[@id="nutrionFacts"]//table'):
                                #     tr = response2.xpath('//tr')
                                #     for t in tr:
                                #         u = t.xpath('./td/text()')
                                #         if len(u) == 4:
                                #             td = t.xpath('./td[1]/text()')[0].strip()
                                #             table_key.append(td)
                                #             td = t.xpath('./td/text()')[1:]
                                #             table_child.append(td)
                                #
                                #         elif len(u) == 3 and t.xpath('./td[@colspan="2"]'):
                                #             td1 = t.xpath('./td/text()')[0].strip()
                                #             table_key.append(td1)
                                #             td2 = t.xpath('./td/text()')
                                #             td2[0] = ""
                                #             table_child.append(td2)
                                #         elif len(u) == 1:
                                #             td = t.xpath('./td[1]/text()')[0].strip()
                                #             Nutrition_Facts['text'] = td
                                #         elif len(u) == 3 and u[0] == "Calories:":
                                #             table_sibling_key = t.xpath('./td/text()')
                                #
                                #     for tbc in range(len(table_child)):
                                #         table_sibling = {}
                                #         for tsk in range(len(table_sibling_key)):
                                #             table_sibling[table_sibling_key[tsk]] = \
                                #             table_child[tbc][tsk]
                                #         tmp[table_key[tbc]] = table_sibling
                                #         table_value.append(tmp)
                                #     Nutrition_Facts['Nutrition_details'] = tmp
                                # elif response2.xpath('//*[@id="nutrionFacts"]/p'):
                                #     text = response2.xpath('//*[@id="nutrionFacts"]/p/text()')[0].strip()
                                #     Nutrition_Facts['text'] = text
                            # else:
                            #     serving_size,number_of_servings_in_package,calories_per_serving = '','',''
                            #     calories_from_fat_per_serving,total_fat_per_serving,total_fat_per_serving_uom = '','',''
                            #     saturated_fat_per_serving,saturated_fat_per_serving_uom,trans_fat_per_serving = '','',''
                            #     trans_fat_per_serving_uom,cholesterol_per_serving,cholesterol_per_serving_uom = '','',''
                            #     sodium_per_serving,sodium_per_serving_uom,total_carb_per_serving = '','',''
                            #     total_carb_per_serving_uom,dietary_fibre_per_serving,dietary_fibre_per_serving_uom = '','',''
                            #     total_sugars_per_serving,total_sugars_per_serving_uom,protein_per_serving = '','',''
                            #     protein_per_serving_uom,vitamin_a_per_serving,vitamin_a_per_serving_uom = '','',''
                            #     vitamin_c_per_serving,vitamin_c_per_serving_uom,calcium_per_serving = '','',''
                            #     calcium_per_serving_uom,iron_per_serving,iron_per_serving_uom = '','',''
                        except Exception as e:
                            print(e)

                        try:
                            item = ShopriteDataItem()
                            item['product_image'] = product_image
                            # item['keywords'] = keywords
                            item['download_time'] = download_time
                            item['url'] = URL
                            category1 = category.split('/')[0]
                            item['category'] = category1
                            sub_category = '>'.join(category.split('/')[1:])
                            item['sub_category'] = sub_category
                            item['Item_Name'] = Item_Name
                            item['product_description'] = product_description
                            item['price'] = online_price
                            # item['online_price_currency'] = online_price_currency
                            item['availability'] = ava
                            # item['in_store_price'] = in_store_price
                            # item['in_store_price_currency'] = in_store_price_currency
                            # item['additional_description'] = additional_description
                            item['ingredients_list'] = ingredients_list
                            item['brand'] = brand
                            # item['manufacturer_name'] = manufacturer_name
                            item['size'] = size
                            # item['net_weight'] = net_weight
                            # item['gross_weight'] = gross_weight
                            # item['upc'] = upc
                            # item['asin'] = asin
                            # item['hidden_upc'] = hidden_upc
                            item['sku_number'] = sku_number
                            # item['retailer_product_code'] = retailer_product_code
                            # item['directions_information'] = directions_information
                            item['warnings'] = warnings
                            item['serving_size'] = serving_size
                            # item['serving_size_uom'] = serving_size_uom
                            item['number_of_servings_in_package'] = number_of_servings_in_package
                            item['calories_per_serving'] = calories_per_serving
                            item['calories_from_fat_per_serving'] = calories_from_fat_per_serving
                            item['total_fat_per_serving'] = total_fat_per_serving
                            item['total_fat_per_serving_uom'] = total_fat_per_serving_uom
                            item['saturated_fat_per_serving'] = saturated_fat_per_serving
                            item['saturated_fat_per_serving_uom'] = saturated_fat_per_serving_uom
                            item['trans_fat_per_serving'] = trans_fat_per_serving
                            item['trans_fat_per_serving_uom'] = trans_fat_per_serving_uom
                            item['cholesterol_per_serving'] = cholesterol_per_serving
                            item['cholesterol_per_serving_uom'] = cholesterol_per_serving_uom
                            item['sodium_per_serving'] = sodium_per_serving
                            item['sodium_per_serving_uom'] = sodium_per_serving_uom
                            item['total_carb_per_serving'] = total_carb_per_serving
                            item['total_carb_per_serving_uom'] = total_carb_per_serving_uom
                            item['dietary_fibre_per_serving'] = dietary_fibre_per_serving
                            item['dietary_fibre_per_serving_uom'] = dietary_fibre_per_serving_uom
                            item['total_sugars_per_serving'] = total_sugars_per_serving
                            item['total_sugars_per_serving_uom'] = total_sugars_per_serving_uom
                            item['protein_per_serving'] = protein_per_serving
                            item['protein_per_serving_uom'] = protein_per_serving_uom
                            item['vitamin_a_per_serving'] = vitamin_a_per_serving
                            item['vitamin_a_per_serving_uom'] = vitamin_a_per_serving_uom
                            item['vitamin_c_per_serving'] = vitamin_c_per_serving
                            item['vitamin_c_per_serving_uom'] = vitamin_c_per_serving_uom
                            item['calcium_per_serving'] = calcium_per_serving
                            item['calcium_per_serving_uom'] = calcium_per_serving_uom
                            item['iron_per_serving'] = iron_per_serving
                            item['iron_per_serving_uom'] = iron_per_serving_uom
                            # item['dietary_symbols'] = dietary_symbols
                            # item['secondary_image'] = secondary_image
                            # item['number_of_customer_reviews'] = number_of_customer_reviews
                            # item['customer_review_rating'] = customer_review_rating
                            # item['aplus_images'] = aplus_images
                            # item['category_ranking'] = category_ranking
                            # item['table'] = self.pipe.table3
                            # item['search_terms'] = search_terms
                            # item['search_terms_ranking'] = search_terms_ranking
                            # item['shipping_details'] = shipping_details
                            # item['shipping_dimensions'] = shipping_dimensions
                            # item['specifications'] = specifications
                            # item['shipping_weight'] = shipping_weight
                            # item['warranty'] = warranty
                            # item['ean_gtin'] = ean_gtin
                            # item['storage'] = storage
                            # item['country_of_origin'] = country_of_origin
                            # item['allergy_advice'] = allergy_advice
                            # item['recycling_information'] = recycling_information
                            # item['salt_per_serving'] = salt_per_serving
                            # item['salt_per_serving_uom'] = salt_per_serving_uom
                            # item['serving_size_2'] = serving_size_2
                            # item['serving_size_2_uom'] = serving_size_2_uom
                            # item['dietary_information'] = dietary_information
                            # item['product_other_information'] = product_other_information
                            # item['packaging'] = packaging
                            # item['additives'] = additives
                            # item['footer_product_info'] = footer_product_info
                            # item['award_symbol'] = award_symbol
                            # item['drive'] = drive
                            # item['enhanced_content'] = enhanced_content
                            # item['retailer_category'] = retailer_category
                            # item['retailer_subcategory'] = retailer_subcategory
                            # item['additional_desc_bullet_count'] = additional_desc_bullet_count
                            #item['video'] = video
                            # item['coupons'] = coupons
                            #item['products_per_page'] = products_per_page
                            #item['retailer_id'] = retailer_id
                            #item['addon_item'] = addon_item
                            #item['syndicated_data'] = syndicated_data
                            #item['harvested_price'] = harvested_price
                            #item['price_per_unit'] = price_per_unit
                            #item['price_per_unit_uom'] = price_per_unit_uom
                            #item['scrape_code'] = scrape_code
                            #item['image_alt_text'] = image_alt_text
                            #item['promotion'] = promotion
                            # item['list_price'] = list_price
                            # item['coupon_discount_percentage'] = coupon_discount_percentage
                            # item['coupon_on_full_page_text'] = coupon_on_full_page_text
                            # item['alcohol_content'] = alcohol_content
                            # item['mpc'] = mpc
                            # item['variant_information'] = variant_information
                            # item['pack_size'] = pack_size
                            # item['secondary_image_total'] = secondary_image_total
                            yield item
                        except Exception as e:
                            print(e)
                    else:
                        ava = "not found"
                        try:
                            sub_category = '>'.join(category.split('/')[1:])
                            item = ShopriteDataItem()
                            # item['product_image'] = product_image
                            # item['keywords'] = keywords
                            item['download_time'] = download_time
                            item['url'] = URL
                            item['category'] = category
                            item['sub_category'] = sub_category
                            item['product_description'] = ''
                            # item['online_price'] = online_price
                            # item['online_price_currency'] = online_price_currency
                            item['availability'] = ava
                            # item['in_store_price'] = in_store_price
                            # item['in_store_price_currency'] = in_store_price_currency
                            # item['additional_description'] = additional_description
                            item['ingredients_list'] = ''
                            item['brand'] = ''
                            # item['manufacturer_name'] = manufacturer_name
                            item['size'] = ''
                            # item['net_weight'] = net_weight
                            # item['gross_weight'] = gross_weight
                            # item['upc'] = upc
                            # item['asin'] = asin
                            # item['hidden_upc'] = hidden_upc
                            item['sku_number'] = sku_number
                            # item['retailer_product_code'] = ''
                            # item['directions_information'] = ''
                            item['warnings'] = ''
                            item['serving_size'] = ''
                            item['serving_size_uom'] = ''
                            item['number_of_servings_in_package'] = ''
                            item['calories_per_serving'] = ''
                            item['calories_from_fat_per_serving'] = ''
                            item['total_fat_per_serving'] = ''
                            item['total_fat_per_serving_uom'] = ''
                            item['saturated_fat_per_serving'] = ''
                            item['saturated_fat_per_serving_uom'] = ''
                            item['trans_fat_per_serving'] = ''
                            item['trans_fat_per_serving_uom'] = ''
                            item['cholesterol_per_serving'] = ''
                            item['cholesterol_per_serving_uom'] = ''
                            item['sodium_per_serving'] = ''
                            item['sodium_per_serving_uom'] = ''
                            item['total_carb_per_serving'] = ''
                            item['total_carb_per_serving_uom'] = ''
                            item['dietary_fibre_per_serving'] = ''
                            item['dietary_fibre_per_serving_uom'] = ''
                            item['total_sugars_per_serving'] = ''
                            item['total_sugars_per_serving_uom'] = ''
                            item['protein_per_serving'] = ''
                            item['protein_per_serving_uom'] = ''
                            item['vitamin_a_per_serving'] = ''
                            item['vitamin_a_per_serving_uom'] = ''
                            item['vitamin_c_per_serving'] = ''
                            item['vitamin_c_per_serving_uom'] = ''
                            item['calcium_per_serving'] = ''
                            item['calcium_per_serving_uom'] = ''
                            item['iron_per_serving'] = ''
                            item['iron_per_serving_uom'] = ''
                            # item['table'] = self.pipe.table3
                            # item['dietary_symbols'] = dietary_symbols
                            # item['secondary_image'] = secondary_image
                            # item['number_of_customer_reviews'] = number_of_customer_reviews
                            # item['customer_review_rating'] = customer_review_rating
                            # item['aplus_images'] = aplus_images
                            # item['category_ranking'] = category_ranking
                            # item['search_terms'] = search_terms
                            # item['search_terms_ranking'] = search_terms_ranking
                            # item['shipping_details'] = shipping_details
                            # item['shipping_dimensions'] = shipping_dimensions
                            # item['specifications'] = specifications
                            # item['shipping_weight'] = shipping_weight
                            # item['warranty'] = warranty
                            # item['ean_gtin'] = ean_gtin
                            # item['storage'] = storage
                            # item['country_of_origin'] = country_of_origin
                            # item['allergy_advice'] = allergy_advice
                            # item['recycling_information'] = recycling_information
                            # item['salt_per_serving'] = salt_per_serving
                            # item['salt_per_serving_uom'] = salt_per_serving_uom
                            # item['serving_size_2'] = serving_size_2
                            # item['serving_size_2_uom'] = serving_size_2_uom
                            # item['dietary_information'] = dietary_information
                            # item['product_other_information'] = product_other_information
                            # item['packaging'] = packaging
                            # item['additives'] = additives
                            # item['footer_product_info'] = footer_product_info
                            # item['award_symbol'] = award_symbol
                            # item['drive'] = drive
                            # item['enhanced_content'] = enhanced_content
                            # item['retailer_category'] = retailer_category
                            # item['retailer_subcategory'] = retailer_subcategory
                            # item['additional_desc_bullet_count'] = additional_desc_bullet_count
                            # item['video'] = video
                            # item['coupons'] = coupons
                            # item['products_per_page'] = products_per_page
                            # item['retailer_id'] = retailer_id
                            # item['addon_item'] = addon_item
                            # item['syndicated_data'] = syndicated_data
                            # item['harvested_price'] = harvested_price
                            # item['price_per_unit'] = price_per_unit
                            # item['price_per_unit_uom'] = price_per_unit_uom
                            # item['scrape_code'] = scrape_code
                            # item['image_alt_text'] = image_alt_text
                            # item['promotion'] = promotion
                            # item['list_price'] = list_price
                            # item['coupon_discount_percentage'] = coupon_discount_percentage
                            # item['coupon_on_full_page_text'] = coupon_on_full_page_text
                            # item['alcohol_content'] = alcohol_content
                            # item['mpc'] = mpc
                            # item['variant_information'] = variant_information
                            # item['pack_size'] = pack_size
                            # item['secondary_image_total'] = secondary_image_total
                            yield item
                        except Exception as e:
                            print(e)
                    # if response1.xpath('//*[@class="product__detailsLink"]/@href'):
                    #     other_links = response1.xpath('//*[@class="product__detailsLink"]/@href')
                    #     for other_link in other_links:
                    #         item = ShopriteLinkItem()
                    #         item['Link'] = "https://shop.shoprite.com"+other_link
                    #         item['category'] = category
                    #         item['sub_category'] = sub_category
                    #         item['category_ranking'] = category_ranking
                    #         yield item
                except Exception as e:
                    print(e)
                    # try:
                    #     self.set.cursor.execute(f"update {dbc.database}.{self.pipe.table1} set Status='NO' where final_link='{URL}'")
                    #     self.set.con.commit()
                    #     print("link updated")
                    # except Exception as e:
                    #     print(e)
        except Exception as e:
            print(e)

# execute("scrapy crawl data".split())
# execute("scrapy crawl data -a start=0 -a end=26156".split())
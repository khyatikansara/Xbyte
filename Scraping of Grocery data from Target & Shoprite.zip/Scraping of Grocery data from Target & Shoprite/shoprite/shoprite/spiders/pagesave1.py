import socket
from datetime import datetime

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from shoprite.items import ShopriteItem
from shoprite import db_config as dbc
from shoprite.pipelines import ShopritePipeline
from shoprite.spiders.temp import Temp


class pagesave1Spider(scrapy.Spider):
    name = 'link_pagesave1'
    allowed_domains = []
    start_urls = ['https://example.com']

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.pipe = ShopritePipeline()
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress)

    def parse(self,response):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path")
            file_open = self.set.page_read(f"{self.this_week_html_path}\\ShopRite of West Deptford.html")
            response1 = html.fromstring(file_open)
            links = response1.xpath('//*[@class="menuItem__itemLink js-replacingMenuItemLink megaDropAccessibilityAnchor"]/@href')
            print(links)
            for link in links:
                Category = link.split('/c977694/')[1]
                item = ShopriteItem()
                item['Link'] = link
                item['Category'] = Category
                item['html_path'] = ""
                yield item
        except Exception as e:
            print(e)

# execute("scrapy crawl link_pagesave1".split())
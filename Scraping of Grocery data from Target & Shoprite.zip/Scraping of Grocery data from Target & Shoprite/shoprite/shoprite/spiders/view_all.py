# -*- coding: utf-8 -*-
import json
import os
import time
import socket
from datetime import datetime
import scrapy
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from shoprite.pipelines import ShopritePipeline
from selenium.webdriver.common.by import By
from shoprite import db_config as dbc
from scrapy.cmdline import execute
from shoprite.spiders.temp import Temp


class ViewAllSpider(scrapy.Spider):
    name = 'view_all'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.pipe = ShopritePipeline()
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress)

    def parse(self,response):
        try:
            self.this_week_html_path = self.set.get_name("this_week_html_path")
            # prox = Proxy()
            # prox.proxy_type = ProxyType.MANUAL
            # prox.http_proxy = "zproxy.lum-superproxy.io:22225"
            # capabilities = webdriver.DesiredCapabilities.CHROME
            # prox.add_to_capabilities(capabilities)
            options = webdriver.ChromeOptions()
            # options.add_argument('--proxy-server=%s' % "zproxy.lum-superproxy.io" + ":" + '22225')
            # options.headless = True

            driver = webdriver.Chrome(options=options)  # Optional argument, if not specified will search path.
            time.sleep(5)
            driver.get("https://shop.shoprite.com/store/c977694")
            # time.sleep(10)
            delay = 10
            myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, 'Email')))
            print("Page is ready!")
            email = driver.find_element_by_id("Email")
            email.send_keys("stopthatsquirrel15@protonmail.com")
            password = driver.find_element_by_id("Password")
            password.send_keys("Xbyte1234.")
            time.sleep(3)
            driver.find_element_by_id("SignIn").click()
            print("Login Done")
            self.set.cursor.execute(f'Select * from {str(dbc.database)}.{self.pipe.table1} where status="pending" and Id>{self.start} and Id<{self.end}')
            # pipe.db_cursor.execute(f'Select * from {str(dbc.database)}.{dbc.table5} where availability="not found" and status="pending"')
            self.set.con.commit()
            link_results = self.set.cursor.fetchall()
            for row in link_results:
                Id = row[0]
                final_link = row[3]
                status = row[6]
                item_path = f"{self.this_week_html_path}Data\\{final_link.split('/')[-1]}.html"
                final_item_path = item_path.replace("\\","\\\\")
                if os.path.isfile(item_path):
                    print(f"already exist {Id}")
                    if status == 'pending':
                        self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table1} set status="Done",html_path="{final_item_path}" where final_link="{final_link}"''')
                        self.set.con.commit()
                        print("data url updated")
                else:
                    # name = ""
                    driver.get(final_link)
                    time.sleep(5)
                    # try:
                    #     if driver.find_element_by_xpath('//*[@class="basicInfo__brandName"]'):
                    #         name = driver.find_element_by_xpath('//*[@class="basicInfo__brandName"]').text
                    # except Exception as e:
                    #     print(" Sorry, this product seems to be currently unavailable ")
                    item_page = driver.page_source
                    self.set.page_save(item_path, item_page)
                    print(f"final Item page save {Id}")
                    # if "'" in name:
                    self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table1} set status="Done",html_path="{final_item_path}" where final_link="{final_link}"''')
                    # pipe.db_cursor.execute(f'''update {dbc.database}.{dbc.table5} set status="Done" where url="{final_link}"''')
                    self.set.con.commit()
                    print("data url updated")
                    # else:
                    #     pipe.db_cursor.execute(f'''update {dbc.database}.{dbc.table4} set status="Done",html_path="{final_item_path}",name='{name}' where final_link="{final_link}"''')
                    #     # pipe.db_cursor.execute(f'''update {dbc.database}.{dbc.table5} set status="Done" where url="{final_link}"''')
                    #     pipe.db_con.commit()
                    #     print("data url updated")
            driver.quit()
        except Exception as e:
            print(e)

# execute("scrapy crawl view_all -a start=0 -a end=26359".split())
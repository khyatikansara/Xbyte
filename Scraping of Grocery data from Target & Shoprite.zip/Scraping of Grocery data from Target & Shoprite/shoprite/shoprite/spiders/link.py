import socket
from datetime import datetime

import pandas as pd
import requests
import scrapy
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from shoprite.items import ShopriteLinkItem
from shoprite import db_config as dbc
from shoprite.pipelines import ShopritePipeline
from shoprite.spiders.temp import Temp


class linkSpider(scrapy.Spider):
    name = 'link'
    allowed_domains = []
    start_urls = ['https://example.com']
    start, end = '', ''

    def __init__(self, name=None, **kwargs):
        super().__init__(name, **kwargs)
        self.set = Temp()
        self.pipe = ShopritePipeline()
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        self.run_date = str(datetime.today()).split()[0].replace('-', '_')
        self.set.basic(self.run_date, self.ipaddress)

    def parse(self,response):
        try:
            self.set.cursor.execute(f'Select * from {str(dbc.database)}.{self.pipe.table2} where status="Done" and Id>{self.start} and Id<{self.end}')
            self.set.con.commit()
            item_link_results = self.set.cursor.fetchall()
            for row in item_link_results:
                url = row[1]
                category = row[2]
                html_path = row[3]
                file_open = self.set.page_read(html_path)
                response1 = html.fromstring(file_open)
                selectors = response1.xpath('//*[@class="product__detailsLink"]')
                for selector in selectors:
                    link = "https://shop.shoprite.com" + selector.xpath('./@href')[0]
                    name = ''.join(selector.xpath('.//text()')).strip()
                    item = ShopriteLinkItem()
                    item['MainLink'] = url
                    item['Category'] = category
                    item['final_link'] = link
                    item['name'] = name
                    item['html_path'] = ""
                    yield item
                self.set.cursor.execute(f'''update {dbc.database}.{self.pipe.table2} set Status="Done1" where Link="{url}"''')
                self.set.con.commit()
                print("data url updated")
        except Exception as  e:
            print(e)


# execute("scrapy crawl link -a start=0 -a end=983".split())
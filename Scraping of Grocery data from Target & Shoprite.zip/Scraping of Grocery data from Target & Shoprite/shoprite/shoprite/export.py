from datetime import datetime

import pandas as pd
import re
import xlsxwriter
from shoprite import db_config as dbc
from shoprite.pipelines import ShopritePipeline
from shoprite.spiders.temp import Temp


def export_data():
    set = Temp()
    try:
        run_date = str(datetime.today()).split()[0].replace('-', '_')
        # this_week_html_path = set.get_name("this_week_html_path")
        this_week_html_path = "D:\\khyati-H\\Ajay sir SHOPRITE\\HTML\\shoprite\\Html_2020_10_01\\"
        sql = f"Select * from {dbc.database}.data_2020_10_26"
        df_all = pd.read_sql(sql, set.db_con)
        output_path = f"{this_week_html_path}CSV\\Shoprite_{run_date}.xlsx"
        df_all.drop(columns=['Hash_id'], inplace=True)
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', '_') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        df_all.to_excel(output_path, index=False)
        print('Excel File generated', output_path)
    except Exception as e:
        print(e)

export_data()
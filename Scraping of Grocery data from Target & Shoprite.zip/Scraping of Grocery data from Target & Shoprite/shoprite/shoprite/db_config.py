import os, platform
import re
from datetime import datetime, timedelta, date
from decimal import Decimal

host = "localhost"
usernm = "root"
passwd = "xbyte"
database = "West_Deptford_shoprite"

# table1 = "link"
# table2 = "data"
# table3 = "main_link"
# table4 = "final_links"
# table5 = "data_2020_08_17"
table7 = "history"


def convert(string):
    try:
        try:uofm = re.findall('(\D+)',string)[0]
        except:uofm = 'oz'
        temp = [re.findall('(\d+)',str(i).strip())[0] for i in string.split('/')]
        divided = Decimal(str(int(temp[0])/int(temp[1]))).quantize(Decimal('.01'))
        return f"{divided} {uofm}"
    except Exception as e:
        print(e)
        return "Please check size"
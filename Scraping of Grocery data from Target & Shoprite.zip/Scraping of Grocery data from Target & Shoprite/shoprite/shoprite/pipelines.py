# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql
from shoprite import db_config as dbc
from sqlalchemy import create_engine
from shoprite.spiders.temp import Temp
from shoprite.items import ShopriteItem,ShopriteLinkItem,ShopriteDataItem,ShopriteMainItem,ShopriteFinalItem

class ShopritePipeline:
    def __init__(self):
        self.count = 0
        self.engine = create_engine(f'mysql+pymysql://{str(dbc.usernm)}:{str(dbc.passwd)}@{str(dbc.host)}/{str(dbc.database)}')
        self.set = Temp()
        self.table1 = self.set.get_name('link_table')
        self.table2 = self.set.get_name('this_week_main')
        self.table3 = 'data_2020_10_26' #self.set.get_name('this_week_data_table')
    # con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd)
    # cursor = con.cursor()
    # cursor.execute(f'CREATE DATABASE IF NOT EXISTS {dbc.database} CHARACTER SET UTF8MB4 COLLATE utf8mb4_general_ci')
    # db_con = pymysql.connect(dbc.host, dbc.usernm, dbc.passwd, dbc.database)
    # db_cursor = db_con.cursor()

        # try:
        #     create_table_1 = "CREATE TABLE IF NOT EXISTS " + dbc.table1 + """(Id INT NOT NULL AUTO_INCREMENT,
        #                                                                         Link varchar(250),
        #                                                                         name longtext DEFAULT NULL,
        #                                                                         link_html longtext DEFAULT NULL,
        #                                                                         Status varchar(50) DEFAULT 'pending',
        #                                                                         UNIQUE KEY (`Link`),
        #                                                                            PRIMARY KEY (`Id`))"""
        #     db_cursor.execute(create_table_1)
        # except Exception as e:
        #     print(e)

        try:
            create_table_2 = "CREATE TABLE IF NOT EXISTS " + self.table2 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                Link varchar(250),
                                                                                Category longtext DEFAULT NULL,
                                                                                html_path longtext DEFAULT NULL,
                                                                                Status varchar(50) DEFAULT 'pending',
                                                                                UNIQUE KEY (`Link`),
                                                                                   PRIMARY KEY (`Id`))"""
            self.set.cursor.execute(create_table_2)
        except Exception as e:
            print(e)

        try:
            create_table_1 = "CREATE TABLE IF NOT EXISTS " + self.table1 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                MainLink varchar(250),
                                                                                Category longtext DEFAULT NULL,
                                                                                final_link varchar(250),
                                                                                name longtext DEFAULT NULL,
                                                                                html_path longtext DEFAULT NULL,
                                                                                Status varchar(50) DEFAULT 'pending',
                                                                                UNIQUE KEY (`final_link`),
                                                                                   PRIMARY KEY (`Id`))"""
            self.set.cursor.execute(create_table_1)
        except Exception as e:
            print(e)

        try:
            create_table_3 = "CREATE TABLE IF NOT EXISTS " + self.table3 + """(Id INT NOT NULL AUTO_INCREMENT,
                                                                                Item_Name longtext DEFAULT NULL,
                                                                                product_image longtext DEFAULT NULL,
                                                                                download_time longtext DEFAULT NULL,
                                                                                url varchar(250) DEFAULT NULL,
                                                                                category longtext DEFAULT NULL,
                                                                                sub_category longtext DEFAULT NULL,
                                                                                product_description longtext DEFAULT NULL,
                                                                                price longtext DEFAULT NULL,
                                                                                availability longtext DEFAULT NULL,
                                                                                ingredients_list longtext DEFAULT NULL,
                                                                                brand longtext DEFAULT NULL,
                                                                                manufacturer_name longtext DEFAULT NULL,
                                                                                size longtext DEFAULT NULL,
                                                                                sku_number longtext DEFAULT NULL,
                                                                                warnings longtext DEFAULT NULL,
                                                                                serving_size longtext DEFAULT NULL,
                                                                                serving_size_uom longtext DEFAULT NULL,
                                                                                number_of_servings_in_package longtext DEFAULT NULL,
                                                                                calories_per_serving longtext DEFAULT NULL,
                                                                                calories_from_fat_per_serving longtext DEFAULT NULL,
                                                                                total_fat_per_serving longtext DEFAULT NULL,
                                                                                total_fat_per_serving_uom longtext DEFAULT NULL,
                                                                                saturated_fat_per_serving longtext DEFAULT NULL,
                                                                                saturated_fat_per_serving_uom longtext DEFAULT NULL,
                                                                                trans_fat_per_serving longtext DEFAULT NULL,
                                                                                trans_fat_per_serving_uom longtext DEFAULT NULL,
                                                                                cholesterol_per_serving longtext DEFAULT NULL,
                                                                                cholesterol_per_serving_uom longtext DEFAULT NULL,
                                                                                sodium_per_serving longtext DEFAULT NULL,
                                                                                sodium_per_serving_uom longtext DEFAULT NULL,
                                                                                total_carb_per_serving longtext DEFAULT NULL,
                                                                                total_carb_per_serving_uom longtext DEFAULT NULL,
                                                                                dietary_fibre_per_serving longtext DEFAULT NULL,
                                                                                dietary_fibre_per_serving_uom longtext DEFAULT NULL,
                                                                                total_sugars_per_serving longtext DEFAULT NULL,
                                                                                total_sugars_per_serving_uom longtext DEFAULT NULL,
                                                                                protein_per_serving longtext DEFAULT NULL,
                                                                                protein_per_serving_uom longtext DEFAULT NULL,
                                                                                vitamin_a_per_serving longtext DEFAULT NULL,
                                                                                vitamin_a_per_serving_uom longtext DEFAULT NULL,
                                                                                vitamin_c_per_serving longtext DEFAULT NULL,
                                                                                vitamin_c_per_serving_uom longtext DEFAULT NULL,
                                                                                calcium_per_serving longtext DEFAULT NULL,
                                                                                calcium_per_serving_uom longtext DEFAULT NULL,
                                                                                iron_per_serving longtext DEFAULT NULL,
                                                                                iron_per_serving_uom longtext DEFAULT NULL,
                                                                                Store_ID varchar(50) DEFAULT 'c429610',
                                                                                Hash_id varchar(40),
                                                                                PRIMARY KEY (`Id`),
                                                                                UNIQUE KEY (`Hash_id`,`url`)) CHARACTER SET utf8 COLLATE utf8_general_ci"""
            self.set.cursor.execute(create_table_3)
        except Exception as e:
            print(e)

    def process_item(self, item, spider):
        if isinstance(item, ShopriteItem):
            self.insert_item(self.table2,item)
        if isinstance(item, ShopriteLinkItem):
            self.insert_item(self.table1, item)
        if isinstance(item, ShopriteMainItem):
            self.insert_item(dbc.table3, item)
        if isinstance(item, ShopriteFinalItem):
            self.insert_item(dbc.table4, item)
        if isinstance(item, ShopriteDataItem):
            self.insert_item(self.table3, item)
            try:
                self.set.cursor.execute(
                    f"update {dbc.database}.link_2020_10_01 set Status='Done12' where final_link='{str(item['url'])}'")
                self.set.con.commit()
                print("link updated")
            except Exception as e:
                print(e)

    def insert_item(self, table, item):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.set.cursor.execute(insert_db)
            self.set.con.commit()
            print('\rdata inserted ')
        except Exception as e:
            print('problem in insertion ', str(e))
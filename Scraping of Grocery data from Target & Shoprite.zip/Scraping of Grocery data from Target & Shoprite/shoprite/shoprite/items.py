# product_image longtext DEFAULT NULL,
#                                                                             keywords longtext DEFAULT NULL,
#                                                                             download_time longtext DEFAULT NULL,
#                                                                             url longtext DEFAULT NULL,
#                                                                             category longtext DEFAULT NULL,
#                                                                             sub_category longtext DEFAULT NULL,
#                                                                             product_description longtext DEFAULT NULL,
#                                                                             online_price longtext DEFAULT NULL,
#                                                                             online_price_currency longtext DEFAULT NULL,
#                                                                             availability longtext DEFAULT NULL,
#                                                                             in_store_price longtext DEFAULT NULL,
#                                                                             in_store_price_currency longtext DEFAULT NULL,
#                                                                             additional_description longtext DEFAULT NULL,
#                                                                             ingredients_list longtext DEFAULT NULL,
#                                                                             brand longtext DEFAULT NULL,
#                                                                             manufacturer_name varchar(250) DEFAULT NULL,
#                                                                             size longtext DEFAULT NULL,
#                                                                             net_weight longtext DEFAULT NULL,
#                                                                             gross_weight longtext DEFAULT NULL,
#                                                                             upc longtext DEFAULT NULL,
#                                                                             asin longtext DEFAULT NULL,
#                                                                             hidden_upc longtext DEFAULT NULL,
#                                                                             sku_number longtext DEFAULT NULL,
#                                                                             retailer_product_code longtext DEFAULT NULL,
#                                                                             directions_information longtext DEFAULT NULL,
#                                                                             warnings longtext DEFAULT NULL,
#                                                                             serving_size longtext DEFAULT NULL,
#                                                                             serving_size_uom longtext DEFAULT NULL,
#                                                                             number_of_servings_in_package longtext DEFAULT NULL,
#                                                                             calories_per_serving longtext DEFAULT NULL,
#                                                                             calories_from_fat_per_serving longtext DEFAULT NULL,
#                                                                             total_fat_per_serving longtext DEFAULT NULL,
#                                                                             total_fat_per_serving_uom varchar(250) DEFAULT NULL,
#                                                                             saturated_fat_per_serving longtext DEFAULT NULL,
#                                                                             saturated_fat_per_serving_uom longtext DEFAULT NULL,
#                                                                             trans_fat_per_serving longtext DEFAULT NULL,
#                                                                             trans_fat_per_serving_uom longtext DEFAULT NULL,
#                                                                             cholesterol_per_serving varchar(250) DEFAULT NULL,
#                                                                             cholesterol_per_serving_uom longtext DEFAULT NULL,
#                                                                             sodium_per_serving longtext DEFAULT NULL,
#                                                                             sodium_per_serving_uom longtext DEFAULT NULL,
#                                                                             total_carb_per_serving longtext DEFAULT NULL,
#                                                                             total_carb_per_serving_uom longtext DEFAULT NULL,
#                                                                             dietary_fibre_per_serving longtext DEFAULT NULL,
#                                                                             dietary_fibre_per_serving_uom longtext DEFAULT NULL,
#                                                                             total_sugars_per_serving longtext DEFAULT NULL,
#                                                                             total_sugars_per_serving_uom longtext DEFAULT NULL,
#                                                                             protein_per_serving longtext DEFAULT NULL,
#                                                                             protein_per_serving_uom longtext DEFAULT NULL,
#                                                                             vitamin_a_per_serving longtext DEFAULT NULL,
#                                                                             vitamin_a_per_serving_uom longtext DEFAULT NULL,
#                                                                             vitamin_c_per_serving longtext DEFAULT NULL,
#                                                                             vitamin_c_per_serving_uom longtext DEFAULT NULL,
#                                                                             calcium_per_serving longtext DEFAULT NULL,
#                                                                             calcium_per_serving_uom longtext DEFAULT NULL,
#                                                                             iron_per_serving longtext DEFAULT NULL,
#                                                                             iron_per_serving_uom longtext DEFAULT NULL,
#                                                                             dietary_symbols longtext DEFAULT NULL,
#                                                                             secondary_image longtext DEFAULT NULL,
#                                                                             number_of_customer_reviews longtext DEFAULT NULL,
#                                                                             customer_review_rating longtext DEFAULT NULL,
#                                                                             aplus_images longtext DEFAULT NULL,
#                                                                             category_ranking longtext DEFAULT NULL,
#                                                                             search_terms longtext DEFAULT NULL,
#                                                                             search_terms_ranking longtext DEFAULT NULL,
#                                                                             shipping_details longtext DEFAULT NULL,
#                                                                             shipping_dimensions longtext DEFAULT NULL,
#                                                                             specifications longtext DEFAULT NULL,
#                                                                             shipping_weight longtext DEFAULT NULL,
#                                                                             warranty longtext DEFAULT NULL,
#                                                                             ean_gtin longtext DEFAULT NULL,
#                                                                             storage longtext DEFAULT NULL,
#                                                                             country_of_origin longtext DEFAULT NULL,
#                                                                             allergy_advice longtext DEFAULT NULL,
#                                                                             recycling_information longtext DEFAULT NULL,
#                                                                             salt_per_serving longtext DEFAULT NULL,
#                                                                             salt_per_serving_uom longtext DEFAULT NULL,
#                                                                             serving_size_2 longtext DEFAULT NULL,
#                                                                             serving_size_2_uom longtext DEFAULT NULL,
#                                                                             dietary_information longtext DEFAULT NULL,
#                                                                             product_other_information longtext DEFAULT NULL,
#                                                                             packaging longtext DEFAULT NULL,
#                                                                             additives longtext DEFAULT NULL,
#                                                                             footer_product_info longtext DEFAULT NULL,
#                                                                             award_symbol longtext DEFAULT NULL,
#                                                                             drive longtext DEFAULT NULL,
#                                                                             enhanced_content longtext DEFAULT NULL,
#                                                                             retailer_category longtext DEFAULT NULL,
#                                                                             retailer_subcategory longtext DEFAULT NULL,
#                                                                             additional_desc_bullet_count longtext DEFAULT NULL,
#                                                                             video longtext DEFAULT NULL,
#                                                                             coupons longtext DEFAULT NULL,
#                                                                             products_per_page longtext DEFAULT NULL,
#                                                                             retailer_id longtext DEFAULT NULL,
#                                                                             addon_item longtext DEFAULT NULL,
#                                                                             syndicated_data longtext DEFAULT NULL,
#                                                                             harvested_price longtext DEFAULT NULL,
#                                                                             price_per_unit longtext DEFAULT NULL,
#                                                                             price_per_unit_uom longtext DEFAULT NULL,
#                                                                             scrape_code longtext DEFAULT NULL,
#                                                                             image_alt_text longtext DEFAULT NULL,
#                                                                             promotion longtext DEFAULT NULL,
#                                                                             list_price longtext DEFAULT NULL,
#                                                                             coupon_discount_percentage longtext DEFAULT NULL,
#                                                                             coupon_on_full_page_text longtext DEFAULT NULL,
#                                                                             alcohol_content longtext DEFAULT NULL,
#                                                                             mpc longtext DEFAULT NULL,
#                                                                             variant_information longtext DEFAULT NULL,
#                                                                             pack_size longtext DEFAULT NULL,
#                                                                             secondary_image_total longtext DEFAULT NULL,
# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

class ShopriteItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    def __setitem__(self, key, value):
        if key not in self.fields:
            self.fields[key] = scrapy.Field()
        self._values[key] = value
        super().__setitem__(key, value)

class ShopriteLinkItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    def __setitem__(self, key, value):
        if key not in self.fields:
            self.fields[key] = scrapy.Field()
        self._values[key] = value
        super().__setitem__(key, value)

class ShopriteDataItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    def __setitem__(self, key, value):
        if key not in self.fields:
            self.fields[key] = scrapy.Field()
        self._values[key] = value
        super().__setitem__(key, value)

class ShopriteMainItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    def __setitem__(self, key, value):
        if key not in self.fields:
            self.fields[key] = scrapy.Field()
        self._values[key] = value
        super().__setitem__(key, value)

class ShopriteFinalItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    def __setitem__(self, key, value):
        if key not in self.fields:
            self.fields[key] = scrapy.Field()
        self._values[key] = value
        super().__setitem__(key, value)


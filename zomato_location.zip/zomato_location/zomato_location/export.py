import pandas as pd
import pymysql
from unidecode import unidecode

def export_data():
    try:
        db_con = pymysql.connect('192.168.1.252', 'root', 'xbyte', 'zomato')
        # sql = f"Select * from zomato.app_data_2020_11_26"
        sql = f"Select * from zomato.web_data_2020_11_26"
        df_all = pd.read_sql(sql, db_con)
        # output_path = "D:\\khyati-H\\Zomato\\Zomato_APP_2020-11-27.xlsx"
        output_path = "D:\\khyati-H\\Zomato\\Zomato_WEBSITE_2020-11-30.xlsx"
        # df_all.drop(columns=['json_path'], inplace=True)
        df_all.drop(columns=['page_html','order_html'], inplace=True)
        old_columns = list(df_all.columns)
        new_columns = [column.replace('_', ' ') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df_all.rename(columns=columns, inplace=True)
        df_all.to_excel(output_path, index=True)
        print('Excel File generated', output_path)
    except Exception as e:
        print(e)

# def junk_remove():
#     df = pd.read_excel("F:\\khyati\\zomato\\HTML\\Zomato.xlsx")
#     for index,row in df.iterrows():
#         URL = row[2]
#         Restaurant_Name = row[3]
#         Cuisine = row[4]
#         Address = row[8]
#         new_URL = unidecode(URL.decode('utf-8'))
#         new_Restaurant_Name = unidecode(Restaurant_Name.decode('utf8'))
#         new_Cuisine = unidecode(Cuisine.decode('utf8'))
#         new_Address = unidecode(Address.decode('utf8'))
#         print(Restaurant_Name)
#         print(new_Restaurant_Name)
#     # my_clean_list = [unidecode(x.decode('utf8')) for x in my_list]


# junk_remove()
export_data()

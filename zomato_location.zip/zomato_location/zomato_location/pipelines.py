# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# class ZomatoLocationPipeline:
#     def process_item(self, item, spider):
#         return item

import datetime
import json
import pymongo
import dropbox
from scrapy.exceptions import DropItem
import pandas
import pymysql
from zomato_location.items import ZomatoLocationItem, ZomatoDataItem, ZomatoLinkItem


class ZomatoLocationPipeline:
    month = datetime.datetime.now().strftime("%d_%m_%Y")
    couter = 0

    try:
        con = pymysql.connect('192.168.1.140', 'root', 'xbyte')
        cursor = con.cursor()
        cursor.execute('CREATE DATABASE IF NOT EXISTS zomato_dubai')
    except Exception as e:
        print(str(e))
    con = pymysql.connect('192.168.1.140', 'root', 'xbyte', 'zomato_dubai')
    cursor = con.cursor()

    try:
        create = f"""CREATE TABLE IF NOT EXISTS link_2020_12_28 (`Id` int NOT NULL AUTO_INCREMENT,
                                                        URL varchar(255),
                                                        city varchar(255),
                                                        html longtext DEFAULT NULL,
                                                        status varchar(50) DEFAULT 'pending',
                                                        UNIQUE KEY (`URL`),
                                                        primary key(`Id`));"""
        cursor.execute(create)
    except Exception as e:
        print(e)

    try:
        create1 = f"""CREATE TABLE IF NOT EXISTS web_data_2020_12_28 (`Id` int NOT NULL AUTO_INCREMENT,
                                                        Restaurant_Id varchar(255) DEFAULT NULL,
                                                        URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Restaurant_Name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Cuisine longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Dining_Rating varchar(255),
                                                        Dining_Review varchar(255),
                                                        Dining_subtext varchar(255) DEFAULT NULL,
                                                        Delivery_Rating varchar(255),
                                                        Delivery_Review varchar(255),
                                                        Delivery_subtext varchar(255) DEFAULT NULL,
                                                        Cost_For_Two varchar(255),
                                                        Address longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        City varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        State varchar(255),
                                                        latitude varchar(255),
                                                        longitude varchar(255),
                                                        Order_Lockdown varchar(255),
                                                        Working_Hours longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Contactless_Dining_Option longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
                                                        Contactless_Dining_Option_text longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
                                                        Number_of_Outlets longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Popular_Dishes longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        place_is_known_for longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Known_for longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Other_Info longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Offers longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Vegetarian_Option longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Category_and_listed_number_of_Items longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        page_html longtext DEFAULT NULL,
                                                        order_html longtext DEFAULT NULL,
                                                        status varchar(50) DEFAULT NULL,
                                                        UNIQUE KEY (`Restaurant_Id`),
                                                        primary key(`Id`));"""
        cursor.execute(create1)
    except Exception as e:
        print(e)

    try:
        create2 = f"""CREATE TABLE IF NOT EXISTS app_data_2020_12_28 (`Id` int NOT NULL AUTO_INCREMENT,
                                                        Restaurant_Id varchar(255) DEFAULT NULL,
                                                        URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Restaurant_Name longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Cuisine longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Dining_Rating varchar(255),
                                                        Dining_Review varchar(255),
                                                        Dining_subtext varchar(255) DEFAULT NULL,
                                                        Delivery_Rating varchar(255),
                                                        Delivery_Review varchar(255),
                                                        Delivery_subtext varchar(255) DEFAULT NULL,
                                                        Cost_For_Two varchar(255),
                                                        Address longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        City varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        State varchar(255),
                                                        latitude varchar(255),
                                                        longitude varchar(255),
                                                        Order_Lockdown varchar(255),
                                                        Working_Hours longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Contactless_Dining_Option longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
                                                        Contactless_Dining_Option_text longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
                                                        Number_of_Outlets longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Popular_Dishes longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        place_is_known_for longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Known_for longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Other_Info longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Offers longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Vegetarian_Option longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        Category_and_listed_number_of_Items longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                        json_path longtext DEFAULT NULL,
                                                        status varchar(50) DEFAULT NULL,
                                                        UNIQUE KEY (`Restaurant_Id`),
                                                        primary key(`Id`));"""
        cursor.execute(create2)
    except Exception as e:
        print(e)

    try:
        create2 = f"""CREATE TABLE IF NOT EXISTS finallink_2020_12_28 (`Id` int NOT NULL AUTO_INCREMENT,
                                                                    URL longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                    Restaurant_Id varchar(255) DEFAULT NULL,
                                                                    html longtext DEFAULT NULL,
                                                                    status varchar(50) DEFAULT 'pending',
                                                                    UNIQUE KEY (`Restaurant_Id`),
                                                                    primary key(`Id`));"""
        cursor.execute(create2)
    except Exception as e:
        print(e)


    # try:
    #     MONGO_HOST = "51.161.13.140"
    #     MONGO_PORT = "27017"
    #     MONGO_DB = "zomato"
    #     MONGO_USER = "khyati.k"
    #     MONGO_PASS = "Khyati#123"
    #
    #     uri = "mongodb://{}:{}@{}:{}/{}?authSource=admin".format(MONGO_USER, MONGO_PASS, MONGO_HOST, MONGO_PORT, MONGO_DB)
    #
    #     connection = pymongo.MongoClient(uri)
    #     db = connection.zomato
    #     link_table = db['link']
    # except Exception as e:
    #     print(e)

    def process_item(self, item, spider):
        if isinstance(item, ZomatoLocationItem):
            self.couter+=1
            # self.link_table.insert(item)
            self.insert_item('link_2020_12_28', item, self.couter)

        if isinstance(item, ZomatoDataItem):
            self.couter+=1
            if spider.name == 'data_website':
                self.insert_item('web_data_2020_12_28', item, self.couter)
            else:
                self.insert_item('app_data_2020_12_28', item, self.couter)

        if isinstance(item, ZomatoLinkItem):
            self.couter+=1
            self.insert_item('finallink_2020_12_28', item, self.couter)

    def insert_item(self, table, item, counter):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(str(field))
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = "insert into " + table + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print('Data Inserted...', counter)
        except pymysql.IntegrityError as e:
            print('Duplicate entry ', str(e))
        except Exception as e:
            print('problem in Data insert ', str(e))

    def page_save(self, path, response):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(response)
            f.close()

    def page_read(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            file_open = file.read()
            file.close()
            return file_open




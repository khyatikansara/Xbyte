import json
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato_location.items import ZomatoLinkItem
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class ZomatotmpSpider(scrapy.Spider):
    name = 'zomato_tmp'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self, response):
        pipe.cursor.execute(f'select * from zomato_dubai.link_2020_12_28 where status="pending" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                url = row[1]
                path = row[3]
                file = pipe.page_read(self,path)
                response = html.fromstring(file)
                selectors = response.xpath('//*[@data-result-type="ResCard_Name"]')
                for selector in selectors:
                    try:
                        URL = unidecode(selector.xpath('./@href')[0])
                        Restaurant_Id = selector.xpath('./../../../../../../../@data-res_id')[0].strip()
                        item = ZomatoLinkItem()
                        item['URL'] = URL
                        item['Restaurant_Id'] = Restaurant_Id
                        yield item
                        # yield scrapy.Request(url=URL, callback=self.get_data, dont_filter=True, meta={'res_id': Restaurant_Id})
                    except Exception as e:
                        print(e)
                try:
                    pipe.cursor.execute(f'update zomato_dubai.link_2020_12_28 set status="Done" where URL="{url}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)


# execute("scrapy crawl zomato_tmp -a start=0 -a end=3389".split())
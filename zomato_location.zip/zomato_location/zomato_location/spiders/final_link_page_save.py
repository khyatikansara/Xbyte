import json
import os
from os import listdir
from os.path import isfile, join
import pandas as pd
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato_location.items import ZomatoLinkItem
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class ZomatoFinalPageSpider(scrapy.Spider):
    name = 'final_link_page'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self, response):
        pipe.cursor.execute(f'select * from zomato_dubai.finallink_2020_12_28 where status="pending" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                url = row[1]
                Restaurant_Id = row[2]
                yield scrapy.Request(url=url, callback=self.get_data, dont_filter=True, meta={'res_id': Restaurant_Id})
            except Exception as e:
                print(e)

    def get_data(self, response):
        try:
            Restaurant_Id = response.meta['res_id']
            order_ava = 'no'
            try:
                order_url = response.xpath('//a[contains(text(),"Order Online")]/@href').extract_first()
            except:
                order_url = ''
            if order_url == None:
                try:
                    pipe.cursor.execute(f'update zomato_dubai.finallink_2020_12_28 set status="no order" where Restaurant_Id="{Restaurant_Id}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
            if order_url != '' and order_url != None:
                order_ava = 'yes'
                order_path = f"D:\\khyati-H\\Zomato\\HTML_2021-01-19\\Order\\{Restaurant_Id}.html"
                try:
                    file_o = pipe.page_read(self, order_path)
                except Exception as e:
                    print(e)
                if not os.path.exists(order_path) or Restaurant_Id not in file_o:
                    header_o = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
                        'Cookie': 'PHPSESSID=f221d98b7a357b040f2935c6c18d6944; fre=0; rd=1380000; zl=en; fbtrack=3feb80d0ae55a2cd55b238514a0460a5; _gcl_au=1.1.1444906348.1608535772; _ga=GA1.2.90178738.1608535773; _gid=GA1.2.1157854073.1608535773; G_ENABLED_IDPS=google; _fbp=fb.1.1608535773745.1662307549; dpr=1; __gads=ID=c4d795ab306e73cc:T=1608705368:S=ALNI_MaAXX1j60EGGpMUo8qSyQUz_tnclw; expab=3; lty=city; fbcity=25; ltv=25; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A19.88%2C%22lng%22%3A75.32%2C%22cityId%22%3A25%2C%22ltv%22%3A25%2C%22lty%22%3A%22city%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A14368%2C%22fen%22%3A%22Aurangabad%22%7D; csrf=387fb8d91fc850cf3d50d80a1d1e8ac2; AWSALBTG=4EJFQNwSXyrfy7Zw2dVmcCcqnbe7T5PR/830/SXXO4F6XThbJrnY9AxsYPS5qAfNXqSMCowqGExYTB9d5El4gL/iLVQsLLMccFAcJRUIVoGwR3LN81V9qGClIFCt3KJ2H/oAGHkt+F89c51jIzokP16yEROCWdqair76uTIUXwNU; AWSALBTGCORS=4EJFQNwSXyrfy7Zw2dVmcCcqnbe7T5PR/830/SXXO4F6XThbJrnY9AxsYPS5qAfNXqSMCowqGExYTB9d5El4gL/iLVQsLLMccFAcJRUIVoGwR3LN81V9qGClIFCt3KJ2H/oAGHkt+F89c51jIzokP16yEROCWdqair76uTIUXwNU; zacpol=1'
                    }

                    res_o = requests.get(url=order_url, headers=header_o)
                    response_o = HtmlResponse(url=res_o.url, body=res_o.content)
                    pipe.page_save(self, order_path, response_o.text)
                    print("page save Done")

            # path = f"D:\\khyati-H\\Zomato\\HTML_2021-01-19\\Data\\{Restaurant_Id}.html"
            # pipe.page_save(self,path,response.text)
            # print("page save done")
            if order_ava == 'yes':
                try:
                    path = order_path.replace('\\','\\\\')
                    pipe.cursor.execute(f'update zomato_dubai.finallink_2020_12_28 set status="order page done",order_html="{path}" where Restaurant_Id="{Restaurant_Id}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
            else:
                try:
                    pipe.cursor.execute(f'update zomato_dubai.finallink_2020_12_28 set status="no order" where Restaurant_Id="{Restaurant_Id}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

execute("scrapy crawl final_link_page -a start=0 -a end=416459".split())
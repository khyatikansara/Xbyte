import json
import scrapy
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from scrapy.cmdline import execute
import requests
from scrapy.http import HtmlResponse


class LockdownCountSpider(scrapy.Spider):
    name = 'lockdown_count'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        pipe.cursor.execute(f'select * from zomato.data_2020_11_04 where Order_Lockdown="" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                while True:
                    Restaurant_Id = row[1]
                    url = f"https://api.zomato.com/v2/order/menu.json/{Restaurant_Id}"
                    headers = {
                        'X-Jumbo-Session-Id': '39d8ca1b-e207-4884-b596-fd3308bd54a31604570397',
                        'X-Zomato-API-Key': '7749b19667964b87a3efc739e254ada2',
                        'X-App-Language': '&lang=en&android_language=en&android_country=IN',
                        'X-Access-UUID': 'e9989f1c-8c8a-4cbd-be67-8aaddcb7d82c',
                        'X-Zomato-App-Version': '527',
                        'X-Present-Long': '72.5075895',
                        'X-Zomato-UUID': '51722a17-64af-4e96-8e24-26591c1af174',
                        'X-Access-Token': '',
                        'X-Appsflyer-UID': '1603278077568-4561078522886349397',
                        'X-City-Id': '51',
                        'X-Device-Width': '600',
                        'X-Zomato-Is-Metric': 'true',
                        'Akamai-Mobile-Connectivity': 'type=wifi;v=tpv1;tpresult=2;rtt=59;appdata=com.application.zomato;prepositioned=true;websdk=21.50.5;devicetype=1;rwnd=2097152;optimization=transport;p=a',
                        'X-Client-Id': 'zomato_android_v2',
                        'X-Present-Lat': '23.0260629',
                        'X-RIDER-INSTALLED': 'false',
                        'Accept': 'image/webp',
                        'X-User-Defined-Long': '55.2707828',
                        'X-Device-Height': '976',
                        'X-Zomato-App-Version-Code': '1710015270',
                        'X-Accessibility-Dynamic-Text-Scale-Factor': '1.0',
                        'Akamai-Referrer': 'com.application.zomato/15.2.7',
                        'USER-BUCKET': '0',
                        'USER-HIGH-PRIORITY': '1',
                        'X-Network-Type': 'wifi',
                        'X-User-Defined-Lat': '25.2048493',
                        'X-VPN-Active': '0',
                        'X-O2-City-Id': '51',
                        'User-Agent': '&source=android_market&version=5.1&device_manufacturer=Lenovo&device_brand=Lenovo&device_model=Lenovo+TB3-710I&api_version=527&app_version=v15.2.7',
                        'X-Device-Pixel-Ratio': '1.0',
                        'X-Installer-Package-Name': 'com.android.vending',
                        'X-DV-Token': 'DT_znx9PTRKFCj922eH5SPbkTbs-ouKkykdo6PmA2VjQ9H',
                        'X-Android-Id': '5eddd85b5f7124c1',
                        'X-Accessibility-Voice-Over-Enabled': '0',
                        'Host': 'api.zomato.com',
                        'Connection': 'Keep-Alive',
                        'Cookie': 'fre=0; rd=1380000; zl=en; fbtrack=7f1eb9cc8a9da010a2faf1deafef6e5c; fbcity=6; AWSALBTG=nHhTo4U6iN1Mi4ONLiXbaabGCgCKULbfrSEEUCftj3ggLhNTOGnENQw2BvBkOPPX7TRVfc0a1rYSxTX7xtLD6/Dl0GWHt89X7YWchWa1kWAQshJuNcWryAmdzjM/t0ASzwuLbPKlAbZfIYRr+zmh0QD76pKwwKYKzvsdER2bNDo4; AWSALBTGCORS=nHhTo4U6iN1Mi4ONLiXbaabGCgCKULbfrSEEUCftj3ggLhNTOGnENQw2BvBkOPPX7TRVfc0a1rYSxTX7xtLD6/Dl0GWHt89X7YWchWa1kWAQshJuNcWryAmdzjM/t0ASzwuLbPKlAbZfIYRr+zmh0QD76pKwwKYKzvsdER2bNDo4; csrf=ad2b0fab499d0d5c91ff7feab02fb4cb'
                    }
                    res_l = requests.get(url=url, headers=headers)
                    response_l = HtmlResponse(url=res_l.url, body=res_l.content)
                    if res_l.status_code == 200:
                        try:
                            Restaurant_Id = response_l.url.split('/')[-1]
                            path = f"D:\\khyati-H\\Zomato\\HTML_2020-11-04\\lockdown json\\{Restaurant_Id}.json"
                            pipe.page_save(self, path, response_l.text)
                            print("Page Save Done")
                            file = pipe.page_read(self, path)
                            # response1 = html.fromstring(file)
                            data_json = json.loads(file)
                            Order_Lockdown = data_json['top_snippets']
                            flag = True
                            locdown_count = ''
                            for count in range(len(Order_Lockdown)):
                                # print(Order_Lockdown[count])
                                if Order_Lockdown[count]['layout_config']['snippet_type'] == "ticker_snippet_type_1":
                                    flag = False
                                    data = Order_Lockdown[count]['ticker_snippet_type_1']['items'][0]['title']['text']
                                    if "lockdown" in data:
                                        locdown_count = data
                                        if "+" in locdown_count:
                                            print(locdown_count)
                                            try:
                                                pipe.cursor.execute(f'update zomato.data_2020_11_04 set Order_Lockdown="{locdown_count}" where Restaurant_Id="{Restaurant_Id}"')
                                                pipe.con.commit()
                                                print("update done")
                                            except Exception as e:
                                                print(e)
                            if flag:
                                try:
                                    pipe.cursor.execute(f'update zomato.data_2020_11_04 set Order_Lockdown="{locdown_count}" where Restaurant_Id="{Restaurant_Id}"')
                                    pipe.con.commit()
                                    print("update done")
                                except Exception as e:
                                    print(e)
                        except Exception as e:
                            print(e)
                        break
                # yield scrapy.Request(url=url, callback=self.get_data, headers=headers, dont_filter=True)
            except Exception as e:
                print(e)

    def get_data(self, response):
        try:
            Restaurant_Id = response.url.split('/')[-1]
            path = f"D:\\khyati-H\\Zomato\\HTML_2020-11-04\\lockdown json\\{Restaurant_Id}.json"
            pipe.page_save(self, path, response.text)
            print("Page Save Done")
            file = pipe.page_read(self, path)
            # response1 = html.fromstring(file)
            data_json = json.loads(file)
            Order_Lockdown = data_json['top_snippets']
            flag = True
            locdown_count = ''
            for count in range(len(Order_Lockdown)):
                # print(Order_Lockdown[count])
                if Order_Lockdown[count]['layout_config']['snippet_type'] == "ticker_snippet_type_1":
                    flag = False
                    data = Order_Lockdown[count]['ticker_snippet_type_1']['items'][0]['title']['text']
                    if "lockdown" in data:
                        locdown_count = data
                        if "+" in locdown_count:
                            print(locdown_count)
                            try:
                                pipe.cursor.execute(f'update zomato.data_2020_11_04 set Order_Lockdown="{locdown_count}" where Restaurant_Id="{Restaurant_Id}"')
                                pipe.con.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
            if flag:
                try:
                    pipe.cursor.execute(f'update zomato.data_2020_11_04 set Order_Lockdown="{locdown_count}" where Restaurant_Id="{Restaurant_Id}"')
                    pipe.con.commit()
                    print("update done")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

# execute("scrapy crawl lockdown_count -a start=0 -a end=379593".split())
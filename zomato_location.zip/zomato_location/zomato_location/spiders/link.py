import os
from os import listdir
from os.path import isfile, join

import scrapy
from lxml import html
from scrapy.cmdline import execute
from zomato_location.items import ZomatoLocationItem
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from datetime import datetime
import shutil


class LinkSpider(scrapy.Spider):
    name = 'link'
    allowed_domains = []
    start_urls = ['https://www.zomato.com']

    def parse(self,response):
        # urls = ['https://www.zomato.com/dubai/dubai-marina-restaurants',
        #        'https://www.zomato.com/dubai/motor-city-restaurants', 'https://www.zomato.com/dubai/difc-restaurants',
        #        'https://www.zomato.com/dubai/dubai-silicon-oasis-dso-restaurants',
        #        'https://www.zomato.com/dubai/mirdif-restaurants',
        #        'https://www.zomato.com/dubai/dubai-media-city-restaurants',
        #        'https://www.zomato.com/abudhabi/khalifa-city-restaurants',
        #        'https://www.zomato.com/abudhabi/al-reem-island-restaurants',
        #        'https://www.zomato.com/abudhabi/khalifa-city-restaurants']
        urls = ['https://www.zomato.com/abudhabi/restaurants/near/al-shawamekh',
                'https://www.zomato.com/abudhabi/restaurants/near/corniche']
        # urls = ['https://www.zomato.com/sharjah','https://www.zomato.com/dubai','https://www.zomato.com/abudhabi']
        for url in urls:
            yield scrapy.Request(url=url, callback=self.get_data, dont_filter=True)

    def get_data(self, response):
        try:
            page = response.text
            if '?' in response.url:
                file_name = f"{response.url.split('?')[0].split('/')[-1]}_{response.url.split('page=')[-1]}"
            else:
                file_name = f"{response.url.split('/')[-1]}"
            path = f"D:\\khyati-H\\Zomato\\HTML_2021-01-19\\Link\\{file_name}.html"
            pipe.page_save(self, path, page)
            city = response.url.split('/')[3]
            if city == "abudhabi":
                city = "Abu Dhabi"
            elif city == "dubai":
                city = "Dubai"
            else:
                city = "Sharjah"
            item = ZomatoLocationItem()
            item['URL'] = response.url
            item['city'] = city
            item['html'] = path.replace("\\","\\\\")
            yield item
            next_page = response.xpath('//a[@aria-label="Next Page"]/@href').extract_first()
            if next_page:
                next_url = f"{self.start_urls[0]}{next_page}"
                yield scrapy.Request(url=next_url, callback=self.get_data, dont_filter=True)
        except Exception as e:
            print(e)

# execute("scrapy crawl link".split())
import json
import os
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato_location.items import ZomatoDataItem
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from datetime import datetime
from scrapy.http import HtmlResponse


class DataAPPSpider(scrapy.Spider):
    name = 'data_app'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        pipe.cursor.execute(f'select * from zomato.data_2020_11_17 where json_status="Done" and Id>"{self.start}" and Id<"{self.end}"')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                Restaurant_Id = row[1]
                URL = row[2]
                json_path = f"D:\\khyati-H\\Zomato\\HTML_2020-11-17\\lockdown json\\{Restaurant_Id}.json"
                try:
                    file = pipe.page_read(self, json_path)
                    data_json = json.loads(file)

                    try:
                        Restaurant_Name = data_json['restaurant']['name']
                    except Exception as e:
                        print(e)

                    try:
                        Cuisines = ''
                        Cuisines = data_json['restaurant']['cuisines'].replace(', ',' | ')
                    except Exception as e:
                        print(e)
                        Cuisines = data_json['restaurant']['sections'][1]['section_items'][0]['subtitle']['text'].replace(', ', ' | ')

                    try:
                        Delivery_Rating = Dining_Rating = ''
                        rating_snippets = data_json['restaurant']['rating_snippets']
                        if rating_snippets != []:
                            for rating in rating_snippets:
                                if '"tag":{"title":{"text":"NEWLY OPENED",' in file:
                                    if rating['tag']['title']['text'] == "NEWLY OPENED":
                                        Dining_Rating = Delivery_Rating= "NEWLY OPENED"
                                else:
                                    if rating['text']['title']['prefix_icon']['color']['type'] == "black":
                                        Dining_Rating = rating['text']['title']['text']
                                    if rating['text']['title']['prefix_icon']['color']['type'] == "zRed":
                                        Delivery_Rating = rating['text']['title']['text']
                        else:
                            Dining_Rating = Delivery_Rating = ''
                    except Exception as e:
                        print(e)
                        Dining_Rating = Delivery_Rating = ''

                    try:
                        Dining_Review = ''
                        Dining_Review = str(data_json['restaurant']['all_reviews_count'])
                        if 'Reviews' in Dining_Review:
                            Dining_Review = Dining_Review.replace('Reviews', '')
                    except Exception as e:
                        print(e)
                        Dining_Review = ''

                    try:
                        Delivery_Review = ''
                        try:
                            Delivery_Review_sections = data_json['restaurant']['sections'][1]['section_items']
                            for Delivery_Review_section in Delivery_Review_sections:
                                if Delivery_Review_section['data']['rating_snippet']['stars']['bg_color']['type'] == "zRed":
                                    Delivery_Review = Delivery_Review_section['data']['rating_snippet']['stars']['subtitle']['text'].replace('(', '').replace(')', '')
                                else:
                                    Delivery_Review = ''
                        except Exception as e:
                            print(e)
                            Delivery_Review = str(data_json['restaurant']['sections'][1]['section_items'][1]['data']['rating_snippet']['stars']['subtitle']['text'].replace('(', '').replace(')', ''))
                        if 'Reviews' in Delivery_Review:
                            Delivery_Review = Delivery_Review.replace('Reviews', '')
                    except Exception as e:
                        print(e)
                        Delivery_Review = ''

                    try:
                        Cost_For_Two = ''
                        if "cost_for_details" in file:
                            try:
                                Cost_For_Two = re.findall(r'"cost_for_details":{"text":"(.*?)"}', file)[0]
                            except:
                                Cost_For_Two = data_json['restaurant']['sections'][1]['section_items'][1]['data']['cost_for_details']['text']
                            Cost_For_Two = "AED " + re.findall(r'AED (.*?)\s', Cost_For_Two)[0]
                        else:
                            Cost_For_Two = ''
                    except Exception as e:
                        print(e)
                        Cost_For_Two = ''

                    try:
                        Address = ''
                        Address = data_json['restaurant']['location']['address']
                    except Exception as e:
                        print(e)
                        Address = ''

                    try:
                        City = ''
                        City = data_json['restaurant']['location']['locality']
                    except Exception as e:
                        print(e)
                        City = ''

                    try:
                        State = ''
                        State = data_json['restaurant']['location']['city']
                    except Exception as e:
                        print(e)
                        State = ''

                    try:
                        latitude = ''
                        latitude = data_json['restaurant']['location']['latitude']
                    except Exception as e:
                        print(e)
                        latitude = ''

                    try:
                        longitude = ''
                        longitude = data_json['restaurant']['location']['longitude']
                    except Exception as e:
                        print(e)
                        longitude = ''

                    try:
                        if data_json['restaurant']['is_pure_veg'] == 1:
                            Vegetarian_Option = "Pure veg"
                        else:
                            Vegetarian_Option = "Veg Only"
                    except Exception as e:
                        print(e)

                    try:
                        Order_Lockdown = ''
                        Order_Lockdown_text = data_json['top_snippets']
                        for count in range(len(Order_Lockdown_text)):
                            if Order_Lockdown_text[count]['layout_config']['snippet_type'] == "ticker_snippet_type_1":
                                data = Order_Lockdown_text[count]['ticker_snippet_type_1']['items'][0]['title']['text']
                                if "lockdown" in data:
                                    locdown_count = data
                                    if "+" in locdown_count:
                                        Order_Lockdown = locdown_count
                                    else:
                                        print(locdown_count)
                    except Exception as e:
                        print(e)

                    try:
                        Working_Hours = ''
                        for work in data_json['restaurant']['sections'][1]['section_items']:
                            if work['type'] == "RES_HEADER":
                                Working_Hours = work['data']['custom_timings']['opening_hours']
                    except Exception as e:
                        print(e)
                        Working_Hours = ''

                    # try:
                    #     Contactless_Dining_Option_text = re.findall(r'"tagTitle\\":\\"(.*?)\\",\\"title\\":\\"\\",\\"subtitle\\":\\"(.*?)\\",\\"actionText\\":',file)
                    #     if len(Contactless_Dining_Option_text) == 1:
                    #         Contactless_Dining_Option = "Available"
                    #         Contactless_Dining_Option_1 = response.xpath(f'//*[contains(text(),"{Contactless_Dining_Option_text[0][0]}")]/following-sibling::*/text()')[0]
                    #     else:
                    #         Contactless_Dining_Option = "Not Available"
                    #         Contactless_Dining_Option_1 = ""
                    # except Exception as e:
                    #     print(e)

                    # try:
                    #     if response.xpath('//a//*[contains(text(),"See all")]/text()'):
                    #         Number_of_Outlets_text = response.xpath('//a//*[contains(text(),"See all")]/text()')
                    #         if len(Number_of_Outlets_text) == 1:
                    #             Number_of_Outlets = Number_of_Outlets_text[0]
                    #         elif len(Number_of_Outlets_text) > 1:
                    #             Number_of_Outlets = ' | '.join(Number_of_Outlets_text)
                    #         else:
                    #             Number_of_Outlets = ''
                    #     else:
                    #         Number_of_Outlets = ''
                    # except Exception as e:
                    #     print(e)

                    # try:
                    #     if response.xpath('//*[contains(text(),"Popular Dishes")]/following-sibling::p/text()'):
                    #         Popular_Dishes = ''.join(response.xpath('//*[contains(text(),"Popular Dishes")]/following-sibling::p[1]/text()'))
                    #         Popular_Dishes = Popular_Dishes.replace(', ', ' | ')
                    #     else:
                    #         Popular_Dishes = ''
                    # except Exception as e:
                    #     print(e)
                    #
                    # try:
                    #     if response.xpath('//*[contains(text(),"People Say This Place Is Known For")]/following-sibling::p[1]/text()'):
                    #         place_is_known_for = response.xpath('//*[contains(text(),"People Say This Place Is Known For")]/following-sibling::p[1]/text()')[0].replace(', ', ' | ')
                    #     else:
                    #         place_is_known_for = ''
                    # except Exception as e:
                    #     print(e)
                    #
                    # try:
                    #     if response.xpath('//*[text()="Known For"]/following-sibling::p[1]/text()'):
                    #         Known_for = ' | '.join(response.xpath('//*[text()="Known For"]/following-sibling::p[1]/text()'))
                    #     else:
                    #         Known_for = ''
                    # except Exception as e:
                    #     print(e)
                    #
                    # try:
                    #     if response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()'):
                    #         Other_Info = ' | '.join(response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()'))
                    #     else:
                    #         Other_Info = ''
                    # except Exception as e:
                    #     print(e)

                    try:
                        offer_list = []
                        offers_text = data_json['promos_on_menu']['promos']
                        for offer_text in offers_text:
                            title_obj = offer_text['title_obj']['text']
                            subtitle1 = offer_text['subtitle1']['text']
                            offer_list.append(f"{title_obj} : {subtitle1}")
                        Offers = ' | '.join(offer_list)
                    except Exception as e:
                        print(e)

                    try:
                        Category_and_listed = []
                        Menus = data_json['menus']
                        for menu in Menus:
                            total_count = []
                            item_name = menu['menu']['name']
                            category_count = menu['menu']['categories']
                            for cat_count in category_count:
                                listed_number_of_Items = len(cat_count['category']['items'])
                                total_count.append(listed_number_of_Items)
                            total_listed_number_of_Items = sum(total_count)
                            Category_and_listed.append(f"{item_name} ({total_listed_number_of_Items})")
                        Category_and_listed_number_of_Items = ' | '.join(Category_and_listed)
                    except Exception as e:
                        print(e)

                except Exception as e:
                    print(e)

                try:
                    item = ZomatoDataItem()
                    item['Restaurant_Id'] = Restaurant_Id
                    item['URL'] = URL
                    item['Restaurant_Name'] = Restaurant_Name
                    item['Cuisine'] = Cuisines
                    item['Dining_Rating'] = Dining_Rating
                    item['Dining_Review'] = Dining_Review
                    item['Dining_subtext'] = ''
                    item['Delivery_Rating'] = Delivery_Rating
                    item['Delivery_Review'] = Delivery_Review
                    item['Delivery_subtext'] = ''
                    item['Cost_For_Two'] = Cost_For_Two
                    item['Address'] = Address
                    item['City'] = City
                    item['State'] = State
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['Order_Lockdown'] = Order_Lockdown
                    item['Working_Hours'] = Working_Hours
                    item['Contactless_Dining_Option'] = ''
                    item['Contactless_Dining_Option_text'] = ''
                    item['Number_of_Outlets'] = ''
                    item['Popular_Dishes'] = ''
                    item['place_is_known_for'] = ''
                    item['Known_for'] = ''
                    item['Other_Info'] = ''
                    item['Offers'] = Offers
                    item['Vegetarian_Option'] = Vegetarian_Option
                    item['Category_and_listed_number_of_Items'] = unidecode(Category_and_listed_number_of_Items)
                    item['json_path'] = json_path.replace("\\","\\\\")
                    yield item
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

            try:
                pipe.cursor.execute(f'update zomato.data_2020_11_17 set json_status="Done" where Restaurant_Id="{Restaurant_Id}"')
                pipe.con.commit()
                print("update done")
            except Exception as e:
                print(e)

# execute("scrapy crawl data_app -a start=6 -a end=8".split())
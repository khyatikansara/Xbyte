import json
import os
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato_location.items import ZomatoDataItem
from zomato_location.pipelines import ZomatoLocationPipeline as pipe
from datetime import datetime
from scrapy.http import HtmlResponse


class DataWebsiteSpider(scrapy.Spider):
    name = 'data_website'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = '',''

    def parse(self,response):
        pipe.cursor.execute(f'select * from zomato.data_2020_11_17 where html_status="Done" and Id>"{self.start}" and Id<"{self.end}" and Category_and_listed_number_of_Items!=""')
        results = pipe.cursor.fetchall()
        for row in results:
            try:
                avai = "not available"
                Restaurant_Id = row[1]
                URL = row[2]
                html_path = f"D:\\khyati-H\\Zomato\\HTML_2020-11-17\\Data\\{Restaurant_Id}.html"
                try:
                    file = pipe.page_read(self, html_path)
                    response = html.fromstring(file)

                    try:
                        Restaurant_Name = response.xpath('//h1/text()')[0]
                    except Exception as e:
                        print(e)
                        Restaurant_Name = ''

                    if Restaurant_Name != '':
                        # avai = "available"
                        # try:
                        #     Cuisines = ' | '.join(response.xpath('//*[contains(text(),"Cuisines")]/../section/a/text()'))
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     Dining_text = re.findall(r'"ratings\\":\{\\"DINING\\":(.*?)\},\\"', file)[0]
                        #     Dining_Rating = re.findall(r'rating\\":\\"(.*?)\\",\\"', Dining_text)[0]
                        #     Dining_Review = re.findall(r'reviewCount\\":\\"(.*?)\\",', Dining_text)[0]
                        #     if Dining_Review == '0':
                        #         Dining_Review = ''
                        #     Dining_subtext = re.findall(r'"subtext\\":\\"(.*?)\\",\\"', Dining_text)[0]
                        # except Exception as e:
                        #     print(e)
                        #     Dining_Rating = Dining_Review = Dining_subtext = ''
                        #
                        # try:
                        #     Delivery_text = re.findall(r'\{\\"rating_type\\":\\"DELIVERY\\",(.*?)\\"color\\":\\"',file)[0]
                        #     Delivery_Rating = re.findall(r'rating\\":\\"(.*?)\\",\\"',Delivery_text)[0]
                        #     Delivery_Review = re.findall(r'reviewCount\\":\\"(.*?)\\",', Delivery_text)[0]
                        #     if Delivery_Review == '0':
                        #         Delivery_Review = ''
                        #     Delivery_subtext = re.findall(r'"subtext\\":\\"(.*?)\\",', Delivery_text)[0]
                        # except Exception as e:
                        #     print(e)
                        #     Delivery_Rating = Delivery_Review = Delivery_subtext = ''
                        #
                        # try:
                        #     if "Average Cost</h5>" in file:
                        #         Cost_For_Two = response.xpath('//*[contains(text(),"Average Cost")]/following-sibling::p/text()')[0]
                        #         Cost_For_Two = "AED " + re.findall(r'AED (.*?)\s',Cost_For_Two)[0]
                        #     else:
                        #         Cost_For_Two = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     Address = re.findall(r'\\"address\\":\\"(.*?)\\",\\"',file)[0]
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     City = re.findall(r'\{\\"LOCALITY\\":\{\\"text\\":\\"(.*?)\\",\\"',file)[0]
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     State = re.findall(r'"city_name\\":\\"(.*?)\\",\\"',file)[0]
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     latitude = re.findall(r'"latitude\\":\\"(.*?)\\",\\"',file)[0]
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     longitude = re.findall(r'"longitude\\":\\"(.*?)\\",\\"',file)[0]
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//span[contains(text(),"Open now")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Open now")]/../span/text()'))
                        #     elif response.xpath('//span[contains(text(),"Close")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Close")]/../span/text()'))
                        #     elif response.xpath('//span[contains(text(),"Temporarily closed")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Temporarily closed")]/../span/text()'))
                        #     elif response.xpath('//span[contains(text(),"Opening to the public soon")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Opening to the public soon")]/../span/text()'))
                        #     elif response.xpath('//span[contains(text(),"Opening hours not available")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Opening hours not available")]/../span/text()'))
                        #     elif response.xpath(
                        #             '''//p[contains(text(),"We can't seem to find the page you're looking for...")]'''):
                        #         Working_Hours = ''
                        #     elif response.xpath('//span[contains(text(),"Opens in")]/../span/text()'):
                        #         Working_Hours = ' - '.join(
                        #             response.xpath('//span[contains(text(),"Opens in")]/../span/text()'))
                        #     else:
                        #         Working_Hours = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     Contactless_Dining_Option_text = re.findall(r'"tagTitle\\":\\"(.*?)\\",\\"title\\":\\"\\",\\"subtitle\\":\\"(.*?)\\",\\"actionText\\":',file)
                        #     if len(Contactless_Dining_Option_text) == 1:
                        #         Contactless_Dining_Option = "Available"
                        #         Contactless_Dining_Option_1 = response.xpath(f'//*[contains(text(),"{Contactless_Dining_Option_text[0][0]}")]/following-sibling::*/text()')[0]
                        #     else:
                        #         Contactless_Dining_Option = "Not Available"
                        #         Contactless_Dining_Option_1 = ""
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//a//*[contains(text(),"See all")]/text()'):
                        #         Number_of_Outlets_text = response.xpath('//a//*[contains(text(),"See all")]/text()')
                        #         if len(Number_of_Outlets_text) == 1:
                        #             Number_of_Outlets = Number_of_Outlets_text[0]
                        #         elif len(Number_of_Outlets_text) > 1:
                        #             Number_of_Outlets = ' | '.join(Number_of_Outlets_text)
                        #         else:
                        #             Number_of_Outlets = ''
                        #     else:
                        #         Number_of_Outlets = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//*[contains(text(),"Popular Dishes")]/following-sibling::p/text()'):
                        #         Popular_Dishes = ''.join(response.xpath('//*[contains(text(),"Popular Dishes")]/following-sibling::p[1]/text()'))
                        #         Popular_Dishes = Popular_Dishes.replace(', ', ' | ')
                        #     else:
                        #         Popular_Dishes = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//*[contains(text(),"People Say This Place Is Known For")]/following-sibling::p[1]/text()'):
                        #         place_is_known_for = response.xpath('//*[contains(text(),"People Say This Place Is Known For")]/following-sibling::p[1]/text()')[0].replace(', ', ' | ')
                        #     else:
                        #         place_is_known_for = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//*[text()="Known For"]/following-sibling::p[1]/text()'):
                        #         Known_for = ' | '.join(response.xpath('//*[text()="Known For"]/following-sibling::p[1]/text()'))
                        #     else:
                        #         Known_for = ''
                        # except Exception as e:
                        #     print(e)
                        #
                        # try:
                        #     if response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()'):
                        #         Other_Info = ' | '.join(response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()'))
                        #     else:
                        #         Other_Info = ''
                        # except Exception as e:
                        #     print(e)

                        #---order page---
                        order_path = f"D:\\khyati-H\\Zomato\\HTML_2020-11-17\\Order\\{Restaurant_Id}.html"
                        if os.path.exists(order_path):
                            file_order = pipe.page_read(self, order_path)
                            # try:
                            #     if '<div type="non-veg"' in file_order:
                            #         Vegetarian_Option = "Veg Only"
                            #     else:
                            #         Vegetarian_Option = "Pure veg"
                            # except Exception as e:
                            #     print(e)

                            # try:
                            #     offer_list = []
                            #     offer_text = re.findall(r'\\"title1\\":\{\\"text\\":\\"(.*?)\\",\\"color\\":(.*?)\\"sub_title1\\":\{\\"text\\":\\"(.*?)\\",\\"color\\":',file_order, re.DOTALL)
                            #     for offer_tmp in offer_text:
                            #         offer_list.append(f"{offer_tmp[0]} : {offer_tmp[2]}")
                            #     Offers = ' | '.join(offer_list)
                            # except Exception as e:
                            #     print(e)

                            try:
                                Category_text = re.findall(r'\[\{\\"key\\":\\"(.*?)\]\}', file_order, re.DOTALL)[0]
                                Category_and_listed = re.findall(r'\\"title\\":\\"(.*?)$', Category_text, re.DOTALL)
                                final_Category_and_listed = re.findall(r'\\"title\\":\\"(.*?)\\"\}', Category_and_listed[0], re.DOTALL)
                                Category_and_listed_number_of_Items = ' | '.join(final_Category_and_listed)
                                print(Category_and_listed_number_of_Items)
                            except Exception as e:
                                print(e)
                                Category_and_listed_number_of_Items = ''

                            try:
                                pipe.cursor.execute(f'update zomato.web_data_2020_11_26 set Category_and_listed_number_of_Items="{Category_and_listed_number_of_Items}" where Restaurant_Id="{Restaurant_Id}"')
                                pipe.con.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
                        else:
                            Vegetarian_Option = Offers = Category_and_listed_number_of_Items = ''
                    else:
                        Cuisines = Dining_Rating = Dining_Review = Dining_subtext = Delivery_Rating = Delivery_Review = Delivery_subtext = Cost_For_Two = Address = City = State = ''
                        latitude = longitude = Working_Hours = Contactless_Dining_Option = Contactless_Dining_Option_1 = Number_of_Outlets = Popular_Dishes = place_is_known_for = ''
                        Known_for = Other_Info = Offers = Vegetarian_Option = Category_and_listed_number_of_Items = ''
                except Exception as e:
                    print(e)

            #     try:
            #         item = ZomatoDataItem()
            #         item['Restaurant_Id'] = Restaurant_Id
            #         item['URL'] = URL
            #         item['Restaurant_Name'] = Restaurant_Name
            #         item['Cuisine'] = Cuisines
            #         item['Dining_Rating'] = Dining_Rating
            #         item['Dining_Review'] = Dining_Review
            #         item['Dining_subtext'] = Dining_subtext
            #         item['Delivery_Rating'] = Delivery_Rating
            #         item['Delivery_Review'] = Delivery_Review
            #         item['Delivery_subtext'] = Delivery_subtext
            #         item['Cost_For_Two'] = Cost_For_Two
            #         item['Address'] = Address
            #         item['City'] = City
            #         item['State'] = State
            #         item['latitude'] = latitude
            #         item['longitude'] = longitude
            #         item['Order_Lockdown'] = ''
            #         item['Working_Hours'] = Working_Hours
            #         item['Contactless_Dining_Option'] = Contactless_Dining_Option
            #         item['Contactless_Dining_Option_text'] = Contactless_Dining_Option_1
            #         item['Number_of_Outlets'] = Number_of_Outlets
            #         item['Popular_Dishes'] = Popular_Dishes
            #         item['place_is_known_for'] = place_is_known_for
            #         item['Known_for'] = Known_for
            #         item['Other_Info'] = Other_Info
            #         item['Offers'] = Offers
            #         item['Vegetarian_Option'] = Vegetarian_Option
            #         item['Category_and_listed_number_of_Items'] = Category_and_listed_number_of_Items
            #         item['page_html'] = html_path.replace("\\","\\\\")
            #         item['order_html'] = order_path.replace("\\", "\\\\")
            #         item['status'] = avai
            #         yield item
            #     except Exception as e:
            #         print(e)
            #
            except Exception as e:
                print(e)
            #
            # try:
            #     pipe.cursor.execute(f'update zomato.data_2020_11_17 set html_status="Done" where Restaurant_Id="{Restaurant_Id}"')
            #     pipe.con.commit()
            #     print("update done")
            # except Exception as e:
            #     print(e)

execute("scrapy crawl data_website -a start=0 -a end=17593".split())
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from itemadapter import ItemAdapter


class MatronexPipeline:
    host = "192.168.1.252"
    passwd = "xbyte"
    uname = "root"
    insertcount = 0
    con1 = pymysql.connect(host, uname, passwd)
    db_name = "bungeetech_daily_sites"
    tb = 'matronex_finaldata'

    try:
        try:
            con = pymysql.connect(host, uname, passwd)
            cursor = con.cursor()
            cursor.execute(f'CREATE DATABASE IF NOT EXISTS {db_name}')
        except Exception as e:
            print(str(e))
        con = pymysql.connect(host, uname, passwd, db_name)
        cursor = con.cursor()

        # con1.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        # con = pymysql.connect(host, uname, passwd, {db_name})
        # crsr = con.cursor()

        CT = f"""CREATE TABLE IF NOT EXISTS `{tb}` (`ID` int(11) NOT NULL AUTO_INCREMENT,
                                                              `HashID` varchar(50),
                                                              `Date` varchar(50),
                                                              `Title` varchar(250),
                                                              `crawl_date_time` varchar(50),
                                                              `site_name` varchar(20),
                                                              `review_url` varchar(255),
                                                              `country` varchar(255) DEFAULT 'United States',
                                                              `amazon_url` varchar(255),
                                                              `asin` varchar(255),
                                                              `scrapingStatus` varchar(255),
                                                              `sold_by` varchar(255),
                                                              `seller_id` varchar(255),
                                                              `screenshotamazonpage` varchar(255),
                                                              `screenshotproductpage` varchar(255),
                                                              `domain_promo_price` varchar(255),
                                                              `domain_price` varchar(255),
                                                              `amazon_price` varchar(255),
                                                              `stockStatus` varchar(255),
                                                              `variationProduct` varchar(50),
                                                              `isMatchProduct` varchar(50),
                                                              `amazon_status` varchar(20) DEFAULT 'Pending',
                                                              `Status` varchar(250) DEFAULT 'pending',
                                                              UNIQUE KEY (`HashID`),
                                                              PRIMARY KEY (`ID`))"""
        cursor.execute(CT)
        con.commit()
    except Exception as e:
        print(e)

    def process_item(self, item, spider):
        try:
            field_list = []
            value_list = []
            for field in item:
                field_list.append(f"`{str(field)}`")
                value_list.append(str(item[field]).replace("'", "’"))
            fields = ','.join(field_list)
            values = "','".join(value_list)
            insert_db = f"insert into {self.tb}" + "( " + fields + " ) values ( '" + values + "' )"
            self.cursor.execute(insert_db)
            self.con.commit()
            print("data inserted")
        except Exception as e:
            print(e)
        return item


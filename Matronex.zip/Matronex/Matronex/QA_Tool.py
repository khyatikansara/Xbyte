import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
from datetime import datetime, timedelta
import socket
from json2html import *
import numpy as np
import boto3
import re
import os


File_Name = f"matronex"
# File_Name = f"severnvine_UK"

def email_alert():
    ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
    SECRET_KEY = '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'
    s = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

    today_date = str(datetime.now().date())
    today_path = f"\\\\192.168.1.249\\DataGators\\Temp\\Foram\\Bungee Daily Files\\{today_date}\\"
    previous_date = str(datetime.now().date() - timedelta(1))
    previous_path = f"\\\\192.168.1.249\\DataGators\\Temp\\Foram\\Bungee Daily Files\\{previous_date}\\Done\\"
    previous_path_1 = f"\\\\192.168.1.249\\DataGators\\Temp\\Foram\\Bungee Daily Files\\{previous_date}\\"

    try:
        today_file_name = f"{File_Name}_{str(datetime.now().date())}.csv".replace("-", "")
        today_file = pd.read_csv(today_path + today_file_name)
        # today_file = today_file.fillna(None)
        # today_file = today_file.astype('str')
        today_file_grp = today_file.groupby(['review_url'])
        total_length = len(today_file.index)
        count = len(today_file_grp.size())

        previous_file_name = f"{File_Name}_{str(datetime.now().date() - timedelta(1))}.csv".replace("-", "")
        try:
            previous_file = pd.read_csv(previous_path + previous_file_name)
        except:
            previous_file = pd.read_csv(previous_path_1 + previous_file_name)
        previous_file_grp = previous_file.groupby(['review_url'])
        # old_count = len(previous_file.index)
        old_count = len(previous_file_grp.size())
        # print()
        today_file.columns = ['crawl_date_time #', 'site_name #', 'review_url #', 'country #', 'amazon_url #', 'asin #',
                              'scrapingStatus #', 'sold_by', 'seller_id', 'screenshotamazonpage #',
                              'screenshotproductpage #', 'domain_promo_price', 'domain_price', 'amazon_price',
                              'stockStatus', 'variationProduct', 'isMatchProduct', 'IsUsedProduct']
        previous_file.columns = ['crawl_date_time #', 'site_name #', 'review_url #', 'country #', 'amazon_url #', 'asin #',
                              'scrapingStatus #', 'sold_by', 'seller_id', 'screenshotamazonpage #',
                              'screenshotproductpage #', 'domain_promo_price', 'domain_price', 'amazon_price',
                              'stockStatus', 'variationProduct', 'isMatchProduct', 'IsUsedProduct']
        today_count = today_file.count(axis=0).to_dict()
        previous_count = previous_file.count(axis=0).to_dict()
        count_df = (pd.DataFrame.from_dict([today_count, previous_count])).T.fillna(0).astype(int)
        count_df.columns = ['count_new', 'count_old']
        count_df['difference'] = count_df['count_new'] - count_df['count_old']
        count_df['diff_percentage'] = (count_df['difference'] * 100) / count_df['count_old']
        count_df['Count_Validate'] = 'Yes'
        count_df['None_Validate'] = "Yes"
        count_df['Length_Validate'] = "Yes"
        # count_df.loc[count_df['count_new'] == 0, 'Count_Validate'] = 'No'
        all_columns = list(today_file.columns)
        # print(all_columns)
        mandatory_column = ['crawl_date_time', 'site_name', 'review_url', 'country', 'amazon_url', 'asin', 'scrapingStatus', 'screenshotamazonpage', 'screenshotproductpage']
        today_file_str = today_file.astype('str')
        file_validate = 'Yes'
        if count == 0:
            file_validate = 'No'
        for column in all_columns:
            check_none = today_file_str[today_file_str[column].str.contains(r'None')]
            if not check_none.empty:
                print('None found in column', column)
                count_df.loc[column, "None_Validate"] = 'No'

            if column == 'crawl_date_time #':
                crawl_len = today_file_str[today_file_str[column].str.len() != 19]
                if not crawl_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'site_name #':
                site_len = today_file_str[today_file_str[column].str.len() > 20]
                if not site_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'review_url #':
                review_len = today_file_str[today_file_str[column].str.len() > 1000]
                if not review_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'country #':
                country_len = today_file_str[today_file_str[column].str.len() > 20]
                if not country_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'amazon_url #':
                amazon_len = today_file_str[today_file_str[column].str.len() > 300]
                if not amazon_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'asin #':
                asin_len = today_file_str[today_file_str[column].str.len() > 25]
                if not asin_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'scrapingStatus #':
                sstatus = today_file_str[today_file_str[column].str.len() != 3]
                if not sstatus.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'sold_by':
                sold_len = today_file_str[today_file_str[column].str.len() > 100]
                if not sold_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'seller_id':
                sellerid_len = today_file_str[today_file_str[column].str.len() > 25]
                if not sellerid_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'screenshotamazonpage #':
                ssamazon_len = today_file_str[today_file_str[column].str.len() > 300]
                if not ssamazon_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'screenshotproductpage #':
                ssproduct = today_file_str[today_file_str[column].str.len() > 300]
                if not ssproduct.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'domain_promo_price':
                dpprice_len = today_file_str[today_file_str[column].str.len() > 10]
                if not dpprice_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'domain_price':
                dp_len = today_file_str[today_file_str[column].str.len() > 10]
                if not dp_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'amazon_price':
                ap_len = today_file_str[today_file_str[column].str.len() > 10]
                if not ap_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'stockStatus':
                stock_len = today_file_str[today_file_str[column].str.len() > 3]
                if not stock_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'variationProduct':
                varp_len = today_file_str[today_file_str[column].str.len() > 6]
                if not varp_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'isMatchProduct':
                match_len = today_file_str[today_file_str[column].str.len() > 6]
                if not match_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'
            elif column == 'IsUsedProduct':
                used_len = today_file_str[today_file_str[column].str.len() > 6]
                if not used_len.empty:
                    count_df.loc[column, 'Length_Validate'] = 'No'
                    file_validate = 'No'

        for mandate in mandatory_column:
            # count_df.loc[(count_df.index == mandate) & (count_df['count_new'] != total_length), 'Count_Validate'] = 'No'
            check_null = today_file[today_file[f'{mandate} #'].isnull()]
            if not check_null.empty:
                count_df.loc[f'{mandate} #', 'Count_Validate'] = 'No'
                file_validate = 'No'

        count_df_html = count_df.to_html(na_rep='0', justify='center', border=1).replace("<td>No</td>",
                                                                                           '<td style="background-color:red;"><b>No</b></td>')


        found_count = count_df[count_df['Count_Validate'].str.contains('No')]
        found_none = count_df[count_df['None_Validate'].str.contains('No')]

        if found_count.count().empty or found_none.count().empty:
            file_validate = 'No'
        try:
            stock_status = today_file[(today_file['stockStatus'] == 1) & (today_file["amazon_price"].isnull())]["amazon_url #"].values[0]
            file_validate = 'No'
        except Exception as e:
            stock_status = 'No Errors'
        try:
            sold_by = today_file[(today_file['sold_by'].isnull()) & (today_file["amazon_price"].notnull())]["amazon_url #"].values[0]
            file_validate = 'No'
        except Exception as e:
            sold_by = 'No Errors'

        try:
            seller_id_length = today_file[(today_file['seller_id'].str.contains(' '))]
            if not seller_id_length.empty:
                errosellerid = 'Yes'
                file_validate = 'No'
            else:
                errosellerid = 'No Errors'
        except Exception as e:
            errosellerid = 'No Errors'

        try:
            dateformat = today_file[~today_file['crawl_date_time #'].str.contains(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}')]
            if not dateformat.empty:
                errordateformat = 'Yes'
                file_validate = 'No'
            else:
                errordateformat = 'No Errors'
        except Exception as e:
            errordateformat = "No Errors"
            # print(e)

        try:
            ismatch = today_file[(today_file['isMatchProduct'].isnull()) & (today_file['scrapingStatus #'] == 200)]
            if not ismatch.empty:
                errorismatch = 'Yes'
                file_validate = 'No'
            else:
                errorismatch = 'No Errors'
        except Exception as e:
            errorismatch = 'No Errors'

        try:
            dt = datetime.strftime(datetime.now(), "%d-%m-%Y")
            s3_folder = f"{dt}/{File_Name}/screenshots/amazon/"
            ssamazon = today_file[~today_file['screenshotamazonpage #'].str.contains(s3_folder)]

            if not ssamazon.empty:
                errorssamazon = 'Yes'
                file_validate = 'No'
            else:
                errorssamazon = 'No Errors'
        except Exception as e:
            errorssamazon = 'No Errors'

        try:
            dt = datetime.strftime(datetime.now(), "%d-%m-%Y")
            s3_folder = f"{dt}/{File_Name}/screenshots/domain/"
            ssdomain = today_file[~today_file['screenshotproductpage #'].str.contains(s3_folder)]

            if not ssdomain.empty:
                errorssdomain = 'Yes'
                file_validate = 'No'
            else:
                errorssdomain = 'No Errors'
        except Exception as e:
            errorssdomain = 'No Errors'

        try:
            a = today_file['amazon_price'].astype(float)
            dtype_amazon_price = 'No Error'
        except Exception as e:
            dtype_amazon_price = "Yes"
            file_validate = 'No'

        if os.path.isfile(today_path + today_file_name):
            file_info = os.stat(today_path + today_file_name)
            num = file_info.st_size
            full_size = file_info.st_size
            for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
                if num < 1024.0:
                    final_size = "%3.1f %s" % (num, x)
                    break
                num /= 1024.0
        # if num == 0:
        # print(final_size)
        if os.path.isfile(previous_path + previous_file_name):
            file_info_old = os.stat(previous_path + previous_file_name)
            num_old = file_info_old.st_size
            size_old = file_info_old.st_size
            for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
                if num_old < 1024.0:
                    final_size_old = "%3.2f %s" % (num_old, x)
                    break
                else:
                    file_info_old = 0
                num_old /= 1024.0
        # print(final_size_old)
        difference = ("{:.2f}".format(((float(full_size) - size_old) / size_old) * 100)).replace("-", "") + " %"
        if 'bytes' in final_size:
            file_validate = 'No'

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 1))
        local_ip_address = s.getsockname()[0]

        userId = "emailapikey"
        emailpass = "wSsVR61/+hP5DKcszTH5Jbhpml9dVlL0HEV6iVSn7XSpTKzLoMdukkCdVlWjGPgfRDRpHDAWrLIhnBZShztYjdQszVtSDiiF9mqRe1U4J3x17qnvhDzPV2RdlhuAJYgIwwlqmWVoE88k+g=="
        emailId = "alerts@xbyte.io"
        send_to = [
            'khyati.xbyte@gmail.com'
        ]
        cc = [
            # 'foram.patel.xbyte@gmail.com',
            # 'masum.patel.xbyte@gmail.com',
            # 'xbyte.qa@gmail.com',
        ]

        mail_content = list()
        mail_content.append("<html>")
        mail_content.append("<head>")
        mail_content.append("<style>")
        mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
        mail_content.append("</style>")
        mail_content.append("</head>")
        mail_content.append("<body>")
        mail_content.append("<br><h3>Data Summary</h3>")
        mail_content.append("<table border='1'>")
        mail_content.append("<tr><td><b>File Name</b></td><td>" + str(today_file_name) + "</td></tr>")
        mail_content.append("<tr><td><b>Total URL's Found</b></td><td>" + str(count) + "</td></tr>")
        mail_content.append("<tr><td><b>Previous URL's Found</b></td><td>" + str(old_count) + "</td></tr>")
        mail_content.append("<tr><td><b>File Validate</b></td><td>" + str(file_validate) + "</td></tr>")
        mail_content.append("</table>")
        mail_content.append("<br><h3>Data Count Comparision</h3>")
        m_content = json2html.convert(json=count_df_html)
        m_content = m_content.replace("&lt;", "<")
        m_content = m_content.replace("&gt;", ">")
        m_content = m_content.replace("\n", "")
        m_content = m_content.replace('&quot;', '"')
        mail_content.append(m_content)
        mail_content.append("<br><h3>Row wise errors</h3>")
        mail_content.append("<table border='1'>")
        mail_content.append("<tr><td><b>Price Missing for Stock_Status='1'</b></td><td>" + str(stock_status) + "</td></tr>")
        mail_content.append("<tr><td><b>Price Missing Sold_by</b></td><td>" + str(sold_by) + "</td></tr>")
        mail_content.append("<tr><td><b>crawl_date_time format issue</b></td><td>" + str(errordateformat) + "</td></tr>")
        mail_content.append("<tr><td><b>Is Match issue</b></td><td>" + str(errorismatch) + "</td></tr>")
        mail_content.append("<tr><td><b>Screenshot Amazon Issue</b></td><td>" + str(errorssamazon) + "</td></tr>")
        mail_content.append("<tr><td><b>Screenshot Domain Issue</b></td><td>" + str(errorssdomain) + "</td></tr>")
        mail_content.append("<tr><td><b>Dtype Amazon Price Issue</b></td><td>" + str(dtype_amazon_price) + "</td></tr>")
        mail_content.append("<tr><td><b>Space In Seller ID</b></td><td>" + str(errosellerid) + "</td></tr>")
        mail_content.append("</table>")
        mail_content.append("<br><h3>File Size</h3>")
        mail_content.append("<table border='1'>")
        mail_content.append(
            "<tr><th>No.</th><th>File Names</th><th>Today Filesize</th><th>Previous Filesize</th><th>Filesize Difference</th></tr>")
        mail_content.append("<tr>")
        mail_content.append("<td> 1 </td>")
        mail_content.append("<td> %s </td>" % today_file_name)
        if 'bytes' in final_size:
            mail_content.append('<td style="background-color:red;"><b> %s </b></td>' % final_size)
        else:
            mail_content.append("<td> %s </td>" % final_size)
        mail_content.append("<td> %s </td>" % final_size_old)
        mail_content.append("<td> %s </td>" % (difference))
        mail_content.append("</tr>")
        mail_content.append("</table>")
        mail_content.append("</body>")
        mail_content.append("</html>")
        body = "".join(mail_content).replace("<td>No</td>", '<td style="background-color:red;"><b>No</b></td>')
        try:
            # time.sleep()
            msg = MIMEMultipart()
            msg['From'] = emailId
            msg['To'] = ",".join(send_to)
            msg['CC'] = ",".join(cc)
            msg['Subject'] = f"Bungeetech QA Tool {File_Name} (Date : " + str(datetime.now().date()) + ") (V1.4)"
            msg.attach(MIMEText(body, 'html'))
            s = smtplib.SMTP('smtp.zeptomail.com', 587)
            s.starttls()
            s.login(userId, emailpass)
            text = msg.as_string()
            s.sendmail(emailId, send_to + cc, text)
            print("Mail Sent ...")
            s.quit()
        except Exception as e:
            print(e)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    email_alert()
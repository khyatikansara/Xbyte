
import scrapy
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import datetime
import boto3
import os
from os import listdir
from os.path import isfile, join
from datetime import datetime,timedelta
import sys
siteName = 'getandtest'
domain_name=siteName
chromedriverpath ="chromedriver.exe"

def get_ss():
    options = Options()
    options.add_argument('--headless')
    driver = webdriver.Chrome(executable_path=chromedriverpath, options=options)
    dd1 = (datetime.now() - timedelta(1)).strftime('%d%m%Y')

    path1 = os.getcwd()
    path = str(path1).split("Qa tool and csv\Searching_page_screeshot")[0]
    html_path = f'{path}Getandtest_Daily_Html\\Searching_Page_HTML\\{dd1}\\'
    print(html_path)
    if not os.path.exists(html_path):
        os.makedirs(html_path)

    # html_path = f'F:\\Bhagyashree\\Project\\2021\\BungeeTech_Deal\\Getandtest_Daily\\Getandtest_Daily_Html\\Searching_Page_HTML\\{dd1}\\'


    onlyfiles = [f for f in listdir(html_path) if isfile(join(html_path, f))]

    for files in onlyfiles:
        print(files)
        if "Searching" in str(files):
            continue
        link1=html_path+files

        files = files.replace(".html", "").strip()
        domain_id="Searching_"+ files

        s3FolderName=files
        s3FolderName=s3FolderName.upper()
        s3FolderName="getandtest_"+ s3FolderName

        driver.get(link1)
        driver.maximize_window()
        el = driver.find_element_by_tag_name('body')
        el.send_keys(Keys.END)
        time.sleep(7)
        el.send_keys(Keys.HOME)

        total_width = 5000
        total_height = 5000
        driver.set_window_size(total_width, total_height)
        time.sleep(7)
        domain_img=html_path

        domian_path = domain_img + domain_id + ".png"

        driver.save_screenshot(domian_path)
        print("domain ss done")
        ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
        SECRET_KEY = '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'

        # dt = datetime.strftime(datetime.now(), "%d-%m-%Y")

        dt = (datetime.now() - timedelta(1)).strftime('%d-%m-%Y')
        # dt = '01092021'

        month = datetime.strftime(datetime.now() - timedelta(1), "%B")

        try:
            bucket = "bungee.internal.data"
            s3_file = domain_id + ".png"
            FileFromMachine = domain_img + s3_file
            fileName = s3_file
            s3_folder = f"{month}'21/{dt}/{s3FolderName}/screenshots/Link/"
            FileToS3 = s3_folder + fileName
            s = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            s.upload_file(FileFromMachine, bucket, FileToS3, ExtraArgs={'ContentType': "image/png"})
            # s3_url = f"https://xbyte.s3.amazonaws.com/{s3_folder}{s3_file}"
            # print(f'Screenshot Uploaded to S3: {s3_url}')
            # s3_folder = f"{month}21/{dt}/{s3FolderName}/screenshots/Link"
            # s3_url = f"https://xbyte.s3.amazonaws.com/{s3_folder}{s3_file}"
            # try:
            #     s3_url = s.generate_presigned_url('get_object',Params={'Bucket': bucket, 'Key': FileToS3}, ExpiresIn=600000)
            # except Exception as e:
            #     print(e)
        except Exception as e:
            print(e)

    driver.quit()


if __name__ == '__main__':
    get_ss()
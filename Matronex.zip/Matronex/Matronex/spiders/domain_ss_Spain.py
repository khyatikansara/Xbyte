import os
import logging
import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
import dropbox
import re
import pymysql
from datetime import datetime
import os
import sys
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
import json

# with open('config.json', 'r') as f:
#     configJson = json.load(f)

siteName = "matronex"#configJson['siteName']
# country = "Canada"#configJson['country']
country = "Spain"#configJson['country']
chromedriverpath = "chromedriver.exe"#configJson['chromeDriver']
s3FolderName = "matronex"#configJson['s3FolderName']
date = str(datetime.now().date())
# date = '2021-08-05'

db = 'bungeetech_daily_sites'
conn = pymysql.connect(host="localhost", user="root", password="xbyte", database=db)
finaldatatable = 'matronex_finaldata'
finalsellertable = 'finaldata_with_sellers'
crsr = conn.cursor(pymysql.cursors.DictCursor)


def get_ss(start, end):
    options = Options()
    options.add_argument('--headless')
    driver = webdriver.Chrome(executable_path=chromedriverpath, options=options)

    # path = os.getcwd()
    # path = str(path).split("amazon")[0]
    # imagePath = f'{path}images'
    # if not os.path.exists(imagePath):
    #     os.mkdir(imagePath)
    imagePath = f'F:\khyati\Project_FP\\bungetech\matronex_html\domain_ss\\{datetime.now().strftime("%d%m%Y")}_screenshot_new\\'
    if not os.path.exists(imagePath):
        os.mkdir(imagePath)

    while True:
        try:
            crsr.execute(
                f"select id,amazon_url,asin,review_url from matronex_finaldata where site_name = '{siteName}' and  Date like '%{date}%' and Status='pending' and country='{country}' limit {start},{end}")
            results = crsr.fetchall()
            print(f"Screenshot pending = {len(results)}")

            if len(results) == 0:
                break

            print(f"Screenshot pending = {len(results)}")
            if len(results) != 0:
                for row in results:
                    id = row['id']
                    url = f"{row['review_url']}"
                    driver.get(url)
                    domain_id = id
                    # domain_id = url.split('/')[-1]
                    # domain_id = domain_id.split('-')[-1]
                    IMG = imagePath + str(domain_id) + ".png"
                    S = lambda X: driver.execute_script('return document.body.parentNode.scroll' + X)
                    driver.set_window_size(S('Width'), S('Height'))
                    driver.find_element_by_tag_name('body').screenshot(IMG)
                    link = uploadS3(imagePath, domain_id)
                    if link and link != 'None':
                        print(f"done {link}")
                        qr = f"""update matronex_finaldata set status = 'done1',screenshotproductpage = "{link}" where id='{row['id']}' and site_name = '{siteName}' and date like '%{date}%'"""
                        crsr.execute(qr)
                        conn.commit()
                    else:
                        link = uploadS3(imagePath, domain_id)
                        print(f"done {link}")
                        qr2 = f"""update matronex_finaldata set status = 'done1',screenshotproductpage = "{link}" where id='{row['id']}' and site_name = '{siteName}' and date like '%{date}%'"""
                        if link == 'None' or link is None:
                            qr1 = f"""update matronex_finaldata set status = 'pending' where id='{row['id']}' and site_name = '{siteName}' and date like '%{date}%'"""
                            crsr.execute(qr1)
                            conn.commit()
                        else:
                            crsr.execute(qr2)
                            conn.commit()
        except Exception as e:
            print(e)

    driver.close()


def uploadS3(path, domain_id):
    filename = f'{domain_id}.png'

    ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
    SECRET_KEY = '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'
    dt = datetime.strftime(datetime.now(), "%d-%m-%Y")
    # dt = "27-07-2021"
    month = datetime.strftime(datetime.now(), "%B")
    try:
        bucket = "xbyte"
        s3_file = filename
        FileFromMachine = path + filename
        fileName = s3_file
        s3_folder = f"{month}'21/{dt}/{s3FolderName}/screenshots/domain/"
        FileToS3 = s3_folder + fileName
        s = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        # s.upload_file(FileFromMachine, bucket, FileToS3)
        s.upload_file(FileFromMachine, bucket, FileToS3, ExtraArgs={'ContentType': "image/png"})
        # s3_url = f"https://xbyte.s3.amazonaws.com/{s3_folder}{s3_file}"
        # print(f'Screenshot Uploaded to S3: {s3_url}')
        s3_url = s.generate_presigned_url('get_object',
                                          Params={'Bucket': bucket, 'Key': FileToS3},
                                          ExpiresIn=600000)
        # print(s3_url)
        if s3_url is not None:
            return s3_url
    except Exception as e:
        print(e)


def create_presigned_url(bucket, object):
    try:
        bucket_name = bucket
        ACCESS_KEY = 'AKIATBUD4GB6JVRCEE37'
        SECRET_KEY = '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'
        key = object
        location = boto3.client('s3', aws_access_key_id=ACCESS_KEY,
                                aws_secret_access_key=SECRET_KEY).get_bucket_location(Bucket=bucket_name)
        s3_client = boto3.client(
            's3',
            # region_name=location,
            aws_access_key_id=ACCESS_KEY,
            aws_secret_access_key=SECRET_KEY,
        )
        url = s3_client.generate_presigned_url(
            ClientMethod='get_object',
            Params={'Bucket': bucket_name, 'Key': key, },
            ExpiresIn=600000,
        )
    except ClientError as e:
        print(e)
        return None
    return url


def uploaddropbox(path, asin):
    filename = f'{asin}.png'

    try:
        access_token = 'Mw46Be7ueY4AAAAAAAAAAU00jILbPUEiwLeAT38dKe2r4RagMsmHZykPizAFE8VB'
        file_to = f'/Bungeetech_amazon_ss/{siteName}/{date}/' + filename
        dbx = dropbox.Dropbox(access_token)

        with open(path + filename, 'rb') as f:
            dbx.files_upload(f.read(), file_to, mode=dropbox.files.WriteMode.overwrite)
        print('SS Uploaded To :' + file_to)
        result = dbx.sharing_create_shared_link_with_settings(file_to)
        dropboxlink = result.url
        print('output Path : ' + dropboxlink)
    except Exception as e:
        print(e)
        dropboxlink = re.findall("FileLinkMetadata\(url='(.*?)'", str(e))[0]
        print('output Path : ' + dropboxlink)

    return dropboxlink


if __name__ == '__main__':

    try:
        start = sys.argv[1]
        end = sys.argv[2]
    except:
        start = '0'
        end = '100000'

    get_ss(start, end)
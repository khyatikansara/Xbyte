from datetime import datetime
import pandas as pd
import pymysql

# host = "192.168.1.252"
host = "192.168.1.72"
passwd = "xbyte"
uname = "root"
app_name='matronex_'  #app name is filename
db_name = 'bungeetech_daily_sites'
con = pymysql.connect(host=host, user=uname, password=passwd, database=f'{db_name}')
try:
    filename = "D:\khyati-H\CRM\Projects FP\Bungeetech\\files\\"
    d = datetime.today().strftime("%Y/%m/%d").replace('/', '')
    # date=datetime.today().strftime("%Y-%m-%d")
    # date='2021-07-30'
    file_name = filename + app_name + d + '.csv'
    sql = f'SELECT * FROM finaldata_with_sellers WHERE `site_name`= "matronex" AND DATE LIKE"%2021-09-17%" AND Status="done" ' #table name change
    df = pd.read_sql(sql, con)
    df.pop('HashID')
    df.pop('Status')
    df.pop('HtmlPath')
    df.pop('server')
    df.pop('id')
    df.pop('amazon_path')
    df.pop('Title')
    df.pop('Date')
    df.pop('scraping_location')
    df.pop('domain_image_url')
    df.pop('amazon_image_url')
    df['sold_by'] = df['sold_by'].str.decode("utf-8")

    df.to_csv(file_name, index=False)
    print('csv file Generated at', file_name)
except Exception as e:
    print(str(e))

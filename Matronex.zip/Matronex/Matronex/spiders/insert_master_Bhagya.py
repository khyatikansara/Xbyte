import pymysql
from datetime import datetime, timedelta
import hashlib

db_name = "bungeetech_daily_sites"
finaldata_tb = "matronex_finaldata"
finaldata_with_sellers_tb = "finaldata_with_sellers"
if __name__ == '__main__':
    # conn = pymysql.connect("localhost", "root", "xbyte", "bungeetech_daily_sites", charset='utf8')
    conn = pymysql.connect("192.168.1.72", "root", "xbyte", f"{db_name}", charset='utf8')
    crsr = conn.cursor()
    # datw = str(datetime.now().date()) #'2021-08-23'


    datw=str(datetime.now().date() - timedelta(1))
    # datw_current=str(datetime.now().date())
    dev_name = 'Mrudul'
    l1 = ["matronex"]  #site_name
    c1 = 'All' #country

    for l in l1:
        sql_q = f'''select * from {finaldata_tb} where site_name = "{l}" and date like "%{datw}%" '''
        crsr.execute(sql_q)
        final_results = crsr.fetchall()
        final_results_len1 = len(final_results)   #domain url count

        print(final_results_len1)

        sql_q2 = f'select * from {finaldata_with_sellers_tb} where date like "{datw}%" and site_name = "{l}" group by asin'
        crsr.execute(sql_q2)
        final_with_results_len = crsr.fetchall()
        final_with_results_len1 = len(final_with_results_len)
        print(final_with_results_len1)   # uniue amazon url count

        sql_q3 = f'select * from {finaldata_with_sellers_tb} where date like "{datw}%" and site_name = "{l}"'
        crsr.execute(sql_q3)
        final_with_results_len = crsr.fetchall()
        final_with_results_len2 = len(final_with_results_len)
        print(final_with_results_len2)   # total count

        sql_q4 = f'select * from {finaldata_with_sellers_tb} where date like "{datw}%" and site_name = "{l}" group by sold_by'
        crsr.execute(sql_q4)
        final_with_results_len = crsr.fetchall()
        final_with_results_len3 = len(final_with_results_len)
        print(final_with_results_len3) # sold_by count uniueq seller count



        hash_id = bytes(str(l + str(datw) + str(l1) ), encoding='utf-8')

        HashId = str(int(hashlib.md5(hash_id).hexdigest(), 16) % (10 ** 16))

        conn2 = pymysql.connect("192.168.1.167", "root", "xbyte", f"{db_name}", charset='utf8')
        crsr2 = conn2.cursor()
        sql_ins = f"""INSERT INTO `bungeetech_daily_sites`.`bungee_count_master`
            (
             `Developer`,
             `HashID`,
             `Date`,
             `Country`,
             `Sitename`,
             `Total_Counts`,
             `Domain_URL_count`,
             `Domain_scrapped_count`,
             `Amazon_URL_count`,
             `Amazon_scrapped_count`,
             `Summary`,
             `Unique_seller_id`)
        VALUES (
                '{dev_name}',
                '{HashId}',
                '{datw}',
                '{c1}',
                '{l}',
                '{final_with_results_len2}',
                '{final_results_len1}',
                '{final_results_len1}',
                '{final_with_results_len1}',
                '{final_with_results_len1}',
                '{final_with_results_len2}',
                '{final_with_results_len3}');"""

        crsr2.execute(sql_ins)
        conn2.commit()

        print("data inserted")
    conn.close()




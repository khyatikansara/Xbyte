import scrapy
from Matronex.items import MatronexItem
import datetime
import hashlib


class MatronexCrawlerSpider(scrapy.Spider):
    name = 'matronex_crawler'
    allowed_domains = ['matronex.com']
    # start_urls = ['https://matronex.com/product-category/unitedstates/']
    links_check = ['https://matronex.com/product/bonnet-satin-cheveux/','https://matronex.com/product/personal-alarm-horns-and-sirens-keychain-rechargeable-comes-with-compass-and-led-light-suitable-for-women-children-the-elderly-and-outdoor-emergency-callspink/','https://matronex.com/product/sunshine-smile-window-stickers-4/','https://matronex.com/product/webcam-1080p-con-microfono-estereo/','https://matronex.com/product/sunshine-smile-chongwukoushuijin-2/','https://matronex.com/product/auger-drill-plant-screw-for-drill-auger-drill-for-planting-garden-snails-spiral-drill-ground-cultivator-drill-garden-auger-diameter-4-cm-length-42-cm-diameter-8-cm-length-30-cm/','https://matronex.com/product/sunshine-smile-shengdanghuihuamuban-6/','https://matronex.com/product/kinder-schutzausrustung-kinder-schonerset-schutzausrustung-protektoren-set-6-in-1-profi-schutzausrustung-fur-kinder-knieschoner-ellenbogenschutzer-handgelenkschoner-set-fur-skateboard-rol/','https://matronex.com/product/sunshine-smile-shengdanghuihuamuban-5/','https://matronex.com/product/sunshine-smile-shengdanghuihuamuban-3/','https://matronex.com/product/sunshine-smile-window-stickers-2/','https://matronex.com/product/kinder-schutzausrustung-kinder-schonerset-schutzausrustung-protektoren-set-6-in-1-profi-schutzausrustung-fur-kinder-knieschoner-ellenbogenschutzer-handgelenkschoner-set-fur-skateboard-rol-2/','https://matronex.com/product/cartridge-press-cartridge-gun-portable-diy-anti-drip-gun-for-extremely-durable-silicone-cartridges-with-4-inches-and-comfort-grip-insulating-small-seam-for-sealing-the-seal-filling/','https://matronex.com/product/sunshine-smile-shengdanghuihuamuban-4/','https://matronex.com/product/kinder-schutzausrustung-kinder-schonerset-schutzausrustung-protektoren-set-6-in-1-profi-schutzausrustung-fur-kinder-knieschoner-ellenbogenschutzer-handgelenkschoner-set-fur-skateboard-rol-3/','https://matronex.com/product/improved-claw-grinder-for-dogs-professional-electric-led-nail-file-for-pets-rechargeable-silent-3-speed-dog-nail-trimmer-powerful-pain-free-paws/','https://matronex.com/product/baby-pillow-cot-pillow-for-sleeping-ganke-baby-pillow-with-removable-pillowcase-soft-memory-foam-pillow-toddler-pillow-deep-grey/','https://matronex.com/product/led-solarleuchte-oneid-solar-lichterkette-aussen-warmweis-50led-7m-60led-11m-optional-solar-kristall-kugeln-wasserdicht-auser-innen-lichter-fur-garten-baume-terrasse-weihnachten-hochze/','https://matronex.com/product/sunshine-smile-chongwukoushuijin/','https://matronex.com/product/gardening-gloves-ladies-small-size-2-pairs/','https://matronex.com/product/led-headlamp-rechargeable/','https://matronex.com/product/indoor-herb-garden-kit/','https://matronex.com/product/sunset-lamp-5/','https://matronex.com/product/moon-lamp/','https://matronex.com/product/flexible-gooseneck-lamp/','https://matronex.com/product/sunset-lamp-projector-7/','https://matronex.com/product/touch-lamp-with-4-usb-ports/','https://matronex.com/product/essential-oils-set/','https://matronex.com/product/usb-bedside-table-lamp/','https://matronex.com/product/meat-thermometer-with-probe-cover/','https://matronex.com/product/led-strip-lights-2/','https://matronex.com/product/sunset-lamp-projector-6/']

    def start_requests(self):

        country_dict = {'United States': 'https://matronex.com/product-category/unitedstates/',
                        'United Kingdom': 'https://matronex.com/product-category/unitedkingdom/',
                        'Germany': 'https://matronex.com/product-category/germany/',
                        'Holland': 'https://matronex.com/product-category/holland/',
                        'France': 'https://matronex.com/product-category/france/',
                        'Japan': 'https://matronex.com/product-category/japan/',
                        'Canada': 'https://matronex.com/product-category/canada/',
                        'Spain': 'https://matronex.com/product-category/Spain/',
                        'Spain': 'https://matronex.com/?s=&product_cat=spain&post_type=product',
                        'United Kingdom': 'https://matronex.com/?s=&product_cat=united-kingdom-deals&post_type=product',
                        'Germany': 'https://matronex.com/?s=&product_cat=germany-deals&post_type=product',
                        'United States': 'https://matronex.com/?s=&product_cat=united-states-deals&post_type=product'
                        }
        # country_dict = {'United States':'https://matronex.com/product-category/unitedstates/','United Kingdom':'https://matronex.com/product-category/unitedkingdom/',
        #                 'Germany':'https://matronex.com/product-category/germany/','Holland':'https://matronex.com/product-category/holland/',
        #                 'France':'https://matronex.com/product-category/france/','Japan':'https://matronex.com/product-category/japan/',
        #                 'Canada':'https://matronex.com/product-category/canada/','Spain':'https://matronex.com/product-category/Spain/',
        #                 'Spain': 'https://matronex.com/?s=&product_cat=spain-deals&post_type=product',
        #                 'United Kingdom': 'https://matronex.com/?s=&product_cat=united-kingdom-deals&post_type=product',
        #                 'Germany': 'https://matronex.com/?s=&product_cat=germany-deals&post_type=product',
        #                 'United States': 'https://matronex.com/?s=&product_cat=united-states-deals&post_type=product'
        #                 }
        # country_dict = {'Spain': 'https://matronex.com/?s=&product_cat=spain-deals&post_type=product',
        #                 'United Kingdom': 'https://matronex.com/?s=&product_cat=united-kingdom-deals&post_type=product',
        #                 'Germany': 'https://matronex.com/?s=&product_cat=germany-deals&post_type=product',
        #                 'United States': 'https://matronex.com/?s=&product_cat=united-states-deals&post_type=product'}
        for name,url in country_dict.items():
            formdata = {'ppp':'-1'}
            yield scrapy.FormRequest(url, callback=self.parse, method='POST', formdata=formdata,meta={'country':name})

    def parse(self, response):
        try:
            country = response.meta['country']
            product_links = list(set(response.xpath('//li[contains(@class,"product type-product")]//a[contains(@href,"/product/")]/@href').extract()))
            for product_url in product_links:
                yield scrapy.Request(url=product_url, callback=self.get_data,meta={'country':country})
        except Exception as e:
            print(e)

    def get_data(self, response):
        try:
            if response.url in self.links_check:
                print("STOP")
            try:
                Title = response.xpath('//h1[@class="product_title entry-title"]/text()').extract_first().encode('ascii', 'ignore').decode('utf8')
            except Exception as e:
                print(e)
                Title = ''
            try:
                amazon_link = ''
                amazon_link1 = response.xpath('//p/a/@href').extract_first()
                if amazon_link1 != None:
                    if 'amazon.' and '/dp/' in amazon_link1:
                        t1 = amazon_link1.split('/dp/')[-1]
                        t2 = amazon_link1.split('/dp/')[0]
                        if '/' in t1:
                            t1 = t1.split('/')[0]
                        elif '?' in t1:
                            t1 = t1.split('?')[0]
                        amazon_link = t2 + '/dp/' + t1
                    if '/gp/product/' in amazon_link1:
                        amazon_link = amazon_link1.replace('/gp/product/','/dp/')
                    # if 'https://www.amazon.com' not in amazon_link1:
                    #     amazon_link = ''
            except Exception as e:
                print(e)
                amazon_link = ''
            # if amazon_link == '':
            #     print("wait")

            # if 'Buy on Amazon' in response.text:
            #     amazon_link = response.xpath('//*[contains(text(),"Buy on Amazon ")]/@href').extract_first()
            #     if 'amazon' not in amazon_link:
            #         amazon_link = ''

            try:
                domain_promo_price = response.xpath('//ins/span/bdi/text()').extract_first().strip()
                domain_promo_price = domain_promo_price.replace(',', '.').strip()
            except Exception as e:
                print(e)
                domain_promo_price = '0'

            if domain_promo_price == 'FREE':
                domain_promo_price = '0'

            try:
                domain_price = response.xpath('//del/span/bdi/text()').extract_first().strip()
                domain_price = domain_price.replace(',', '.').strip()
            except Exception as e:
                print(e)
                domain_price = ''

            x = datetime.datetime.now()
            crawl_date_time = str(x).replace(' ', 'T').split('.')[0]
            date = str(x).split(' ')[0]

            hashid = int(hashlib.md5(bytes(str('bungetech') + str(response.url) + str({date}), "utf8")).hexdigest(),16) % (10 ** 20)

            item = MatronexItem()
            item['HashID'] = hashid
            item['Date'] = date
            item['Title'] = Title
            item['crawl_date_time'] = crawl_date_time
            item['site_name'] = 'matronex'
            item['review_url'] = response.url
            item['country'] = response.meta['country']
            item['amazon_url'] = amazon_link
            item['asin'] = ''
            item['sold_by'] = ''
            item['seller_id'] = ''
            item['screenshotamazonpage'] = ''
            item['screenshotproductpage'] = ''
            item['domain_promo_price'] = domain_promo_price
            item['domain_price'] = domain_price
            item['amazon_price'] = ''
            yield item
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl matronex_crawler'.split())

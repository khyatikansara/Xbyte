# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import mysql.connector
Data_in = 0
first = True

#--- DB Config ---#
host="localhost"
user="root"
passwd="xbyte"
db_name = 'Latestdeal'
table_name = '' #'Latestdeal'
save_file_path = ''#'E:\\Xbyte\\storelocator-property\\output_file\\'
save_file_name = ''#'.csv'
#-------------------------------------------------------------------------

#change class name      <-------------------##
class LatestdealsPipeline(object):
    def __init__(self):
        try:
            self.mysql = mysql.connector.connect(host=host,user=user,passwd=passwd)
            self.con = self.mysql.cursor()
            self.con.execute("CREATE DATABASE if not exists storelocatore_property")
        except Exception as e:
            print("ERROR IN DATABASE create : ",e)
        try:
            self.mysql = mysql.connector.connect(host=host,user=user,passwd=passwd)
            self.con = self.mysql.cursor()
        except Exception as e:
            print("Error in creat table :", e)

    def process_item(self, item, spider):
        global first,table_name
        table_name = spider.name
        if first == True:
            try:
                self.mysql = mysql.connector.connect(host=host,user=user,passwd=passwd)
                self.con = self.mysql.cursor()
                qry = "CREATE DATABASE if not exists "+db_name
                self.con.execute(qry)
            except Exception as e:
                print("ERROR IN DATABASE create : ", e)
            try:
                self.mysql = mysql.connector.connect(host=host,user=user,passwd=passwd,database=db_name)
                self.con = self.mysql.cursor()

                # Enter headers list heare      <-------------------##
                keylist = ['Url','Category','Storename','Merchant_Name','Dealname','Description','Discounts','Coupencode','Expire_Date']

                # keylist = []
                # for i in item.keys():
                #     if i!='hash':
                #         keylist.append(i)

                table = "CREATE TABLE if not exists "+table_name+" (Id INT NOT NULL AUTO_INCREMENT,"
                columname = ' longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,'.join(keylist)+' longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,'
                end = """hash VARCHAR(200) DEFAULT NULL,UNIQUE KEY (hash),PRIMARY KEY (`Id`))"""
                qry = str(table+columname+end)
                qry.replace('hash longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,','')
                self.con.execute(qry)
            except Exception as e:
                print("Error in creat table :", e)
            first = False

        sql = 'INSERT INTO '+table_name+' ('+','.join(item.keys())+') VALUES ('+('%s,'*int(len(item.keys()))).strip(',')+')'
        val = []
        for i in item.keys():
            val.append(item[i])
        try:
            self.con.execute(sql, val)
            global Data_in
            Data_in += 1
            print(Data_in, "record inserted.")
        except Exception as e:
            print("error in data insertion : ",e)
        self.mysql.commit()
        return item

    def close_spider(self, spider):
        save_file_name = spider.name+'.csv'
        import pymysql
        import pandas as pd
        try:
            con = pymysql.connect(host=host,user=user,passwd=passwd,database=db_name)
            cursor = con.cursor()
            sql = f"select * from  {table_name}"
            df = pd.read_sql(sql, con)
            df.to_csv(save_file_path+save_file_name, index=False)
            print('file genarated : ',save_file_path+save_file_name)
        except Exception as e:
            print(e)
import hashlib
import scrapy
import json
from latestdeals.items import LatestdealsItem


class Latestdeals(scrapy.Spider):

    name = 'latestdeals_20210818_1'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def start_requests(self):
        url = f'https://images.latestdeals.co.uk/sitemaps/sitemap-merchants-vouchers.xml'
        yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response, **kwargs):
        for i in str(response.text).split('<url><loc>'):
            url = f"https://www.latestdeals.co.uk/api/posts?merchantSlug={i.split('</loc>')[0].split('/')[-1]}&showEntered=false&showExpired=true&type=voucher"
            yield scrapy.Request(url, callback=self.final)

    def final(self, response):

        data = json.loads(response.text)

        for i in list(data['entities'].keys()):

            url = 'https://www.latestdeals.co.uk/vouchers/' + str(i)

            try:
                Category = f"Home > {data['entities'][i]['type']} > {data['entities'][i]['category']} > {data['entities'][i]['title']}"
            except:
                Category = ''

            try:
                Merchant_Name = data['entities'][i]['merchantName']
            except:
                Merchant_Name = ''

            try:
                Storename = data['entities'][i]['merchantSlug']
            except:
                Storename = ''

            try:
                offer_title = data['entities'][i]['title']
            except:
                offer_title = ''

            try:
                offer_cod = data['entities'][i]['code']
            except:
                offer_cod = ''

            try:
                descrip = ''
                for j in json.loads(data['entities'][i]['descriptionJs'])['blocks']:
                    descrip += str(' ') + j['text']
            except:
                descrip = ''

            try:
                end_date = data['entities'][i]['endDate']
            except:
                end_date = ''

            Discounts = ''
            try:
                if '% off' in offer_title:
                    Discounts = offer_title.split('% off')[0].strip()[-2:].strip() + str('% off')
                else:
                    Discounts = ''
            except:
                pass

            try:
                if '£' in offer_title and 'off' in offer_title:
                    Discounts = str('£') + offer_title.split('off')[0].split('£')[1].strip() + str(' off')
            except:
                pass

            if 'T' in end_date:
                ed = end_date.split('T')[0]
            else:
                ed = ''

            if 'Free Delivery' in offer_title:
                Discounts = 'Free Delivery'

            item = LatestdealsItem()
            item['Url'] = url
            item['Category'] = Category
            item['Storename'] = Storename
            item['Merchant_Name'] = Merchant_Name
            item['Dealname'] = offer_title
            item['Description'] = descrip
            item['Discounts'] = Discounts
            item['Coupencode'] = offer_cod
            item['Expire_Date'] = ed
            hasstr = (str(item['Url'])).encode('utf8')
            Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
            item['hash'] = Hash_id

            yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl latestdeals_20210818_1'.split())

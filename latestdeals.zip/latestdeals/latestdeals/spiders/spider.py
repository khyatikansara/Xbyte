import hashlib
import scrapy
import json
from latestdeals.items import LatestdealsItem


class Latestdeals(scrapy.Spider):

    name = 'latestdeals_20210818'

    def start_requests(self):

        for i in range(0, 550):
            url = f'https://www.latestdeals.co.uk/api/posts?page={i}&showEntered=false&showExpired=false&type='
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response, **kwargs):
        data = json.loads(response.text)
        for i in data['entities'].keys():
            cod_url = f"https://www.latestdeals.co.uk/api/posts/{i}"
            yield scrapy.Request(url=cod_url, callback=self.Coupen, meta={'json': data, 'I': i})

    def Coupen(self, response):

        CODjson = json.loads(response.text)

        try:
            url = 'https://www.latestdeals.co.uk/deals/' + response.meta['I']
        except:
            url = ''

        try:
            Category = f"Home > {CODjson['entities'][response.meta['I']]['type']}" \
                       f" > {CODjson['entities'][response.meta['I']]['category']}" \
                       f" > {CODjson['entities'][response.meta['I']]['title']}"
        except:
            Category = ''

        try:
            Merchant_Name = CODjson['entities'][response.meta['I']]['merchantName']
        except:
            Merchant_Name = ''

        try:
            Storename = CODjson['entities'][response.meta['I']]['merchantSlug']
        except:
            Storename = ''

        try:
            offer_title = CODjson['entities'][response.meta['I']]['title']
        except:
            offer_title = ''

        try:
            offer_cod = CODjson['entities'][response.meta['I']]['code']
        except:
            offer_cod = ''

        try:
            descrip = ''
            for j in json.loads(CODjson['entities'][response.meta['I']]['descriptionJs'])['blocks']:
                descrip += str(' ') + j['text']
        except:
            descrip = ''

        try:
            end_date = CODjson['entities']['I']['endDate']
        except:
            end_date = ''

        Discounts = ''
        try:
            if '% off' in offer_title:
                Discounts = offer_title.split('% off')[0].strip()[-2:].strip() + str('% off')
            else:
                Discounts = ''
        except:
            pass

        try:
            if '£' in offer_title and 'off' in offer_title:
                Discounts = str('£') + offer_title.split('off')[0].split('£')[1].strip() + str(' off')
        except:
            pass

        if 'T' in end_date:
            ed = end_date.split('T')[0]
        else:
            ed = ''

        if 'Free Delivery' in offer_title:
            Discounts = 'Free Delivery'

        item = LatestdealsItem()
        item['Url'] = url
        item['Category'] = Category
        item['Storename'] = Storename
        item['Merchant_Name'] = Merchant_Name
        item['Dealname'] = offer_title
        item['Description'] = descrip
        item['Discounts'] = Discounts
        item['Coupencode'] = offer_cod
        item['Expire_Date'] = ed

        has_str = (str(item['Url'])).encode('utf8')
        Hash_id = int(hashlib.md5(has_str).hexdigest(), 16)
        item['hash'] = Hash_id

        yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl latestdeals_20210818 -a s=0 -a e=1'.split())
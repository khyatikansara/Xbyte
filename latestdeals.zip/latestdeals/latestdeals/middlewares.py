# -*- coding: utf-8 -*-
# Define here the models for your spider middleware

# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import random
from scrapy import signals
from w3lib.http import basic_auth_header


class LatestdealsSpiderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, dict or Item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request, dict
        # or Item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class LatestdealsDownloaderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # Called for each request that goes through the downloader
        # middleware.
        dict = {"lum-customer-xbyte-zone-zone_us": "0gi0pioy3oey",
                "lum-customer-xbyte-zone-zone_germany": "germany@2018",
                "lum-customer-xbyte-zone-zone_uk": "bqa3iap0g4nr",
                "lum-customer-xbyte-zone-zone_france": "france@2018",
                "lum-customer-xbyte-zone-zone_spain": "k4vt6e2v53v9",
                "lum-customer-xbyte-zone-zone_italy": "et2g17oqw1nm",
                "lum-customer-xbyte-zone-zone_australia": "rjbsuy1tzgco",
                "lum-customer-xbyte-zone-zone_japan": "5v9sl7ilbppn",
                "lum-customer-xbyte-zone-zone_taiwan": "b2kqeq76cxi6",
                "lum-customer-xbyte-zone-zone_netherland": "zvptczvd2ahq",
                "lum-customer-xbyte-zone-zone_russia": "plpsy85v8pu6",
                "lum-customer-xbyte-zone-zone_india": "w6zj0g4ikjy3",
                "lum-customer-xbyte-zone-zone_israel": "gtuythxi5oc3"}
        username, password = random.choice(list(dict.items()))
        request.meta['proxy'] = "https://zproxy.lum-superproxy.io:22225"
        request.headers['Proxy-Authorization'] = basic_auth_header(username, password)

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)

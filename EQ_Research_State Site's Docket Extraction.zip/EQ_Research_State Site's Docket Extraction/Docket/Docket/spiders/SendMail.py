# -*- coding: utf-8 -*-
import os
import platform
import time
from datetime import datetime
from os import listdir
from os.path import isfile, join
from random import choice
import scrapy
from json2html import json2html
import pandas as pd
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib


class EmailSpider(scrapy.Spider):
    name = 'email_spider'
    allowed_domains = ['www.example.com']
    start_urls = []
    process_date = ''
    date1 = ''

    def start_requests(self):
        try:
            mypath = "D:\khyati-H\CRM\Projects AP\EQ_Research_State Site's Docket Extraction\Files_2021_07_01\\"
            onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
            emailIds = ['khyati.xbyte@gmail.com', "alerts@xbyte.io"]#, 'asingh.xbyte@gmail.com']
            # emailpasswords = ["xbyte@20_11_2019", "xbyte123", 'xbyte123*']
            for files in onlyfiles:
                print(files)
                df = pd.read_excel(mypath+files)
                for key,value in df.iterrows():
                    State = value['State']
                    Docket = value['Docket_Number']
                    Link = value['Docket_Link']

                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        s.connect(('8.8.8.8', 1))
                        emailId_choice = choice(emailIds)
                        emailId = ''.join(emailId_choice.split('_')[0])
                        if emailId == 'khyati.xbyte@gmail.com':
                            emailpass = 'xbyte@20_11_2019'
                        if emailId == 'alerts@xbyte.io':
                            emailpass = 'xbyte123'
                        if emailId == 'asingh.xbyte@gmail.com':
                            emailpass = 'xbyte123*'

                        # password = ['asingh.xbyte@gmail.com','xbyte123*']

                        send_to = [
                            "regtrackdsire@gmail.com",
                            "mmakhyoun@eq-research.com"
                            # 'alpesh.khunt.xbyte@gmail.com',
                            # 'vishal.xbyte@gmail.com',
                            # 'kunals.xbyte@gmail.com',
                            # 'foram.patel.xbyte@gmail.com',
                            # 'hiral.trivedi.xbyte@gmail.com',
                            # 'vikram.chauhan.xbyte@gmail.com',
                            # 'xbyte.qa@gmail.com',
                            # 'ricky.xbyte@gmail.com'
                            # 'asingh.xbyte@gmail.com',
                            # 'khyati.xbyte@gmail.com'
                            # "khyati.xbyte@gmail.com"
                        ]
                        bcc = [
                            # "bhagyashree.rojivadiya.xbyte@gmail.com"
                            # 'foram.patel.xbyte@gmail.com',
                            # 'hiral.trivedi.xbyte@gmail.com',
                            # 'alpesh.khunt.xbyte@gmail.com',
                            # 'vikram.chauhan.xbyte@gmail.com',
                            # 'xbyte.qa@gmail.com',
                            # 'lata.sonkusare.xbyte@gmail.com',
                            # 'vishal.xbyte@gmail.com',
                            # 'kunals.xbyte@gmail.com',
                            'asingh.xbyte@gmail.com',
                            'victor.douglas@xbyte.io',
                            'khyati.xbyte@gmail.com'
                        ]
                        # cc = ['khyati.xbyte@gmail.com']

                        mail_content = list()
                        mail_content.append("<html>")
                        mail_content.append("<head>")
                        mail_content.append("<style>")
                        mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
                        mail_content.append("</style>")
                        mail_content.append("</head>")
                        mail_content.append("<body>")
                        mail_content.append(f"Below is an update on {State} {Docket}")
                        mail_content.append(f"<br>{Link}")
                        mail_content.append("</body>")
                        mail_content.append("</html>")
                        # Data count summary

                        body = "".join(mail_content)
                        with open(f'mail_{self.process_date}.html', 'w') as o:
                            o.write(body)
                        try:
                            msg = MIMEMultipart()
                            msg['From'] = emailId
                            msg['To'] = ",".join(send_to)
                            # msg['CC'] = ",".join(cc)
                            msg['BCC'] = ",".join(bcc)
                            msg['Subject'] = f"{State} {Docket}"
                            msg.attach(MIMEText(body, 'html'))
                            if emailId == "alerts@xbyte.io":
                                s = smtplib.SMTP('mail.xbyte.io', 587)
                            else:
                                s = smtplib.SMTP('smtp.gmail.com', 587)
                            s.starttls()
                            s.login(emailId, emailpass)
                            text = msg.as_string()
                            s.sendmail(emailId, send_to + bcc, text)
                            print("Mail Sent ...")
                            s.quit()
                        except Exception as e:
                            print(e)
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute(f"scrapy crawl email_spider".split())
# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.http import HtmlResponse
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketWashingtonSpider(scrapy.Spider):
    name = 'nevada'
    allowed_domains = []
    start_urls = ['http://example.com/']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_01_07']
        self.data = self.db[f'Docket_{self.name}']
        self.flag = True
        self.page = 1

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        urls = ["http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Electric", "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Gas", "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Rulemaking",
               "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=MHP", "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Safety", "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Renewable",
               "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Telecommunications", "http://pucweb1.state.nv.us/PUC2/Dktinfo.aspx?Util=Water"]
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': 'AspxAutoDetectCookieSupport=1; ASP.NET_SessionId=zbfdm5vrln1k2vntmyvlv1xh',
            'Host': 'pucweb1.state.nv.us',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'
            }
        for url in urls:
            yield scrapy.Request(url=url, dont_filter=True, headers=self.headers)

    def parse(self,response):
        try:
            if response.status != 200:
                yield scrapy.Request(url=response.url, headers=self.headers, dont_filter=True)
            else:
                selectors = response.xpath('//table[@id="GridView1"]/tr')
                for i in range(1,len(selectors)+1):
                    Docket_Number = selectors[i].xpath('./td[2]//text()').extract_first()
                    Docket_Open_Date = selectors[i].xpath('./td[3]//text()').extract_first()
                    Topic = selectors[i].xpath('./td[4]//text()').extract_first()
                    Case_Summary = Topic
                    Topic_Status = 'Open'
                    Docket_Link = f'<a href= "http://pucweb1.state.nv.us/PUC2/DktDetail.aspx" target = "_blank">{str(Docket_Number)} (Use Search)</a>'
                    Agency = ''
                    Policies = ''
                    Technologies2 = ''
                    Utilities = ''
                    item = DocketItem()
                    item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                    item['State'] = 'Nevada'
                    item['Docket_Number'] = Docket_Number
                    item['Docket_Link'] = Docket_Link
                    item['Topic'] = Topic
                    item['Agency'] = Agency
                    item['Policies'] = Policies
                    item['Technologies2'] = Technologies2
                    item['Case_Summary'] = Case_Summary
                    item['Topic_Status'] = Topic_Status
                    item['Docket_Open_Date'] = Docket_Open_Date
                    item['Utilities'] = Utilities
                    try:
                        self.data.insert(item)
                        print("Data inserted....")
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data,'nevada')


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl nevada -a name=Nevada'.split())
# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketSouthDakotaSpider(scrapy.Spider):
    name = 'south_dakota'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_01_07']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "https://puc.sd.gov/Dockets/default.aspx"
            self.headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                # 'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                # 'Connection': 'keep-alive',
                # 'Cookie': 'ASP.NET_SessionId=tn1bhsx50oiryovklmrg0cyn',
                # 'Host': 'puc.sd.gov',
                # 'Referer': 'https://scc.virginia.gov/docketsearch',
                # 'Sec-Fetch-Dest': 'document',
                # 'Sec-Fetch-Mode': 'navigate',
                # 'Sec-Fetch-Site': 'none',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
            }
            yield scrapy.Request(url=url, headers=self.headers)
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            links = response.xpath('//*[@id="main_content"]/ul/li//a/@href').extract()
            for link in links:
                url = f"https://puc.sd.gov/Dockets/{link}"
                yield scrapy.Request(url=url, headers=self.headers, dont_filter=True, callback=self.parse_link)
        except Exception as e:
            print(e)

    def parse_link(self, response):
        try:
            url = '/'.join(response.url.split('/')[0:-1])
            meta_link = response.xpath('//*[@id="main_content"]//a[contains(@href,"2021/")]/@href').extract_first()
            if meta_link != None:
                meta_url = f"{url}/{meta_link}"
                yield scrapy.Request(url=meta_url, headers=self.headers, dont_filter=True, callback=self.parse_link1)
        except Exception as e:
            print(e)

    def parse_link1(self, response):
        try:
            final_links = response.xpath('//*[@id="main_content"]/p/a/@href').extract()
            for final_link in final_links:
                url = '/'.join(response.url.split('/')[0:-1])
                final_url = f"{url}/{final_link}"
                yield scrapy.Request(url=final_url, headers=self.headers, dont_filter=True, callback=self.get_data)
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            Topic_Status = ''.join(re.findall(r'Docket Closed:(.*?)<', response.text))
            if Topic_Status != '':
                Docket_Number = response.url.split('/')[-1].split('.')[0]
                if Docket_Number == "EL21-012":
                    print("stop")
                if Docket_Number == "NG21-002":
                    print("stop")
                Docket_Link = f'<a href= "{response.url}" target = "_blank">{Docket_Number}</a>'
                Topic = ''.join(response.xpath('//div[@align="center"]/p//text()').extract())
                if Topic == '':
                    Topic = ''.join(response.xpath('//div[@align="center"]/strong//text()').extract())
                Agency = 'Public Utilities Commission'
                Policies = ''
                Technologies2 = ''
                Case_Summary = Topic
                Docket_Open_Date = ''.join(re.findall(r'Date Filed:(.*?)&',response.text)).strip()
                if Docket_Open_Date == "":
                    Docket_Open_Date = ''.join(re.findall(r'Date Filed:(.*?)Intervention Date:', response.text)).strip()
                if '♦' in Docket_Open_Date:
                    Docket_Open_Date = Docket_Open_Date.replace('♦','').strip()
                if '<' in Docket_Open_Date or '>' in Docket_Open_Date:
                    Docket_Open_Date = re.sub(r'<(.*?)>','',Docket_Open_Date)
                Utilities = ''
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State'] = 'South Dakota'
                item['Docket_Number'] = Docket_Number
                item['Docket_Link'] = Docket_Link
                item['Topic'] = Topic
                item['Agency'] = Agency
                item['Policies'] = Policies
                item['Technologies2'] = Technologies2
                item['Case_Summary'] = Case_Summary
                item['Topic_Status'] = 'Open'
                item['Docket_Open_Date'] = Docket_Open_Date
                item['Utilities'] = Utilities
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl south_dakota -a name=South_Dakota'.split())
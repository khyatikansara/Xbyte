# -*- coding: utf-8 -*-
import hashlib
import re
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketRhodeIslandSpider(scrapy.Spider):
    name = 'rhode_island'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']
        self.flag = True
        self.page = 1

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            urls = {
                "docket":"http://www.ripuc.ri.gov/eventsactions/docket.html",
                "divdocket":"http://www.ripuc.ri.gov/eventsactions/divdocket.html"
                    }
            self.headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'http://www.ripuc.ri.gov/eventsactions/docket/D_20_13%20Page.html',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'
            }
            for url in urls:
                if url == 'docket':
                    yield scrapy.Request(url=urls['docket'], headers=self.headers)
                else:
                    yield scrapy.Request(url=urls['divdocket'], headers=self.headers)
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            docket_link,Docket_Number,Agency,Docket_Open_Date,Topic_Status,Topic = '','','','','',''
            selector = response.xpath('//*[@class="pagehead"]/..//table/tr')
            for sel in selector[1:]:
                try:
                    if len(sel.xpath('./td')) == 3:
                        if sel.xpath('./td/a/@href'):
                            docket_link = sel.xpath('./td/a/@href').extract_first()
                            if "http://www.ripuc.ri.gov/eventsactions" not in docket_link:
                                docket_link = f"http://www.ripuc.ri.gov/eventsactions/{docket_link}"
                            Docket_Number = sel.xpath('./td/a/text()').extract_first()
                            Topic = ''.join(sel.xpath('./td[3]//text()').extract())
                            Agency = ''.join(sel.xpath('./td[2]//text()').extract()).replace('\r', '').replace('\n','').strip()
                            if Topic != None:
                                if 'filedl' in Topic:
                                    Docket_Open_Date_list = re.findall(r'filedl(.*?)\)', Topic)
                                else:
                                    Docket_Open_Date_list = re.findall(r'filed(.*?)\)',Topic)
                                if len(Docket_Open_Date_list) == 1:
                                    Docket_Open_Date = Docket_Open_Date_list[0].replace('(filed','').strip()
                                    if re.match(r'^/',Docket_Open_Date):
                                        Docket_Open_Date = re.sub(r'^/','',Docket_Open_Date)
                                if len(Docket_Open_Date_list) > 1:
                                    Docket_Open_Date = Docket_Open_Date_list[0].strip()
                            else:
                                Docket_Open_Date = ''
                            Docket_Link = docket_link

                            item = DocketItem()
                            hash_id = Docket_Link + Docket_Number + Topic + Agency
                            item['_id'] = int(hashlib.md5(bytes(hash_id, "utf8")).hexdigest(), 16) % (10 ** 8)
                            item['State'] = 'Rhode Island'
                            item['Docket_Number'] = Docket_Number
                            item['Docket_Link'] = Docket_Link
                            item['Topic'] = Topic
                            item['Agency'] = Agency
                            item['Policies'] = ''
                            item['Technologies2'] = ''
                            item['Case_Summary'] = ''
                            item['Topic_Status'] = Topic_Status
                            item['Docket_Open_Date'] = Docket_Open_Date
                            item['Utilities'] = ''
                            try:
                                self.data.insert(item)
                                print("Data inserted....")
                            except Exception as e:
                                print(e)
                    else:
                        if sel.xpath('./td/a/@href'):
                            print()
                            Topic_tmp = ''.join(sel.xpath('./td[2]//text()').extract())
                            Docket_Number = sel.xpath('./td[1]//text()').extract_first()
                        else:
                            Topic_tmp = ''.join(sel.xpath('./td[2]//text()').extract())
                            Agency = ''.join(sel.xpath('./td[1]//text()').extract()).replace('\r', '').replace('\n','').strip()
                        if Topic_tmp == '':
                            Topic = Topic
                        else:
                            Topic = Topic_tmp
                        if Topic != None:
                            if 'filedl' in Topic:
                                Docket_Open_Date_list = re.findall(r'filedl(.*?)\)', Topic)
                            else:
                                Docket_Open_Date_list = re.findall(r'filed(.*?)\)',Topic)
                            if len(Docket_Open_Date_list) == 1:
                                Docket_Open_Date = Docket_Open_Date_list[0].replace('(filed','').strip()
                                if re.match(r'^/',Docket_Open_Date):
                                    Docket_Open_Date = re.sub(r'^/','',Docket_Open_Date)
                            if len(Docket_Open_Date_list) > 1:
                                Docket_Open_Date = Docket_Open_Date_list[0].strip()
                        else:
                            Docket_Open_Date = ''
                        Docket_Link = docket_link

                        item = DocketItem()
                        hash_id = Docket_Link + Docket_Number + Topic + Agency
                        item['_id'] = int(hashlib.md5(bytes(hash_id, "utf8")).hexdigest(), 16) % (10 ** 8)
                        item['State'] = 'Rhode Island'
                        item['Docket_Number'] = Docket_Number
                        item['Docket_Link'] = Docket_Link
                        item['Topic'] = Topic
                        item['Agency'] = Agency
                        item['Policies'] = ''
                        item['Technologies2'] = ''
                        item['Case_Summary'] = ''
                        item['Topic_Status'] = Topic_Status
                        item['Docket_Open_Date'] = Docket_Open_Date
                        item['Utilities'] = ''
                        try:
                            self.data.insert(item)
                            print("Data inserted....")
                        except Exception as e:
                            print(e)
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl rhode_island  -a name=Rhode_Island '.split())

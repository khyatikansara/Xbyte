# -*- coding: utf-8 -*-
import hashlib
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketArkansasSpider(scrapy.Spider):
    name = 'arkansas'
    allowed_domains = []
    start_urls = ['http://www.apscservices.info/efilings/docket_search.asp']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_01_07']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def parse(self, response):
        try:
            Dockets = response.xpath('//select[@id="CaseNumber"]/option/@value').extract()
            for Docket in Dockets:
                url = "http://www.apscservices.info/efilings/docket_search_results.asp"
                formdata={'CaseNumber2':'','CaseNumber':Docket}
                yield scrapy.FormRequest(url=url, formdata=formdata, callback=self.get_data, meta={"Docket_Number":Docket})
        except Exception as e:
            print(e)

    def get_data(self, response):
        try:
            Docket_Number = response.meta['Docket_Number']
            Docket_Link = f"http://www.apscservices.info/efilings/docket_search_results.asp?casenumber={Docket_Number}"
            Agency = 'AR Public Service Commission'
            Topic = response.xpath('//strong[text()="Style:"]/../text()').extract_first()
            Docket_Open_Date = response.xpath('//div[@class="onesixth gutterless first"]/span/text()').extract_first()
            Docket_status = response.xpath('//strong[text()="Open:"]/../text()').extract_first()
            if "True" in Docket_status:
                Topic_Status = 'Open'
            else:
                Topic_Status = 'Close'
            Utilities = response.xpath('//td[text()="Initiating Party"]/../td/text()').extract_first()
            if Topic_Status == 'Open':
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State'] = 'Arkansas'
                item['Docket_Number'] = Docket_Number
                item['Docket_Link'] = Docket_Link
                item['Topic'] = Topic
                item['Agency'] = Agency
                item['Policies'] = ''
                item['Technologies2'] = ''
                item['Case_Summary'] = Topic
                item['Topic_Status'] = Topic_Status
                item['Docket_Open_Date'] = Docket_Open_Date
                item['Utilities'] = Utilities
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl arkansas -a name=Arkansas'.split())
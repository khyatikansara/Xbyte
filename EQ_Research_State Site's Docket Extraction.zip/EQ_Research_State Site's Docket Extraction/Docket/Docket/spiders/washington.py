# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from w3lib.http import basic_auth_header

from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketWashingtonSpider(scrapy.Spider):
    name = 'washington'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']
        self.flag = True
        self.page = 1

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "https://www.utc.wa.gov/_vti_bin/CasesPublicWebsite/SearchService.svc/CaseSearch?querytext=&page=1&rowlimit=500&refiners=%3Crefiners%3E%3Crefiner+name%3D%27IndustryCodeOWSTEXT%27%3E140%3C%2Frefiner%3E%3C%2Frefiners%3E"
            # url = "https://www.utc.wa.gov/_layouts/15/CasesPublicWebsite/CaseSearch.aspx?resultSource=&page=1&query=&refiners=140%2C&isModal=false&omItem=false&doItem=false"
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.146 Safari/537.36',
                'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'),
                'Cookie': 'BIGipServer~UTC~Sharepoint_WFE_443_pool=2920101779.47873.0000; TS01393db4=016853f6a48d88f20b4a8224d97013c6c85c3fb8dfd15781b2e50f8048ebeb5d3e0b4388ecf9173e9b90034c0dbe0e5d81987d3cf632b2261d89d27ccac5d8782553e018fb'
            }
            yield scrapy.Request(url=url, headers=headers, meta={'proxy': 'https://zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.146 Safari/537.36',
                'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'),
                'Cookie': 'BIGipServer~UTC~Sharepoint_WFE_443_pool=2920101779.47873.0000; TS01393db4=016853f6a48d88f20b4a8224d97013c6c85c3fb8dfd15781b2e50f8048ebeb5d3e0b4388ecf9173e9b90034c0dbe0e5d81987d3cf632b2261d89d27ccac5d8782553e018fb'
            }
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(
                    url=response.url,
                    headers=headers,
                    meta=response.meta,
                    dont_filter=True
                )
            else:
                data_text = json.loads(response.text)
                json_data = json.loads(data_text)
                if json_data['d']['query']['PrimaryQueryResult']['RelevantResults'] != None:
                    for data in json_data['d']['query']['PrimaryQueryResult']['RelevantResults']['Table']['Rows']['results']:
                        for i in data['Cells']['results']:
                            if i["Key"] == "Title":
                                Docket_Number = i["Value"]
                            if i["Key"] == "YearOWSNMBR":
                                year = i["Value"]
                                break
                        Docket_Link = f"https://www.utc.wa.gov/_layouts/15/CasesPublicWebsite/Case.aspx?year={year}&docketNumber={Docket_Number}&resultSource=&page=1&query=&refiners=140%2C&isModal=false"
                        yield scrapy.Request(url=Docket_Link, headers=headers, callback=self.get_data)
                else:
                    self.flag = False
            if self.flag:
                self.page += 1
                url = f"https://www.utc.wa.gov/_vti_bin/CasesPublicWebsite/SearchService.svc/CaseSearch?querytext=&page={self.page}&rowlimit=500&refiners=%3Crefiners%3E%3Crefiner+name%3D%27IndustryCodeOWSTEXT%27%3E140%3C%2Frefiner%3E%3C%2Frefiners%3E"
                yield scrapy.Request(url=url, headers=headers, callback=self.parse)
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            Docket_Link = response.url
            Docket_Number = response.xpath('//dt[contains(text(),"Docket No")]/following-sibling::dd/span/text()').get()
            Topic = response.xpath('//dt[contains(text(),"Summary")]/following-sibling::dd/span/text()').get()
            Agency = ''
            Policies = ''
            Technologies2 = ''
            Case_Summary = ''
            Topic_Status = response.xpath('//dt[contains(text(),"Status")]/following-sibling::dd/span/text()').get()
            Docket_Open_Date = response.xpath('//dt[contains(text(),"Filed Date")]/following-sibling::dd/span/text()').get()
            Utilities = ''
            item = DocketItem()
            item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['State'] = 'Washington'
            item['Docket_Number'] = Docket_Number
            item['Docket_Link'] = Docket_Link
            item['Topic'] = Topic
            item['Agency'] = Agency
            item['Policies'] = Policies
            item['Technologies2'] = Technologies2
            item['Case_Summary'] = Case_Summary
            item['Topic_Status'] = Topic_Status
            item['Docket_Open_Date'] = Docket_Open_Date
            item['Utilities'] = Utilities
            try:
                self.data.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl washington -a name=Washington'.split())
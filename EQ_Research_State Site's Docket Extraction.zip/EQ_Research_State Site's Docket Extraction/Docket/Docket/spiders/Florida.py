# -*- coding: utf-8 -*-
import hashlib
import re

import requests
import scrapy
from lxml import html
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo
from selenium import webdriver
import time


class DocketFloridaSpider(scrapy.Spider):
    name = 'florida'
    allowed_domains = []
    # start_urls = ['http://www.psc.state.fl.us/ClerkOffice/Docket']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']
        self.docket_list = []

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "http://www.psc.state.fl.us/ClerkOffice/Docket"
            payload = "radioValue=DocketSelection&docket="
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'http://www.psc.state.fl.us',
                'Referer': 'http://www.psc.state.fl.us/ClerkOffice/Docket',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
            }
            response = requests.request("POST", url, headers=headers, data=payload)
            response = html.fromstring(response.text)
            Topic_list = response.xpath('//select[@id="doctitle1"]/option/text()')[1:]
            for Topic in Topic_list:
                Docket_Number = Topic.split('-')[0]
                link = f"http://www.psc.state.fl.us/ClerkOffice/DocketDetail?doctitle1={Topic.replace(' ','%20')}&docket={Docket_Number}&casestatus=0&preHearingDate=01%2F01%2F0001%2000%3A00%3A00&document_id=0&radioValue=DocketSelection&isCompleted=False&docutype=0&EventType=All"
                yield scrapy.Request(url=link, headers=headers,meta={'Topic':Topic,'Docket_Number':Docket_Number})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            Title = ''.join(response.xpath('//table/../h3/../table//tr[2]/td/strong//text()').extract())
            if '(OPEN)' in Title:
                Docket_Number = response.meta['Docket_Number']
                Docket_Link = f'<a href= "http://www.floridapsc.com/ClerkOffice/DocketDetail?docket={Docket_Number}" target = "_blank">{Docket_Number}</a>'
                Utilities = response.xpath('//*[@id="dvUtilities"]//td/text()').extract_first()
                Docket_Open_Date = response.xpath('//td[@class="eventDesc"]/../td[2]/text()').extract()[-1]
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State'] = 'Florida'
                item['Docket_Number'] = response.meta['Docket_Number']
                item['Docket_Link'] = Docket_Link
                item['Topic'] = response.meta['Topic']
                item['Agency'] = 'FL Public Service Commission'
                item['Policies'] = ''
                item['Technologies2'] = ''
                item['Case_Summary'] = Title
                item['Topic_Status'] = 'Open'
                item['Docket_Open_Date'] = Docket_Open_Date
                item['Utilities'] = Utilities
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl florida -a name=Florida'.split())
# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from w3lib.http import basic_auth_header
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo
from random import choice

proxy = ["lum-customer-xbyte-zone-zone_us-country-us|0gi0pioy3oey|zproxy.lum-superproxy.io:22225"]
current_proxy = choice(proxy).split("|")


class DocketUtahSpider(scrapy.Spider):
    name = 'utah'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "https://psc.utah.gov/electric/dockets/electric-2021/"
            self.headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'referer': 'https://psc.utah.gov/all-electric-dockets/',
                'upgrade-insecure-requests': '1',
                "Proxy-Authorization": basic_auth_header(current_proxy[0], current_proxy[1]),
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
            }
            yield scrapy.Request(url=url, headers=self.headers, meta={"proxy":"http://zproxy.lum-superproxy.io:22225"})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            if response.status in self.handle_httpstatus_list:
                yield scrapy.Request(url=response.url, headers=self.headers, meta=response.meta, dont_filter=True)
            else:
                self.header1 = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    # 'referer': 'https://psc.utah.gov/all-electric-dockets/',
                    'upgrade-insecure-requests': '1',
                    "Proxy-Authorization": basic_auth_header(current_proxy[0], current_proxy[1]),
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
                }
                main_links = response.xpath('//ul[@class="sub-menu"]/li[1]//a[contains(@href,"/dockets/") and contains(@href,"-2021")]/@href').extract()
                for main_link in main_links:
                    yield scrapy.Request(url=main_link, headers=self.headers, dont_filter=True, callback=self.parse_link, meta={"proxy": "http://zproxy.lum-superproxy.io:22225"})
        except Exception as e:
            print(e)

    def parse_link(self, response):
        try:
            Docket_links = response.xpath('//*[@class="docket-rows"]/li//a/@href').extract()
            for docket_link in Docket_links:
                yield scrapy.Request(url=docket_link, headers=self.headers, callback=self.get_data, meta={"proxy": "http://zproxy.lum-superproxy.io:22225"})
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            Docket_Link = response.url
            Docket_Number = response.xpath('//h2[contains(text(),"Docket No:")]/text()').get().replace('Docket No:','')
            Topic = response.xpath('//article/h2[2]/text()').get()
            Agency = ''
            Policies = ''
            Technologies2 = ''
            Case_Summary = ''
            Topic_Status = "Opened"
            Docket_Open_Date = response.xpath('//div[@class="article--category"]/following-sibling::div/text()').get()
            Utilities = ''
            item = DocketItem()
            item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['State'] = 'Utah'
            item['Docket_Number'] = Docket_Number
            item['Docket_Link'] = Docket_Link
            item['Topic'] = Topic
            item['Agency'] = Agency
            item['Policies'] = Policies
            item['Technologies2'] = Technologies2
            item['Case_Summary'] = Case_Summary
            item['Topic_Status'] = Topic_Status
            item['Docket_Open_Date'] = Docket_Open_Date
            item['Utilities'] = Utilities
            try:
                self.data.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data,'Utah')


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl utah -a name=Utah'.split())
# -*- coding: utf-8 -*-
import hashlib
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from w3lib.http import basic_auth_header

from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo
from scraper_api import ScraperAPIClient
client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')


class DocketColoradoSpider(scrapy.Spider):
    name = 'colorado'
    allowed_domains = []
    # start_urls = ['https://www.dora.state.co.us/pls/efi/EFI_SEARCH_UI.SEARCH?p_session_id=&p_results=Proceedings&p_document_type=Choose%20One&p_docket_status=ACTIVE&p_decision_type=Choose%20One&p_decision_author=Choose%20One&p_auto_search=Y']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "https://www.dora.state.co.us/pls/efi/EFI_SEARCH_UI.SEARCH?p_session_id=&p_results=Proceedings&p_document_type=Choose%20One&p_docket_status=ACTIVE&p_decision_type=Choose%20One&p_decision_author=Choose%20One&p_auto_search=Y"
            # url = "https://www.utc.wa.gov/_layouts/15/CasesPublicWebsite/CaseSearch.aspx?resultSource=&page=1&query=&refiners=140%2C&isModal=false&omItem=false&doItem=false"
            headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    # 'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US,en;q=0.9',
                    # 'Connection': 'keep-alive',
                    'Host': 'www.dora.state.co.us',
                    # 'Referer': 'https://www.dora.state.co.us/pls/efi/EFI_SEARCH_UI.SEARCH?p_session_id=&p_results=Proceedings&p_document_type=Choose%20One&p_docket_status=ACTIVE&p_decision_type=Choose%20One&p_decision_author=Choose%20One&p_auto_search=Y',
                    # 'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                    # 'sec-ch-ua-mobile': '?0',
                    # 'Sec-Fetch-Dest': 'iframe',
                    # 'Sec-Fetch-Mode': 'navigate',
                    # 'Sec-Fetch-Site': 'same-origin',
                    'Upgrade-Insecure-Requests': '1',
                    'Proxy-Authorization': basic_auth_header("lum-customer-xbyte-zone-zone_us-country-us", "0gi0pioy3oey"),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'
            }
            # yield scrapy.Request(client.scrapyGet(url=url), headers=headers)
            yield scrapy.Request(url=url, headers=headers, meta={'proxy': 'https://zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            print(response.text)
            url = "https://www.dora.state.co.us/pls/efi/EFI_SEARCH_UI.getProceedingResults?p_session_id=&p_proceeding=&p_title=&p_industry=Choose%20One&p_docket_status=ACTIVE&p_after=&p_before=&p_cache=1624016973209&p_sort=START_DATE&p_direction=DESC"
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                # 'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                # 'Connection': 'keep-alive',
                'Host': 'www.dora.state.co.us',
                # 'Referer': 'https://www.dora.state.co.us/pls/efi/EFI_SEARCH_UI.SEARCH?p_session_id=&p_results=Proceedings&p_document_type=Choose%20One&p_docket_status=ACTIVE&p_decision_type=Choose%20One&p_decision_author=Choose%20One&p_auto_search=Y',
                # 'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                'sec-ch-ua-mobile': '?0',
                'Sec-Fetch-Dest': 'iframe',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Upgrade-Insecure-Requests': '1',
                'Proxy-Authorization': basic_auth_header("lum-customer-xbyte-zone-zone_us-country-us", "0gi0pioy3oey"),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'
            }
            yield scrapy.Request(url=url, headers=headers, callback=self.get_data, meta={'proxy': 'https://zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def get_data(self, response):
        try:
            selectors = response.xpath('//h2/following-sibling::table//tr')[1:]
            for selector in selectors:
                Docket_Link = selector.xpath('./td[1]/a/@href').extract_first()
                Docket_Link = f"https://psc.nd.gov/database/{Docket_Link}"
                Docket_Number = selector.xpath('./td[1]/a/text()').extract_first()
                Agency = selector.xpath('./td[3]/text()').extract_first()
                Topic = selector.xpath('./td[2]/text()').extract_first()
                Docket_Open_Date = selector.xpath('./td[5]/text()').extract_first()
                Topic_Status = 'Open'
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State'] = 'North Dakota'
                item['Docket_Number'] = Docket_Number
                item['Docket_Link'] = Docket_Link
                item['Topic'] = Topic
                item['Agency'] = Agency
                item['Policies'] = ''
                item['Technologies2'] = ''
                item['Case_Summary'] = Topic
                item['Topic_Status'] = Topic_Status
                item['Docket_Open_Date'] = Docket_Open_Date
                item['Utilities'] = ''
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl colorado -a name=Colorado'.split())
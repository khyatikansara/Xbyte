# -*- coding: utf-8 -*-
import datetime
import hashlib
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from random import choice
from w3lib.http import basic_auth_header


class DocketAlabamaSpider(scrapy.Spider):
    name = 'alabama_docket'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def start_requests(self):
        try:
            url = 'https://www.pscpublicaccess.alabama.gov/pscpublicaccess/page/docket-docs/PSC/DocketDetails.aspx'
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Host': 'www.pscpublicaccess.alabama.gov',
                'Referer': 'https://www.pscpublicaccess.alabama.gov/pscpublicaccess/PSC/DocketDetailsPage.aspx',
                'Upgrade-Insecure-Requests': '1'
            }
            yield scrapy.Request(url=url, headers=headers, meta={"proxy":"http://zproxy.lum-superproxy.io:22225"})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            if response.status in self.handle_httpstatus_list:
                headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Host': 'www.pscpublicaccess.alabama.gov',
                    'Referer': 'https://www.pscpublicaccess.alabama.gov/pscpublicaccess/PSC/DocketDetailsPage.aspx',
                    'Upgrade-Insecure-Requests': '1',
                    "Proxy-Authorization": basic_auth_header(current_proxy[0], current_proxy[1]),
                    'User-Agent': self.get_useragent()
                }
                yield scrapy.Request(
                    url=response.url,
                    headers=headers,
                    meta=response.meta,
                    dont_filter=True
                )
            else:
                item = DocketItem()
                links = response.xpath('//a[@class="film-link"]/@href').getall()
                for link in links:
                    link = f'https://mubi.com{link}'
                    item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                    item['link'] = link
                    yield item
                try:
                    next_page_tmp = response.xpath('//a[@rel="next"]/@href').get()
                    if next_page_tmp:
                        next_page = 'https://mubi.com' + next_page_tmp
                        yield scrapy.Request(
                            url=next_page,
                            headers=headers,
                            meta=response.meta,
                            dont_filter=True,
                            callback=self.parse
                        )
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

# execute('scrapy crawl alabama_docket -a name=Alabama'.split())
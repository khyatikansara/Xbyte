import hashlib

import pymongo
import scrapy
from scrapy.http import HtmlResponse
from Docket.items import DocketItem
import requests
from Docket.mongoexport import export


class DocketMissouriSpider(scrapy.Spider):
    name = 'missouri'
    start_urls=['https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/Docket_sheet.asp?screen_id=FIL10&deltemp=true']
    allowed_domains = []

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_01_07']
        self.data = self.db[f'Docket_{self.name}']

    def parse(self, response):
        try:
            # urls='https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/Docket_sheet.asp?screen_id=FIL10&deltemp=true'
            payload = "txt_caseNo=2021-&rqNewCriteria=&HidBlur=False&Mode="
            querystring = {"screen_id": "FIL10", "deltemp": "true"}
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'Cache-Control': 'max-age=0',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
                'Cookie': 'ASPSESSIONIDCGBACDRT=FPJGIHJBGJCPCHOFDCBPHCGM'
            }

            response1= requests.request("POST", url=response.url, headers=headers, data=payload, params=querystring)
            response = HtmlResponse(url=response1.url, body=bytes(response1.text.encode('utf-8')))
            docs=response.xpath('//a[@target="_self"]/@href').getall()
            for link in docs:
                full='https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/'+str(link)
                yield scrapy.Request(url=full, callback=self.get_data,meta={'link':full})
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            Topic_Status = response.xpath('//span[contains(text(),"Status")]//following::td[1]//text()').get()
            if Topic_Status == 'Open':
                Docket_Link = response.meta['link']
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State']='Missouri'
                item['Docket_Number']=response.xpath('//span[contains(text(),"Case No.")]//following::td[1]//text()').get().replace('\r\n\t\t','').replace('\r\n\t','')
                item['Docket_Link']=(f'<a href= {Docket_Link} target = "_blank">{item["Docket_Number"]}</a>')
                item['Topic']=''.join(response.xpath('//td[@width="85%"]//text()').getall()[:2]).replace('\r\n\t\t','')
                item['Agency']='MO Public Service Commission'
                item['Policies'] = ''
                item['Technologies2'] = ''
                item['Case_Summary']=''.join(response.xpath('//span[contains(text(),"Company Name(s)")]//following::td[1]//text()').get()).replace('\r\n\t\t','')
                item['Topic_Status'] = response.xpath('//span[contains(text(),"Status")]//following::td[1]//text()').get()
                item['Docket_Open_Date']=response.xpath("//td[contains(text(),'/')]//text()").getall()[::][-1]
                item['Utilities'] = ''
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl missouri -a name=Missouri'.split())
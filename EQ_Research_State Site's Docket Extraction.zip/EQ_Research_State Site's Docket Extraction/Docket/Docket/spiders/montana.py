import requests
import scrapy
from Docket.items import DocketItem
import http.client

class data_get(scrapy.Spider):

    name = 'henny_montana'

    def start_requests(self):
        url = "https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/Docket_sheet.asp?screen_id=FIL10&deltemp=true"

        payload = "txt_caseNo=2021-&rqNewCriteria=&HidBlur=False&Mode="
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'max-age=0',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
            'Cookie': 'ASPSESSIONIDCGBACDRT=FPJGIHJBGJCPCHOFDCBPHCGM'
        }

        response = requests.request("POST", url, headers=headers, data=payload)

        print(response.text)

        url='https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/Docket_sheet.asp?screen_id=FIL10&deltemp=true'

        payload = "txt_caseNo=2021-&rqNewCriteria=&HidBlur=False&Mode="
        headers = {
            'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            'Accept-Encoding': "gzip, deflate, br",
            'Accept-Language': "en-US,en;q=0.9",
            'Cache-Control': "max-age=0",
            'Content-Type': "application/x-www-form-urlencoded",
            'Referer': "https://www.efis.psc.mo.gov/mpsc/Filing_Submission/DocketSheet/Docket_sheet.asp?screen_id=FIL10&deltemp=true",
            'Upgrade-Insecure-Requests': "1",
            'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
            'Postman-Token': "fd453f39-58e6-4688-bb79-21e2928addc1,ad9ec2d6-a4d5-425d-8360-c5e4894817c2",
            'cache-control': "no-cache"
        }

        yield scrapy.FormRequest(url=url, headers=headers, formdata=payload, method="POST")


    def parse(self, response):
        item=DocketItem()
        docs=response.xpath('//a[@target="_self"]/@href').getall()
        print(docs)

        # state='Missouri'
        # dock_num= response.xpath('//td[@width="40%"]//text()').get().replace('\r\n\t\t','').replace('\r\n\t','')
        # topic=''.join(response.xpath('//td[@width="85%"]//text()').getall()[:2]).replace('\r\n\t\t','')
        # agency='MO Public Service Commission'
        # case_summarry=''.join(response.xpath('//td[@width="85%"]//text()').getall()[:2]).replace('\r\n\t\t','')
        # docket_open=response.xpath('//td[@width="85%"]//text()').getall()[5]
        #
        #
        # item['state']=state
        # item['docket_number']=dock_num
        # item['docket_link']=''
        # item['topic']=topic
        # item['agency']=agency
        # item['policies']=''
        # item['Technologies2']=''
        # item['Case_Summary']=case_summarry
        # item['Topic_Status']=''
        # item['Docket_Open_Date']=docket_open
        # item['Utilities']=''
        # yield item


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl henny_montana'.split())
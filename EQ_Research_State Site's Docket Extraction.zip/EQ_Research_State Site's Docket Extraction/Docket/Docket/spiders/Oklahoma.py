import hashlib

import scrapy
import requests
from scrapy.http import HtmlResponse
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketOklahomaSpider(scrapy.Spider):
    name = 'oklahoma'
    allowed_domains = []
    start_urls=['https://docs.google.com/spreadsheets/d/1I5hubNY4l8CH-vGKVOODLTr8lPGfwM8zb-efQ_XgNgs/edit#gid=0']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']

    def parse(self, response):
        try:
            url = "https://imaging.occ.ok.gov/imaging/OAP.aspx"
            payload = "__VIEWSTATE=%2FwEPDwUKMTE2NDQzNDU4OA8WBB4Mc29ydENyaXRlcmlhBQZGaWVsZDEeB3NvcnREaXIFA2FzYxYCAgEPZBYCAi4PPCsACwBkZJJjfcx%2BLPl7zS8S55SemGQPJ6Af&__VIEWSTATEGENERATOR=E72A4D89&__EVENTVALIDATION=%2FwEWDALSou2SCAKAltyeBgKDltyeBgKCltyeBgL8ldyeBgL9ldyeBgL%2FldyeBgK1lvCVCwKJjcPvAQLxi%2FDrAgKM54rGBgK7q7GGCGHyleR2cdDc9G1hA61l2aE%2FGqEQ&txtIndex1=&txtIndex2=&txtIndex3=&txtIndex5=&txtIndex4=&txtIndex6=1%2F1%2F21&txtDateTo=3%2F23%2F21&txtScanDate=&txtScanDateTo=&Button1=Search"
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'Content-Length': '466',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
                # 'Cookie': 'ASP.NET_SessionId=l30zsd55sfdkqpnee1axhx2p; BIGipServer~ONE-ARMED-PUBLIC-2~occ_imaging.occ.ok.gov.app~occ_imaging.occ.ok.gov_pool=rd35o00000000000000000000ffffac109035o80'
            }

            response1 = requests.request("POST", url, headers=headers, data=payload)
            response = HtmlResponse(url='', body=bytes(response1.text.encode('utf-8')))
            item=DocketItem()
            data=response.xpath('//*[@style="color:#000066;white-space:nowrap;"]')

            for d in data:
                item['State'] = 'Oklahoma'
                item['Docket_Number']=d.xpath('.//td[2]//text()').get()
                Docket_Link = ''.join(f'<a href= "http://imaging.occeweb.com/imaging/OAP.aspx" target = "_blank">PUD {item["Docket_Number"]} (Use Search)</a>')
                item['Topic'] = d.xpath('.//td[3]//text()').get()
                item['Case_Summary'] = d.xpath('.//td[4]//text()').get()
                item['Docket_Open_Date'] = d.xpath('.//td[7]//text()').get()
                item['Docket_Link'] = Docket_Link
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['Agency'] ='Oklahoma Corporation Commission'
                item['Utilities'] = ''
                item['Topic_Status'] = ''
                item['Policies'] = ''
                item['Technologies2'] = ''
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl oklahoma -a name=Oklahoma'.split())


# -*- coding: utf-8 -*-
import hashlib
import json
import re
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from Docket.items import DocketItem
from Docket.mongoexport import export
from selenium import webdriver
import pymongo


class DocketWyomingSpider(scrapy.Spider):
    name = 'wyoming'
    allowed_domains = []
    start_urls = ['https://dms.wyo.gov/SearchDocket.aspx']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def parse(self, response):
        try:
            py = "lum-customer-xbyte-zone-zone_us-country-us|0gi0pioy3oey|zproxy.lum-superproxy.io:22225"
            self.options = webdriver.ChromeOptions()
            self.driver = webdriver.Chrome(chrome_options=self.options,
                                           executable_path="D:\\chromedriver_win32\\chromedriver.exe")
            self.options.add_argument('--proxy-server=%s' % py)
            self.driver.get('https://dms.wyo.gov/external/publicusers.aspx')
            submit = self.driver.find_element_by_xpath('//input[@type="submit"]').click()
            search = self.driver.find_element_by_xpath('//input[@value="Search"]').click()
            selectors = self.driver.find_elements_by_xpath('//table[@id="ctl00_ContentPlaceHolder_uctSearchDockets_dgDockets"]/tbody/tr/td[1]')
            for selector in selectors:
                docket_click = selector.click()
                Docket_Link = selector.xpath('./td[1]/a/@href').extract_first()
                Docket_Link = f"https://psc.nd.gov/database/{Docket_Link}"
                Docket_Number = selector.xpath('./td[1]/a/text()').extract_first()
                Agency = selector.xpath('./td[3]/text()').extract_first()
                Topic = selector.xpath('./td[2]/text()').extract_first()
                Docket_Open_Date = selector.xpath('./td[5]/text()').extract_first()
                Topic_Status = 'Open'
                item = DocketItem()
                item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['State'] = 'North Dakota'
                item['Docket_Number'] = Docket_Number
                item['Docket_Link'] = Docket_Link
                item['Topic'] = Topic
                item['Agency'] = Agency
                item['Policies'] = ''
                item['Technologies2'] = ''
                item['Case_Summary'] = Topic
                item['Topic_Status'] = Topic_Status
                item['Docket_Open_Date'] = Docket_Open_Date
                item['Utilities'] = ''
                try:
                    self.data.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)

# execute('scrapy crawl wyoming -a name=Wyoming'.split())
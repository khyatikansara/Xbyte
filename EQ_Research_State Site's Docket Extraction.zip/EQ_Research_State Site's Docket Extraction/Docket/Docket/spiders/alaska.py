# -*- coding: utf-8 -*-
import hashlib
import requests
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.http import HtmlResponse
from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketAlaskaSpider(scrapy.Spider):
    name = 'alaska'
    allowed_domains = []
    start_urls = ['http://rca.alaska.gov/RCAWeb/RCALibrary/SearchResults.aspx?t=docket&c=openutil&p=quick']
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_01_07']
        self.data = self.db[f'Docket_{self.name}']

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def parse(self, response):
        url = "http://rca.alaska.gov/RCAWeb/RCALibrary/SearchResults.aspx?t=docket&c=openutil&p=home"
        payload = {
            '__EVENTTARGET': 'PortalPageControl1$_ctl6$searchResultQuickMatter$docketGrid$matterGridHeader$ddlNumberPerPage',
            '__EVENTARGUMENT': '',
            '__LASTFOCUS': '',
            '__VIEWSTATE1': f'5',
            '__VIEWSTATE': '',
            '__EVENTVALIDATION': '/wEdABKvVXD1oYELeveMr0vHCmYPWw3WeKCKZ0GwfSFYgJ6uKxXJPeZupRqHG2pDSFEdkg5e3XOKiVwX9NkBoFjpVWdGeot27+mPmH5gPehtVeksyEStOblvBAMGl9lJP+C9hCzwdMfyKA89hGcttZMY6kJ580R4W1BOigwJ5giNqU8rLkUQqHhPBwovyik2JZ+Fy2TE/x/sHZt2tbPHazVHtS9QW6HmDomMdyKirogfwyv3/tYcHlv1wyA4A7W0qM8jOuc2P8cV05p06P+4Am22O7w8h0LuSal7wRpA8fgafCcGbPW3sGnCI1PeWvIAIhCu2YtQ5srUQl5Hq8gcS05/d+/dTkDxO4rH6soQp/2i9yqdkgnJ36Smha8MSG1ij8TEl9vnwkhP1rloJFvlkUZ6ygoS6tWQXr0B9BqQgTZTz1im8g==',
            'PortalPageControl1': '_ctl6:searchResultQuickMatter:docketGrid:matterGridHeader:ddlNumberPerPage: 200'}

        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'ASP.NET_SessionId=sxfoynenmbr3eomxg4obobza',
            'Host': 'rca.alaska.gov',
            'Origin': 'http://rca.alaska.gov',
            'Referer': 'http://rca.alaska.gov/RCAWeb/RCALibrary/SearchResults.aspx?t=docket&c=openutil&p=quick',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
        }
        while True:
            res = requests.post(url=url,headers=headers,data=payload)
            response1 = HtmlResponse(url=res.url, body=res.content)
            if "Error In Application" not in response1.text:
                docket_links = response1.xpath('//a[@class="RCALibrary"]/@href').extract()
                if docket_links != []:
                    for docket_link in docket_links:
                        yield scrapy.Request(url=docket_link, callback=self.get_data)
                break

    def get_data(self, response):
        try:
            Docket_Link = response.url
            Docket_Number = response.xpath('//*[@class="DetailTitle"]/text()').extract_first().replace('Matter Number:','').strip()
            Utilities = response.xpath('//td[@headers="d7"]/span/text()').extract_first()
            Topic = response.xpath('//td[@headers="d1"]/span/text()').extract_first()
            Docket_Open_Date = response.xpath('//td[@headers="d8"]/span/text()').extract_first()
            Topic_Status = response.xpath('//td[@headers="d3"]/span/text()').extract_first()
            item = DocketItem()
            item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['State'] = 'Alaska'
            item['Docket_Number'] = Docket_Number
            item['Docket_Link'] = Docket_Link
            item['Topic'] = Topic
            item['Agency'] = ''
            item['Policies'] = ''
            item['Technologies2'] = ''
            item['Case_Summary'] = Topic
            item['Topic_Status'] = Topic_Status
            item['Docket_Open_Date'] = Docket_Open_Date
            item['Utilities'] = Utilities
            try:
                self.data.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl alaska -a name=Alaska'.split())
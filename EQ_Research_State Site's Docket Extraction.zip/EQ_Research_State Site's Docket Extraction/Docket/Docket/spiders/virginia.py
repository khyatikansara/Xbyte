# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from w3lib.http import basic_auth_header

from Docket.items import DocketItem
from Docket.mongoexport import export
import pymongo


class DocketVirginiaSpider(scrapy.Spider):
    name = 'virginia'
    allowed_domains = []
    handle_httpstatus_list = [503, 502, 501, 500]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['EQ_Research_16_06']
        self.data = self.db[f'Docket_{self.name}']
        self.flag = True
        self.page = 1

    def get_useragent(self):
        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
        return user_agent_rotator.get_random_user_agent()

    def start_requests(self):
        try:
            url = "https://scc.virginia.gov/DocketSearchAPI/breeze/CaseType/GetDistinctTypes?$orderby=TypeCode&$select=TypeCode%2CTypeDesc"
            self.headers = {
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Cookie': 'nmstat=a6354c45-cac7-2248-f004-05cbd42385f4; NSC_ESNS=0261337d-e5ba-1038-9678-bec66341cf18_3053117222_0003966510_00000000000039521948',
                'Host': 'scc.virginia.gov',
                'Referer': 'https://scc.virginia.gov/docketsearch',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'),
                'X-Requested-With': 'XMLHttpRequest'
            }
            yield scrapy.Request(url=url, headers=self.headers, meta={'proxy': 'https://zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            json_data = json.loads(response.text)
            self.headers1 = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Cookie': 'nmstat=c73b00de-fdb7-2a45-adc1-60de33adcebe',
                'Host': 'scc.virginia.gov',
                # 'Referer': 'https://scc.virginia.gov/docketsearch',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                'Proxy-Authorization': basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'),
                'Upgrade-Insecure-Requests': '1'
            }
            for data in json_data:
                key = data['TypeCode']
                url = f"https://scc.virginia.gov/DocketSearchAPI/breeze/CASES_ESTABDATE/GetCasesEstDateByType?$orderby=Case_Established_Date%20desc&$select=MATTER_NO%2CCase_Number%2CCase_Name%2CCase_Caption%2CCase_Established_Date%2CSTATUS&TypeCode={key}"
                yield scrapy.Request(url=url, headers=self.headers1, dont_filter=True, callback=self.parse_link, meta={'proxy': 'https://zproxy.lum-superproxy.io:22225'})
        except Exception as e:
            print(e)

    def parse_link(self, response):
        try:
            json_data1 = json.loads(response.text)
            headers = {
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Cookie': 'nmstat=2409a16c-1e58-3f56-54d8-743ae4566ea0',
                'Host': 'scc.virginia.gov',
                # 'Referer': 'https://scc.virginia.gov/docketsearch',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest'
            }
            for data1 in json_data1:
                MATTER_NO = str(data1['MATTER_NO'])
                url1 = f"https://scc.virginia.gov/DocketSearchAPI/breeze/CaseDetails/GetDetail?$filter=MATTER_NO%20eq%20{MATTER_NO}&$select=Case_Number%2CCase_Name%2CCaption%2CStatus%2CCase_Established_Date%2CDivision%2CSection%2CDisposition%2CDisposition_Date%2CAppealed%2CFinal_Order_Date%2CClosed_Date"
                yield scrapy.Request(url=url1, headers=headers, dont_filter=True, callback=self.get_data, meta={'MATTER_NO':MATTER_NO})
        except Exception as e:
            print(e)

    def get_data(self,response):
        try:
            json_data2 = json.loads(response.text)
            Docket_Link = f"https://scc.virginia.gov/docketsearch#/caseDetails/{response.meta['MATTER_NO']}"
            Docket_Number = json_data2[0]['Case_Number']
            Topic = json_data2[0]['Case_Name']
            Agency = ''
            Policies = ''
            Technologies2 = ''
            Case_Summary = json_data2[0]['Caption']
            Topic_Status = json_data2[0]['Status']
            Docket_Open_Date = json_data2[0]['Case_Established_Date']
            Utilities = ''
            item = DocketItem()
            item['_id'] = int(hashlib.md5(bytes(Docket_Link, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['State'] = 'Virginia'
            item['Docket_Number'] = Docket_Number
            item['Docket_Link'] = Docket_Link
            item['Topic'] = Topic
            item['Agency'] = Agency
            item['Policies'] = Policies
            item['Technologies2'] = Technologies2
            item['Case_Summary'] = Case_Summary
            item['Topic_Status'] = Topic_Status
            item['Docket_Open_Date'] = Docket_Open_Date
            item['Utilities'] = Utilities
            try:
                self.data.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)

    def close(spider, reason):
        export(spider.data, spider.name)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl virginia -a name=Virginia'.split())
# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DocketItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    _id = scrapy.Field()
    State = scrapy.Field()
    Docket_Number = scrapy.Field()
    Docket_Link = scrapy.Field()
    Topic = scrapy.Field()
    Agency = scrapy.Field()
    Policies = scrapy.Field()
    Technologies2 = scrapy.Field()
    Case_Summary = scrapy.Field()
    Topic_Status = scrapy.Field()
    Docket_Open_Date = scrapy.Field()
    Utilities = scrapy.Field()

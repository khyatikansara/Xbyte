import numpy as np
import pandas as pd


def export(db_name,file_name):
    try:
        query = {}
        cursor = db_name.find(query)
        df = pd.DataFrame(cursor)
        df.pop('_id')

        df.index = np.arange(1, len(df) + 1)
        df.index.name = 'Id'

        writer = pd.ExcelWriter(f"D:\khyati-H\CRM\Projects AP\EQ_Research_State Site's Docket Extraction\Files_2021_07_01\\{file_name}.xlsx", engine='xlsxwriter',options={'strings_to_urls': False})
        df.to_excel(writer, 'Sheet1')
        writer.save()
        print("File generated")
    except Exception as e:
        print(e)
        print("Excel File not generated")

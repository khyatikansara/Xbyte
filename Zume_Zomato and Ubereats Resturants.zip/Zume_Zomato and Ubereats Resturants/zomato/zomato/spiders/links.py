# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
# from random_user_agent.params import SoftwareName, OperatingSystem
# from random_user_agent.user_agent import UserAgent
from zomato.items import ZomatoItem
from zomato.mongoexport import export
import pymongo
import pandas as pd
import requests


class LinkSpider(scrapy.Spider):
    name = 'links'
    allowed_domains = []
    start_urls = ['https://www.zomato.com/directory']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        self.Area_links = self.db[f'Area_links']

    def start_requests(self):
        try:
            main_urls = {'Delhi NCR':'https://www.zomato.com/ncr','Mumbai':'https://www.zomato.com/mumbai','Bangalore':'https://www.zomato.com/bangalore',
                         'Chennai':'https://www.zomato.com/chennai'}

            for city,main_url in main_urls.items():
                yield scrapy.Request(url=main_url, callback=self.parse, dont_filter=True,meta={'city':city})
        except Exception as e:
            print(str(e))

    def parse(self, response):
        if response.xpath('//*[@class="city-name"]/../../../div//a'):
            area_selector = response.xpath('//*[@class="city-name"]/../../../div//a')
            for area in area_selector:
                count_text = area.xpath('.//h5/text()').extract_first()
                area_link = area.xpath('./@href').extract_first()
                item = ZomatoItem()
                item['city'] = area_link.split('/')[-2]
                item['Link'] = area_link
                item['count'] = count_text
                item['_id'] = int(hashlib.md5(bytes(area_link, "utf8")).hexdigest(), 16) % (10 ** 8)
                item['status'] = 'pending'
                try:
                    self.Area_links.insert(item)
                    print("Data inserted....")
                except Exception as e:
                    print(e)
        else:
            item = ZomatoItem()
            item['city'] = response.url.split('/')[-2]
            item['Link'] = response.url
            item['count'] = ''
            item['_id'] = int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['status'] = 'pending'
            try:
                self.Area_links.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute('scrapy crawl links'.split())

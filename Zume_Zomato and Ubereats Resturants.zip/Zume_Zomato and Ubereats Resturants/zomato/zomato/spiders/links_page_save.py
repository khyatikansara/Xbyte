# -*- coding: utf-8 -*-
import os
import pandas as pd
import pymongo
import pymysql
import scrapy
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
from selenium import webdriver
import time
from zomato.items import ZomatoItem
from selenium.webdriver.chrome.options import Options


class PageSaveSpider(scrapy.Spider):
    name = 'page_save'
    start_urls = ['https://www.example.com/']
    city = ''
    start = ''
    end = ''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        self.Area_links = self.db[f'Area_links']
        # self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_4_city')
        # self.cursor1 = self.con1.cursor()

    def parse(self, response):
        self.options = webdriver.ChromeOptions()
        self.driver = webdriver.Chrome(chrome_options=self.options, executable_path="D:\\chromedriver.exe")
        # sql_select_Query = f'select * from area_links_2021_08_17 where status="pending" and Id > "{self.start}" and Id < "{self.end}"'
        # self.cursor1.execute(sql_select_Query)
        # links = self.cursor1.fetchall()
        # chrome_options = Options()
        # chrome_options.add_experimental_option("debuggerAddress", "localhost:9000")
        # self.driver = webdriver.Chrome(chrome_options=chrome_options)
        # links = self.Area_links.find({"$and":[{"city":self.city},{"status":"pending"}]})
        # print(self.Area_links.find({"$and":[{"city":self.city},{"status":"pending"}]}).count())
        links = self.Area_links.find({"status": "pending"})
        print(self.Area_links.find({"status": "pending"}).count())
        for row in links:
            try:
                res_list, res_count = 0, 0
                Id1 = row['_id']
                link = row['Link']
                city = row['city']
                self.driver.get(link)
                time.sleep(5)
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(5)
                while True:
                    try:
                        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        time.sleep(5)
                        res_count = self.driver.find_elements_by_xpath('//a/p[1]')
                        res_list = len(res_count)
                        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                        time.sleep(5)
                        res_count = self.driver.find_elements_by_xpath('//a/p[1]')
                    except Exception as e:
                        print(e)
                    if res_list == len(res_count):
                        break
                page_source = self.driver.page_source
                try:
                    folder_path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\load_more_page\\{city}\\"
                    if not os.path.exists(folder_path):
                        os.makedirs(folder_path)
                    path = f"{folder_path}\\{Id1}.html"
                    file = open(path, 'w', encoding='utf-8')
                    file.write(page_source)
                    file.close()
                    print("page save done")
                    try:
                        # final_path = path.replace('\\','\\\\')
                        # sql_update_Query = f"update area_links_2021_08_17 set status='page_done',path='{final_path}' where Id1='{Id1}'"
                        # self.cursor1.execute(sql_update_Query)
                        # self.con1.commit()
                        self.Area_links.update({'_id': Id1}, {'$set': {'path': path}}, upsert=False)
                        self.Area_links.update({'_id': Id1}, {'$set': {'status': 'page_done'}}, upsert=False)
                        print("update done")
                    except Exception as e:
                        print(e)
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)
        self.driver.close()


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl page_save'.split())

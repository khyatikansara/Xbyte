# -*- coding: utf-8 -*-
import hashlib
import json
import os
import re
import time
import pymysql
from scrapy.cmdline import execute
import scrapy
from zomato.items import ZomatoItem
import pymongo
import requests
from scraper_api import ScraperAPIClient
# client = ScraperAPIClient('3b634b2d9dccdc93c6b18a3f0372c60d')
# client = ScraperAPIClient('370fd24c59d43efdcbafwefja0j8j8e')
# client = ScraperAPIClient('0f2e50f637e062a098bdf4d0a3e6e0d3')
# client = ScraperAPIClient('23292b2ff2324af3bcb7acab7c639654')
# client = ScraperAPIClient('300a3210851d44098e18bf60655a8f2e')
# client = ScraperAPIClient('30aa984ae6a94b0d8898f8e9393413c1')
# client = ScraperAPIClient('847641580f8a287fcf415713f838796b')
client = ScraperAPIClient('626f05bb44bb46b592c7c91c6cdad05e')

class LinksPostSpider(scrapy.Spider):
    name = 'links_post'
    allowed_domains = []
    start_urls = ['https://www.zomato.com/directory']
    start = ''
    end = ''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        self.Area_links = self.db[f'Area_links']
        self.final_links_city = self.db[f'final_links_city']
        self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_restaurant_2021_09_04')
        self.cursor1 = self.con1.cursor()

    def start_requests(self):
        try:
            sql_select_Query = f'select * from area_links where status="pending" and Id > "{self.start}" and Id < "{self.end}"'
            self.cursor1.execute(sql_select_Query)
            links = self.cursor1.fetchall()
            # links = self.Area_links.find({"$and":[{"city":"bangalore"},{"status":"pending"}]})
            # print(self.Area_links.find({"$and":[{"city":"bangalore"},{"status":"pending"}]}).count())
            # links = self.Area_links.find({"status": "pending"})
            # print(self.Area_links.find({"status": "pending"}).count())
            for row in links:
                try:
                    Id = row[0]
                    Id1 = row[1]
                    link = row[3]
                    city = row[2]
                    # Id1 = row['_id']
                    # link = row['Link']
                    # city = row['city']
                    # yield scrapy.Request(client.scrapyGet(url=link), callback=self.parse,meta={'city':city,'Id1':Id1,'area_link':link,'Id':Id})
                    yield scrapy.Request(url=link, callback=self.parse,meta={'city':city,'Id1':Id1,'area_link':link,'Id':Id})
                except Exception as e:
                    print(str(e))
        except Exception as e:
            print(str(e))

    def parse(self, response):
        try:
            print(response.url)
            for page in range(1,3):
                post_json = []
                post_json = re.findall(r'window.__PRELOADED_STATE__ = JSON.parse\("(.*?)"\);',response.text)
                if post_json != []:
                    post_json1 = post_json[0].replace('\\"','"').replace('\\\\"','\\"')
                    post_json = json.loads(post_json1)
                    if page == 1:
                        file_name = f"{response.meta['Id1']}_{page}.json"
                        path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\json_area_page\\{file_name}"
                        file = open(path, 'w', encoding='utf-8')
                        file.write(post_json1)
                        file.close()
                        search_dict = post_json['pages']['search']
                        search_key = list(search_dict.keys())[0]
                        for count in search_dict[search_key]['sections']['SECTION_SEARCH_RESULT']:
                            link = ''
                            for key,value in count.items():
                                try:
                                    if key == 'type' and value == 'restaurant':
                                        link = count['order']['actionInfo']['clickUrl'].replace('/order', '')
                                        if link == '':
                                            link = count['cardAction']['clickUrl'].replace('/order', '')
                                        if 'https://www.zomato.com' not in link:
                                            link = 'https://www.zomato.com' + link
                                        item = ZomatoItem()
                                        item['Link'] = link
                                        item['city'] = response.meta['city']
                                        item['_id'] = int(hashlib.md5(bytes(link + response.meta['area_link'], "utf8")).hexdigest(), 16) % (10 ** 8)
                                        item['status'] = 'pending'
                                        self.final_links_city.insert(item)
                                        print("Data inserted....")
                                except Exception as e:
                                    print(str(e))
                    else:
                        data_json = []
                        while True:
                            url = 'https://www.zomato.com/webroutes/search/home'
                            headers = {
                                # 'authority': "www.zomato.com",
                                'accept': "*/*",
                                'accept-encoding': "gzip, deflate, br",
                                'accept-language': "en-US,en;q=0.9",
                                # 'content-length': "1462",
                                'content-type': "application/json",
                                'cookie': "PHPSESSID=ef278c29de24d708c1e34e40f13f14b4; fre=0; rd=1380000; zl=en; fbtrack=dcb320efc711a2350d04bdeefa706339; _gcl_au=1.1.1869607189.1629199877; _ga=GA1.2.609930535.1629199877; _fbp=fb.1.1629199877923.1620586338; expab=1; dpr=1; csrf=d31fe6697e1f7ec91b8354aea19bd650; _gid=GA1.2.1933171086.1630906734; fbcity=7; lty=subzone; ltv=6102; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A13.005603%2C%22lng%22%3A80.257316%2C%22cityId%22%3A7%2C%22ltv%22%3A6102%2C%22lty%22%3A%22subzone%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A3166%7D; _gat_global=1; _gat_city=1; _gat_country=1; AWSALBTG=tXE9aksZs7wDZugALZLDfUaoVJTtHyV8cOY1xi4xrtHJeGyQCHpxDpFDi1hqUW4le66K9gfpptfIQ2Exg8Hslbjmzo+K8C34XIxHjysOY4hf89o9pIKuntpTXZU9UbNJaoL7+GxVmBFOISgy0P2yuUwR+X/iX3DClejiP4w+cG8k; AWSALBTGCORS=tXE9aksZs7wDZugALZLDfUaoVJTtHyV8cOY1xi4xrtHJeGyQCHpxDpFDi1hqUW4le66K9gfpptfIQ2Exg8Hslbjmzo+K8C34XIxHjysOY4hf89o9pIKuntpTXZU9UbNJaoL7+GxVmBFOISgy0P2yuUwR+X/iX3DClejiP4w+cG8k",
                                'origin': "https://www.zomato.com",
                                'referer': "https://www.zomato.com/chennai/adyar-restaurants",
                                # 'sec-ch-ua': "\"Chromium\";v=\"92\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"92\"",
                                # 'sec-ch-ua-mobile': "?0",
                                # 'sec-fetch-dest': "empty",
                                # 'sec-fetch-mode': "cors",
                                # 'sec-fetch-site': "same-origin",
                                'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36",
                                'x-zomato-csrft': "d31fe6697e1f7ec91b8354aea19bd650",
                                # 'cache-control': "no-cache",
                                'postman-token': "b2750ec6-4fc9-9b84-98b7-26c17ff53b38"
                            }
                            if page == 2:
                                search_dict = post_json['pages']['search']
                                search_key = list(search_dict.keys())[0]
                                previousSearchParams = search_dict[search_key]['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['previousSearchParams']
                                PreviousSearchId = re.findall(r'"PreviousSearchId":"(.*?)","',previousSearchParams)[0]
                                postbackParams = search_dict[search_key]['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['postbackParams']
                                processed_chain_ids = re.findall(r'"processed_chain_ids":(.*?),"',postbackParams)[0]
                                shown_res_count = re.findall(r'shown_res_count":(.*?),"',postbackParams)[0]
                                search_id = re.findall(r'"search_id":"(.*?)"',postbackParams)[0]
                                totalResults = str(search_dict[search_key]['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['totalResults'])
                            else:
                                previousSearchParams = data_json['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['previousSearchParams']
                                PreviousSearchId = re.findall(r'"PreviousSearchId":"(.*?)","', previousSearchParams)[0]
                                postbackParams = data_json['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['postbackParams']
                                processed_chain_ids = re.findall(r'"processed_chain_ids":(.*?),"', postbackParams)[0]
                                shown_res_count = re.findall(r'shown_res_count":(.*?),"', postbackParams)[0]
                                search_id = re.findall(r'"search_id":"(.*?)"', postbackParams)[0]
                                totalResults = str(data_json['sections']['SECTION_SEARCH_META_INFO']['searchMetaData']['totalResults'])
                            addressId = str(post_json['location']['currentLocation']['addressId'])
                            entityId = str(post_json['location']['currentLocation']['entityId'])
                            entityType = post_json['location']['currentLocation']['entityType']
                            locationType = post_json['location']['currentLocation']['locationType']
                            isOrderLocation = str(post_json['location']['currentLocation']['isOrderLocation'])
                            cityId = str(post_json['location']['currentLocation']['cityId'])
                            latitude = post_json['location']['currentLocation']['latitude']
                            longitude = post_json['location']['currentLocation']['longitude']
                            userDefinedLatitude = str(post_json['location']['currentLocation']['userDefinedLatitude'])
                            userDefinedLongitude = str(post_json['location']['currentLocation']['userDefinedLongitude'])
                            entityName = post_json['location']['currentLocation']['entityName']
                            orderLocationName = post_json['location']['currentLocation']['orderLocationName']
                            cityName = post_json['location']['currentLocation']['cityName']
                            countryId = str(post_json['location']['currentLocation']['countryId'])
                            countryName = post_json['location']['currentLocation']['countryName']
                            displayTitle = post_json['location']['currentLocation']['displayTitle']
                            o2Serviceable = str(post_json['location']['currentLocation']['o2Serviceable']).lower()
                            placeId = post_json['location']['currentLocation']['placeId']
                            cellId = post_json['location']['currentLocation']['cellId']
                            deliverySubzoneId = str(post_json['location']['currentLocation']['deliverySubzoneId'])
                            placeType = post_json['location']['currentLocation']['placeType']
                            placeName = post_json['location']['currentLocation']['placeName']
                            isO2City = str(post_json['location']['currentLocation']['isO2City']).lower()
                            address_template = str(post_json['location']['currentLocation']['address_template'])
                            otherRestaurantsUrl = post_json['location']['currentLocation']['otherRestaurantsUrl']

                            payload1 = "{\"context\":\"delivery\",\"filters\":\"{\\\"searchMetadata\\\":{\\\"previousSearchParams\\\":\\\"{\\\\\\\"PreviousSearchId\\\\\\\":\\\\\\\""+PreviousSearchId+"\\\\\\\",\\\\\\\"PreviousSearchFilter\\\\\\\":[\\\\\\\"{\\\\\\\\\\\\\\\"category_context\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"delivery_home\\\\\\\\\\\\\\\"}\\\\\\\"]}\\\",\\\"postbackParams\\\":\\\"{\\\\\\\"processed_chain_ids\\\\\\\":"+processed_chain_ids+",\\\\\\\"shown_res_count\\\\\\\":"+shown_res_count+",\\\\\\\"search_id\\\\\\\":\\\\\\\""+search_id+"\\\\\\\"}\\\",\\\"totalResults\\\":"+totalResults+",\\\"hasMore\\\":true,\\\"getInactive\\\":false},\\\"dineoutAdsMetaData\\\":{},\\\"appliedFilter\\\":[{\\\"filterType\\\":\\\"category_sheet\\\",\\\"filterValue\\\":\\\"delivery_home\\\",\\\"isHidden\\\":true,\\\"isApplied\\\":true,\\\"postKey\\\":\\\"{\\\\\\\"category_context\\\\\\\":\\\\\\\"delivery_home\\\\\\\"}\\\"}],\\\"urlParamsForAds\\\":{}}\",\"addressId\":"+addressId+",\"entityId\":"+entityId+",\"entityType\":\""+entityType+"\",\"locationType\":\""+locationType+"\",\"isOrderLocation\":"+isOrderLocation+",\"cityId\":"+cityId+",\"latitude\":\""+latitude+"\",\"longitude\":\""+longitude+"\",\"userDefinedLatitude\":"+userDefinedLatitude+",\"userDefinedLongitude\":"+userDefinedLongitude+",\"entityName\":\""+entityName+"\",\"orderLocationName\":\""+orderLocationName+"\",\"cityName\":\""+cityName+"\",\"countryId\":"+countryId+",\"countryName\":\""+countryName+"\",\"displayTitle\":\""+displayTitle+"\",\"o2Serviceable\":"+o2Serviceable+",\"placeId\":\""+placeId+"\",\"cellId\":\""+cellId+"\",\"deliverySubzoneId\":"+deliverySubzoneId+",\"placeType\":\""+placeType+"\",\"placeName\":\""+placeName+"\",\"isO2City\":"+isO2City+",\"fetchFromGoogle\":false,\"fetchedFromCookie\":true,\"isO2OnlyCity\":false,\"address_template\":"+address_template+",\"otherRestaurantsUrl\":\""+otherRestaurantsUrl+"\"}"

                            # if not os.path.exists(path):
                            # response1 = requests.request("POST", client.scrapyGet(url=url), data=payload1, headers=headers)
                            response1 = requests.request("POST", url, data=payload1, headers=headers)
                            if response1.status_code == 200:
                                page += 1
                                # print(response1.text)

                                data_json = json.loads(response1.text)
                                file_name = f"{response.meta['Id1']}_{page}.json"
                                path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\json_area_page\\{file_name}"
                                file = open(path, 'w', encoding='utf-8')
                                file.write(response1.text)
                                file.close()
                                if data_json != []:
                                    try:
                                        if data_json['sections']['SECTION_SEARCH_RESULT'] != []:
                                            for count in data_json['sections']['SECTION_SEARCH_RESULT']:
                                                link = ''
                                                for key,value in count.items():
                                                    try:
                                                        if key == 'type' and value == 'restaurant':
                                                            link = count['order']['actionInfo']['clickUrl'].replace('/order', '')
                                                            if link == '':
                                                                link = count['cardAction']['clickUrl'].replace('/order', '')
                                                            if 'https://www.zomato.com' not in link:
                                                                link = 'https://www.zomato.com' + link
                                                            item = ZomatoItem()
                                                            item['Link'] = link
                                                            item['city'] = response.meta['city']
                                                            item['_id'] = int(hashlib.md5(bytes(link + response.meta['area_link'], "utf8")).hexdigest(), 16) % (10 ** 8)
                                                            item['status'] = 'pending'
                                                            self.final_links_city.insert(item)
                                                            print(f"Data inserted....{str(page)}_{str(response.meta['Id'])}")
                                                            print(f"page-----{page} and Id-----{response.meta['Id']}")
                                                    except Exception as e:
                                                        print(str(e))
                                                        print(f"page-----{page} and Id-----{response.meta['Id']}")
                                        else:
                                            print("STOP")
                                            break
                                    except Exception as e:
                                        print(str(e))
                            else:
                                print("start IP Vanish")
                                time.sleep(50)
                            # else:
                            #     print("Already exists")
                else:
                    print("STOP")
            self.Area_links.update({'Link': response.meta['area_link']}, {'$set': {'status': 'Done'}}, upsert=False)
            print("Mongodb Data updated....")
            sql_update_Query = f"update area_links set status='Done' where Id='{response.meta['Id']}'"
            self.cursor1.execute(sql_update_Query)
            self.con1.commit()
            print("SQL Data updated....")

        except Exception as e:
            print(str(e))


if __name__ == '__main__':

    execute('scrapy crawl links_post -a start=1 -a end=122'.split())

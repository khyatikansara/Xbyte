import hashlib
import os
import pymongo
import pymysql
import scrapy
import re
import requests
from scrapy.cmdline import execute
from zomato.items import ZomatoItem
import time
from scrapy.http import HtmlResponse
import json


class HoursUpdateSpider(scrapy.Spider):
    name = 'hours_update'
    allowed_domains = []
    start_urls = ['https://example.com']
    skip,end = 0,0

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        # self.final_links = self.db[f'final_links']
        # self.final_links_sitemap = self.db[f'final_links_sitemap']
        # self.final_links_city = self.db[f'final_links_city']
        # self.master_links = self.db[f'master_link_2021_07_28']
        self.data = self.db[f'zomato_final_data']
        # self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_restaurant_2021_09_04')
        # self.cursor1 = self.con1.cursor()

        self.folder_path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\data\\"
        if not os.path.exists(self.folder_path):
            os.makedirs(self.folder_path)

    def parse(self,response):
        # self.master_links.rename('master_link_2021_07_28', dropTarget=True)
        # self.data.update_many({}, {'$set': {'status': 'pending'}}, upsert=False)
        links = self.data.find({'status': "No"}, no_cursor_timeout=True)
        # links = self.data.find({'status': "pending"}, no_cursor_timeout=True).limit(100).skip(int(self.skip))
        print(self.data.find({'status': "No"}).count())
        # sql_select_Query = f"select * from final_master_link where `from`='area' and status='Done' and Id>'{self.start}' and Id<'{self.end}'"
        # self.cursor1.execute(sql_select_Query)
        # links = self.cursor1.fetchall()
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'en-US,en;q=0.9',
            'cookie': 'PHPSESSID=ccb09cd740dd2941761b341026261f41; csrf=84aa930174eb5dc89d13a659ebbda3aa; fre=0; rd=1380000; zl=en; fbtrack=424b9eb9c2a5ffdadebbb57f36b565ea; lty=city; _gcl_au=1.1.879432484.1631253014; _ga=GA1.2.1443451914.1631253014; _gid=GA1.2.1662109567.1631253014; _fbp=fb.1.1631253015775.915546525; fbcity=1; ltv=1; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A28.625789%2C%22lng%22%3A77.210276%2C%22cityId%22%3A1%2C%22ltv%22%3A1%2C%22lty%22%3A%22city%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A514%2C%22fen%22%3A%22Ywca%2C+1%2C+Ashoka+Rd%2C+Hanuman+Road+Area%2C+Connaught+Place%2C+New+Delhi%2C+Delhi%22%7D; _gat_global=1; _gat_city=1; _gat_country=1; AWSALBTG=VBjNyveAax+HahlsUEyq5KcT9apT5neXbulC9/iq5WUuDH8kkfrVfN2qAz0jM8GxbMfcCBZOhML12HTbe/4WyWk3ZISGz2c6s0VV8/gwYtuvZi+p/+WN+QO/0kfCJ2MRyi6bK7n+K0AYL7/HFk1HypSZAnpEeRjOENDxiz9IFftX; AWSALBTGCORS=VBjNyveAax+HahlsUEyq5KcT9apT5neXbulC9/iq5WUuDH8kkfrVfN2qAz0jM8GxbMfcCBZOhML12HTbe/4WyWk3ZISGz2c6s0VV8/gwYtuvZi+p/+WN+QO/0kfCJ2MRyi6bK7n+K0AYL7/HFk1HypSZAnpEeRjOENDxiz9IFftX',
            'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
            'sec-ch-ua-mobile': '?0',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36',
            'Content-Type': 'text/plain'
        }
        for row in links:
            print(self.data.find({'status': "No"}).count())
            try:
                Opening_Hours_list1 = []
                URL = row['URL']
                try:
                    opening_hours = row['Opening_Hours']
                except:
                    url1 = URL.replace('https://www.zomato.com', '')
                    # if opening_hours != 'Permanently Closed' and opening_hours != 'Temporarily closed, will be back soon!' and opening_hours != 'Opening hours not available' and opening_hours != 'Temporarily closed for renovations, will be back soon!':
                    # print(opening_hours)
                    url = f"https://www.zomato.com/webroutes/getPage?page_url={url1}&location=&isMobile=0"
                    while True:
                        res = requests.get(url=url, headers=headers)
                        if res.status_code == 200:
                            break
                        else:
                            print(res.status_code)
                            time.sleep(5)
                    response_o = HtmlResponse(url=res.url, body=res.content)
                    data_json = json.loads(response_o.text)

                # opening_hours = row['Opening_Hours']
                # if opening_hours != 'Permanently Closed' and opening_hours != 'Temporarily closed, will be back soon!' and opening_hours != 'Opening hours not available' and opening_hours != 'Temporarily closed for renovations, will be back soon!':
                #     while True:
                #         res1 = requests.get(url=URL,headers=headers)
                #         if res1.status_code == 200:
                #             break
                #         else:
                #             print(res1.status_code)
                #             time.sleep(5)
                #     response1 = HtmlResponse(url=res1.url, body=res1.content)
                #     res_id = re.findall(r'\\"resId\\":(.*?),', response1.text)[0]
                #     file_name = res_id + '.json'
                #     path = self.folder_path + file_name
                #     if os.path.exists(path):
                #         file = open(path, 'r', encoding='utf-8')
                #         response_o = file.read()
                #         file.close()
                #         data_json = json.loads(response_o)
                #     else:
                #         # if URL == 'https://www.zomato.com/chennai/sweet-guilt-nandanam':
                #         url1 = URL.replace('https://www.zomato.com', '')
                #         # if opening_hours != 'Permanently Closed' and opening_hours != 'Temporarily closed, will be back soon!' and opening_hours != 'Opening hours not available' and opening_hours != 'Temporarily closed for renovations, will be back soon!':
                #         # print(opening_hours)
                #         url = f"https://www.zomato.com/webroutes/getPage?page_url={url1}&location=&isMobile=0"
                #         while True:
                #             res = requests.get(url=url, headers=headers)
                #             # ---------with crawlera-----------
                #             # res = requests.get(url=url, headers=headers, proxies={"https": f"https://{self.crawlera_key}:@scrapingproxy.crawlera.com:8011/"},verify="D:\zyte-proxy-ca.crt")
                #             if res.status_code == 200:
                #                 break
                #             else:
                #                 print(res.status_code)
                #                 time.sleep(5)
                #         response_o = HtmlResponse(url=res.url, body=res.content)
                #         data_json = json.loads(response_o.text)
                try:
                    # data_json = json.loads(response_o.text)
                    if data_json['page_info']['name'] != '404':
                        try:
                            Opening_Hours_list = data_json['page_data']['sections']['SECTION_BASIC_INFO']['timing']['customised_timings']
                            Opening_Hours = data_json['page_data']['sections']['SECTION_BASIC_INFO']['res_status_text']
                            if Opening_Hours == 'Permanently Closed' or Opening_Hours == 'Temporarily closed, will be back soon!':
                                self.data.update({'URL': URL}, {'$set': {'Opening_Hours': Opening_Hours}}, upsert=False)
                                self.data.update({'URL': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                                print("Mongodb Data updated....")
                            elif Opening_Hours_list == [] or Opening_Hours_list['disclaimer'] == '                                ':
                                Opening_Hours = data_json['page_data']['sections']['SECTION_BASIC_INFO']['res_status_text']
                                self.data.update({'URL': URL}, {'$set': {'Opening_Hours': Opening_Hours}}, upsert=False)
                                self.data.update({'URL': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                                print("Mongodb Data updated....")
                            else:
                                Opening_Hours1 = data_json['page_data']['sections']['SECTION_BASIC_INFO']['timing']['customised_timings']['opening_hours']
                                if len(Opening_Hours1) == 1:
                                    self.data.update({'URL': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                                    print("Mongodb Data updated....")
                                else:
                                    for i in Opening_Hours1:
                                        days = i['days']
                                        timing = i['timing']
                                        if timing == '':
                                            timing = 'Closed'
                                        Opening_Hours_tmp = f"{days} : {timing}"
                                        Opening_Hours_list1.append(Opening_Hours_tmp)
                                        Opening_Hours = ','.join(Opening_Hours_list1)
                                        self.data.update({'URL': URL}, {'$set': {'Opening_Hours': Opening_Hours}}, upsert=False)
                                        # print("Mongodb Data updated....")
                                        self.data.update({'URL': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                                        print("Mongodb Data updated....")
                        except Exception as e:
                            print("Opening_Hours" + str(e))
                            Opening_Hours = ''
                except Exception as e:
                    print(str(e))
                # else:
                #     self.data.update({'URL': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                #     print("Mongodb Data updated....")
            except Exception as e:
                print(e)
                URL = row['URL']
                self.data.update({'URL': URL}, {'$set': {'status': 'No'}}, upsert=False)
                print("Mongodb Data updated....")


if __name__ == '__main__':

    # execute("scrapy crawl hours_update -a skip=100".split())
    execute("scrapy crawl hours_update".split())
import hashlib
import json
from os import listdir
from os.path import isfile, join
import pandas as pd
import pymongo
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class FinalLinkSitemapSpider(scrapy.Spider):
    name = 'final_link_sitemap'
    allowed_domains = []
    start_urls = ['https://example.com']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        # self.final_links = self.db[f'final_links']
        # self.Area_links = self.db[f'Area_links']
        self.final_links_sitemap = self.db[f'final_links_sitemap']
        self.Link_sitemap = self.db[f'Link_sitemap']


    def parse(self,response):
        # self.Area_sitemaplinks.update_many({}, {'$set': {'status': 'pending'}}, upsert=False)
        links = self.Link_sitemap.find({'status': "pending"}, no_cursor_timeout=True)
        print(self.Link_sitemap.find({'status': "pending"}).count())
        for row in links:
            try:
                Id = row['_id']
                link = row['Link']
                city = row['city']
                yield scrapy.Request(url=link, callback=self.parse_link, dont_filter=True, meta={'city':city,'Id':Id})
            except Exception as e:
                print(e)

    def parse_link(self,response):
        try:
            city = response.meta['city']
            Id = response.meta['Id']
            links1 = response.xpath('//div[@class="col-m-8 pbot"]//div[@class="plr10"]/a[1]/@href').extract()
            for link in links1:
                if link != f"https://www.zomato.com/{city}/restaurants":
                    if 'https://www.zomato.com' not in link:
                        link = 'https://www.zomato.com'+link
                    try:
                        item = ZomatoItem()
                        # Link2 = link.replace('/order','')
                        item['Link'] = link
                        item['city'] = city
                        item['_id'] = int(hashlib.md5(bytes(link, "utf8")).hexdigest(), 16) % (10 ** 8)
                        item['status'] = 'pending'
                        self.final_links_sitemap.insert(item)
                        print("Data inserted....")
                    except Exception as e:
                        print(e)
            try:
                self.Link_sitemap.update({'_id': Id}, {'$set': {'status': 'Done'}}, upsert=False)
                print("update done")
            except Exception as e:
                print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':

    execute("scrapy crawl final_link_sitemap".split())
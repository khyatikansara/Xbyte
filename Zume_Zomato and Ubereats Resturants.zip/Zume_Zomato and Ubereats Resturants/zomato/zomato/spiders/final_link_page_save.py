# -*- coding: utf-8 -*-
import os
import pymongo
import scrapy


class FinalPageSaveSpider(scrapy.Spider):
    name = 'final_page_save'
    start_urls = ['https://www.example.com/']
    city = ''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_food_menu']
        self.final_links = self.db[f'final_links']
        self.final_links_city = self.db[f'final_links_city']
        self.final_links_sitemap = self.db[f'final_links_sitemap']

    def parse(self, response):
        links = self.final_links_sitemap.find({'status': "pending"}, no_cursor_timeout=True)
        print(self.final_links_sitemap.find({'status': "pending"}).count())
        for row in links:
            try:
                Id = row['_id']
                link = row['Link']
                city = row['city']
                folder_path = f"D:\khyati-H\Project_Henna_mem\Vipani Technologies LLP - Restaurant & Food Menu Data from Zomato (monthly basis)\HTML\\final_link_sitemap\\{city}\\"
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
                yield scrapy.Request(url=link, callback=self.get_data, dont_filter=True, meta={'Id': Id,'folder_path':folder_path})
            except Exception as e:
                print(e)

    def get_data(self, response):
        folder_path = response.meta['folder_path']
        Id = response.meta['Id']
        path = f"{folder_path}{Id}.html"
        file = open(path, 'wb')
        file.write(response.body)
        file.close()
        print("page save done")
        try:
            self.final_links_sitemap.update({'_id': Id}, {'$set': {'path': path}}, upsert=False)
            self.final_links_sitemap.update({'_id': Id}, {'$set': {'status': 'page_done'}}, upsert=False)
            print("update done")
        except Exception as e:
            print(e)


if __name__ == '__main__':

    from scrapy.cmdline import execute
    execute('scrapy crawl final_page_save'.split())

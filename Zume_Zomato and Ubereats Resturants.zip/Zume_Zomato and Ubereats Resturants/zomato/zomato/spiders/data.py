import hashlib
import os
import pymongo
import pymysql
import scrapy
import re
from scrapy.cmdline import execute
from zomato.items import ZomatoItem


class DataSpider(scrapy.Spider):
    name = 'data'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = 0,0

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        # self.final_links = self.db[f'final_links']
        self.final_links_sitemap = self.db[f'final_links_sitemap']
        # self.final_links_city = self.db[f'final_links_city']
        # self.master_links = self.db[f'master_link_2021_07_28']
        self.data = self.db[f'data_2021_09_07']
        self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_restaurant_2021_09_04')
        self.cursor1 = self.con1.cursor()

        self.folder_path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\data\\"
        if not os.path.exists(self.folder_path):
            os.makedirs(self.folder_path)

    def parse(self,response):
        # self.master_links.rename('master_link_2021_07_28', dropTarget=True)
        # self.master_links.update_many({}, {'$set': {'status': 'pending'}}, upsert=False)
        # links = self.master_links.find({'status': "pending"}, no_cursor_timeout=True)
        # print(self.master_links.find({'status': "pending"}).count())
        sql_select_Query = f"select * from final_master_link where `from`='area' and status='Done' and Id>'{self.start}' and Id<'{self.end}'"
        self.cursor1.execute(sql_select_Query)
        links = self.cursor1.fetchall()
        for row in links:
            try:
                # URL = row['Link']
                URL = row[1]
                yield scrapy.Request(url=URL, callback=self.get_data, dont_filter=True, meta={'URL': URL})
            except Exception as e:
                print(e)

    def get_data(self, response):
        if response.url == 'https://www.zomato.com/ncr/delhi-walon-ki-mashoor-rasoi-1-vaishali-ghaziabad':
            print("STOP")
        flag = False
        URL = response.meta['URL']
        if '{\\"name\\":\\"404\\",' not in response.text:
            try:
                res_id = re.findall(r'\\"resId\\":(.*?),',response.text)[0]
                file_name = res_id+'.html'
                path = self.folder_path+file_name
                file = open(path, 'wb')
                file.write(response.body)
                file.close()
                print("page save done")
                self.final_links_sitemap.update({'Link': URL}, {'$set': {'path': path}}, upsert=False)
                print("update done")


                try:
                    Restaurant_Name = response.xpath('//h1/text()').extract()[0]
                except Exception as e:
                    print("Restaurant_Name"+str(e))
                    Restaurant_Name = ''

                if Restaurant_Name != '':
                    try:
                        Address = re.findall(r'"streetAddress":"(.*?)","',response.text)[0]
                    except Exception as e:
                        print("Address"+str(e))
                        Address = ''

                    try:
                        Phone_No_list = re.findall(r'"telephone":"(.*?)","',response.text)
                        if len(Phone_No_list) == 1:
                            Phone_No = Phone_No_list[0].replace('+','')
                        else:
                            Phone_No = ' | '.join(Phone_No_list).replace('+','')
                    except Exception as e:
                        print("Phone_No"+str(e))
                        Phone_No = ''

                    try:
                        Dining_Star_Rating_text = re.findall(r'\{\\"rating_type\\":\\"DINING\\",(.*?)\\"color\\":\\"',response.text)[0]
                        Dining_Star_Rating = re.findall(r'rating\\":\\"(.*?)\\",\\"',Dining_Star_Rating_text)[0]
                        Dining_Reviews = re.findall(r'reviewCount\\":\\"(.*?)\\",\\"',Dining_Star_Rating_text)[0]
                    except Exception as e:
                        print("Dining_Star_Rating"+str(e))
                        Dining_Star_Rating = Dining_Reviews = ''

                    try:
                        Delivery_Star_Rating_text = re.findall(r'\{\\"rating_type\\":\\"DELIVERY\\",(.*?)\\"color\\":\\"',response.text)[0]
                        Delivery_Star_Rating = re.findall(r'rating\\":\\"(.*?)\\",\\"',Delivery_Star_Rating_text)[0]
                        Delivery_Reviews = re.findall(r'reviewCount\\":\\"(.*?)\\",\\"',Delivery_Star_Rating_text)[0]
                    except Exception as e:
                        print("Customer_star_rating_for_delivery"+str(e))
                        Delivery_Star_Rating = Delivery_Reviews = ''

                    try:
                        Cuisine = ' | '.join(response.xpath('//*[contains(text(),"Cuisines")]/../section/a/text()').extract())
                    except Exception as e:
                        print("Cuisine"+str(e))
                        Cuisine = ''

                    try:
                        if response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()'):
                            More_Info = ', '.join(response.xpath('//*[contains(text(),"More Info")]/following-sibling::div/div/i[@color="#119199"]/../p/text()').extract())
                        else:
                            More_Info = ''
                    except Exception as e:
                        print("More_Info"+str(e))
                        More_Info = ''

                    try:
                        Average_Cost_per_two_without_alcohol = re.findall(r'"priceRange":"(.*?)","',response.text)[0]
                    except Exception as e:
                        print("Average_Cost_per_two_without_alcohol"+str(e))
                        Average_Cost_per_two_without_alcohol = ''

                    try:
                        Average_Cost_per_two_with_alcohol = re.findall(r'\\"cfts\\":(.*?),\{\\"title\\":\\"(.*?)for a pint of beer',response.text)[0][1].strip()
                    except Exception as e:
                        print("Average_Cost_per_two_with_alcohol"+str(e))
                        Average_Cost_per_two_with_alcohol = ''

                    try:
                        if response.xpath('//span[contains(text(),"Open now")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Open now")]/../span/text()').extract())
                        elif response.xpath('//span[contains(text(),"Close")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Close")]/../span/text()').extract())
                        elif response.xpath('//span[contains(text(),"Temporarily closed")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Temporarily closed")]/../span/text()').extract())
                        elif response.xpath('//span[contains(text(),"Opening to the public soon")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Opening to the public soon")]/../span/text()').extract())
                        elif response.xpath('//span[contains(text(),"Opening hours not available")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Opening hours not available")]/../span/text()').extract())
                        elif response.xpath('''//p[contains(text(),"We can't seem to find the page you're looking for...")]'''):
                            Opening_Hours = ''
                        elif response.xpath('//span[contains(text(),"Opens in")]/../span/text()'):
                            Opening_Hours = ' - '.join(response.xpath('//span[contains(text(),"Opens in")]/../span/text()').extract())
                        else:
                            Opening_Hours = ''
                    except Exception as e:
                        print("Opening_Hours"+str(e))
                        Opening_Hours = ''

                    try:
                        if Opening_Hours != 'Permanently Closed':
                            if Opening_Hours != 'Opening hours not available':
                                "Mon-Sun : 10am – 11pm"
                                Opening_Hours1 = re.findall(r'\{\\"opening_hours\\":\[\{\\"timing\\":\\"(.*?),\\"happy_hours\\"',response.text)
                                if len(Opening_Hours1) != 0:
                                    Opening_Hours1 = Opening_Hours1[0].replace('\\n',',')
                                else:
                                    Opening_Hours1 = re.findall(r'\{\\"opening_hours\\":\[\{\\"timing\\":\\"(.*?)}]}},', response.text)
                                    if len(Opening_Hours1) == 0:
                                        Opening_Hours1 = re.findall(r'\\"opening_hours\\":\[\{\\"timing\\":\\"(.*?)}]}},', response.text)
                                        if len(Opening_Hours1) != 0:
                                            Opening_Hours1 = Opening_Hours1[0]
                                    else:
                                        Opening_Hours1 = Opening_Hours1[0]

                                days = re.findall(r'"days\\":\\"(.*?)\\"',Opening_Hours1)
                                if len(days) == 1:
                                    days = days[0]
                                    timing = re.findall(r'(.*?)\\",\\"days\\',Opening_Hours1)[0]
                                    if timing == '':
                                        timing = 'Closed'
                                else:
                                    timing = re.findall(r'(.*?)\\",\\"days\\":\\"(.*?)\\"},\{\\"timing\\":\\"(.*?)\\",\\"days\\":\\"(.*?)\\"', Opening_Hours1)
                                    if timing[0][0] == '':
                                        Opening_Hours = f"{timing[0][1]},{timing[0][3]} : 'Closed',{timing[0][2]}"
                                    else:
                                        Opening_Hours = f"{timing[0][1]},{timing[0][3]} : {timing[0][0]},{timing[0][2]}"
                                # Opening_Hours = f"{days}.{timing[0][3]} : {timing}"
                            else:
                                Opening_Hours = Opening_Hours
                        else:
                            Opening_Hours = Opening_Hours
                    except Exception as e:
                        print("Opening_Hours"+str(e))
                        Opening_Hours = ''

                    try:
                        Payment = re.findall(r'"paymentAccepted":"(.*?)","',response.text)[0].replace('\\n',',')
                    except Exception as e:
                        print("Payment"+str(e))
                        Payment = ''

                    try:
                        item = ZomatoItem()
                        unique_key = str(res_id) + str(Restaurant_Name) + str(URL)
                        Hash_id = str(int(hashlib.md5(bytes(unique_key, encoding='utf8')).hexdigest(), 16) % (10 ** 30))
                        item['_id'] = Hash_id
                        item['URL'] = URL
                        item['Restaurant_Name'] = Restaurant_Name
                        item['Cuisine'] = Cuisine
                        item['Address'] = Address
                        item['Phone_No'] = Phone_No
                        item['Average_Cost_per_two_without_alcohol'] = Average_Cost_per_two_without_alcohol
                        item['Average_Cost_per_two_with_alcohol'] = Average_Cost_per_two_with_alcohol
                        item['Opening_Hours'] = Opening_Hours
                        item['Payment'] = Payment
                        item['More_Info'] = More_Info
                        item['Dining_Reviews'] = Dining_Reviews
                        item['Dining_Star_Rating'] = Dining_Star_Rating
                        item['Delivery_Reviews'] = Delivery_Reviews
                        item['Delivery_Star_Rating'] = Delivery_Star_Rating
                        self.data.insert(item)
                        print("Data inserted....")
                        flag = True
                    except Exception as e:
                        flag = True
                        print("item2"+str(e))

                if flag == True:
                    try:
                        # self.final_links_sitemap.update({'Link': URL}, {'$set': {'status': 'Done'}}, upsert=False)
                        # print("Mongodb Data updated....")
                        sql_update_Query = f"update final_master_link set status='Done' where Link='{URL}'"
                        self.cursor1.execute(sql_update_Query)
                        self.con1.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)
        else:
            try:
                # self.final_links_sitemap.update({'Link': URL}, {'$set': {'status': '404_1'}}, upsert=False)
                # print("Mongodb Data updated....")
                sql_update_Query = f"update final_master_link set status='404_1' where Link='{URL}'"
                self.cursor1.execute(sql_update_Query)
                self.con1.commit()
                print("update done")
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute("scrapy crawl data -a start=91659 -a end=91661".split())
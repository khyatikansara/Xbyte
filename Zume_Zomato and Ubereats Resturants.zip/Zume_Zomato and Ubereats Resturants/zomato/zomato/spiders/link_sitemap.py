# -*- coding: utf-8 -*-
import hashlib
import json
from scrapy.cmdline import execute
import scrapy
from zomato.items import ZomatoItem
from zomato.mongoexport import export
import pymongo


class LinkSitemapSpider(scrapy.Spider):
    name = 'links_sitemap'
    allowed_domains = []
    start_urls = ['https://www.zomato.com/directory']

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        self.Link_sitemap = self.db[f'Link_sitemap']

    def start_requests(self):
        try:
            main_urls = {'Delhi NCR':'https://www.zomato.com/ncr/directory','Mumbai':'https://www.zomato.com/mumbai/directory','Bangalore':'https://www.zomato.com/bangalore/directory',
                         'Chennai':'https://www.zomato.com/chennai/directory'}

            for city,main_url in main_urls.items():
                yield scrapy.Request(url=main_url, callback=self.parse, dont_filter=True,meta={'city':city})
        except Exception as e:
            print(str(e))

    def parse(self, response):
        # if response.xpath('//*[@class="city-name"]/../../../div//a'):
        area_links = response.xpath('//a[contains(@href,"restaurants-")]/@href').extract()
        for area_link in area_links:
            #     item = ZomatoMenuItem()
            #     item['city'] = area_link.split('/')[-2]
            #     item['Link'] = area_link
            #     item['_id'] = int(hashlib.md5(bytes(area_link, "utf8")).hexdigest(), 16) % (10 ** 8)
            #     item['status'] = 'pending'
            #     try:
            #         self.Area_links.insert(item)
            #         print("Data inserted....")
            #     except Exception as e:
            #         print(e)
            item = ZomatoItem()
            item['city'] = response.meta['city']
            item['Link'] = area_link
            item['_id'] = int(hashlib.md5(bytes(area_link, "utf8")).hexdigest(), 16) % (10 ** 8)
            item['status'] = 'pending'
            try:
                self.Link_sitemap.insert(item)
                print("Data inserted....")
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute('scrapy crawl links_sitemap'.split())

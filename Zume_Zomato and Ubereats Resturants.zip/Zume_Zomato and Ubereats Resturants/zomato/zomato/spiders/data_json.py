import hashlib
import json
import os
import pymongo
import pymysql
import requests
import scrapy
import re
import time
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse

from zomato.items import ZomatoItem


class DataJsonSpider(scrapy.Spider):
    name = 'data_json'
    allowed_domains = []
    start_urls = ['https://example.com']
    start,end = 0,0

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        # self.final_links = self.db[f'final_links']
        self.final_links_sitemap = self.db[f'final_links_sitemap']
        # self.final_links_city = self.db[f'final_links_city']
        # self.master_links = self.db[f'master_link_2021_07_28']
        self.data = self.db[f'data_2021_09_09']
        self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_restaurant_2021_09_04')
        self.cursor1 = self.con1.cursor()
        self.crawlera_key = '1e54d2378d2a49e3a199083741f8b389'

        self.folder_path = f"F:\khyati\Project_Henna_mem\Zume_Zomato and Ubereats Resturants\HTML_2021_09_04\data\\"
        if not os.path.exists(self.folder_path):
            os.makedirs(self.folder_path)

    def parse(self,response):
        # self.master_links.rename('master_link_2021_07_28', dropTarget=True)
        # self.final_links_sitemap.update_many({}, {'$set': {'status': 'pending'}}, upsert=False)
        # links = self.master_links.find({'status': "pending"}, no_cursor_timeout=True)
        # print(self.master_links.find({'status': "pending"}).count())
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'en-US,en;q=0.9',
            'cookie': 'PHPSESSID=ccb09cd740dd2941761b341026261f41; csrf=84aa930174eb5dc89d13a659ebbda3aa; fre=0; rd=1380000; zl=en; fbtrack=424b9eb9c2a5ffdadebbb57f36b565ea; lty=city; _gcl_au=1.1.879432484.1631253014; _ga=GA1.2.1443451914.1631253014; _gid=GA1.2.1662109567.1631253014; _fbp=fb.1.1631253015775.915546525; fbcity=1; ltv=1; locus=%7B%22addressId%22%3A0%2C%22lat%22%3A28.625789%2C%22lng%22%3A77.210276%2C%22cityId%22%3A1%2C%22ltv%22%3A1%2C%22lty%22%3A%22city%22%2C%22fetchFromGoogle%22%3Afalse%2C%22dszId%22%3A514%2C%22fen%22%3A%22Ywca%2C+1%2C+Ashoka+Rd%2C+Hanuman+Road+Area%2C+Connaught+Place%2C+New+Delhi%2C+Delhi%22%7D; _gat_global=1; _gat_city=1; _gat_country=1; AWSALBTG=VBjNyveAax+HahlsUEyq5KcT9apT5neXbulC9/iq5WUuDH8kkfrVfN2qAz0jM8GxbMfcCBZOhML12HTbe/4WyWk3ZISGz2c6s0VV8/gwYtuvZi+p/+WN+QO/0kfCJ2MRyi6bK7n+K0AYL7/HFk1HypSZAnpEeRjOENDxiz9IFftX; AWSALBTGCORS=VBjNyveAax+HahlsUEyq5KcT9apT5neXbulC9/iq5WUuDH8kkfrVfN2qAz0jM8GxbMfcCBZOhML12HTbe/4WyWk3ZISGz2c6s0VV8/gwYtuvZi+p/+WN+QO/0kfCJ2MRyi6bK7n+K0AYL7/HFk1HypSZAnpEeRjOENDxiz9IFftX',
            'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
            'sec-ch-ua-mobile': '?0',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36',
            'Content-Type': 'text/plain'
        }

        sql_select_Query = f"select * from final_master_link where `from`='area' and status='pending' and Id>'{self.start}' and Id<'{self.end}'"
        self.cursor1.execute(sql_select_Query)
        links = self.cursor1.fetchall()
        for row in links:
            flag = False
            try:
                # URL = row['Link']
                Source_url = row[1]
                url1 = Source_url.replace('https://www.zomato.com','')
                url = f"https://www.zomato.com/webroutes/getPage?page_url={url1}&location=&isMobile=0"
                while True:
                    res = requests.get(url=url, headers=headers)
                    #---------with crawlera-----------
                    # res = requests.get(url=url, headers=headers, proxies={"https": f"https://{self.crawlera_key}:@scrapingproxy.crawlera.com:8011/"},verify="D:\zyte-proxy-ca.crt")
                    if res.status_code == 200:
                        break
                    else:
                        print(res.status_code)
                        time.sleep(5)
                response_o = HtmlResponse(url=res.url, body=res.content)
                data_json = json.loads(response_o.text)
                if data_json['page_info']['name'] != '404':
                    res_id = data_json['page_data']['sections']['SECTION_BASIC_INFO']['res_id']
                    file_name = str(res_id) + '.json'
                    path = self.folder_path + file_name
                    file = open(path, 'wb')
                    file.write(response_o.body)
                    file.close()
                    print("page save done")
                    try:
                        Restaurant_Name = data_json['page_data']['sections']['SECTION_BASIC_INFO']['name']
                    except Exception as e:
                        print("Restaurant_Name"+str(e))
                        Restaurant_Name = ''

                    if Restaurant_Name != '':
                        try:
                            Address = data_json['page_data']['sections']['SECTION_RES_CONTACT']['address']
                        except Exception as e:
                            print("Address"+str(e))
                            Address = ''

                        try:
                            Phone_No = data_json['page_data']['sections']['SECTION_RES_CONTACT']['phoneDetails']['phoneStr'].replace('+','')
                        except Exception as e:
                            print("Phone_No" + str(e))
                            Phone_No = ''

                        try:
                            Dining_Star_Rating = data_json['page_data']['sections']['SECTION_BASIC_INFO']['rating_new']['ratings']['DINING']['rating']
                            Dining_Reviews = data_json['page_data']['sections']['SECTION_BASIC_INFO']['rating_new']['ratings']['DINING']['reviewCount']
                        except Exception as e:
                            print("Dining_Star_Rating" + str(e))
                            Dining_Star_Rating = Dining_Reviews = ''

                        try:
                            Delivery_Star_Rating = data_json['page_data']['sections']['SECTION_BASIC_INFO']['rating_new']['ratings']['DELIVERY']['rating']
                            Delivery_Reviews = data_json['page_data']['sections']['SECTION_BASIC_INFO']['rating_new']['ratings']['DELIVERY']['reviewCount']
                        except Exception as e:
                            print("Customer_star_rating_for_delivery" + str(e))
                            Delivery_Star_Rating = Delivery_Reviews = ''

                        try:
                            Cuisine = data_json['page_data']['sections']['SECTION_BASIC_INFO']['cuisine_string']
                        except Exception as e:
                            print("Cuisine" + str(e))
                            Cuisine = ''

                        try:
                            More_Info = ''
                            More_Info_list = []
                            for more_info in data_json['page_data']['sections']['SECTION_RES_DETAILS']['HIGHLIGHTS']['highlights']:
                                if more_info['type'] == 'AVAILABLE':
                                    More_Info_list.append(more_info['text'])
                            More_Info = ', '.join(More_Info_list)
                        except Exception as e:
                            print("More_Info" + str(e))
                            More_Info = ''

                        try:
                            Average_Cost_per_two_without_alcohol = data_json['page_data']['sections']['SECTION_RES_DETAILS']['CFT_DETAILS']['cfts'][0]['title']
                        except Exception as e:
                            print("Average_Cost_per_two_without_alcohol" + str(e))
                            Average_Cost_per_two_without_alcohol = ''

                        try:
                            Average_Cost_per_two_with_alcohol = data_json['page_data']['sections']['SECTION_RES_DETAILS']['CFT_DETAILS']['cfts'][1]['title']
                        except Exception as e:
                            print("Average_Cost_per_two_with_alcohol" + str(e))
                            Average_Cost_per_two_with_alcohol = ''

                        try:
                            Opening_Hours_list = data_json['page_data']['sections']['SECTION_BASIC_INFO']['timing']['customised_timings']
                            if Opening_Hours_list == []:
                                Opening_Hours = data_json['page_data']['sections']['SECTION_BASIC_INFO']['res_status_text']
                            else:
                                Opening_Hours1 = data_json['page_data']['sections']['SECTION_BASIC_INFO']['timing']['customised_timings']['opening_hours']
                                days = Opening_Hours1[0]['days']
                                timing = Opening_Hours1[0]['timing']
                                Opening_Hours = f"{days} : {timing}"
                        except Exception as e:
                            print("Opening_Hours" + str(e))
                            Opening_Hours = ''

                        try:
                            Payment = data_json['page_data']['sections']['SECTION_RES_DETAILS']['CFT_DETAILS']['accepted_payments'].replace('\n',',')
                        except Exception as e:
                            print("Payment" + str(e))
                            Payment = ''

                        try:
                            item = ZomatoItem()
                            unique_key = str(res_id) + str(Restaurant_Name) + str(Source_url)
                            Hash_id = str(int(hashlib.md5(bytes(unique_key, encoding='utf8')).hexdigest(), 16) % (10 ** 30))
                            item['_id'] = Hash_id
                            item['URL'] = Source_url
                            item['Restaurant_Name'] = Restaurant_Name
                            item['Cuisine'] = Cuisine
                            item['Address'] = Address
                            item['Phone_No'] = Phone_No
                            item['Average_Cost_per_two_without_alcohol'] = Average_Cost_per_two_without_alcohol
                            item['Average_Cost_per_two_with_alcohol'] = Average_Cost_per_two_with_alcohol
                            item['Opening_Hours'] = Opening_Hours
                            item['Payment'] = Payment
                            item['More_Info'] = More_Info
                            item['Dining_Reviews'] = Dining_Reviews
                            item['Dining_Star_Rating'] = Dining_Star_Rating
                            item['Delivery_Reviews'] = Delivery_Reviews
                            item['Delivery_Star_Rating'] = Delivery_Star_Rating
                            self.data.insert(item)
                            print("Data inserted....")
                            flag = True
                        except Exception as e:
                            print("item2" + str(e))

                        if flag == True:
                            try:
                                # self.final_links_sitemap.update({'Link': Source_url}, {'$set': {'status': 'Done'}}, upsert=False)
                                # print("Mongodb Data updated....")
                                sql_update_Query = f"update final_master_link set status='Done' where Link='{Source_url}'"
                                self.cursor1.execute(sql_update_Query)
                                self.con1.commit()
                                print("update done")
                            except Exception as e:
                                print(e)
                else:
                    try:
                        # self.final_links_sitemap.update({'Link': Source_url}, {'$set': {'status': '404'}}, upsert=False)
                        # print("Mongodb Data updated....")
                        sql_update_Query = f"update final_master_link set status='404' where Link='{Source_url}'"
                        self.cursor1.execute(sql_update_Query)
                        self.con1.commit()
                        print("update done")
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute("scrapy crawl data_json -a start=1 -a end=102563".split())
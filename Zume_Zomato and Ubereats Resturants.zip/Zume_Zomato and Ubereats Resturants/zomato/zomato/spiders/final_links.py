import hashlib
import json
from os import listdir
from os.path import isfile, join
import pandas as pd
import pymongo
import pymysql
import scrapy
import re
from lxml import html
import requests
from scrapy.cmdline import execute
from unidecode import unidecode
from zomato.items import ZomatoItem
from datetime import datetime
import geopy
from scrapy.http import HtmlResponse


class FinalLinkSpider(scrapy.Spider):
    name = 'final_link'
    allowed_domains = []
    start_urls = ['https://example.com']
    start = ''
    end = ''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.con = pymongo.MongoClient('mongodb://localhost:27017/')
        self.db = self.con['zomato_restaurant_2021_09_04']
        self.final_links = self.db[f'final_links']
        self.Area_links = self.db[f'Area_links']
        self.final_links_city = self.db[f'final_links_city']
        self.con1 = pymysql.connect('localhost', 'root', 'xbyte', 'zomato_menu')
        self.cursor1 = self.con1.cursor()

    def parse(self,response):
        sql_select_Query = f'select * from area_links_2021_08_17 where status="page_done" and Id > "{self.start}" and Id < "{self.end}"'
        self.cursor1.execute(sql_select_Query)
        links = self.cursor1.fetchall()
        not_link = ['https://www.zomato.com/kochi/','https://www.zomato.com/kozhikode/','https://www.zomato.com/trivandrum/']
        # links = self.Area_links.find({'status': "Done2"}, no_cursor_timeout=True)
        # print(self.Area_links.find({'status': "Done2"}).count())
        for row in links:
            try:
                Id1 = row[1] #row['_id']
                link1 = row[3] #row['Link']
                city = row[2] #row['city']
                path = row[6]#row['path']#.replace('\\\\','\\')
                count = row[4]
                file = open(path, 'r', encoding='utf-8')
                f = file.read()
                file.close()
                response1 = html.fromstring(f)
                links1 = response1.xpath(f'//a[contains(@href,"/{city}/")][1]/@href')
                for link in links1:
                    if f"/{city}/restaurants?" not in link:
                        if link != f"https://www.zomato.com/{city}/restaurants":
                            if 'https://www.zomato.com' not in link:
                                link = 'https://www.zomato.com'+link
                            try:
                                item = ZomatoItem()
                                Link2 = link.replace('/order','')
                                item['Link'] = Link2
                                if item['Link'] not in not_link:
                                    item['count'] = count
                                    item['city'] = city
                                    item['_id'] = int(hashlib.md5(bytes(Link2+link1, "utf8")).hexdigest(), 16) % (10 ** 8)
                                    item['status'] = 'pending'
                                    self.final_links_city.insert(item)
                                    print("Data inserted....")
                            except Exception as e:
                                print(e)
                try:
                    sql_update_Query = f"update area_links_2021_08_17 set status='Done' where Id1='{Id1}'"
                    self.cursor1.execute(sql_update_Query)
                    self.con1.commit()
                    # self.Area_links.update({'_id': Id}, {'$set': {'status': 'Done'}}, upsert=False)
                    print("update done")
                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)


if __name__ == '__main__':

    execute("scrapy crawl final_link -a start=0 -a end=57".split())